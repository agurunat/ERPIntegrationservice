package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class Obj_PostQuote extends AbstractPage {

    public WebElement StartDate() {
        return waitForElementPresent(By.id("C1__QUE_CDAB5AE71362F2141912827"));
    }

    public WebElement YourDetailsNext() {
        return waitForElementPresent(By.xpath("//*[@id='C1__BUT_55E5AE0A984C2873498711']"));
    }

    public WebElement ExemptERM() {
        return waitForElementVisible(By.xpath("//*[@id='radio_C1__QUE_48BDF1EEA3569326393280']/label[2]/span"));
    }

    public WebElement ernHelpText() {
        return waitForElementVisible(By.xpath("//*[@id='C1__p4_QUE_48BDF1EEA3569326384056']/div/div[1]"));
    }


    public WebElement ERMnum() {
        return waitForElementVisible(By.id("C1__QUE_48BDF1EEA3569326384056"));
    }

    public WebElement ELNext() {
        return waitForElementVisible(By.id("C1__BUT_55E5AE0A984C2873500515"));
    }

    public WebElement InterestedPartyNoButton() {
        return waitForElementVisible(By.xpath("//*[@id='radio_C1__QUE_48BDF1EEA3569326406504']/label[2]/span"));
    }

    public WebElement InterestedPartyNext() {
        return waitForElementVisible(By.id("C1__BUT_55E5AE0A984C2873500530"));
    }

    public WebElement ContactsNoButton() {
        return waitForElementVisible(By.xpath("//*[@id='radio_C1__QUE_48BDF1EEA3569326409122']/label[2]/span"));
    }

    public WebElement Contactsnextbutton() {
        return waitForElementPresent(By.id("C1__BUT_55E5AE0A984C2873500535"));
    }

    public WebElement previousLossesNoRadiobutton() {
        return waitForElementVisible(By.xpath("//*[@id='radio_C10__sufferedLosses']/label[2]/span"));
    }

    public WebElement Addloss() {
        return waitForElementVisible(By.id("C10__BUT_88226D8BEA5153C5863424"));
    }

    public WebElement Lossdate() {
        return waitForElementVisible(By.id("C10__QUE_0882CD82D8250E65806877"));
    }

    public WebElement Cause() {
        return waitForElementVisible(By.id("C10__QUE_0882CD82D8250E65806880"));
    }

    public WebElement Lossamt() {
        return waitForElementVisible(By.id("C10__QUE_0882CD82D8250E65806883"));
    }

    public WebElement SettledYesbutton() {
        return waitForElementVisible(By.xpath("//*[@id='radio_C10__QUE_0882CD82D8250E65362625']/label[2]/span"));
    }

    public WebElement AddLossInternal() {
        return waitForElementVisible(By.id("C10__BUT_0882CD82D8250E65872991"));
    }

    public WebElement AddAnotherLoss() {
        return waitForElementVisible(By.id("C10__BUT_784FD54145997E0D837067"));
    }


    public WebElement getQuoteButton() {
        return waitForElementVisible(By.id("C10__BUT_006AB5B0B0C7206C622756"));
    }

    public WebElement ReviewAndConfirm() {
        return waitForElementVisible(By.id("C10__BUT_E8AE1FC2C8F53163909211"));
    }

    public WebElement saveExitButton() {
        return waitForElementPresent(By.id("C10__BUT_D3E81D5ED026892F942222"));
    }

    public WebElement saveExitContact() {
        return waitForElementPresent(By.xpath("//*[@id='C1__BUT_48BDF1EEA3569326413922']"));
    }

    public WebElement saveExitPopUpButtonContact() {
        return waitForElementPresent(By.xpath("//*[@id='BUT_638302E96729F5851483311']"));
    }

    public WebElement saveExitPopupButton() {
        return waitForElementPresent(By.id("UT_B098F5691AD7B0DE560426"));
    }


    public WebElement businessaAddressNoButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C1__QUE_48BDF1EEA3569326351437']/label[2]/span"));
    }

    public WebElement businessaAddressYesButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C1__QUE_48BDF1EEA3569326351437']/label[1]/span"));
    }

    public WebElement InterestedPartyYesButton() {
        return waitForElementVisible(By.xpath("//*[@id='radio_C1__QUE_48BDF1EEA3569326406504']/label[1]/span"));
    }

    public WebElement addInterestedParty() {
        return waitForElementVisible(By.id("C1__BUT_91CF534994373C07998772"));
    }

    public WebElement interestedPartyName() {
        return waitForElementVisible(By.id("C1__QUE_48BDF1EEA3569326406897"));
    }

    public WebElement postCodeTextBox() {
//        return waitForElementPresent(By.id("C1__C1__QUE_CC6AE75C0AD6F1E6924015"));
        return waitForElementPresent(By.id("C1__C3__QUE_CC6AE75C0AD6F1E6924015"));  // CT2
    }

    public WebElement findAddressButton() {
//        return waitForUnstableElement(By.id("C1__C1__BUT_CC6AE75C0AD6F1E6928020"));
        return waitForUnstableElement(By.id("C1__C3__BUT_CC6AE75C0AD6F1E6928020")); //CT2
    }

    public WebElement correspondenceAddressDropdown() {
//        return waitForUnstableElement(By.id("C1__C1__QUE_CC6AE75C0AD6F1E6924030"));
        return waitForUnstableElement(By.id("C1__C3__QUE_CC6AE75C0AD6F1E6924030")); //CT2
    }

    public WebElement natureOfInterestDropDown() {
        return waitForUnstableElement(By.id("C1__QUE_A9C1F13340E65841814338"));
    }

    public WebElement addButtonToSave() {
        return waitForUnstableElement(By.id("C1__BUT_91CF534994373C07999374"));
    }

    public WebElement contactsYesButton() {
        return waitForElementVisible(By.xpath("//*[@id='radio_C1__QUE_48BDF1EEA3569326409122']/label[1]/span"));
    }

    public WebElement addContactButton() {
        return waitForElementVisible(By.id("C1__BUT_1999EF46744176C3526924"));
    }

    public WebElement contactTitle() {
        return waitForElementVisible(By.id("C1__QUE_EFE281AF6E39A131148934"));
    }

    public WebElement contactFirstName() {
        return waitForElementVisible(By.id("C1__QUE_48BDF1EEA3569326410216"));
    }

    public WebElement contactLasttName() {
        return waitForElementVisible(By.id("C1__QUE_EFE281AF6E39A131148922"));
    }

    public WebElement contactRelationship() {
        return waitForElementVisible(By.id("C1__QUE_48BDF1EEA3569326410219"));
    }
    public WebElement addAnotherContactButton(){
        return waitForElementPresent(By.id("C1__BUT_1999EF46744176C3526930"));
    }

    public WebElement addButtonToSaveContact() {
        return waitForElementVisible(By.id("C1__BUT_1999EF46744176C3529282"));
    }

    public WebElement contactNextButton() {
        return waitForElementVisible(By.id("C1__BUT_55E5AE0A984C2873500535"));
    }

    public List<WebElement> contactNextButton1() {
        return findElements(By.id("C1__BUT_55E5AE0A984C2873500535"));
    }

    public WebElement seasonalStockMonth1() {
        return waitForElementVisible(By.id("C1__QUE_48BDF1EEA3569326412782"));
    }

    public WebElement seasonalStockMonth2() {
        return waitForElementVisible(By.id("C1__QUE_48BDF1EEA3569326412785"));
    }

    public WebElement interestedPartyAddAnother() {
        return waitForElementPresent(By.id("C1__BUT_91CF534994373C07997609"));
    }

    public WebElement addpartner() {
        return waitForUnstableElement(By.xpath("//*[@id='C1__BUT_D304421B4A30AE94573230'][contains(text(),'Add partner')]"));
    }

    public WebElement partnerTitle() {
        return waitForUnstableElement(By.id("C1__QUE_48BDF1EEA3569326405358"));
    }

    public WebElement partnerFirstName() {
        return waitForUnstableElement(By.id("C1__QUE_48BDF1EEA3569326405361"));
    }

    public WebElement partnerLastName() {
        return waitForUnstableElement(By.id("C1__QUE_EFE281AF6E39A131169832"));
    }

    public WebElement partnerAddButton() {
        return waitForUnstableElement(By.id("C1__BUT_E9B4CF71BABEB218517288"));
    }

    public WebElement partnerAddAnotherPartnerButton() {
        return waitForElementPresent(By.id("C1__BUT_D304421B4A30AE94573853"));
    }

    public WebElement partnernextButton() {
        return waitForUnstableElement(By.id("C1__BUT_55E5AE0A984C2873500525"));
    }

    public WebElement checkOutButton() {
        return waitForElementPresent(By.id("C1__BUT_48BDF1EEA3569326413916"));
    }

    public WebElement interestedRemove() {
        return waitForElementVisible(By.xpath("//*[@id='C1__BUT_91CF534994373C07997018_R2']"));
    }

    public WebElement contactRemove() {
        return waitForElementVisible(By.xpath("//*[@id='C1__BUT_1999EF46744176C3524574_R2']"));
    }
}
