package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Obj_CognosTaxReport extends AbstractPage {

    public WebElement reportAsAtDate() {
        return waitForElementVisible(By.xpath("(//input[starts-with(@class,'clsSelectDateEditBox')])[1]"));
    }

    public WebElement reportStartDateTextbox() {
        return waitForElementVisible(By.xpath("(//input[starts-with(@class,'clsSelectDateEditBox')])[2]"));
    }

    public WebElement reportEndDateTextbox() {
        return waitForElementVisible(By.xpath("(//input[starts-with(@class,'clsSelectDateEditBox')])[3]"));
    }

}
