package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Obj_Claims extends AbstractPage {

    public WebElement previousLossesYesRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='radio_C11__sufferedLosses']/label[1]/span"));
    }

    public WebElement previousLossesNoRadiobutton() {
        return waitAndFindElement(By.xpath("//*[@id='radio_C11__sufferedLosses']/label[2]/span"));
    }

    public WebElement getQuoteButton() {
        return waitForElementToBeClickableAndReturnElement(By.id("C11__BUT_006AB5B0B0C7206C622756"));
    }

    public WebElement saveExitButton() {
        return waitForUnstableElement(By.id("C11__BUT_D3E81D5ED026892F942222"));
    }

    public WebElement saveExitPopupButton() {
        return waitForUnstableElement(By.id("BUT_B098F5691AD7B0DE560426"));
    }

    public WebElement addALoss() {
        return waitForUnstableElement(By.id("C11__BUT_88226D8BEA5153C5863424"));
    }
    public WebElement addAnotherLoss(){
        return waitForElementPresent(By.xpath("//*[@id='C11__BUT_784FD54145997E0D837067']"));
    }
    public WebElement dateOfLoss() {
        return waitForUnstableElement(By.id("C11__QUE_0882CD82D8250E65806877"));
    }

    public WebElement causeOfLoss() {
        return waitForUnstableElement(By.id("C11__QUE_0882CD82D8250E65806880"));
    }

    public WebElement amountOfloss() {
        return waitForUnstableElement(By.id("C11__QUE_0882CD82D8250E65806883"));
    }

    public WebElement lossStatusOpen() {
        return waitForUnstableElement(By.id("C11__QUE_0882CD82D8250E65362625_0"));
    }

    public WebElement lossStatusSettled() {
        return waitForUnstableElement(By.id("C11__QUE_0882CD82D8250E65362625_1"));
    }

    public WebElement Addloss() {
        return waitForElementVisible(By.id("C11__BUT_88226D8BEA5153C5863424"));
    }

    public WebElement Lossdate() {
        return waitForElementVisible(By.id("C11__QUE_0882CD82D8250E65806877"));
    }

    public WebElement Cause() {
        return waitForElementVisible(By.id("C11__QUE_0882CD82D8250E65806880"));
    }

    public WebElement Lossamt() {
        return waitForElementVisible(By.id("C11__QUE_0882CD82D8250E65806883"));
    }

    public WebElement SettledYesbutton() {
        return waitForElementVisible(By.xpath("//*[@id='radio_C11__QUE_0882CD82D8250E65362625']/label[2]/span"));
    }
    public WebElement SettledNobutton() {
        return waitForElementVisible(By.xpath("//*[@id='radio_C11__QUE_0882CD82D8250E65362625']/label[1]/span"));
    }
    public WebElement AddLossInternal() {
        return waitForElementVisible(By.id("C11__BUT_0882CD82D8250E65872991"));
    }
    public WebElement cancelLoss(){
        return waitForElementPresent(By.id("C11__BUT_88226D8BEA5153C5884375"));

    }
    public WebElement ReviewAndConfirm() {
        return waitForElementVisible(By.xpath("//*[@id='C11__BUT_E8AE1FC2C8F53163909211' or @id='C10__BUT_E8AE1FC2C8F53163909211']"));
    }

    public WebElement SaveAndExit() {
        return waitForElementVisible(By.id("C11__BUT_D3E81D5ED026892F942222"));
    }

    public WebElement SaveAndExitpopup() {
        return waitForElementVisible(By.id("BUT_B098F5691AD7B0DE560426"));
    }
    //
    public WebElement SaveAndExitpopupSS() {
        return waitForElementVisible(By.id("BUT_B098F5691AD7B0DE890877"));
    }

    public WebElement Email() {
        return waitForElementVisible(By.id("QUE_879C6A11B52E18631000835"));
    }

    public WebElement ConfirmEmail() {
        return waitForElementVisible(By.id("QUE_879C6A11B52E18631000853"));
    }

    public WebElement telephone() {
        return waitForElementVisible(By.id("QUE_879C6A11B52E18631000859"));
    }

    public WebElement Exit() {
        return waitForElementVisible(By.id("BUT_879C6A11B52E18633458448"));
    }

    public WebElement changebutton(int i) {
        return waitForElementVisible(By.id("C11__BUT_86E373B37B580C92637682_R" + i));
    }

    public WebElement binbuttonlosspage(int i) {
        return waitForElementVisible(By.id("C11__BUT_86E373B37B580C92637688_R" + i));
    }

    public WebElement validationMessage() {
        return waitForElementPresent(By.xpath("//*[@id='p4_QUE_5EC803E035FC94EC215214_R1']/div"));
    }

    public WebElement promocodeTextBox() {
        return waitForElementToBeClickableAndReturnElement(By.id("C11__QUE_E8AE1FC2C8F53163909178"));
    }

    public WebElement addPromoCodeButton() {
        return waitForElementToBeClickableAndReturnElement(By.id("C11__BUT_E8AE1FC2C8F53163909202"));
    }

    public WebElement addTreatmentCoverLink() {
        return waitForElementToBeClickableAndReturnElement(By.id("C3__BUT_24D9276FBA6E19C58823816"));
    }

    public WebElement addAnothetTreatmentCoverButton() {
        return waitForElementToBeClickableAndReturnElement(By.id("C3__C1__BUT_24D9276FBA6E19C58823780_R1"));
    }

    public WebElement addAnothetTreatmentCoverDropDown() {
        return waitForElementToBeClickableAndReturnElement(By.id("C3__C1__QUE_C8F3E8A0E3C242A2684130"));
    }

    public WebElement addAnothetTreatmentCoverEmpTextbox() {
        return waitForElementToBeClickableAndReturnElement(By.id("C3__C1__QUE_C8F3E8A0E3C242A2684143"));
    }

    public WebElement addAnothetTreatmentButton() {
        return waitForElementToBeClickableAndReturnElement(By.id("C3__C1__BUT_C8F3E8A0E3C242A2684188"));
    }


    public WebElement qualificationYesButton() {
        return waitForElementToBeClickableAndReturnElement(By.id("C3__C1__BUT_C8F3E8A0E3C242A2684188"));
    }

    public WebElement addToQuoteButton() {
        return waitForElementToBeClickableAndReturnElement(By.id("C3__C1__BUT_24D9276FBA6E19C58823792"));
    }

    public WebElement changebutton() {
        return waitForElementVisible(By.id("C11__BUT_86E373B37B580C92637682_R1"));
    }

    public WebElement updateLossButton() {
        return waitForUnstableElement(By.id("C11__BUT_82E592530552AB4D341759"));
    }

    public WebElement saveAndExitButtonQuoteSummary() {
        return waitForElementPresent(By.id("C11__BUT_E8AE1FC2C8F53163909220"));
    }

    public WebElement changeLoss() {
        return waitForElementPresent(By.id("C11__BUT_86E373B37B580C92637682_R1"));
    }
}

