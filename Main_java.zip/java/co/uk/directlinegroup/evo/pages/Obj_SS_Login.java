package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import net.serenitybdd.core.annotations.findby.By;
import org.openqa.selenium.WebElement;

public class Obj_SS_Login extends AbstractPage {

    public WebElement signInButton() {
        return waitForElementPresent(By.id("BUT_E14D31D21EBB8E7F24944"));
    }

    public boolean ccPageLoading() {
        return waitForElementInVisible(By.xpath("html/body/div[1]"));
    }


    public void ccPageLoad() {
        waitForElementEnabled(By.xpath("html/body/div[1]"));
    }

    public WebElement usernameTextbox() {
        return waitForElementPresent(By.id("email_address"));
    }

    public WebElement passwordTextbox() {
        return waitForElementPresent(By.id("password"));
    }

    public WebElement emailSignInButton() {
        return waitForUnstableElement(By.id("sign_in"));
    }

    public WebElement newQuoteButton() {
        return waitForUnstableElement(By.id("BUT_DB4A6646C4C5D63933681"));
    }

    public WebElement emailAddressTextbox() {
        return waitForElementPresent(By.xpath("//input[@type='text'][@id='QUE_3D8461446F669061149913']"));
    }

    public WebElement newPasswordTextbox() {
        return waitForElementVisible(By.id("QUE_0B7C43580EA64B0B87286"));
    }

    public WebElement confirmPasswordTextbox() {
        return waitForElementVisible(By.id("QUE_0B7C43580EA64B0B87294"));
    }

    public WebElement welcomeUserLink() {
        return waitForElementVisible(By.xpath("//*[@id='ITM_B2C721F075FCE394207808']/a"));
    }

    public WebElement welcomeUserLinkHideButton() {
        return waitForElementVisible(By.xpath("//*[@id='TXT_3D8461446F669061149234']/div/button"));
    }

    public WebElement signOutLink() {
        return waitForElementVisible(By.id("ITM_B2C721F075FCE394207820"));
    }

    public WebElement continueQuote() {
        return waitForElementPresent(By.xpath("//*[@id='BUT_B3A80BADFCD28CFD90816_R1']"));
    }

    public WebElement premiumSSDisplay() {
        return waitForElementVisible(By.xpath("//*[@id='FMT_7F8F110B7A232E78358483_R1']/h4/a/div[5]"));
    }

    public WebElement amendErrorMsg() {
        return waitForElementVisible(By.xpath("//*[@id='p4_QUE_B9F9034988F6AFFA2047640_R1']/div"));
    }

}