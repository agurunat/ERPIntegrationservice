package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class Obj_CC_Search extends AbstractPage {

    public WebElement policyNumberTextbox() {
        return waitForUnstableElement(By.id("C2__QUE_57179A1244E6618013741"));
    }

    public WebElement searchButton() {
        return waitForUnstableElement(By.id("C2__BUT_57179A1244E6618013765"));
    }

    public WebElement policySelectionLink() {
        return waitForUnstableElement(By.id("C2__p0_TBL_9C3BD3DB194DC120259818_R1"));
    }

    public WebElement authorizContanctselectionLink() {
        return waitForUnstableElement(By.id("C2__p4_QUE_5D046CA9B13A360C790791_R1"));
    }

    public WebElement verifyButton() {
        return waitForUnstableElement(By.xpath("//a[starts-with(@id, 'btnvfy-')][@class='btn btn-default pull-right custom-hide btn-verify']"));
    }

    public WebElement passedVerificaitionButton() {
        return waitForUnstableElement(By.id("C2__BUT_9252AAA206FD524963824"));
    }
    public WebElement retrievePolicyNumberAfterQuote() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__C6__p4_QUE_24F4D09ABF5D5E60315856']/div/div"));
    }
    public WebElement documentsLinkclick() {
        return waitForUnstableElement(By.xpath("//*[@id='Documents']"));
    }

    public List<WebElement> tableRow() {
        return findElements(By.xpath("//table[@id='C2__C6__TBL_BD388A52554BC5E72766684']/tbody/tr/td[1]"));
    }

    public List<WebElement> tableColumn() {
        return findElements(By.xpath("//table[@id='C2__C6__TBL_BD388A52554BC5E72766684']/tbody/tr/td[1]"));
    }

    public WebElement logInhereButton() {
        return waitForUnstableElement(By.xpath("//a[contains(text(),'Log in here')]"));
    }

    public void ccPageLoad() throws Throwable {
        waitForElementEnabled(By.xpath("html/body/div[1]"));
    }

    public WebElement ccSearchFirstName() {
        return waitForElementPresent(By.xpath("//*[@id='C2__QUE_57179A1244E6618013759']"));
    }

    public WebElement ccSearchLastName() {
        return waitForElementPresent(By.xpath("//*[@id='C2__QUE_57179A1244E6618013753']"));
    }

    public WebElement ManagequoteButton() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__C6__TXT_C1866409B7CE50882281927']/div/div/ul/li[3]/a"));
    }

    public WebElement editButton() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__C6__TXT_C1866409B7CE50882281927']/div/div/ul/li[3]/ul/li/a"));
    }

    public WebElement cancelPolicyButton() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__TXT_C1866409B7CE50882210760']/div/div/ul/li[5]/a"));
    }

    public WebElement StandardcancelButton() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__TXT_C1866409B7CE50882210760']/div/div/ul/li[5]/ul/li/a"));
    }
    public WebElement coolingCancelButton() {
    return waitForElementPresent(By.xpath("//*[@id='C2__C6__TXT_C1866409B7CE50882210760']/div/div/ul/li[5]/ul/li[2]/a"));
    }

    public WebElement EffectivedateTextBox() {
        return waitForElementPresent(By.xpath("//*[@id='date-picker-C2__C6__QUE_8D734F2AC91F8FEB325795']"));
    }

    public WebElement ReasonDropdown() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__QUE_99ADFDA008E513D23696576']"));
    }

    public WebElement ReturnTypeDropdown() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__QUE_99ADFDA008E513D23844242']"));
    }

    public WebElement CalculateButton() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__BUT_99ADFDA008E513D23696578']"));
    }

    public WebElement WaiveFeeButton() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__QUE_99ADFDA008E513D23898124_0']"));
    }

    public WebElement ConfirmButton() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__BUT_99ADFDA008E513D23844180']"));
    }

    public WebElement CancelledStatus() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__TXT_E27EEAA35FDE73D3218642']/div/h4/div[2]"));
    }

    public WebElement FinanceLink() {
        return waitForElementPresent(By.xpath("//*[@id='finance']"));
    }

    public WebElement OutstandingAmount() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__p4_QUE_89ED8F82775D82BB1163895']"));
    }

    public WebElement claimsButton() {
        return waitForElementPresent(By.xpath("//*[@id='view-claims-id']"));
    }

    public WebElement viewClaimsButton() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__TXT_C1866409B7CE50882210760']/div/div/ul/li[7]/ul/li/a"));
    }

    public WebElement outstandingCheckbox() {
        return waitForElementPresent(By.xpath("//*[@id='Outstanding']"));
    }

    public WebElement firstNameTextBox() {
        return waitForElementPresent(By.xpath("//*[@id='C2__QUE_57179A1244E6618013759']"));
    }

    public WebElement lastNameTextBox() {
        return waitForElementPresent(By.xpath("//*[@id='C2__QUE_57179A1244E6618013753']"));
    }

    public WebElement postcodeTextBox() {
        return waitForElementPresent(By.xpath("//*[@id='C2__QUE_57179A1244E6618019335']"));
    }

    public WebElement completeButton() {
        return waitForElementPresent(By.xpath("//*[@id='C2__BUT_A5571F6A30C4735F1601285']"));
    }

    public WebElement addNoteButton() {
        return waitForElementPresent(By.xpath("//*[@id='opener']"));
    }

    public WebElement titleTextBox() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__QUE_6626AE11CA31B27E731132']"));
    }

    public WebElement noteDescriptionTextBox() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__QUE_6626AE11CA31B27E731135']"));
    }

    public WebElement saveNoteButton() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__BUT_6626AE11CA31B27E731273']"));
    }

    public WebElement noteTable() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C5__FMT_F9F4E5F2E56482CB72934_R1']"));
    }

    public WebElement viewNotesTab() {
        return waitForElementPresent(By.xpath("//*[@id='accordian_collapseNine']"));
    }
    public WebElement createDocumentButton() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__BUT_BD388A52554BC5E73737858']"));
    }

    public WebElement declineAfterReferral() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__BUT_B332DA728E9A523B242985_R4']"));
    }

    public WebElement manageAuthorizedContact() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C1__BUT_5D046CA9B13A360C900257']"));
    }
    public WebElement manageAuthorizedContactEdit() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C1__BUT_753975C04A0241C1630778']"));
    }
    public WebElement manageAuthorizedContactEmail() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C1__TXT_753975C04A0241C1630446']/div/ul/li[2]/a"));
    }

    public WebElement manageAuthorizedContactEmailEdit() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C1__QUE_753975C04A0241C1630696']"));
    }
    public WebElement manageAuthorizedContactEditSave() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C1__BUT_753975C04A0241C1630702']"));
    }
    public WebElement manageAuthorizedContactEditClose() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C1__BUT_753975C04A0241C1633500']"));
    }
    public WebElement ccSearchBusinessName() {
    return waitForUnstableElement(By.id("C2__QUE_3EEBD499DACB35483315854"));
    }
    public WebElement cctotalPremiumText() {
    return waitForElementPresent(By.xpath("//*[@id='C2__C6__p4_QUE_24F4D09ABF5D5E60316278']/div/div"));
    }
}
