package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class Obj_Generalinformation extends AbstractPage {

    public WebElement anythingElseYesRadiobutton() {
        return waitForElementToBeClickableAndReturnElement(By.xpath("//*[@id='radio_C1__anythingElse']/label[1]/span"));
    }

    public WebElement anythingElseNoRadiobutton() {
        return waitForElementToBeClickableAndReturnElement(By.xpath("//*[@id='radio_C1__anythingElse']/label[2]/span"));
        //*[@id="radio_C1__anythingElse"]/label[2]/span
    }

    public WebElement otherTradeTextbox() {
        return waitForElementToBeClickableAndReturnElement(By.id("auto-C1__QUE_FAE554C988A5F3933048"));
    }
    public WebElement otherTradeSelect(String text){
        return waitForElementPresent(By.xpath("//*/strong[contains(text(),'"+text+"')]"));
    }

    public WebElement businessNameTextbox() {
        return waitForUnstableElement(By.id("C1__businessName"));
    }

    public WebElement titleDropdown() {
        return waitForUnstableElement(By.id("C1__QUE_8AE91352B238E1201662652"));
    }

    public WebElement firstNameTextbox() {
        return waitForUnstableElement(By.id("C1__QUE_8AE91352B238E1201662661"));
    }

    public WebElement lastNameTextbox() {
        return waitForUnstableElement(By.id("C1__QUE_8AE91352B238E1201662670"));
    }

    public WebElement businessTypeDropdown() {
        return waitForUnstableElement(By.id("C1__QUE_9BFD06CAFB494FB61947"));
    }

    public WebElement subsidiariesYesRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='radio_C1__QUE_9E87048F6CFBCA01515980']/label[1]/span"));
    }

    public WebElement subsidiariesNoRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='radio_C1__QUE_9E87048F6CFBCA01515980']/label[2]/span"));
    }

    public WebElement businessTradeDropdown() {
        return waitForUnstableElement(By.id("C1__QUE_FAE554C988A5F3933901"));
    }

    public WebElement postcodeTextbox() {
        return waitForUnstableElement(By.id("C1__C1__QUE_CC6AE75C0AD6F1E6924015"));
    }

    public WebElement findAddressButton() {
        return waitForUnstableElement(By.id("C1__C1__BUT_CC6AE75C0AD6F1E6928020"));
    }

    public WebElement correspondenceAddressDropdown() {
        return waitForUnstableElement(By.xpath("//*[@id='C1__C1__QUE_CC6AE75C0AD6F1E6924030']"));
    }
    public WebElement enterAddressButton() {
        return waitForUnstableElement(By.id("C1__C1__BUT_CC6AE75C0AD6F1E6928035"));
    }
    public WebElement firstLineAddress() {
        return waitForUnstableElement(By.id("C1__C1__QUE_CC6AE75C0AD6F1E6924034"));
    }

    public WebElement secondLineAddress() {
        return waitForUnstableElement(By.id("C1__C1__QUE_CC6AE75C0AD6F1E6924038"));
    }
    public WebElement addressTown() {
        return waitForUnstableElement(By.id("C1__C1__QUE_CC6AE75C0AD6F1E6924042"));
    }
    public WebElement addressCounty() {
        return waitForUnstableElement(By.id("C1__C1__QUE_4DACBD9E1710D5B23827637"));
    }
    public WebElement addressCountry() {
        return waitForUnstableElement(By.id("C1__C1__QUE_CC6AE75C0AD6F1E6924045"));
    }
    public WebElement anyThingElseRadioButton(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C1__DIRECTLINE[1].YOURBUSINESS[1].GENERALINFORMATION[1].ANYTHINGELSE'][value=" + value + "]";
        return waitForUnstableElement(By.cssSelector(cssSelector));
    }

    public WebElement subsidiariesRadiobutton(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C1__DIRECTLINE[1].YOURBUSINESS[1].GENERALINFORMATION[1].ISSUBSIDARIES'][value=" + value + "]";
        return waitForUnstableElement(By.cssSelector(cssSelector));
    }


    public WebElement businessWorkLocDropdown() {
        return waitForUnstableElement(By.id("C1__work"));
    }

    public WebElement nextButton() {
        return waitForUnstableElement(By.id("C1__BUT_391E4BE220C07767120915"));
    }

    public WebElement manualWork(String option) {
        return waitForUnstableElement(By.xpath("//div[@id='radio_C1__QUE_DD25ED487B167FA01287572']/label/span[text()='" + option + "']"));
    }

    public boolean pageLoading() {
        return waitForElementInVisible(By.xpath("//*[@id='TXT_FAE554C988A5F3932837']/div/div[2]/div"));
    }

    public boolean ccpageLoading() {
        return waitForElementInVisible(By.className("xs-msg-block-active-bg spinning-on-load-bg-table-active"));


    }



    public List<WebElement> businessWorkLoc1Dropdown() {
        return findElements(By.id("C1__work"));
    }

    public WebElement businessFromCheckbox(String choice) {
        String id = "C1__QUE_FAE554C988A5F3934165_" + (Integer.parseInt(choice) - 1);
        return waitForUnstableElement(By.id(id));
    }

    public WebElement mobileDropdown() {
        return waitForUnstableElement(By.id("C1__QUE_FAE554C988A5F3934165_2"));
    }

    public WebElement rentDropdown() {
        return waitForUnstableElement(By.id("C1__QUE_FAE554C988A5F3934165_0"));
    }

    public WebElement salonDropdown() {
        return waitForUnstableElement(By.id("C1__QUE_FAE554C988A5F3934165_1"));
    }

    public WebElement WFHDropdown() {
        return waitForUnstableElement(By.id("C1__QUE_FAE554C988A5F3934165_3"));
    }

    public WebElement changeTrade() {
        return waitForUnstableElement(By.xpath("//*[@id='C1__BUT_FAE554C988A5F3933135_R1']/span"));
    }

    public WebElement changeTradeQuestion() {
        return waitForUnstableElement(By.xpath("//*[@id='C1__p1_QUE_2B7DF87E3EF81F6A3815_R1']/div/label"));
    }

    public WebElement anythingElseTradeQuestion() {
        return waitForUnstableElement(By.xpath("//*[@id='C1__p1_anythingElse']/div/label"));
    }

    public WebElement tradeNameTextbox() {
        return waitForUnstableElement(By.xpath("//*[@id='auto-C1__QUE_FAE554C988A5F3933048']"));
    }

    public WebElement addTradeNameSelect() {
        return waitForUnstableElement(By.xpath("/html/body/div[12]/div"));
    }

    public WebElement tradeQuestionValidation() {
        return waitForUnstableElement(By.xpath("//*[@id='C1__p1_anythingElse']/div/label"));
    }

    public WebElement businessTradeTextBox() {
        return waitForUnstableElement(By.id("auto-C1__QUE_2B7DF87E3EF81F6A3815_R1"));
    }

    public WebElement tradeDropdownListValidation() {
        return waitForUnstableElement(By.xpath("/html/body/div[8]/div[1]"));
    }

    public WebElement tradeDropdownListValue() {
        return waitAndFindElement(By.xpath("//*[@id='C1__QUE_FAE554C988A5F3933901']"));
    }

    public WebElement runBusinesssLbl() {
        return waitForUnstableElement(By.xpath("//*[@id='C1__p1_QUE_FAE554C988A5F3934165']/div/label"));
    }

    public List<WebElement> autoCompleteList() {
        return findElements(By.xpath("//div[@class='autocomplete-suggestion']"));
    }

    public WebElement autoCompleteTrade(String tradename) {
        return findElement(By.xpath("//div[@class='autocomplete-suggestion']/strong[text() = '" + tradename + "']"));
    }//div[@class='autocomplete-suggestion']/strong[text() = 'Antique']

    public WebElement addMultipleTradeNameSelect(String text) {
        String xpath = "//div[@class='autocomplete-suggestion']//strong[contains(text(),'" + text + "')]";
        return waitForElementPresent(By.xpath(xpath));
    }

    public WebElement multiTradeAutocompleteList(String trade) {
        return waitForUnstableElement(By.xpath("//div[@class='autocomplete-suggestion']//strong[contains(text(),'" + trade + "')]"));
    }

    public List<WebElement> multiTradeAutocompleteCount(String trade) {
        return findElements(By.xpath("//div[@class='autocomplete-suggestion']//strong[contains(text(),'" + trade + "')]"));
    }

    public WebElement tanningSalonErrorMsg() {
        return waitForUnstableElement(By.xpath("//*[@id='C1__TXT_F76B852D008C47DE542177']/div/label"));
    }

    public WebElement workOutsideUKYnN(String YorN) {
        String value = "2";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "1";
        }
        String cssSelector = "input[name='C1__DIRECTLINE[1].YOURBUSINESS[1].GENERALINFORMATION[1].WORKINGOUTSIDE'][value='" + value + "']";
        return waitForUnstableElement(By.cssSelector(cssSelector));
    }

    public WebElement tradeSelectGI(String text, int i) {
        return waitForElementPresent(By.xpath("/html/body/div[7]/div[contains(text(),'" + text + "')][" + i + "]"));
    }

    public WebElement validationMsgSuspend() {
        return waitForUnstableElement(By.xpath("//*[@id='p4_QUE_818CB4BDAC15FD54572934_R1']/div"));
    }

    public WebElement giTurnOverDropDown() {
        return waitAndFindElement(By.id("C1__GIestimatedGrossTurnover"));
    }

    public WebElement giLastTurnOverDropDown() {
        return waitAndFindElement(By.id("C1__QUE_FAE2C80F8620D249934888"));
    }

    public WebElement giTurnOverValue() {
        return waitAndFindElement(By.id("C1__QUE_FAE2C80F8620D249934893"));
    }

    public WebElement giErrorMessage() {
        return waitAndFindElement(By.xpath("//table[@class='validation-message']/tbody/tr[2]/td/div"));
    }

    public WebElement lastYearTurnOverHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C1__p4_QUE_FAE2C80F8620D249934888']/div/div[1]/div"));
    }

    public WebElement giNextYearTurnOverQuestionText() {
        return waitAndFindElement(By.xpath("//*[@id=\"C1__p1_GIestimatedGrossTurnover\"]/div/label"));
    }

    public WebElement giNextYearTurnOverHelpText() {
        return waitAndFindElement(By.xpath("//*[@id=\"C1__p4_GIestimatedGrossTurnover\"]/div/div[1]"));
    }

    public WebElement giNextTurnOverDropDown() {
        return waitAndFindElement(By.id("C1__GIestimatedGrossTurnover"));
    }

    public WebElement giTurnOverValueNext() {
        return waitAndFindElement(By.id("C1__QUE_006AB5B0B0C7206C622685"));
    }


    public WebElement giEdit() {
        return waitAndFindElement(By.id("step-0"));
    }

    public WebElement giPlsTellUsText() {
        return waitAndFindElement(By.xpath("//*[@id=\"C1__p1_QUE_006AB5B0B0C7206C622685\"]/div/label"));
    }

    public WebElement giErrorMsgGreaterThan1Mill() {
        return waitAndFindElement(By.xpath("//*[@id=\"p4_QUE_818CB4BDAC15FD54572934_R1\"]/div"));
    }

    public WebElement giErrorMsgDecimal() {
        return waitAndFindElement(By.xpath("//*[@id=\"C1__QUE_006AB5B0B0C7206C622685_ERRORMESSAGE\"]"));
    }


    public List<WebElement> sellProductValidation() {
        return findElements(By.id("checkbox_C1__QUE_41093D85235199A6949123"));
    }

    public List<WebElement> runBusinessCheckBoxes() {
        return findElements(By.id("checkbox_C1__QUE_FAE554C988A5F3934165"));
    }

    public WebElement runBusinessCheckBox() {
        return waitForElementVisible(By.id("checkbox_C1__QUE_FAE554C988A5F3934165"));
    }

    public WebElement runBusinessCheck(String business) {
        return waitForElementPresent(By.xpath("//label/p/span[text()='" + business + "']/../.."));
    }

    public WebElement runBusinessCheckInput(String idValue) {
        return waitForElementPresent(By.xpath("//input[@id='" + idValue + "']"));
    }

    public WebElement gideclineMessage() {
        return waitAndFindElement(By.xpath("//*[@id='C1__TXT_41093D85235199A6976431']/div/label"));
    }

    public WebElement sellProductRunBusinessCoverOPRMobileFood() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C1__QUE_41093D85235199A6949123']/label[8]"));
    }

    public WebElement sellProductRunBusinessCoverOPRshop() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C1__QUE_41093D85235199A6949123']/label[1]"));
    }

    public WebElement sellProductRunBusinessCoverOPROnline() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C1__QUE_41093D85235199A6949123']/label[2]"));
    }

    public List<WebElement> manualWorkQuestion() {
        return findElements(By.xpath("//*[@id='C1__p1_QUE_DD25ED487B167FA01287572']/div/label"));
    }

    public List<WebElement> manualWorkQuestionHT() {
        return findElements(By.xpath("//*[@id='C1__p4_QUE_DD25ED487B167FA01287572']/div/div[1]/div"));
    }


    public List<WebElement> staticTextForITConsult() {
        return findElements(By.xpath("//*[@id='C1__p1_HEAD_DD25ED487B167FA01884097']/div"));
    }

    public List<WebElement> staticTextForEstateProperty() {
        return findElements(By.xpath("//*[@id='C1__p1_HEAD_DD25ED487B167FA01884122']/div"));
    }

    public List<WebElement> staticTextForWindowDresser() {
        return findElements(By.xpath("//*[@id='C1__p1_HEAD_DD25ED487B167FA01884130']/div"));
    }

    public WebElement runYourBusinessErrorMessage() {
        return waitForElementPresent(By.id("C1__QUE_FAE554C988A5F3934165_ERRORMESSAGE"));
    }

    public WebElement changeTradeDeclineMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C1__TXT_43DCC4A7EBA0A286613073_R1']/div/label"));
    }

    public WebElement selectTradeAutoPopulate() {
        return waitForElementPresent(By.xpath("//*[@class='autocomplete-suggestion']/strong"));
    }
    public WebElement twelveMonthPolicy(String option) {
        return waitForElementPresent(By.xpath("//label[starts-with(@for,'C1__QUE_FAE554C988A5F3934171_')]/span[text()='" + option + "']"));
    }
}