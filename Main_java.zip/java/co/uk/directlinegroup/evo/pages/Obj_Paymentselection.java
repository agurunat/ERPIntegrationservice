package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Obj_Paymentselection extends AbstractPage {

    public WebElement monthlyLink() {
        return waitForUnstableElement(By.id("C1__BUT_9615B35FDA83C0DA3957"));
    }

    public WebElement annualLink() {
        return waitForUnstableElement(By.id("C1__BUT_9615B35FDA83C0DA3963"));
    }

    public WebElement acceptRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='C1__p4_QUE_9615B35FDA83C0DA3719']/div/div/label"));
    }

    public WebElement renewRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='checkbox_C1__QUE_F57AEB931671912F1007492']/label"));
    }

    public WebElement understoodRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='C1__p4_QUE_9615B35FDA83C0DA3836']/div/div/label"));
    }

    public WebElement paymentScreenNextButton() {
        return waitForUnstableElement(By.id("C1__BUT_CA5B92658FB254951983"));
    }

    public WebElement paymentScreenBackButton() {
        return waitForUnstableElement(By.id("C1__BUT_E6ED2431D424349D546418"));
    }

    public WebElement paymentScreenBackButtonInPaymentCardPage() {
        return waitForUnstableElement(By.xpath("//*[@id='C1__BUT_E6ED2431D424349D546430']"));
    }
    public WebElement pdfQuoteSummaryLink(){
        return waitForElementPresent(By.xpath("//*[@id='C1__BUT_55C0F64C2CF02EE43250']"));
    }
    public WebElement pdfKeyFactsLink(){
        return waitForElementPresent(By.xpath("//*[@id='C1__BUT_55C0F64C2CF02EE43380']"));
    }
    public WebElement pdfSOFLink(){
        return waitForElementPresent(By.xpath("//*[@id='C1__BUT_55C0F64C2CF02EE43397']"));
    }
    public WebElement pdfPolicyWordingLink(){
        return waitForElementPresent(By.xpath("//*[@id='C1__BUT_55C0F64C2CF02EE43423']"));
    }
    public WebElement pdfSaveIcon(){
        return waitForElementPresent(By.xpath("//*[@id='download']"));
    }
}