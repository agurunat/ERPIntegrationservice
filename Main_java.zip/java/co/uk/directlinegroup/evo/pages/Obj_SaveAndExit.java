package co.uk.directlinegroup.evo.pages;

/**
 * Created by 445607 on 05/08/2017.
 */

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Obj_SaveAndExit extends AbstractPage {

    public WebElement saveAndExitButtonTreatment() {
        return waitForElementPresent(By.id("C4__BUT_D3E81D5ED026892F3306326"));
    }

    public WebElement saveAndExitButtonPremises() {
        return waitForElementPresent(By.id("C5__BUT_C1993409252658783074906"));
    }

    public WebElement saveAndExitButtonPropertyAway() {
        return waitForElementPresent(By.id("C6__BUT_D3E81D5ED026892F3306326"));
    }

    public WebElement saveAndExitButtonImportantStatements() {
        return waitForElementPresent(By.id("C2__BUT_D3E81D5ED026892F942222"));
    }

    public WebElement saveAndExitPopup() //This can be used to all screens except claims screen
    {
        return waitForElementPresent(By.id("BUT_8213FC3835F9DD291056861"));
    }

    public WebElement saveAndExitPopupPeople() {
        return waitForElementPresent(By.xpath("//div[@id='p4_BUT_D3E81D5ED026892F1577152']/div/button"));
    }

    public WebElement saveAndExitEmail() {
        return waitForElementPresent(By.id("QUE_879C6A11B52E18631000835"));
    }

    public WebElement saveAndExitConfirm() {
        return waitForElementPresent(By.id("QUE_879C6A11B52E18631000853"));
    }

    public WebElement saveAndExitMobile() {
        return waitForElementPresent(By.id("QUE_879C6A11B52E18631000859"));
    }

    public WebElement saveAndExitSMS() {
        return waitForElementPresent(By.xpath("//*[@id='p4_QUE_0367DC985D0386EC3421021']/div/div/label/p/span"));
    }

    public WebElement saveAndExitMarketingEmail() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_saveQuoteMarketingPreferences']/label[1]/p/span"));
    }

    public WebElement saveAndExitMarketingText() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_saveQuoteMarketingPreferences']/label[2]/p/span"));
    }

    public WebElement saveAndExitMarketingPhone() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_saveQuoteMarketingPreferences']/label[3]/p/span"));
    }

    public WebElement saveAndExit() {
        return waitForElementPresent(By.xpath("BUT_879C6A11B52E18633458448"));
    }

    public WebElement saveAndExitButtonQuoteSummary() //No popup
    {
        return waitForElementPresent(By.xpath("C10__BUT_E8AE1FC2C8F53163909220"));
    }

    public WebElement saveAndExitButtonPostQuote() {
        return waitForElementPresent(By.xpath("C1__BUT_48BDF1EEA3569326413922"));
    }

    public WebElement saveAndExitPopupPostQuote() {
        return waitForElementPresent(By.xpath("C1__BUT_48BDF1EEA3569326348890"));
    }

    public WebElement saveAndExitButtonQSCC() {
        return waitForElementPresent(By.id("C10__BUT_E8AE1FC2C8F53163909220"));
    }

    public WebElement saveAndExitPopupPostQuoteSS() {
        return waitForElementPresent(By.id("BUT_638302E96729F5851483305"));
    }
}
