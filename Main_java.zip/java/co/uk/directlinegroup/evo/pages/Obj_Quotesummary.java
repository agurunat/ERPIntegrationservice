package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class Obj_Quotesummary extends AbstractPage {

    public WebElement reviewConfirmButton() {
        return waitForUnstableElement(By.id("C11__BUT_E8AE1FC2C8F53163909211"));
    }

    public WebElement referalTextMessage() {
        return waitForUnstableElement(By.xpath("//*[@id='C1__p1_HEAD_2913A5FDBA5243B92097405']/div"));
    }

    public WebElement reasonDropdown() {
        return waitForUnstableElement(By.id("C1__QUE_2913A5FDBA5243B93315273"));
    }

    public String reasonDropdownLable() {
        return "//*[@id='C1__p1_QUE_2913A5FDBA5243B93315273']/div/label";
    }

    public WebElement declineMsg() {
        return waitForUnstableElement(By.xpath("//*[@id='C1__TXT_2913A5FDBA5243B93297212']/div/strong"));
    }

    public WebElement declineMsgText() {
        return waitForUnstableElement(By.xpath("//*[@id='C1__TXT_A42EF8B1E21F4D5C944115']/div/div"));
    }

    public WebElement referralMsgText() {
        return waitForUnstableElement(By.xpath("//*[@id='C1__TXT_2913A5FDBA5243B92127419']/div"));
    }

    public WebElement referalTextMessage1() {
        return waitForUnstableElement(By.xpath("//div[contains(@id,'EDGE_CONNECT_PHASE')]//div[contains(@id,'row_HEAD')]/div[contains(@id,'HEAD')]"));
    }

    public List<WebElement> premiseTab() {
        return findElements(By.xpath("//*[@id='premisesOne']"));
    }

    public List<WebElement> premiseTabCC() {
        return findElements(By.xpath("//*[@id='premisesOne']/div"));
    }
    public List<WebElement> coverYouHaveChosenPage() {
        return findElements(By.xpath("//*[@id='FMT_995CED09B52AA6741824']"));
    }
    public WebElement coverYouHaveChosen() {
        return waitForUnstableElement(By.xpath("//*[@id='FMT_995CED09B52AA6741824']"));
    }

    public List<WebElement> binIcon() {
        return findElements(By.xpath("//div[contains(@id,'C8__p4_BUT_1EED2E0882C2655C536243_R')]/div/button/img"));
    }

    public WebElement removeBinYesButton() {
        return waitAndFindElement(By.xpath("//*[@id='C8__BUT_D175D5C43A7D6F933376526']"));
    }

    public WebElement contentBinButton() {
        return waitForUnstableElement(By.xpath("//*[@id='C8__BUT_24D9276FBA6E19C58823923_R1_1']/span"));
    }

    public WebElement stockBinButton() {
        return waitForUnstableElement(By.xpath("//*[@id='C8__BUT_24D9276FBA6E19C58823923_R1_2']/span"));
    }

    public WebElement premiseTabOne() {
        return findElement(By.id("premisesOne"));
    }

    public WebElement winesAndSpiritBinButton() {
        return waitForElementPresent(By.xpath("//*[@id='C8__BUT_24D9276FBA6E19C58823923_R1_2']/span"));
    }

    public WebElement excludeWineSpiritCovers() {
        return waitForElementPresent(By.xpath("//*[@id='C8__QUE_6D42360776E850EB937176_R1_1']/p"));
    }

    public WebElement wineSpiritCovers() {
        return waitForElementPresent(By.xpath("//*[@id='C8__QUE_6D42360776E850EB937176_R1_2']/p"));
    }

    public List<WebElement> building1Heading() {
        return findElements(By.xpath("//*[@id='C8__TXT_8FDE91C8A8110C6D481663_R1']/div/b"));
    }

    public WebElement legalExpencesDropdown() {
        return waitForUnstableElement(By.id("C7__QUE_965BD2C07905F7002825072"));
    }

    public List<WebElement> building2Heading() {
        return findElements(By.xpath("//*[@id='C8__TXT_A9160300062AFE9E913227_R1']/div/b"));
    }

    public WebElement legalExpencesaddButton() {
        return waitForUnstableElement(By.id("C7__BUT_965BD2C07905F7003521888"));
    }

    public WebElement totalPremiumText() {
        return waitForUnstableElement(By.id("C11__TXT_E2827522B56174171472276"));
    }

    public List<WebElement> PolicyLevelCoverVerification() {
        return findElements(By.xpath("//*[@id='step-1']"));
    }

     public List<WebElement> referralText() {
        return findElements(By.xpath("//*[@id='C1__p1_HEAD_2913A5FDBA5243B92097405']/div"));
    }

    public WebElement PremiseShowArrow() {
        return waitForElementVisible(By.xpath("//*[@id='premisesOne']"));
    }

    public WebElement PremiseCoverValidation() {
        return waitForElementPresent(By.id("C8__p4_QUE_6D42360776E850EB937176_R1_1"));
    }

    public WebElement buildingCoverHelpText() {
        return findElement(By.id("//*[@id='C8__p4_QUE_6D42360776E850EB937176_R1_1']/div/div[1]/div"));
    }

    public List<WebElement> OtherPoliciesLabel() {
        return findElements(By.xpath(" //*[@id='C10__FMT_E2827522B5617417656279']"));
    }

    public List<WebElement> MoreOptionsCover() {
        return findElements(By.xpath(" //*[@id='more-options-row']"));
    }

    public List<WebElement> AddCoverLink() {
        return findElements(By.xpath("//*[@id='C7__BUT_965BD2C07905F7003521888']/span"));
    }

    public WebElement addPremise() {
        return waitForElementVisible(By.xpath("//*[@id='C8__BUT_C4055BF703BD21D9547347']"));
    }

    public WebElement SaveAndExit() {
        return waitForElementPresent(By.id("C10__BUT_E8AE1FC2C8F53163909220"));
    }

    public List<WebElement> professionalLiabilitypolicyLevelCovers(String cover) {
        return findElements(By.xpath("(//p[contains(text(),'"+cover+"')]/../../../../../../../..)"));
    }

    public WebElement professionalLiabilityLimitDrpDown() {
        return waitForElementPresent(By.id("C5__QUE_0D396F41AB6AB8C2504415"));
    }

    public WebElement professionalLiabilityPremium() {
        return waitForElementPresent(By.id("C5__p4_QUE_965BD2C07905F7002825076"));
    }
    public WebElement publicLiabilityDropDown() {
        return waitForElementPresent(By.id("C1__QUE_965BD2C07905F7002825072"));
    }

    public WebElement fixturesCoverQS() {
        return waitForElementPresent(By.xpath("//*[@id='C8__QUE_6D42360776E850EB937176_R1_2']/p"));
    }

    public WebElement viewTreatmentsLink() {
        return waitForElementToBeClickableAndReturnElement(By.xpath("//button[contains(text(),'View the treatments you’re covered for')]"));
    }

    public WebElement deleteTreatment1Button() {
        return waitForElementPresent(By.id("C3__C1__BUT_24D9276FBA6E19C58823782_R1"));
    }

    public WebElement addAnotherTreatmentButton() {
        return waitForElementPresent(By.xpath("//button[contains(text(),'Add another treatment')]"));
    }

    public WebElement treatmentDropDown() {
        return waitForElementPresent(By.id("C3__C1__QUE_C8F3E8A0E3C242A2684130"));
    }

    public WebElement peoplePerformTreatmentTextBox() {
        return waitForElementPresent(By.id("C3__C1__QUE_C8F3E8A0E3C242A2684143"));
    }

    public WebElement addTreatmentButtonToSave() {
        return waitForElementPresent(By.id("C3__C1__BUT_C8F3E8A0E3C242A2684188"));
    }

    public WebElement addToQuoteButton() {
        return waitForElementPresent(By.id("C3__C1__BUT_24D9276FBA6E19C58823792"));
    }

    public WebElement manicureLabel() {
        return waitForElementPresent(By.xpath("//*[@id='C3__C1__p4_QUE_647B1F94A26D5FE1997836_R2']/div"));
    }

    public WebElement facialLabel() {
        return waitForElementPresent(By.xpath("//*[@id='C3__C1__QUE_647B1F94A26D5FE1997836_R3']"));
    }

    public WebElement treatmentPopUpWindowCloseButton() {
        return waitForElementPresent(By.xpath("//*[@id='C3__C1__view-treatments']/div[1]/button"));
    }

    public WebElement TOTdropDown() {
        return waitForElementPresent(By.id("C2__QUE_24D9276FBA6E19C58823814"));
    }

    public WebElement amendBILimitButton() {
        return waitForElementPresent(By.id("C5__BUT_0D396F41AB6AB8C2544911"));
    }

    public WebElement grossTurnOverDropDown() {
        return waitForElementPresent(By.id("C5__C1__QUE_965BD2C07905F7002825186"));
    }

    public WebElement monthOfCoverDropDown() {
        return waitForElementPresent(By.id("C5__C1__QUE_965BD2C07905F7002825190"));
    }

    public WebElement BIAddToQuoteButton() {
        return waitForElementPresent(By.id("C5__C1__BUT_965BD2C07905F7002825194"));
    }

    public WebElement BIpopUpWindowCloseButton() {
        return waitForElementPresent(By.xpath("//*[@id='C5__C1__view-bi']/div[1]/button"));
    }

    public WebElement toolsSumInsuredTextBox() {
        return waitForElementPresent(By.id("C9__QUE_99A2BF20ED976E671699251"));
    }

    public WebElement viewStockCoverLink() {
        return waitForElementPresent(By.id("C9__BUT_24D9276FBA6E19C58823816"));
    }

    public WebElement stockInTransitOwnTextBox() {
        return waitForElementPresent(By.id("C9__QUE_1685FD8EA1DE102C2684712_R1"));
    }

    public WebElement stockInTransitThirdPartyDeleteButton() {
        return waitForElementPresent(By.id("C9__BUT_DD1186DD0DBDF44C780098_R2"));
    }

    public WebElement stockAddToQuoteButton() {
        return waitForElementPresent(By.id("C9__BUT_1685FD8EA1DE102C2668069"));
    }


    public List<WebElement> moreOptionsNoCovers() {
        return findElements(By.xpath("//div[@id='more-options-row']/div[@id='more-options']"));
    }


    public List<WebElement> premiseHouseHoldContent() {
        return findElements(By.id("C8__FMT_6D42360776E850EB941923_R1_1"));
    }

    public List<WebElement> premiseStockExcludingWinesSpirits() {
        return findElements(By.id("C8__FMT_6D42360776E850EB941923_R1_2"));
    }

    public List<WebElement> premiseStockWinesSpirits() {
        return findElements(By.id("C8__FMT_6D42360776E850EB941923_R1_3"));
    }

    public List<WebElement> moreOptionsPublicProductLiability() {
        return findElements(By.id("C1__FMT_3AFE3E129A2861032650420"));
    }

    public List<WebElement> moreOptionsTheftOfTakings() {
        return findElements(By.id("C2__FMT_B133FE1EF5384F8B2517"));
    }

    public List<WebElement> moreOptionsLegalExpenses() {
        return findElements(By.xpath("//*[@id='C7__QUE_965BD2C07905F7002825070']/p"));
    }

    public List<WebElement> moreOptionsBusinessInterruption() {
        return findElements(By.xpath("//*[@id='C5__QUE_965BD2C07905F7002825070']/p"));
    }

    public List<WebElement> moreOptionsEmployersLiability() {
        return findElements(By.id("C4__FMT_3AFE3E129A28610326504521"));
    }

    public List<WebElement> moreOptionsBusinessInterruptionThirdParty() {
        return findElements(By.id("C6__FMT_3AFE3E129A28610326504521"));
    }

    public List<WebElement> moreOptionsHairAndBeautyTreatmentsLiability() {
        return findElements(By.id("C3__FMT_B133FE1EF5555F8B2517"));
    }

    public WebElement legalExpenseSelectQuoteSummary() {
        return waitForElementPresent(By.id("C7__QUE_965BD2C07905F7002825072"));
    }

    public WebElement legalExpensePlusSymbol() {
        return waitForElementPresent(By.id("C7__BUT_965BD2C07905F7003521888"));
    }

    public List<WebElement> quoteSummaryMoreOption() {
        return findElements(By.id("TXT_E2827522B56174171472326"));
    }

    public WebElement propertyAwayNamedItemWithValue() {
        return waitForElementPresent(By.xpath("//*[@id='C9__FMT_8B6DDC529111683F437213']"));
    }

    public WebElement propertyAwayPersonalBelongings() {
        return waitForElementPresent(By.xpath("//*[@id='C9__QUE_24D9276FBA6E19C58823812']/p"));
    }

    public List<WebElement> QuoteSummarypropertyAwayPremises() {
        return findElements(By.xpath("//ul[@id='summaryaccord_three']/li/a"));
    }


    public WebElement QuoteSummaryPropertyAwayCover() {
        return waitForElementPresent(By.xpath("//*[@id='C9__FMT_8B6DDC529111683F437213']"));
    }

    public WebElement propertyAwayBuisnesstoolsAndEquipment() {
        return waitForElementPresent(By.id("C9__FMT_B133FE1EF5384F8B2517"));
    }

    public WebElement propertyAwayBusinessStock() {
        return waitForElementPresent(By.id("C9__FMT_8B6DDC529111683F437132"));
    }

    public WebElement QuoteSummaryBinButton() {
        return waitForElementPresent(By.xpath("//*[@id='C9__BUT_99A2BF20ED976E671699059']/span"));
    }

    public WebElement quoteSummaryBusinessContentsAndStockAway() {
        return waitForElementPresent(By.xpath("//*[@id='C9__FMT_B133FE1EF5384F8B2517']"));
    }

    public WebElement createAccountButton() {
        return waitForElementPresent(By.id("C1__BUT_48BDF1EEA3569326348890"));
    }

    public WebElement contactEmailTextbox() {
        return waitForElementPresent(By.id("QUE_879C6A11B52E18631000835"));
    }

    public WebElement confirmEmailTextbox() {
        return waitForElementToBeClickableAndReturnElement(By.id("QUE_879C6A11B52E18631000853"));
    }

    public WebElement telephoneNumberTextbox() {
        return waitForElementPresent(By.id("QUE_879C6A11B52E18631000859"));
    }

    public WebElement emailRadiobutton() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_saveQuoteMarketingPreferences']/label[1]"));
    }

    public WebElement saveExitButton() {
        return waitForElementPresent(By.xpath("//*[@id='BUT_879C6A11B52E18633458448']"));

    }

    public WebElement QuoteSummarySaveAndExit() {
        return waitForElementPresent(By.xpath("//div[@id='C10__p4_BUT_E8AE1FC2C8F53163909220']/div/button[@id='C10__BUT_E8AE1FC2C8F53163909220']"));
    }

    public WebElement premiseDetailsEditLink() {
        return waitForElementPresent(By.xpath("//*[@id='C8__BUT_1EED2E0882C2655C503325_R1']/span"));

    }

    public WebElement goBackAndEditTheQuote() {
        return waitForElementPresent(By.id("C1__BUT_2913A5FDBA5243B93675222"));
    }


    public WebElement quoteSummaryBackbutton() {
        return waitForElementPresent(By.xpath("//*[@id='C11__BUT_0B05D8BDF306C9A5532617']"));
    }

    public WebElement addTreatmentButtonInQS() {
        return waitForElementToBeClickableAndReturnElement(By.id("C3__C1__BUT_24D9276FBA6E19C58823785"));
    }

    public WebElement addAnotherTreatmentButtonInQS() {
        return waitForElementToBeClickableAndReturnElement(By.id("C3__C1__BUT_24D9276FBA6E19C58823786"));
        //button[contains(text(),'Add another treatment')]
    }

    public WebElement SaveAndExitPostQuote() {
        return waitForElementPresent(By.id("C1__BUT_48BDF1EEA3569326413922"));
    }

    public WebElement saveExitButtonPopUp() {
        return waitForElementVisible(By.xpath("//*[@id='BUT_638302E96729F5851483311'][@class='green-btn pq_exit']"));

    }

    public WebElement carOtherPolicies() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C10__QUE_E8AE1FC2C8F53163909160']/label[1]"));
    }

    public WebElement petOtherPolicies() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C10__QUE_E8AE1FC2C8F53163909160']/label[2]"));
    }

    public WebElement stockTextQuoteSummary(int i) {
        return waitForElementPresent(By.id("C8__p4_QUE_6D42360776E850EB937178_R" + i + "_3"));
    }

    public WebElement BICover(String screenName) {
        return waitForElementPresent(By.xpath("(//p[text()='" + screenName + "']/../../../../../../..)/div[2]/div/div[1]/div/div[1]/div[1]/div/label"));
    }

    public WebElement quoteSummaryBICover() {
        return waitForElementPresent(By.xpath("//*[@id='C5__BUT_0D396F41AB6AB8C2544911']/span"));
    }

    public WebElement grossOverAmountBI() {
        return waitForElementPresent(By.id("C5__C1__QUE_965BD2C07905F7002825186"));
    }

    public WebElement monthBI() {
        return waitForElementPresent(By.id("C5__C1__QUE_965BD2C07905F7002825190"));
    }

    public WebElement addToQuoteBI() {
        return waitForElementPresent(By.id("C5__C1__BUT_965BD2C07905F7002825194"));
    }

    public WebElement editPAContentLimit() {
        return waitForElementPresent(By.xpath("//input[@name='C9__DIRECTLINE[1].YOURBUSINESS[1].PROPERTYAWAY[1].SUMMARY[1].BUSINESSCONTENTS[1].LIMIT']"));
    }

    public WebElement editPAStockLimit() {
        return waitForElementPresent(By.xpath("//input[@name='C9__DIRECTLINE[1].YOURBUSINESS[1].PROPERTYAWAY[1].SUMMARY[1].STOCK[1].STOCKITEMS[1].SUMINSURED']"));
    }

    public WebElement editPAStockTransitLimit() {
        return waitForElementPresent(By.xpath("//input[@name='C9__DIRECTLINE[1].YOURBUSINESS[1].PROPERTYAWAY[1].SUMMARY[1].STOCK[1].STOCKITEMS[2].SUMINSURED']"));
    }

    public WebElement editPABelongingsLimit() {
        return waitForElementPresent(By.xpath("//input[@name='C9__DIRECTLINE[1].YOURBUSINESS[1].PROPERTYAWAY[1].SUMMARY[1].PERSONALBELONGINGS[1].LIMIT']"));
    }

    public WebElement validationMessagePALimit() {
        return waitForElementPresent(By.xpath("//*[@id='p4_QUE_B9F9034988F6AFFA2047640_R1']/div"));
    }

    public WebElement PAViewFullCover() {
        return waitForElementPresent(By.xpath("(//button[@id='C9__BUT_99A2BF20ED976E671836148'])[1]"));
    }

    public WebElement changeButton() {
        return waitForElementPresent(By.xpath("//button[@id='C9__BUT_24D9276FBA6E19C58823884_R1']"));
    }

    public WebElement sumInsured() {
        return waitForElementPresent(By.xpath("//input[@name='C9__DIRECTLINE[1].YOURBUSINESS[1].PROPERTYAWAY[1].SUMMARY[1].NAMEDITEMS[1].NAMEDITEM[1].VALUEOFITEM']"));
    }

    public WebElement updateItem() {
        return waitForElementPresent(By.id("C9__BUT_24D9276FBA6E19C58823874"));
    }

    public WebElement validationMessageNamedItems() {
        return waitForElementPresent(By.xpath("//div[@id='C9__p1_TBL_A69EAD8A064809B2472574']"));
    }

    public WebElement viewFullCoverLinkStock() {
        return waitForElementPresent(By.xpath("(//button[@id='C9__BUT_24D9276FBA6E19C58823816'])[1]"));
    }

    public WebElement ppliabilityHelpText() {
        return waitForElementPresent(net.serenitybdd.core.annotations.findby.By.xpath("//*[@id='C1__p4_QUE_965BD2C07905F7002826181']/div/div[1]/div"));
    }

    public WebElement excessHelpText() {
        return waitForElementPresent(net.serenitybdd.core.annotations.findby.By.xpath("//*[@id='p4_QUE_1FBE82459A94B8DD1079195']/div/div[1]/div"));
    }

    public WebElement glassHelpText() {
        return waitForElementPresent(net.serenitybdd.core.annotations.findby.By.xpath("//*[@id='C8__p4_QUE_6D42360776E850EB937176_R1_1']/div/div[1]/div"));
    }

    public WebElement fixturesFittingsHelpText() {
        return waitForElementPresent(net.serenitybdd.core.annotations.findby.By.xpath("//*[@id='C8__p4_QUE_6D42360776E850EB937176_R1_2']/div/div[1]/div"));
    }

    public WebElement businessContentStockHelpTextQS() {
        return waitForElementPresent(By.xpath("//*[@id='C8__p4_QUE_6D42360776E850EB937176_R1_2']/div/div[1]/div"));
    }

    public WebElement thirdPartyPremisesWhereYouWorkText() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C1__TXT_006AB5B0B0C7206C1512469']/div/table/tbody/tr[4]/td[1]"));
    }

    public WebElement thirdPartyPremisesWhereYouWorkValue() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C1__TXT_006AB5B0B0C7206C1512469']/div/table/tbody/tr[4]/td[2]"));
    }

    public List<WebElement> premiseBusinessContentsQuoteSummary() {
        return findElements(By.id("C8__FMT_6D42360776E850EB941923_R1_2"));
    }

    public List<WebElement> premiseBusinessStockQuoteSummary() {
        return findElements(By.id("C8__FMT_6D42360776E850EB941923_R1_3"));
    }

    public WebElement referralMsgTextOverAll() {
         return waitForElementPresent(By.xpath("//*[@id='C1__FMT_2913A5FDBA5243B92084676']"));
    }

    public List<WebElement> referralMsg() {
        return findElements(By.xpath("//*[@id='C1__FMT_2913A5FDBA5243B92084676']"));
    }
    public WebElement crossSellDiscount() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C10__QUE_E8AE1FC2C8F53163909160']/label[2]"));
    }
    public WebElement removeYES() {
        return waitForElementPresent(By.xpath("//*[@id='information']/div[2]/button[1]"));
    }
    public WebElement removeNO() {
        return waitForElementPresent(By.xpath("//*[@id='information]/div[2]/button[2]"));
    }
    public WebElement removeCLE() {
        return waitForElementPresent(By.xpath("//*[@id='C7__BUT_965BD2C07905F7003509104']/span"));
    }
    public WebElement removeEL() {
        return waitForElementPresent(By.xpath("//*[@id='C4__BUT_965BD2C07905F7003509104']/span"));
    }
    public WebElement qsPLHelpText() {
    return waitForElementPresent(By.xpath("//*[@id='C1__p4_QUE_965BD2C07905F7002826181']/div/div[1]/div"));
}
    public WebElement qsGlassHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C8__p4_QUE_6D42360776E850EB937176_R1_1']/div/div[1]/div"));
    }
    public WebElement qsBusinessContnentStockHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C8__p4_QUE_6D42360776E850EB937176_R1_2']/div/div[1]/div"));
    }
    public WebElement qsWinesSpiritHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C8__p4_QUE_6D42360776E850EB937176_R1_3']/div/div[1]/div"));
    }
    public WebElement YourQuoteBreadcrumb() {
        return waitForElementPresent(By.xpath("//*[@id='STP_2']/a"));
    }
    public WebElement YourBusinessBreadcrumb() {
        return waitForElementPresent(By.xpath("//*[@id='STP_1']/a"));
    }

    public WebElement professionalHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C5__p4_QUE_965BD2C07905F7002825070']/div/div[1]/div"));
    }

    public List<WebElement> policyLevelprofessionalLiabilityBinButton() {
        return findElements(By.id("C5__BUT_965BD2C07905F7003509104"));
    }

    public WebElement policyLeveBinButton() {
        return waitForElementVisible(By.id("C5__BUT_965BD2C07905F7003509104"));
    }


    public List<WebElement> coverPopup(String YesOrNo) {
        return findElements(By.xpath("//div[@id='information']/div/button[contains(text(),'"+YesOrNo+"')]"));
    }

    public WebElement coverPopupWarningMsg(){
        return waitForElementPresent(By.xpath("//*[@id='information']/div[1]/p"));
    }

    public List<WebElement> profLiabilityEnterDetails(){
        return findElements(By.xpath("//*[@id='C5__BUT_0D396F41AB6AB8C2544911' or @id='C5__BUT_B27861E7D1B6D9CA2115252']"));
    }

    public WebElement profLiabilityPlusButton(){
        return findElement(By.xpath("//*[@id='C5__BUT_965BD2C07905F7003521888']/span"));
    }

    public List<WebElement> coversPresentOrNot(String covers){
        return findElements(By.xpath("//p[contains(text(),'"+covers+"')]"));
    }
    public WebElement publicLiabilityHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C5__p4_QUE_965BD2C07905F7002825070']/div/div[1]/div"));
    }
    public WebElement publicLiabilityBinBtn() {
        return waitForElementPresent(By.xpath("//*[@id='C1__BUT_58DEE732A208EC82633228']/span"));
    }
    public WebElement publicLiabilityLimit()
    {
        return waitForElementPresent(By.id("C1__QUE_965BD2C07905F7002825072"));
    }
    public WebElement publicLiabilityAdd()
    {
        return waitForElementPresent(By.xpath("//*[@id='C1__BUT_965BD2C07905F7003521888']/span"));
    }

}