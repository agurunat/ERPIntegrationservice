package co.uk.directlinegroup.evo.pages;

import co.uk.directlinegroup.evo.utils.CognosReportsUtil;
import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.List;

public class Obj_CognosReportCommon extends AbstractPage {

    public WebElement reportHomeButton() {
        return waitForElementVisible(By.xpath(" //img[@title='Home']"));
    }


    public WebElement reportStartDateTextbox() {
        Wait<WebDriver> wait = new WebDriverWait(getDriver, 180L);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[starts-with(@class,'clsSelectDateEditBox')])[1]")));
        return waitForElementVisible(By.xpath("(//input[starts-with(@class,'clsSelectDateEditBox')])[1]"));
    }


    public WebElement reportEndDateTextbox() {
        return waitForElementVisible(By.xpath("(//input[starts-with(@class,'clsSelectDateEditBox')])[2]"));
    }

    public WebElement reportDateRangeOkButton() {
        return waitForElementVisible(By.xpath("//button[@class='bp']/span"));
    }

    public List<WebElement> reportTbs() {
        return waitForElementsPresent(By.xpath("//span[@role='tab']"));
    }

    public WebElement reportTitle() {
        return waitForElementVisible(By.xpath("//td[@class='headerTitle']"));
    }

    public WebElement reportSubTabTitle() {
        return waitForElementVisible(By.xpath("//*[@id='rt_NS_']/tbody/tr[1]/td/div/table/tbody/tr[2]/td[2]/span"));
    }

    public WebElement reportTable() {
        return waitForElementVisible(By.xpath("//table[starts-with(@lid,'" + CognosReportsUtil.currentTableLid + "" + CognosReportsUtil.currentTab + "')]"));
    }

    public WebElement reportTableHeaderRow() {
//        System.out.println(reportTable().findElement(By.xpath("//tr")).getText());
        return waitForElementVisible(By.xpath("//table[starts-with(@lid,'" + CognosReportsUtil.currentTableLid + "" + CognosReportsUtil.currentTab + "')]/tbody/tr[1]"));
    }

    public WebElement reportTablePageDownLink() {
//        System.out.println(reportTable().findElement(By.xpath("//tr")).getText());
        return waitForElementVisible(By.linkText("Page down"));
    }

    public WebElement reportTablePageUpLink() {
//        System.out.println(reportTable().findElement(By.xpath("//tr")).getText());
        return waitForElementVisible(By.linkText("Page up"));
    }

    public WebElement reportTableTopLink() {
//        System.out.println(reportTable().findElement(By.xpath("//tr")).getText());
        return waitForElementVisible(By.linkText("Top"));
    }
    public WebElement reportTableBottomLink() {
//        System.out.println(reportTable().findElement(By.xpath("//tr")).getText());
        return waitForElementVisible(By.linkText("Bottom"));
    }

    public WebElement reportRerunButton() {
        return waitForElementVisible(By.xpath("//img[@title='Run Report']"));
    }

    public WebElement viewReportAsButton() {
        return waitForElementVisible(By.id("_NS_runIn"));
    }

    public WebElement viewReportAsExcelButton() {
        return waitForElementVisible(By.id("_NS_viewInExcel"));
    }

    public WebElement viewReportAsExcel2007DataButton() {
        return waitForElementVisible(By.id("_NS_viewInspreadsheetMLData"));
    }

    public WebElement viewReportAsExcel2007FormatButton() {
        return waitForElementVisible(By.id("_NS_viewInspreadsheetML"));
    }
    public WebElement viewReportAsExcel2002FormatButton() {
        return waitForElementVisible(By.id("_NS_viewInXLWA"));
    }


    public List<WebElement> reportTabs() {
        return waitForElementsPresent(By.xpath("//*[@role='tablist']/div/div"));
    }

    public Select processDateDD() {
        return new Select(waitForElementVisible(By.xpath("(//select[starts-with(@class,'clsSelectControl pv')])[1]")));
    }

    public Select sTartMonthDD() {
        return new Select(waitForElementVisible(By.xpath("(//select[starts-with(@class,'clsSelectControl pv')])[2]")));
    }

    public Select sTartYearDD() {
        return new Select(waitForElementVisible(By.xpath("(//select[starts-with(@class,'clsSelectControl pv')])[3]")));
    }

    public Select eNdMonthDD() {
        return new Select(waitForElementVisible(By.xpath("(//select[starts-with(@class,'clsSelectControl pv')])[4]")));
    }

    public Select eNdYearDD() {
        return new Select(waitForElementVisible(By.xpath("(//select[starts-with(@class,'clsSelectControl pv')])[5]")));
    }

    public WebElement gBPRadioButton() {
        return waitForElementVisible(By.xpath("//label[text()='GBP']/preceding-sibling::*/input"));
    }

    public WebElement dLGCheckBox() {
        return waitForElementVisible(By.xpath("//label[contains(text(),'Direct')]/preceding-sibling::*/input"));
    }

    public WebElement logoffLink() {
        return waitForElementVisible(By.xpath("//*[@id='_NS_logOnOff']/tbody/tr/td[2]"));
    }

    public WebElement reportFilterHeaderLabel() {

        Wait<WebDriver> wait = new WebDriverWait(getDriver, 600L);
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("((//table[@lid='Filters_NS_']//table)[1]//span)[1]")));
        return waitForElementVisible(By.xpath("((//table[@lid='Filters_NS_']//table)[1]//span)[1]"));
    }

    public WebElement reportFilterPivotInput() {
        return waitForElementVisible(By.xpath("//table[@lid='Filters_NS_']//table[2]/tbody/tr/td/table/tbody"));
    }

    public WebElement reportFilterApplyButton() {
        return waitForElementVisible(By.xpath("(//table[@lid='Filters_NS_']//table[2]/tbody/tr/td/div/button)[1]"));
    }

    public WebElement reportFilterCancelButton() {
        return waitForElementVisible(By.xpath("(//table[@lid='Filters_NS_']//table[2]/tbody/tr/td/div/button)[2]"));
    }

    public WebElement reportFilterRefreshButton() {
        return waitForElementVisible(By.xpath("(//table[@lid='Filters_NS_']//table[2]/tbody/tr/td/div/button)[3]"));
    }

    public List<WebElement> reportFilterInputOptionDivisions() {
        return waitForElementsPresent(By.xpath("//table[@lid='Filters_NS_']//table[2]/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/div/table//td/div[1]"));
    }

    public List<WebElement> reportFilterInputOptionDivisionsSelectAllLink() {
        return waitForElementsPresent(By.xpath("//table[@lid='Filters_NS_']//table[2]/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/div/table//td/div/a[text()='Select all']"));
    }

    public List<WebElement> reportFilterInputOptionDivisionsDeSelectAllLink() {
        return waitForElementsPresent(By.xpath("//table[@lid='Filters_NS_']//table[2]/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/div/table//td/div/a[text()='Deselect all']"));
    }


    public List<WebElement> reportFilterInputHeaderDivisions() {
        return waitForElementsPresent(By.xpath(" //table[@lid='Filters_NS_']//table[2]/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/span[contains(text(),':')]"));
    }

}
