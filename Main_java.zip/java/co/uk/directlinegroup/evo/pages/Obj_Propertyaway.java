package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import net.serenitybdd.core.annotations.findby.By;
import org.openqa.selenium.WebElement;

public class Obj_Propertyaway extends AbstractPage {

    public WebElement businessToolsEquipmentYesRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C7__QUE_C6DF722AF30BABC9946073']/label[1]/span"));
    }

    public WebElement businessToolsEquipment(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C7__DIRECTLINE[1].YOURBUSINESS[1].PROPERTYAWAY[1].INSUREBUSINESSTOOLSORNOT'][value=" + value + "]";
        return waitForUnstableElement(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement insureYourStock(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C7__DIRECTLINE[1].YOURBUSINESS[1].PROPERTYAWAY[1].INSURESTOCKORNOT'][value=" + value + "]";
        return waitForUnstableElement(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement insureBelongings(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C7__DIRECTLINE[1].YOURBUSINESS[1].PROPERTYAWAY[1].INSUREPERSONALBELONGINGSORNOT'][value='" + value + "']";
        return waitForUnstableElement(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement insureStocksAtTransit(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C7__DIRECTLINE[1].YOURBUSINESS[1].PROPERTYAWAY[1].STOCKVIATHIRDPARTYORNOT'][value=" + value + "]";
        return waitForUnstableElement(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement businessToolsEquipmentNoRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C7__QUE_C6DF722AF30BABC9946073']/label[2]/span"));
    }

    public WebElement businessToolsEquipmentValueTextbox() {
        return waitForUnstableElement(By.xpath(".//*[@id='C7__QUE_C6DF722AF30BABC9946075']"));
    }

    public WebElement insureYourStockYesRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C7__QUE_C6DF722AF30BABC9946081']/label[1]/span"));
    }

    public WebElement insureYourStockNoRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C7__QUE_C6DF722AF30BABC9946081']/label[2]/span"));

    }

    public WebElement insureYourStockValueTextbox() {
        return waitForUnstableElement(By.xpath(".//*[@id='C7__QUE_C6DF722AF30BABC9946083']"));
    }

    public WebElement TransitViaThirdPartyYesRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C7__QUE_C6DF722AF30BABC9946085']/label[1]/span"));
    }

    public WebElement TransitViaThirdPartyNoRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C7__QUE_C6DF722AF30BABC9946085']/label[2]/span"));
    }

    public WebElement transitViaThirdPartyValueTextbox() {
        return waitForUnstableElement(By.xpath(".//*[@id='C7__QUE_C6DF722AF30BABC9946087']"));
    }

    public WebElement insureItemYesRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C7__QUE_661D54578C2C788A275830']/label[1]/span"));
    }

    public WebElement insureItemNoRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C7__QUE_661D54578C2C788A275830']/label[2]/span"));
    }

    public WebElement propertyAwayAddItemRadiobutton() {
        return waitForUnstableElement(By.xpath("(.//*[@id='C7__BUT_04A156C5A0898094574298'])[1]"));
    }

    public WebElement nextButton() {
        return waitForUnstableElement(By.id("C7__BUT_006AB5B0B0C7206C1539605"));
    }

    public void pageLoading() {
        waitForElementEnabled(org.openqa.selenium.By.xpath("//*[@id='TXT_FAE554C988A5F3932837']/div/div[2]/div"));
    }

    public WebElement accordionPA() {
        return waitForUnstableElement(By.xpath("//*[@id='C7__TXT_5ACDC754EE2A23F4970613']/div"));
    }

    public WebElement contentAndStockTextboxLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p1_QUE_C6DF722AF30BABC9946075']/div/label"));
    }

    public WebElement contentAndStockSymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946073']/div/div[1]"));
    }

    public WebElement contentAndStockTextboxSymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946075']/div/div"));
    }

    public WebElement contentAndStockTextboxHelptext() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946075']/div/div/div"));
    }

    public WebElement contentAndStockHelptext() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946073']/div/div[1]/div"));
    }

    public WebElement businessToolsAndEquipmentsLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p1_QUE_C6DF722AF30BABC9946073']/div/label"));
    }

    public WebElement businessToolsAndEquipmentsTextboxLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p1_QUE_C6DF722AF30BABC9946075']/div/label"));
    }

    public WebElement personalBelongingsLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p1_QUE_C6DF722AF30BABC9946077']/div/label"));
    }

    public WebElement personalBelongingsTextboxLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p1_QUE_C6DF722AF30BABC9946079']/div/label"));
    }

    public WebElement personalBelongingsTextbox() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946079"));
    }

    public WebElement personalBelongingsYes() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C7__QUE_C6DF722AF30BABC9946077']/label[1]/span"));
    }

    public WebElement personalBelongingsNo() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C7__QUE_C6DF722AF30BABC9946077']/label[2]/span"));
    }

    public WebElement personalBelongingValueTextbox() {
        return waitForUnstableElement(By.id("C7__QUE_C6DF722AF30BABC9946079"));
    }

    public WebElement stockAwayLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p1_QUE_C6DF722AF30BABC9946081']/div/label"));
    }

    public WebElement stockAwayTextboxLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p1_QUE_C6DF722AF30BABC9946083']/div/label"));
    }

    public WebElement stockAwayTextbox() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946083"));
    }

    public WebElement stockAwayYes() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C7__QUE_C6DF722AF30BABC9946081']/label[1]/span"));
    }

    public WebElement stockAwayNo() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C7__QUE_C6DF722AF30BABC9946081']/label[2]/span"));
    }

    public WebElement stockAtTransitLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p1_QUE_C6DF722AF30BABC9946085']/div/label"));
    }

    public WebElement stockAtTransitTextboxLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p1_QUE_C6DF722AF30BABC9946087']/div/label"));
    }

    public WebElement stockAtTransitTextbox() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946087"));
    }

    public WebElement stockAtTransitYes() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C7__QUE_C6DF722AF30BABC9946085']/label[1]/span"));
    }

    public WebElement stockAtTransitNo() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C7__QUE_C6DF722AF30BABC9946085']/label[2]/span"));
    }

    public WebElement insureBusinessToolsAndEquipmentsLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p1_QUE_C6DF722AF30BABC9946073']/div/label"));
    }

    public WebElement insureBusinessToolsAndEquipmentsTextboxLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p1_QUE_C6DF722AF30BABC9946075']/div/label"));
    }

    public WebElement insureToolsAndEquipmentsYes() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C7__QUE_C6DF722AF30BABC9946073']/label[1]/span"));
    }

    public WebElement insureToolsAndEquipmentsNo() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C7__QUE_C6DF722AF30BABC9946073']/label[2]/span"));
    }

    public WebElement insureToolsAndEquipmentTextbox() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946075"));
    }

    public WebElement insureToolsAndEquipmentSymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946073']/div/div[1]"));
    }

    public WebElement insureToolsAndEquipmentHelptext() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946073']/div/div[1]/div"));
    }

    public WebElement insureToolsAndEquipmentTextboxSymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946075']/div/div"));
    }

    public WebElement insureToolsAndEquipmentTextboxHelptext() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946075']/div/div/div"));
    }

    public WebElement insureStockAwayLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p1_QUE_C6DF722AF30BABC9946081']/div/label"));
    }

    public WebElement insureStockAwayTextboxLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p1_QUE_C6DF722AF30BABC9946083']/div/label"));
    }

    public WebElement insureStockAwayYes() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C7__QUE_C6DF722AF30BABC9946081']/label[1]/span"));
    }

    public WebElement insureStockAwayNo() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C7__QUE_C6DF722AF30BABC9946081']/label[2]/span"));
    }

    public WebElement insureStockAwayTextbox() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946083"));
    }

    public WebElement insureStockAwaySymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946081']/div/div[1]"));
    }

    public WebElement insureStockAwayHelptext() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946081']/div/div[1]/div"));
    }

    public WebElement insureStockAwayTextboxSymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946083']/div/div"));
    }

    public WebElement insureStockAwayTextboxHelptext() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946083']/div/div/div"));
    }

    public WebElement insureStockAtTransitLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p1_QUE_C6DF722AF30BABC9946085']/div/label"));
    }

    public WebElement insureStockAtTransitTextboxLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p1_QUE_C6DF722AF30BABC9946087']/div/label"));
    }

    public WebElement insureStockAtTransitYes() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C7__QUE_C6DF722AF30BABC9946085']/label[1]/span"));
    }

    public WebElement insureStockAtTransitNo() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C7__QUE_C6DF722AF30BABC9946085']/label[2]/span"));
    }

    public WebElement insureStockAtTransitTextbox() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946087"));
    }

    public WebElement insureStockAtTransitSymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946085']/div/div[1]"));
    }

    public WebElement insureStockAtTransitHelptext() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946085']/div/div[1]/div"));
    }

    public WebElement insureStockAtTransitTextboxSymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946087']/div/div"));
    }

    public WebElement insureStockAtTransitTextboxHelptext() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946087']/div/div/div"));
    }

    public WebElement personalBelongingsSymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946077']/div/div[1]"));
    }

    public WebElement personalBelongingsHelptext() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946077']/div/div[1]/div"));
    }

    public WebElement personalBelongingsTextboxSymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946079']/div/div"));
    }

    public WebElement personalBelongingsTextboxHelptext() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946079']/div/div/div"));
    }

    public WebElement contentAndStockLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p1_QUE_C6DF722AF30BABC9946073']/div/label"));
    }

    public WebElement contentAndStockYes() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C7__QUE_C6DF722AF30BABC9946073']/label[1]/span"));
    }

    public WebElement contentAndStockNo() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C7__QUE_C6DF722AF30BABC9946073']/label[2]/span"));
    }

    public WebElement contentAndStockTextbox() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946075"));
    }

    public WebElement insureAnyIndividualItem(String YnN) {
        String value = "N";
        if (YnN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C7__DIRECTLINE[1].YOURBUSINESS[1].PROPERTYAWAY[1].INSUREINDIVIDUALITEMSORNOT'][value=" + value + "]";
        return waitForUnstableElement(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement saveAndExit() {
        return waitForElementPresent(By.xpath("//*[@id='C7__BUT_D3E81D5ED026892F3306326']"));
    }

    public WebElement insureAnyIndividualItemAddItem() {
        return waitForElementPresent(By.id("C7__BUT_04A156C5A0898094574298"));
    }

    public WebElement saveAndExitPopUp() {
        return waitForElementPresent(By.xpath("//*[@id='BUT_D3E81D5ED026892F1577152']"));
    }

    public WebElement insureAnyIndividualPopupItemGroup() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946091"));
    }

    public WebElement ItemGroup() {
        return waitForElementPresent(By.xpath("(.//*[@id='C7__QUE_C6DF722AF30BABC9946091'])[1]"));
    }

    public WebElement insureAnyIndividualPopupTypeofItem() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946093"));
    }

    public WebElement ItemType() {
        return waitForElementPresent(By.xpath("(.//*[@id='C7__QUE_C6DF722AF30BABC9946093'])[1]"));
    }

    public WebElement insureAnyIndividualPopupItemValue() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946097"));
    }

    public WebElement ItemValue() {
        return waitForElementPresent(By.xpath("(.//*[@id='C7__QUE_C6DF722AF30BABC9946097'])[1]"));
    }

    public WebElement insureAnyIndividualPopupDescribe() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946099"));
    }

    public WebElement ItemDesc() {
        return waitForElementPresent(By.xpath("(.//*[@id='C7__QUE_C6DF722AF30BABC9946099'])[1]"));
    }

    public WebElement insureAnyIndividualPopupAddItem() {
        return waitForElementPresent(By.id("C7__BUT_37A57A435749BE72373420"));
    }

    public WebElement AddItem() {
        return waitForElementPresent(By.xpath("(.//*[@id='C7__BUT_37A57A435749BE72373420'])[1]"));
    }

    public WebElement validationMessageSumInsured() {
        return waitForElementPresent(By.xpath("//div[@id='C7__p1_TBL_A69EAD8A064809B2472570']/div"));
    }

    public WebElement addAnotherItemButton() {
        return waitForElementPresent(By.xpath("//button[@id='C7__BUT_573C5B7FFB70A78A218329']"));
    }

    public WebElement personalBelongHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946077']/div/div[1]/div"));
    }

    public WebElement propertyAwayNamedItemHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C7__p4_QUE_C6DF722AF30BABC9946097']/div/div/div"));
    }

    public WebElement toolsSuminsuredRequiredMsg() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946075_ERRORMESSAGE"));
    }

    public WebElement stockSuminsuredRequiredMsg() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946083_ERRORMESSAGE"));
    }

    public WebElement stockTransitSuminsuredRequiredMsg() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946087_ERRORMESSAGE"));
    }

    public WebElement namedItemRequiredMsg() {
        return waitForElementPresent(By.id("C7__QUE_661D54578C2C788A275830_ERRORMESSAGE"));
    }

    public WebElement toolsRequiredMsg() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946073_ERRORMESSAGE"));
    }

    public WebElement stocksRequiredMsg() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946081_ERRORMESSAGE"));
    }

    public WebElement stocksTransitRequiredMsg() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946085_ERRORMESSAGE"));
    }

    public WebElement AddNamedItemRequiredMsg() {
        return waitForElementPresent(By.id("C7__QUE_661D54578C2C788A275830_ERRORMESSAGE"));
    }

    public WebElement ItemGroupRequiredMsg() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946091_ERRORMESSAGE"));
    }

    public WebElement ItemTypeRequiredMsg() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946093_ERRORMESSAGE"));
    }

    public WebElement ItemValueRequiredMsg() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946097_ERRORMESSAGE"));
    }

    public WebElement ItemDescribeRequiredMsg() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946099_ERRORMESSAGE"));
    }

    public WebElement ItemTypeTextBoxRequiredMsg() {
        return waitForElementPresent(By.id("C7__QUE_C6DF722AF30BABC9946095_ERRORMESSAGE"));
    }
    public WebElement propertyAwayBusinessStockInQS() {
        return waitForElementPresent(By.xpath("//*[@id='C9__QUE_99A2BF20ED976E671699251']"));
    }
    public WebElement PropertyAwayBusinessStockInQSAddtoQuote() {
        return waitForElementPresent(By.xpath("//*[@id='C9__BUT_99A2BF20ED976E671699270']/span"));
    }
    public WebElement removeContentsAndStock() {
        return waitForElementPresent(By.xpath("//*[@id='C9__BUT_99A2BF20ED976E671699268']/span"));
    }

}