package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Obj_Paymentinformation extends AbstractPage {

    public WebElement cardBelongsToYesRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C1__QUE_B7C86A0090A9962F1273045']/label[1]/span"));
    }

    public WebElement cardBelongsToNoRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C1__QUE_B7C86A0090A9962F1273045']/label[2]/span"));
    }

    public WebElement cardPermissionYesRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C1__QUE_B7C86A0090A9962F1273048']/label[1]/span"));
    }

    public WebElement cardPermissionNoRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C1__QUE_B7C86A0090A9962F1273048']/label[2]/span"));
    }

    public WebElement cardHolderNameTextbox() {
        return waitForElementToBeClickableAndReturnElement(By.id("C1__QUE_B7C86A0090A9962F1273051"));
    }

    public WebElement billingAddressYesRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C1__QUE_B7C86A0090A9962F1273057']/label[1]/span"));
    }

    public WebElement billingAddressNoRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C1__QUE_B7C86A0090A9962F1273057']/label[2]/span"));
    }

    public WebElement PaymentInfoNextButton() {
        return waitForUnstableElement(By.id("C1__BUT_E6ED2431D424349D547825"));
    }
}