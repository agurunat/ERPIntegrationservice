package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Obj_Createaccount extends AbstractPage {

    public WebElement createAccountButton() {
        //don't change element identification with out consulting Rao
        return waitForElementPresent(By.xpath("//*[@id='C1__p4_BUT_48BDF1EEA3569326348890']/div/button"));
    }

    public WebElement contactEmailTextbox() {
        return waitForElementToBeClickableAndReturnElement(By.id("QUE_879C6A11B52E18631000835"));
    }

    public WebElement confirmEmailTextbox() {
        return waitForElementToBeClickableAndReturnElement(By.id("QUE_879C6A11B52E18631000853"));
    }

    public WebElement telephoneNumberTextbox() {
        return waitForUnstableElement(By.id("QUE_879C6A11B52E18631000859"));
    }

    public WebElement emailRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='checkbox_saveQuoteMarketingPreferences']/label[1]"));
    }

    public WebElement textRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='checkbox_saveQuoteMarketingPreferences']/label[2]"));
    }

    public WebElement telephoneRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='checkbox_saveQuoteMarketingPreferences']/label[3]"));
    }

    public WebElement saveExitButton() {
        return waitForUnstableElement(By.xpath("//*[@id='BUT_879C6A11B52E18633458448']"));
    }

    public WebElement createAccountNextButton() {
        return waitForUnstableElement(By.id("C1__BUT_55E5AE0A984C2873498711"));
    }
}
