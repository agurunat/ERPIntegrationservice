package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Created by 445607 on 11/8/2017.
 */
public class Obj_ProfessionalLiability extends AbstractPage {
    public WebElement businessRegisteredQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p1_QUE_5847B0D83AF0F962230500']/div/label"));
    }


    public WebElement relevantQualificationQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p1_QUE_EB1D0A10B15E75C71173409']/div/label"));
    }
    public List<WebElement> relevantQualification() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_EB1D0A10B15E75C71173409']/div/label"));
    }

    public WebElement relevantQualificationHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_EB1D0A10B15E75C71173409']/div/div[1]/div"));
    }

    public WebElement replacePL() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p1_QUE_B6767FF306D4C438280993']/div/label"));
    }

    public WebElement replacePLYesNo(String option) {
        return waitForElementPresent(By.xpath("//label[starts-with(@for,'C4__QUE_B6767FF306D4C438280993_')]/span[text()='" + option + "']"));
    }

    public WebElement replacePLHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_B6767FF306D4C438280993']/div/div[1]/div"));
    }

    public WebElement retroactiveHistory() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p1_QUE_B6767FF306D4C438280999']/div/label"));
    }

    public List<WebElement> retroactiveHist() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_B6767FF306D4C438280999']/div/label"));
    }

    public WebElement retroactiveHistoryYesNo(String option) {
        return waitForElementPresent(By.xpath("//label[starts-with(@for,'C4__QUE_B6767FF306D4C438280999_')]/span[text()='" + option + "']"));
    }

    public WebElement retroactiveHistoryHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_B6767FF306D4C438280999']/div/div[1]/div"));
    }

    public WebElement retroactiveDateQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p1_QUE_0882CD82D8250E65897562']/div/label"));
    }

    public List<WebElement> retroactiveDateQuestionSize() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_0882CD82D8250E65897562']/div/label"));
    }

    public WebElement retroactiveDateTxtBox() {
        return waitForElementPresent(By.id("C4__QUE_0882CD82D8250E65897562"));
    }


    public WebElement retroactiveDateHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_0882CD82D8250E65897562']/div/div/div"));
    }

    public WebElement retroactiveDateErrMsg() {
        return waitForElementPresent(By.id("C4__QUE_0882CD82D8250E65897562_ERRORMESSAGE"));
    }

    public WebElement professLiabQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p1_QUE_B6767FF306D4C438309498']/div/label"));
    }

    public WebElement professLiabQuestionHT() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_B6767FF306D4C438309498']/div/div[1]/div"));
    }


    public WebElement businessRegisteredYesNo(String option) {
        return waitForElementPresent(By.xpath("//label[starts-with(@for,'C4__QUE_5847B0D83AF0F962230500_')]/span[text()='" + option + "']"));
    }

    public WebElement relevantQualificationsYesNo(String option) {
        return waitForElementPresent(By.xpath("//label[starts-with(@for,'C4__QUE_EB1D0A10B15E75C71173409_')]/span[text()='" + option + "']"));
    }

    public List<WebElement> professionalLiabilityCoverNotPresent() {
        return findElements(By.xpath("//a[@id='step-2'][contains(text(),'Professional Liability')]"));
    }

    public WebElement PLClaimYesNo(String option) {
        return waitForElementPresent(By.xpath("//label[starts-with(@for,'C4__QUE_E51B872E5D2AA4401152654_')]/span[text()='" + option + "']"));
    }

    public WebElement PLClaimIssueYesNo(String option) {
        return waitForElementPresent(By.xpath("//label[starts-with(@for,'C4__QUE_E51B872E5D2AA4401152663_')]/span[text()='" + option + "']"));
    }

    public WebElement PLCoverDropdown() {
        return waitForElementPresent(By.id("C4__QUE_B6767FF306D4C438309498"));
    }

    public WebElement PLNextButton() {
        return waitForElementPresent(By.id("C4__BUT_5847B0D83AF0F962230553"));
    }

    public WebElement professionalLiabilityCover() {
        return waitForElementPresent(By.xpath("//a[@id='step-2'][contains(text(),'Professional Liability')]"));
    }

    public WebElement professionalLiabilityClaimQues() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p1_QUE_E51B872E5D2AA4401152654']/div/label"));
    }

    public WebElement professionalLiabilityClaimHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_E51B872E5D2AA4401152654']/div/div[1]/div"));
    }

    public WebElement professionalLiabilityClaimAgainstQues() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p1_QUE_E51B872E5D2AA4401152663']/div/label"));
    }

    public WebElement professionalLiabilityClaimAgainstHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_E51B872E5D2AA4401152663']/div/div[1]/div"));
    }

    public List<WebElement> businessCarryOutQuestion() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_E2F5D92DB8F898C53385933']/div/label"));
    }
    public WebElement businessCarryOutYesOrNo(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].LEGALMORTGAGEORTAXADVICEETC'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));
    }
    public WebElement requiredMsgBusinessCarryOut()
    {
        return waitForElementPresent(By.id("C4__QUE_E2F5D92DB8F898C53385933_ERRORMESSAGE"));
    }
    public List<WebElement> businessWorkAreaLbl() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_E2F5D92DB8F898C53386068']/div/label"));
    }

    public WebElement businessWorkAreaHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_E2F5D92DB8F898C53386068']/div/div[1]/div"));
    }

    public WebElement businessWorkArea(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].WORKINNUCLEARCHEMICALMININGETC'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));
    }
    public WebElement reqMsgBusinessWorkArea() {
        return waitForElementPresent(By.xpath("//*[@id='C4__QUE_E2F5D92DB8F898C53386068_ERRORMESSAGE']"));
    }

    public List<WebElement> contractWritingLbl() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_E2F5D92DB8F898C53386078']/div/label"));
    }

    public WebElement contractWritingHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_E2F5D92DB8F898C53386078']/div/div[1]/div"));
    }

    public WebElement contractWriting(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].CONTRACTSINWRITING'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));
    }
    public WebElement financialLoss(String YorN)
    {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].LOSSFROMPRODUCTFAILURE'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));
    }

    public WebElement businessDesign(String YorN)
    {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].PROVIDESERVICESFORMANUFACTURING'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));
    }

    public List<WebElement> financialLossQuestion() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_9829F6EFC8BDC80E589347']/div/label"));
    }

    public WebElement financialLossHT() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_9829F6EFC8BDC80E589347']/div/div[1]"));
    }
    public List<WebElement> businessDesignQuestion() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_9829F6EFC8BDC80E589352']/div/label"));
    }

    public WebElement businessDesignHT() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_9829F6EFC8BDC80E589352']/div/div[1]"));
    }
    public List<WebElement> workConnectionQuestion() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_0BB499656A4397591067332']/div/label"));
    }
    public WebElement workConnection(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].WORKINCONNECTIONWITHTHENUCLEARINDUSTRY'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));

    }
    public WebElement financialLossRequired() {
        return waitAndFindElement(By.id("C4__QUE_9829F6EFC8BDC80E589347_ERRORMESSAGE"));
    }
    public WebElement businessDesignRequired() {
        return waitAndFindElement(By.id("C4__QUE_9829F6EFC8BDC80E589352_ERRORMESSAGE"));
    }
    public WebElement reqMsgContractsWriting()
    {
        return waitForElementPresent(By.xpath("//*[@id='C4__QUE_E2F5D92DB8F898C53386078_ERRORMESSAGE']"));
    }
    public List<WebElement> constructionValueLbl() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_E2F5D92DB8F898C53386073']/div/label"));
    }

    public WebElement constructionValueHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_E2F5D92DB8F898C53386073']/div/div[1]/div"));
    }
    public WebElement constructionValue(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].CONTRACTSVALUEABOVE2MILLION'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));
    }

    public WebElement workSpecs(String option) {
          return waitForElementPresent(By.xpath("//label[starts-with(@for,'C4__QUE_F03739927E23D8D81142278_')]/span[text()='" + option + "']"));
    }
    public WebElement commercialEstateAgencyQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p1_QUE_D03457217C638E8E1422379']/div/label"));
    }

    public WebElement commercialEstateAgencyHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_D03457217C638E8E1422379']/div/div[1]/div"));
    }
    public List<WebElement> commercialEstateAgency() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_D03457217C638E8E1422379']/div/label"));
    }

    public WebElement commercialEstateAgencyYesNo(String option) {
        return waitForElementPresent(By.xpath("//label[starts-with(@for,'C4__QUE_D03457217C638E8E1422379_')]/span[text()='" + option + "']"));
    }
    public List<WebElement> surveyOrValuation() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_D03457217C638E8E1445756']/div/label"));
    }

    public WebElement surveyOrValuationQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p1_QUE_D03457217C638E8E1445756']/div/label"));
    }

    public WebElement SurveyOrValuationHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_D03457217C638E8E1445756']/div/div[1]/div"));
    }
    public WebElement surveyOrValuationYesNo(String option) {

        return waitForElementPresent(By.xpath("//label[starts-with(@for,'C4__QUE_D03457217C638E8E1445756_')]/span[text()='" + option + "']"));

    }
    public WebElement relevantQualifications(String option) {
        return waitForElementPresent(By.xpath("//label[starts-with(@for,'C4__QUE_EB1D0A10B15E75C71173409_')]/span[text()='" + option + "']"));
    }
    public WebElement clientSignOff(String option) {
        return waitForElementPresent(By.xpath("//label[starts-with(@for,'C4__QUE_F03739927E23D8D81142284_')]/span[text()='" + option + "']"));
    }

    public WebElement GuaranteedArrivalDate(String option) {
        return waitForElementPresent(By.xpath("//label[starts-with(@for,'C4__QUE_F03739927E23D8D81165658_')]/span[text()='" + option + "']"));
    }

    public WebElement reqMsgConstructionValue()
    {
        return waitForElementPresent(By.xpath("//*[@id='C4__QUE_E2F5D92DB8F898C53386073_ERRORMESSAGE']"));
    }
    public List<WebElement> RIBALbl() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_E2F5D92DB8F898C53386063']/div/label"));
    }
    public WebElement RIBA(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].ARBORRIBAMEMBER'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));
    }
    public WebElement reqMsgRIBA(){
        return waitForElementPresent(By.xpath("//*[@id='C4__QUE_E2F5D92DB8F898C53386063_ERRORMESSAGE']"));
    }
    public WebElement largestFee() {
        return waitForElementPresent(By.id("C4__QUE_5A5CBB95DF234F831327202"));
    }

    public WebElement corporateTaxWork(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].LESSTHAN20PERCENTOFFEESRELATEDTOTAXWORK'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));
    }

    public WebElement workCarriedOutSecretarial(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].WORKRELATINGTOSHAREREGISTRATIONEXECUTORSHIPWORKETC'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));
    }

    public WebElement workCarriedOutLloydsOfLondon(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].LLOYDSENTERTAINMENTQUOTEDCOMPANIES'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));
    }

    public WebElement probateOrEstateAdmin(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].AUTHORISEDTODOPROBATEORESTATEADMINWORK'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));
    }

    public WebElement taxAvoidance(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].TAXPLANNINGSCHEMES'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));
    }

    public WebElement qualifiedACA(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].ACAORICAEWQUALIFIED'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));
    }

    public WebElement mortgageTaxAdvice(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].LEGALMORTGAGEORTAXADVICEETC'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));
    }

    public WebElement largestFeeQuestionPresent()
    {
        return waitAndFindElement(By.xpath("//*[@id='C4__p1_QUE_5A5CBB95DF234F831327202']/div/label"));
    }

    public WebElement largestFeeHelpText()
    {
        return waitAndFindElement(By.xpath("//*[@id='C4__p4_QUE_5A5CBB95DF234F831327202']/div/div"));
    }
    public List<WebElement> largestFeeQuestion() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_5A5CBB95DF234F831327202']/div/label"));
    }
    public WebElement taxWorkQuestionPresent()
    {
        return waitAndFindElement(By.xpath("//*[@id='C4__p1_QUE_5A5CBB95DF234F831334492']/div/label"));
    }

    public WebElement taxWorkHelpText()
    {
        return waitAndFindElement(By.xpath("//*[@id='C4__p4_QUE_5A5CBB95DF234F831334492']/div/div[1]"));
    }
    public List<WebElement> taxWorkQuestion() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_5A5CBB95DF234F831334492']/div/label"));
    }
    public WebElement workInRelationQuestionPresent()
    {
        return waitAndFindElement(By.xpath("//*[@id='C4__p1_QUE_5A5CBB95DF234F831334545']/div/label"));
    }

    public WebElement workInRelationHelpText()
    {
        return waitAndFindElement(By.xpath("//*[@id='C4__p4_QUE_5A5CBB95DF234F831334545']/div/div[1]"));
    }
    public List<WebElement> workInQuestion() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_5A5CBB95DF234F831334545']/div/label"));
    }
    public WebElement lloydsQuestionPresent()
    {
        return waitAndFindElement(By.xpath("//*[@id='C4__p1_QUE_5A5CBB95DF234F831334611']/div/label"));
    }

    public WebElement lloydsHelpText()
    {
        return waitAndFindElement(By.xpath("//*[@id='C4__p4_QUE_5A5CBB95DF234F831334611']/div/div[1]"));
    }
    public List<WebElement> lloydsQuestion() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_5A5CBB95DF234F831334611']/div/label"));
    }
    public WebElement authorisedQuestionPresent()
    {
        return waitAndFindElement(By.xpath("//*[@id='C4__p1_QUE_5A5CBB95DF234F831334677']/div/label"));
    }
    public WebElement authorisedHelpText()
    {
        return waitAndFindElement(By.xpath("//*[@id='C4__p4_QUE_5A5CBB95DF234F831334677']/div/div[1]"));
    }
    public List<WebElement> authorisedQuestion() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_5A5CBB95DF234F831334677']/div/label"));
    }
    public WebElement taxPlanningQuestionPresent()
    {
        return waitAndFindElement(By.xpath("//*[@id='C4__p1_QUE_5A5CBB95DF234F831334756']/div/label"));
    }
    public WebElement taxPlanningHelpText()
    {
        return waitAndFindElement(By.xpath("//*[@id='C4__p4_QUE_5A5CBB95DF234F831334756']/div/div[1]"));
    }
    public List<WebElement> taxPlanningQuestion(){ return findElements(By.xpath("//*[@id='C4__p1_QUE_5A5CBB95DF234F831334756']/div/label"));}

    public WebElement aCCAQuestionPresent()
    {
        return waitAndFindElement(By.xpath("//*[@id='C4__p1_QUE_5A5CBB95DF234F831334837']/div/label"));
    }

    public WebElement aCCAHelpText()
    {
        return waitAndFindElement(By.xpath(""));
    }
    public List<WebElement> aCCAQuestion() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_5A5CBB95DF234F831334837']/div/label"));
    }
    public WebElement largestFeeRequired() {
        return waitAndFindElement(By.id("C4__QUE_5A5CBB95DF234F831327202_ERRORMESSAGE"));
    }
    public WebElement taxWorkRequired() {
        return waitAndFindElement(By.id("C4__QUE_5A5CBB95DF234F831334492_ERRORMESSAGE"));
    }
    public WebElement workInRelationRequired() {
        return waitAndFindElement(By.id("C4__QUE_5A5CBB95DF234F831334545_ERRORMESSAGE"));
    }
    public WebElement lloydsRequired() {
        return waitAndFindElement(By.id("C4__QUE_5A5CBB95DF234F831334611_ERRORMESSAGE"));
    }
    public WebElement authorisedRequired() {
        return waitAndFindElement(By.id("C4__QUE_5A5CBB95DF234F831334677_ERRORMESSAGE"));
    }
    public WebElement taxPlanningRequired() {
        return waitAndFindElement(By.id("C4__QUE_5A5CBB95DF234F831334756_ERRORMESSAGE"));
    }
    public WebElement aCCAQualifiedRequired() {
        return waitAndFindElement(By.id("C4__QUE_5A5CBB95DF234F831334837_ERRORMESSAGE"));
    }

    public List<WebElement> bitButton() {
        return findElements(By.id("C4__BUT_E51B872E5D2AA440704822"));
    }

    public WebElement profLiabilityAccordion(String name){
        return waitForElementPresent(By.xpath("//span[contains(text(),'"+name+"')]"));
    }

    public WebElement profLiabilityPopUpText(){
        return waitForElementPresent(By.id("C4__HEAD_523D3ECD008FAE54669865"));
    }

    public WebElement profLiabilityPopUpYesNoOption(String option){
        return waitForElementPresent(By.xpath("//button[starts-with(@name,'C4____7EC19F740010A227')][@value='"+option+"']"));
    }

    public List<WebElement> eleAccordionProfLiability() {
        return findElements(By.xpath("//*[@id='step-2']/span[contains(text(),'Professional Indemnity')]"));
    }

    public List<WebElement> workSpecsQuestion() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_F03739927E23D8D81142278']/div/label"));
    }

    public WebElement workSpecsHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_F03739927E23D8D81142278']/div/div[1]/div"));
    }

    public List<WebElement> clientSignOffQuestion() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_F03739927E23D8D81142284']/div/label"));
    }

    public WebElement clientSignOffHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_F03739927E23D8D81142284']/div/div[1]/div"));
    }

    public List<WebElement> guaranteedArrivalDateQuestion() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_F03739927E23D8D81165658']/div/label"));
    }

    public WebElement guaranteedArrivalDateHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C4__p4_QUE_F03739927E23D8D81165658']/div/div[1]/div"));
    }

    public List<WebElement> tradeGroup5ErrorMsg() {
        return findElements(By.xpath("//label[starts-with(@id,'C4__QUE_F03739927E23D8D')]"));
    }


    public List<WebElement> tradeGroup6ErrorMsg() {
        return findElements(By.xpath("//div[@id='C4__FMT_D03457217C638E8E1445792']/div[1]/div/div/label[text()='Required']"));
    }

    public WebElement settleClaims(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].AUTHTOSETTLECLAIMSWITHOUTREFERRAL'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));
    }
    public WebElement financialSettlement(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C4__DIRECTLINE[1].YOURBUSINESS[1].PROFESSIONALLIABILITY[1].FINANCIALSETTLEMENTWITHOUTREFERRAL'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));
    }
    public List<WebElement> settleClaimsQuestion() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_D2F2DCAD4567F6332539916']/div/label"));
    }
    public List<WebElement> financialSettlementQuestion() {
        return findElements(By.xpath("//*[@id='C4__p1_QUE_D2F2DCAD4567F6332539922']/div/label"));
    }





}
