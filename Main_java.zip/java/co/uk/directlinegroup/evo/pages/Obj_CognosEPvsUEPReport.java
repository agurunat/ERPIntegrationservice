package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Obj_CognosEPvsUEPReport extends AbstractPage {

    public WebElement reportDateRangeOkButton() {
        return waitForElementVisible(By.xpath("(//button[@class='bp']/span)[2]"));
    }
}
