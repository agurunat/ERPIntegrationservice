package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import net.serenitybdd.core.annotations.findby.By;
import org.openqa.selenium.WebElement;

public class Obj_SS_Dashboard extends AbstractPage {

    public WebElement BannerText() {
        return waitForElementPresent(By.xpath("//*[@id=\"FMT_7F8F110B7A232E78358483_R1\"]/h4/a/div[2]"));

    }



}