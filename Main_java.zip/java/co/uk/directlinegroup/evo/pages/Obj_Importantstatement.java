package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Obj_Importantstatement extends AbstractPage {

    public WebElement agreeRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='C10__p4_QUE_DA77AAE2AA61CFD0865']/div/div/label[1]/span"));
    }

    public WebElement disAgreeRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='C10__p4_QUE_DA77AAE2AA61CFD0865']/div/div/label[2]/span"));
    }

    public WebElement importantStatNextButton() {
        return waitForUnstableElement(By.xpath("//*[@id='C10__BUT_IS_006AB5B0B0C7206C622756' or @id='C10__BUT_006AB5B0B0C7206C622756']"));
    }

    public WebElement importantStatSaveExitButton() {
        return waitForUnstableElement(By.id("C2__BUT_D3E81D5ED026892F942222"));
    }

    public WebElement importantStatSaveExitPopUpButton() {
        return waitForElementPresent(By.xpath("//*[@id='BUT_D3E81D5ED026892F1577152']"));
    }

    public WebElement bbdonotAcceptGuestText() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_4F86F04D0E5C0FBA7355897']/div/div/div[2]/div[1]"));
    }

    public WebElement bbcompliesText() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_4F86F04D0E5C0FBA7355897']/div/div/div[2]/div[2]"));
    }

    public WebElement hbdonotAcceptGuestText() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_4F86F04D0E5C0FBA7355897']/div/div/div[2]/div"));
    }

    public WebElement premisesDependentStatement() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_4F86F04D0E5C0FBA7355902']/div/div/div[2]/div"));
    }

    public WebElement bbHolidaycenterStatement() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_4F86F04D0E5C0FBA7355902']/div/div/div[2]/div[2]"));
    }

    public WebElement bbOvernightStatement() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_4F86F04D0E5C0FBA7355902']/div/div/div[2]/div[3]"));
    }

    public WebElement bbContents() {
        return waitForUnstableElement(By.xpath(".//*[@id='C9__TXT_4F86F04D0E5C0FBA7355897']/div/div/div[2]"));
    }

    public WebElement bbHolidaycenterOvernightStatement() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_4F86F04D0E5C0FBA7355902']/div/div/div[2]"));
    }

    public WebElement contentsImpStmtHbfull() {
        return waitForUnstableElement(By.id("C9__step-imp-stmt"));
    }
}