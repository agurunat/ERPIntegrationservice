package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Obj_CognosWorkBasketReport extends AbstractPage {

    public WebElement snapShotRangeLabel() {
        return waitForElementVisible(By.xpath("//*[@id='rt_NS_']/tbody/tr[2]/td/div[1]"));
    }

    public WebElement emptyRecordLabel() {
        return waitForElementVisible(By.xpath("//*[@id='rt_NS_']/tbody/tr[2]/td/div[3]/span"));
    }

}
