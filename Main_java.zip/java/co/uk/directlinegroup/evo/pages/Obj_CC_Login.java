package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import net.serenitybdd.core.annotations.findby.By;
import org.openqa.selenium.WebElement;

public class Obj_CC_Login extends AbstractPage {

    public WebElement userNameTextbox() {
        return waitForUnstableElement(By.id("C2__QUE_ED508ADA5C44080859323"));
    }

    public WebElement passwordTextbox() {
        return waitForUnstableElement(By.id("C2__QUE_ED508ADA5C44080859331"));
    }

    public WebElement loginButton() {
        return waitForUnstableElement(By.id("C2__BUT_ED508ADA5C44080859357"));
    }

    public WebElement contactCentre() {
        return waitAndFindElement(By.xpath(".//*[@id='TXT_EF285CEB836D4C46171045']/div/div"));
    }

    public WebElement takeACallLink() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__BUT_8A211A5516D895E938601']/span/span"));

    }

    public WebElement makeACallLink() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__BUT_8A211A5516D895E944140']/span/span"));
    }

    public WebElement adminTaskLink() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__BUT_8A211A5516D895E944146']/span/span"));
    }


    public WebElement passedVerificationButton() {
        return waitForElementPresent(By.id("BUT_9252AAA206FD524963824"));
    }

    public WebElement manageQuoteLink() {
        return waitForElementPresent(By.xpath("//*[@id='TXT_48B4D9E9C6401711130844']/div/div/ul/li[3]/a"));
    }

    public WebElement manageQuoteEditLink() {
        return waitForElementPresent(By.xpath("//*[@id='TXT_48B4D9E9C6401711130844']/div/div/ul/li[3]/ul/li/a"));
    }

    public WebElement financeLink() {
        return waitForElementPresent(By.xpath("//*[@id='finance']"));
    }

    public WebElement takePaymentLink() {
        return waitForElementPresent(By.xpath("//*[@id='takepayment']"));
    }

    public WebElement dashboard() {
        return waitForElementPresent(By.id("BUT_05DBD1E701916C229354357"));
    }
    public WebElement backToDashboardButton() {
   return waitForElementPresent(By.id("C2__BUT_7F3FA2E6447B80DD2181412"));

    }

    public WebElement nameOnCardTextBox() {
        return waitForElementPresent(By.id("QUE_0C2583479F42ED0E337154"));
    }

    public WebElement takeAPaymentLink() {
        return waitForElementPresent(By.xpath("//*[@id='BUT_C80027C771EADC7C565485']"));
    }

    public WebElement policyNumberGet() {
        return waitForElementPresent(By.xpath("//*[@id='p4_QUE_48B4D9E9C6401711205890']/div/div"));
    }
    public WebElement installmentCheckbox() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__FS_QUE_EB05634B0D109C89693217_0_R1']"));

    }
    public WebElement takePaymentLinkEC() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C6__takepayment']"));
    }
    public WebElement nameOnCardEC() {
        return waitForElementPresent(By.id("C2__C6__QUE_5D69B1F797D9E483296377"));
    }
    public WebElement takeAPaymentLinkEC() {
        return waitForElementPresent(By.id("C2__C6__BUT_C80027C771EADC7C565485"));
    }

    public WebElement closePopup() {
        return waitForElementPresent(By.id("C2__C6__BUT_753975C04A0241C1683286"));
    }
    public WebElement paymentAmountTextBoxEC() {
        return waitForElementPresent(By.id("C2__C6__QUE_753975C04A0241C1683262"));
    }

    public WebElement paymentAmountDue() {
        return waitForElementPresent(By.xpath("//*[@id='finance_table']/tbody/tr/td[5]"));
    }

    public WebElement paymentAmountPopUpDue() {
        return waitForElementPresent(By.xpath("//input[@id='C2__C6__QUE_753975C04A0241C1683262']"));

    }

    public WebElement tnxId() {
        return waitForElementPresent(By.xpath("//*[@id=\"C2__C6__p1_QUE_int5D69B1F797D9E483296377\"]/div/label/label"));

    }




}
