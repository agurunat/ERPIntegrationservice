package co.uk.directlinegroup.evo.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 * Created by 323996 on 9/5/2017.
 */
public class Obj_CognosMarketingPreferenceReport extends Obj_CognosReportCommon {
    public WebElement snapShotRangeLabel() {
        return waitForElementVisible(By.xpath("//*[@id='rt_NS_']/tbody/tr[2]/td/table/tbody/tr/td"));
    }


}
