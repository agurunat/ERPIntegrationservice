package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Obj_Carddetails extends AbstractPage {

    public WebElement masterCardLink() {
        return waitForUnstableElement(By.xpath("//*[@alt='MasterCard']"));
    }

    public WebElement cardNumberTextbox() {
        return waitForUnstableElement(By.id("cardNumber"));
    }

    public WebElement cardVerificationCodeTextbox() {
        return waitForUnstableElement(By.id("securityCode"));
    }

    public WebElement cardExpiryMMDropdown() {
        return waitForUnstableElement(By.id("expiryMonth"));
    }
    public WebElement cardExpiryMM(String text) {
        return waitForUnstableElement(By.xpath("//select[@id='expiryMonth']/option[@value='"+text+"']"));
    }

    public WebElement cardExpiryYYYYDropdown() {
        return waitForUnstableElement(By.id("expiryYear"));
    }
    public WebElement cardExpiryYYYY(String text) {
        return waitForUnstableElement(By.xpath("//select[@id='expiryYear']/option[@value='"+text+"']"));
    }

    public WebElement cardholderNameTextbox() {
        return waitForUnstableElement(By.id("name"));
    }

    public WebElement buyPolicyButton() {
        return waitForUnstableElement(By.id("op-PMMakePayment"));
    }

    public WebElement cancelPaymentButton() {
        return waitForUnstableElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[3]/td/table/tbody/tr/td[2]/form/table/tbody/tr/td/table/tbody/tr[10]/td/nobr/a/img"));
    }

    public WebElement sppContinueButton() {
        return waitForUnstableElement(By.id("submitButton"));
    }

    public WebElement avsResponse() {
        return waitForUnstableElement(By.cssSelector("option[value=AAAA][selected]"));
    }

    public WebElement acquireResponse() {
        return waitForUnstableElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[3]/td/table/tbody/tr[1]/td[2]/form/table/tbody/tr/td/table/tbody/tr[4]/td/table/tbody/tr/td/table/tbody/tr[3]/td[2]/select"));
    }

    public WebElement paymentFailureMessege() {
        return waitForUnstableElement(By.xpath("//*[@id='C1__TXT_D2EEAD46E0D90E16859767']/div"));
    }

    public WebElement policyNumberFetch() {
        return waitForElementPresent(By.xpath("//span[@id='C1__QUE_4AB6451013067184536351']"));

    }

    public WebElement VisaCardLink() {
        return waitForUnstableElement(By.name("op-DPChoose-VISA^SSL"));
    }

    public WebElement AmexCardLink() {
        return waitForUnstableElement(By.name("op-DPChoose-AMEX^SSL"));
    }

    public WebElement MasteroCardLink() {
        return waitForUnstableElement(By.name("op-DPChoose-MAESTRO^SSL"));
    }

    public WebElement coversStartDate() {
        return waitForElementPresent(By.xpath("//span[@id='C1__QUE_4AB6451013067184536353']"));
    }

    public WebElement coversEndDate() {
        return waitForElementPresent(By.xpath("//span[@id='C1__QUE_4AB6451013067184536355']"));
    }

    public WebElement confirmationPaymentpage() {
        return waitForElementPresent(By.xpath("//*[@id='C1__HEAD_4AB6451013067184536347']"));
    }
    public WebElement paymentConfirmationPolicySchedulePdf(){
        return waitForUnstableElement(By.id("C1__BUT_4AB6451013067184536361"));
    }
    public WebElement paymentConfirmationKeyFactsPdf(){
        return waitForElementPresent(By.xpath("//*[@id='C1__p4_BUT_4AB6451013067184536363']"));
    }
    public WebElement paymentConfirmationSOFPdf(){
        return waitForElementPresent(By.xpath("//*[@id='C1__p4_BUT_4AB6451013067184536365']"));
    }
    public WebElement paymentConfirmationPolicyWordingPdf(){
        return waitForElementPresent(By.xpath("//*[@id='C1__p4_BUT_4AB6451013067184536367']"));
    }
    public WebElement paymentConfirmationPPLCertificatePdf(){
        return waitForElementPresent(By.xpath("//*[@id='C1__p4_BUT_4010E7D9A54E937C1556862']"));
    }
    public WebElement paymentConfirmationCOCPdf(){
        return waitForElementPresent(By.xpath("//*[@id='C1__p4_BUT_4010E7D9A54E937C1556870']"));
    }
}
