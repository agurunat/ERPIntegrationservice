package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Obj_Directdebit extends AbstractPage {

    public WebElement directdebitYesRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='radio_C1__QUE_B7C86A0090A9962F1273009']/label[1]/span"));
    }

    public WebElement directDebitNoRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='TXT_FAE554C988A5F3932837']/div/div[1]"));
    }

    public WebElement sortCodeTextbox() {
        return waitForUnstableElement(By.id("C1__QUE_B7C86A0090A9962F1273015"));
    }

    public WebElement accountNumberTextbox() {
        return waitForElementToBeClickableAndReturnElement(By.id("C1__QUE_B7C86A0090A9962F1273018"));
    }

    public WebElement installmentdayTextbox() {
        return waitForUnstableElement(By.id("C1__QUE_B7C86A0090A9962F1273021"));
    }

    public WebElement paymentInformationNextButton() {
        return waitForUnstableElement(By.id("C1__BUT_0DC24C42BC95DBE3725311"));
    }
}