package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import net.serenitybdd.core.annotations.findby.By;
import org.openqa.selenium.WebElement;


public class Obj_Notes extends AbstractPage {

    public WebElement Addnotes() {
        return waitForUnstableElement(By.id("opener"));
    }

    public WebElement AddnotesTitle() {
        return waitForUnstableElement(By.id("C2__C6__QUE_6626AE11CA31B27E731132"));
    }

    public WebElement AddnotesContent() {
        return waitForUnstableElement(By.id("C2__C6__QUE_6626AE11CA31B27E731135"));
    }

    public WebElement AddnotesSave() {
        return waitForUnstableElement(By.id("C2__C6__BUT_6626AE11CA31B27E731273"));
    }

    public WebElement ViewPolicyNotes() {
        return waitForUnstableElement(By.id("accordian_collapseNine"));
    }



    public WebElement   passVerf() {
        return waitForUnstableElement(By.id("C2__BUT_9252AAA206FD524963824"));
    }


    public WebElement viewAllNotes() {
        return waitForUnstableElement(By.id("C2__C5__View_All_Notes"));


    }

    public WebElement FinanceTab() {
        return waitForUnstableElement(By.id("finance"));
    }

    public WebElement ViewNoteSingle() {
        return waitForUnstableElement(By.id("C2__C5__View-Policy-Notes_R1"));
    }

    public WebElement EngagementCenterText() {
        return waitForUnstableElement(By.xpath("//*[@id=\"C1__TXT_5866E32A0412B1F932558\"]/div/div"));
    }



}
