package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_Importantstatement;
import org.junit.Assert;

import java.util.List;

public class ImpornantUtil {

    private Obj_Importantstatement impornantstatement = new Obj_Importantstatement();
    private CommonUtil commonutil = new CommonUtil();

    public void importantStatement(List<List<String>> data, String fieldName) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        if (StrVal.equalsIgnoreCase("Yes")) {
            impornantstatement.executeScript("arguments[0].click();", impornantstatement.agreeRadiobutton());
        } else {
            impornantstatement.executeScript("arguments[0].click();", impornantstatement.disAgreeRadiobutton());
        }
    }

    public void bbImpornantStatementText(List<List<String>> validationContents) {
        String contentFromPage = impornantstatement.bbContents().getText();
        String contentFromPages[] = contentFromPage.split("\n");
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(contentFromPages[i - 1] + "is displayed", validationContents.get(i).get(0).equalsIgnoreCase(contentFromPages[i - 1]));
            }
        }
    }

    public void hbImpornantStatementText(List<List<String>> validationContents) {
        String contentFromPage = impornantstatement.hbdonotAcceptGuestText().getText();
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(contentFromPage + "is not displayed", !validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            }
        }
    }

    public void hbpremisesDependentText(List<List<String>> validationContents) {
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                String contentFromPage = impornantstatement.hbdonotAcceptGuestText().getText();
                Assert.assertTrue("Specific is not displayed", !validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            } else if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                String contentFromPage = impornantstatement.premisesDependentStatement().getText();
                Assert.assertTrue(contentFromPage + "is displayed", validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            }
        }
    }

    public void bbpremisesDependentText(List<List<String>> validationContents) {
        String premisesDependentText = impornantstatement.bbHolidaycenterOvernightStatement().getText();
        String bbpremisesDependentText[] = premisesDependentText.split("\n");
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(bbpremisesDependentText[i - 1] + "is displayed", validationContents.get(i).get(0).equalsIgnoreCase(bbpremisesDependentText[i - 1]));
            }
        }
    }

    public void hbSpecificImpornantStatementText(List<List<String>> validationContents) {
        String contentFromPage = impornantstatement.hbdonotAcceptGuestText().getText();
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$ ")) {
                Assert.assertTrue(contentFromPage + "is not displayed", !validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            }
        }
    }

    public void hbYourPremisesText(List<List<String>> validationContents) {
        String premisesDependentText = impornantstatement.bbHolidaycenterOvernightStatement().getText();
        String bbpremisesDependentText[] = premisesDependentText.split("\n");
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                if (!validationContents.get(i).get(0).equalsIgnoreCase(bbpremisesDependentText[0])) {
                    Assert.assertTrue(bbpremisesDependentText[0] + "is not displayed", true);
                } else {
                    Assert.assertTrue(bbpremisesDependentText[0] + "is displayed", false);
                }
            }
        }
    }
}