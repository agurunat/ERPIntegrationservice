package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_Contacts;

import java.util.List;

public class ContactsUtil {

    private CommonUtil commonutil = new CommonUtil();
    private Obj_Contacts contacts = new Obj_Contacts();

    public void contacts(List<List<String>> data, String fieldName) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        if (StrVal.equalsIgnoreCase("Yes")) {
            contacts.executeScript("arguments[0].click();", contacts.makeChangesYesRadiobutton());
        } else {
            contacts.executeScript("arguments[0].click();", contacts.makeChangesNoRadiobutton());
        }
    }

}
