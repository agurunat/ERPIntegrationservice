package co.uk.directlinegroup.evo.utils;

/*
    Concatenate Claim number and Transaction id and validate against CSV (target table) file
 */

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.util.Scanner;


public class ARConcatenateTagFileCompare extends  Reader {

    String xmlId = null;

    public static void main(String[] args) {
        try {

            /*Reader rd = new Reader();
            String getCellValue = rd.lookUpreference();
            */

            String csvSplitBy = ",";
            // ----------- read XML File ----------------------------
            File inputFile = new File("C:\\Test\\AR_Trans.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

            NodeList nList = doc.getElementsByTagName("dlg_ar_transaction");
            System.out.println("----------------------------");
            for (int j = 0; j < nList.getLength(); j++) {
                Node nNode = nList.item(j);
                System.out.println("\nCurrent Element :" + nNode.getNodeName());
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    String xmlId = eElement
                            .getElementsByTagName("id")
                            .item(0)
                            .getTextContent();

                    // --------- Read the csv file ------------------
                    Scanner out = new Scanner(new BufferedReader(new FileReader("C:\\Test\\ARConcatenateTagFileCompare.csv")));
                    while (out.hasNextLine()) {
                        String data = out.nextLine();
                        String[] value = data.split(csvSplitBy);
                        for (int csv = 0; csv < value.length; csv++) {
                            if (value[csv].equals(xmlId)) {
                                //------------ validate id tag ---------------
                                String xmlID = eElement
                                        .getElementsByTagName("id")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(xmlID)) {
                                    System.out.println("XML id :-" + xmlID + " is matching with CSV File:-" + value[csv] + " ------------ > PASS");
                                    csv++;
                                } else {
                                    System.out.println("id is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }

                                //------------ validate Base Currency Amount  ---------------
                                String xmlbaseCurrencyAmount = eElement
                                        .getElementsByTagName("base_currency_amount")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("base_currency_amount")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Base Currency Amount :-" + xmlbaseCurrencyAmount + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Base Currency Amount is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }

                                //------------ validate Currency cd  ---------------
                                String xmlcurrencyCode = eElement
                                        .getElementsByTagName("currency_cd")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("currency_cd")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Currency cd :-" + xmlcurrencyCode + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Currency cd is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }

                                //------------ validate claim number ---------------
                                String xmlclaimNumber = eElement
                                        .getElementsByTagName("claim_number")
                                        .item(0)
                                        .getTextContent();

                                //------------ validate Transaction id ---------------
                                String xmltransactionId = eElement
                                        .getElementsByTagName("transaction_id")
                                        .item(0)
                                        .getTextContent();
                                String xmlupdateTransID = xmlclaimNumber + xmltransactionId;

                                //----------- CSV transaction value concatenate claim number and transaction id in xml -------
                                if (value[csv].equals(xmlupdateTransID)) {
                                    System.out.println("XML Transaction id :-" + xmltransactionId + " is matching concatenated Claim number with CSV File:-" + value[csv] + " ------ > PASS");
                                    csv++;
                                } else {
                                    System.out.println("XML Transaction id :-" + xmltransactionId + " is not matching concatenated Claim number with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }

                                //------------ validate Transaction id alone ---------------
                                String xmltransactionId1 = eElement
                                        .getElementsByTagName("transaction_id")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("transaction_id")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Transaction id :-" + xmltransactionId1 + " is matching with CSV File:-" + value[csv] + " ------------ > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Recovery ref is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }

                                //------------ validate Payer Name   ---------------
                                String xmlpayerName = eElement
                                        .getElementsByTagName("payer_name")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("payer_name")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Payer Name :-" + xmlpayerName + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Payer Name is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }

                            }
                        }
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}



