package co.uk.directlinegroup.evo.utils;


/*
    Validate all the direct Map fields from Source table and validate against CSV (target table) file
 */

import co.uk.directlinegroup.evo.utils.common.SampleExcelReader;

import org.junit.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.*;
import java.util.Scanner;



public class ARDirectMapFileCompare extends SampleExcelReader {

    String xmlId = null;
    public static void main(String[] args)  {

        try {
            String csvSplitBy = ",";
            // ----------- read XML File ----------------------------
            File inputFile = new File("C:\\Test\\AR_Trans.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

            NodeList nList = doc.getElementsByTagName("dlg_ar_transaction");
            System.out.println("----------------------------");
            for(int j = 0; j < nList.getLength(); j++){
                Node nNode = nList.item(j);
                System.out.println("\nCurrent Element :" + nNode.getNodeName());
                if(nNode.getNodeType() == Node.ELEMENT_NODE){
                    Element eElement = (Element) nNode;
                    String xmlId = eElement
                            .getElementsByTagName("id")
                            .item(0)
                            .getTextContent();

                    // --------- Read the csv file ------------------
                    Scanner out = new Scanner(new BufferedReader(new FileReader("C:\\Test\\ARDirectMapFileCompare.csv")));
                    while(out.hasNextLine()){
                        String data = out.nextLine();
                        String[] value = data.split(csvSplitBy);
                        for(int csv = 0; csv < value.length;csv++){
                            if(value[csv].equals(xmlId)) {
                                //------------ validate id tag ---------------
                                String xmlID = eElement
                                        .getElementsByTagName("id")
                                        .item(0)
                                        .getTextContent();
                                //Assert.assertTrue(value[csv].equals(xmlID));
                                Assert.assertTrue("XML id :-\" + xmlID + \" is matching with CSV File:-\"' + value[csv] + ",value[csv].equals(xmlID));
                                if (value[csv].equals(xmlID)) {
                                    System.out.println("XML id :-" + xmlID + " is matching with CSV File:-" + value[csv] + " ------------ > PASS");

                                    csv++;
                                } else {
                                    System.out.println("id is not matching with CSV File:-" + value[csv]+ " ------------ > FAIL");
                                }

                                //------------ validate source tag ---------------
                                String xmlSource = eElement
                                        .getElementsByTagName("source")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(xmlSource)) {
                                    System.out.println("XML source :- " + xmlSource + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                    csv++;
                                    //Assert.assertTrue(value[csv].equals(xmlSource));
                                } else {
                                    System.out.println("source is not matching with CSV File:-" + value[csv]+ " ------------ > FAIL");
                                }

                                //------------ validate claim number ---------------
                                String xmlclaimNumber = eElement
                                        .getElementsByTagName("claim_number")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("claim_number")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML claim number :-" + xmlclaimNumber + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                    csv++;
                                } else {
                                    System.out.println("claim number is not matching with CSV File:-" + value[csv]+ " ------ > FAIL");
                                }
                                //------------ validate Recovery ref ---------------
                                String xmlRecovery_ref = eElement
                                        .getElementsByTagName("recovery_ref")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("recovery_ref")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Recovery ref :-" + xmlRecovery_ref + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Recovery ref is not matching with CSV File:-" + value[csv]+ " ------------ > FAIL");
                                }

                                //------------ validate Transaction id ---------------
                                String xmltransactionId = eElement
                                        .getElementsByTagName("transaction_id")
                                        .item(0)
                                        .getTextContent();
                                String xmlupdateTransID = xmlclaimNumber + xmltransactionId;

                                //----------- CSV transaction value concatenate claim number and transaction id in xml -------
                                if (value[csv].equals(xmlupdateTransID)) {
                                    System.out.println("XML Transaction id :-" + xmltransactionId + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                    csv++;
                                } else {
                                    System.out.println("XML Transaction id :-" + xmltransactionId + " is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }

                                //------------ validate Payer Reference ---------------
                                String xmlpayerRef = eElement
                                        .getElementsByTagName("payer_reference")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("payer_reference")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Payer Reference :- " + xmlpayerRef + "  is matching with CSV File:-" + value[csv]+ " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Payer Reference is not matching with CSV File:-" + value[csv]+ " ------------ > FAIL");
                                }

                                //------------ validate Policy Number ---------------
                                String xmlpolicyNumber = eElement
                                        .getElementsByTagName("policy_number")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("policy_number")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Policy Number:- " + xmlpolicyNumber + " is matching with CSV File:-" + value[csv]+ " ------ > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Policy Number is not matching with CSV File:-" + value[csv]+ " ------------ > FAIL");
                                }

                                //------------ validate Payer Type ---------------
                                String xmlpayerType = eElement
                                        .getElementsByTagName("payer_type")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("payer_type")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Payer Type :-" +xmlpayerType+ " is matching with CSV File:-" + value[csv]+ " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Payer Type is not matching with CSV File:-" + value[csv]+ " ------------ > FAIL");
                                }
                                //------------ validate Recovery Category ---------------
                                String xmlRecoveryCatg = eElement
                                        .getElementsByTagName("recovery_category")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("recovery_category")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Recovery Category :-" + xmlRecoveryCatg + " is matching with CSV File:-" + value[csv]+ " ------ > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Recovery Category is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }
                                //------------ validate Change Type ---------------
                                String xmlChangeType = eElement
                                        .getElementsByTagName("change_type")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("change_type")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Change Type :- " + xmlChangeType + " is matching with CSV File:-" + value[csv]+ " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Change Type is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }
                                //------------ validate Transaction Type ---------------
                                String xmlTransactionType = eElement
                                        .getElementsByTagName("transaction_type")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("transaction_type")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Transaction Type :- " + xmlTransactionType + " is matching with CSV File:-" + value[csv]+ " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Transaction Type is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }
                                //------------ validate Underwriter ---------------
                                String xmlUnderwriter = eElement
                                        .getElementsByTagName("underwriter")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("underwriter")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Underwriter :- " + xmlUnderwriter + "  is matching with CSV File:-" + value[csv]+ " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Underwriter is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }

                                //------------ validate Brand ---------------
                                String xmlbrand= eElement
                                        .getElementsByTagName("brand")
                                        .item(0)
                                        .getTextContent();
                                if(xmlbrand.equals("BIS_Ins")){
                                    xmlbrand = "BIS_Ins";
                                    String csvbrand = value[csv];
                                    if (csvbrand .equals("NIG_Ins")){
                                        System.out.println("XML Brand :- " + xmlbrand + " is matching with CSV File:-" + value[csv]+ " ------ > PASS");
                                        csv++;
                                    }
                                }
                                else if (value[csv].equals(xmlbrand)) {
                                    System.out.println("XML Brand :- " + xmlbrand + " is matching with CSV File:-" + value[csv]+ " ------ > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Brand is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }
                                //------------ validate Product Type ---------------
                                String xmlProductType = eElement
                                        .getElementsByTagName("product_type")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("product_type")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Product Type :-" + xmlProductType + " is matching with CSV File:-" + value[csv]+ " ------ > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Product Type is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }
                                //------------ validate Product  ---------------
                                String xmlProduct = eElement
                                        .getElementsByTagName("product")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("product")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Product :- " + xmlProduct + " is matching with CSV File:-" + value[csv]+ " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Product is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }
                                //------------ validate Cost Type  ---------------
                                String xmlcostType = eElement
                                        .getElementsByTagName("cost_type")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("cost_type")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Cost Type :- " + xmlcostType + " is matching with CSV File:-" + value[csv]+ " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Cost Type is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }
                                //------------ validate channel  ---------------
                                String xmlchannel = eElement
                                        .getElementsByTagName("channel")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("channel")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML channel :-" + xmlchannel + " is matching with CSV File:-" + value[csv]+ " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("channel is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }
                                //------------ validate Transaction Date  ---------------
                                String xmltransactionDate = eElement
                                        .getElementsByTagName("transaction_date")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("transaction_date")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Transaction Date :- " + xmltransactionDate + "i s matching with CSV File:-" + value[csv]+ " ------ > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Transaction Date is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }
                                //------------ validate currency_amount  ---------------
                                String xmlcurrencyAmount = eElement
                                        .getElementsByTagName("currency_amount")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("currency_amount")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Currency Amount :-" + xmlcurrencyAmount + " is matching with CSV File:-" + value[csv]+ " ------ > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Currency Amount is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }
                                //------------ validate Base Currency Amount  ---------------
                                String xmlbaseCurrencyAmount = eElement
                                        .getElementsByTagName("base_currency_amount")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("base_currency_amount")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Base Currency Amount :-" + xmlbaseCurrencyAmount + " is matching with CSV File:-" + value[csv]+ " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Base Currency Amount is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }
                                //------------ validate Currency cd  ---------------
                                String xmlcurrencyCode = eElement
                                        .getElementsByTagName("currency_cd")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("currency_cd")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Currency cd :-" + xmlcurrencyCode + " is matching with CSV File:-" + value[csv]+ " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Currency cd is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }
                                //------------ validate Exchange Rate   ---------------
                                String xmlexchangeRate = eElement
                                        .getElementsByTagName("exchange_rate")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("exchange_rate")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Exchange Rate :- " + xmlexchangeRate + " is matching with CSV File:-" + value[csv]+ " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Exchange Rate is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }
                                //------------ validate Exchange Rate Type   ---------------
                                String xmlexchangeRateType = eElement
                                        .getElementsByTagName("exchange_rate_type")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("exchange_rate_type")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Exchange Rate Type :-" + xmlexchangeRateType + " is matching with CSV File:-" + value[csv]+ " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Exchange Rate Type is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }
                                //------------ validate Payer Name   ---------------
                                String xmlpayerName = eElement
                                        .getElementsByTagName("payer_name")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("payer_name")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Payer Name :-" + xmlpayerName + " is matching with CSV File:-" + value[csv]+ " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("XML Payer Name :-" + xmlpayerName + " is not matching with CSV File:-" + value[csv]+ " ----- > FAIL");
                                }
                            }
                        }
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }catch (ParserConfigurationException e) {
            e.printStackTrace();
        }catch (SAXException e) {
            e.printStackTrace();
        }
    }


}
