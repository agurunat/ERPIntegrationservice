package co.uk.directlinegroup.evo.utils;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jruby.RubyProcess;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;

public class Reader_AP {

    public String lookUpAPreference_AP(String lookupValue,String Sheetname,int s_column_no,int t_coloum_no) throws Exception {
        String conversionRef = null;
        String vendor_site_code = null;
        String vendor_name = null;
        String Type = null;

        String filePath = "C:\\Test\\POC Mapping Sheet\\";
        //String fileName = "Test.xlsx";
        String fileName = "POC Mapping values1.2_Cons.xlsx";
        File file = new File(filePath + "\\" + fileName);
        InputStream ExcelFileToRead = new FileInputStream(file);
        XSSFWorkbook wb = new XSSFWorkbook(ExcelFileToRead);
        XSSFSheet sheet = wb.getSheet(Sheetname);
        DataFormatter dataFormatter = new DataFormatter();

        for (Row nextRow : sheet) {
            Type = dataFormatter.formatCellValue(nextRow.getCell(s_column_no));
            vendor_site_code = dataFormatter.formatCellValue(nextRow.getCell(s_column_no));

            if (Type.equals(lookupValue)) {
                conversionRef = dataFormatter.formatCellValue(nextRow.getCell(t_coloum_no));
                break;
            } else if (vendor_site_code.equals(lookupValue)) {
                conversionRef = dataFormatter.formatCellValue(nextRow.getCell(t_coloum_no));
                break;
            }
            ExcelFileToRead.close();
        }
        return conversionRef;

    }
}
