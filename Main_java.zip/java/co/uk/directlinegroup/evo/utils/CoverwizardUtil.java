package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_Coverwizard;
import com.usmanhussain.habanero.framework.AbstractPage;

import java.util.List;

public class CoverwizardUtil extends AbstractPage {

    public static String tradename = null;
    private CommonUtil commonutil = new CommonUtil();
    private Obj_Coverwizard coverwizard = new Obj_Coverwizard();

    public void business(List<List<String>> data, String fieldName) throws Throwable {
        String strValue = commonutil.datapicker(data, fieldName);
        String[] businesvalue = strValue.split(";");
        for (int i = 0; i < businesvalue.length; i++) {
            if (businesvalue[i].equalsIgnoreCase("WFH")) {
                commonutil.clickbyJS(coverwizard.workFromHomeCheckbox());
            } else if (businesvalue[i].equalsIgnoreCase("Salon")) {
                commonutil.clickbyJS(coverwizard.ownSalonCheckbox());
            } else if (businesvalue[i].equalsIgnoreCase("RentChair")) {
                commonutil.clickbyJS(coverwizard.rentChairCheckbox());
            } else if (businesvalue[i].equalsIgnoreCase("Mobile")) {
                commonutil.clickbyJS(coverwizard.mobileCheckbox());
            }
        }
    }

    public void employees(List<List<String>> data, String fieldName) throws Throwable {
        String haveEmp = commonutil.datapicker(data, fieldName);
        waitForPageLoad();
        if (haveEmp.equalsIgnoreCase("No")) {
            coverwizard.executeScript("arguments[0].click();", coverwizard.noEmployeesRadiobutton());
        } else if (haveEmp.equalsIgnoreCase("TemporaryEmployee")) {
            coverwizard.executeScript("arguments[0].click();", coverwizard.temporaryEmployeesRadiobutton());
        } else if (haveEmp.equalsIgnoreCase("PermanentEmployee")) {
            coverwizard.executeScript("arguments[0].click();", coverwizard.permanentEmployeesRadiobutton());
        } else if (haveEmp.equalsIgnoreCase("PermanentAndTempEmployee")) {
            coverwizard.executeScript("arguments[0].click();", coverwizard.permanentTemporaryEmployeesRadiobutton());
        }
    }

    public void coversSelection(List<List<String>> data, String fieldName) throws Throwable {
        String coverVal = commonutil.datapicker(data, fieldName);
        waitForPageLoad();
        tradename = coverwizard.tradeNameTextbox().getAttribute("value");
        String[] coverSele = coverVal.split(";");
        for (String covers : coverSele) {
            if (covers.equalsIgnoreCase("HairandBeauty")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.hairAndBeautyCheckbox());
            } else if (covers.equalsIgnoreCase("Theft")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.theftOfTakingsCheckbox());
            } else if (covers.equalsIgnoreCase("BusinessStock")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.businessStockCheckbox());
            } else if (covers.equalsIgnoreCase("BusinessTools")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.businessToolsCheckbox());
            } else if (covers.equalsIgnoreCase("BusinessContent")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.businessContentCheckbox());
            } else if (covers.equalsIgnoreCase("Business interruption")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.businessInterruptionCheckbox());
            } else if (covers.equalsIgnoreCase("None")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.noneCheckbox());
            }
        }
    }

    public void empLiability(List<List<String>> data, String fieldName) throws Throwable {
        String options = commonutil.datapicker(data, fieldName);
        waitForPageLoad();
        if (!options.equalsIgnoreCase("")) {
            if (options.equalsIgnoreCase("No")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.employersLiabilityCoverNoRadiobutton());
            } else if (options.equalsIgnoreCase("Yes")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.employersLiabilityCoverYesRadiobutton());
            }
        }
    }

    public void bbEmpLiability(List<List<String>> data, String fieldName) throws Throwable {
        String options = commonutil.datapicker(data, fieldName);
        waitForPageLoad();
        if (options.equalsIgnoreCase("No")) {
            coverwizard.executeScript("arguments[0].click();", coverwizard.bbEmployersLiabilityCoverNoRadiobutton());
        } else if (options.equalsIgnoreCase("Yes")) {
            coverwizard.executeScript("arguments[0].click();", coverwizard.bbEmployersLiabilityCoverYesRadiobutton());
        }
    }

    public void livePremises(List<List<String>> data, String fieldName) throws Throwable {
        String options = commonutil.datapicker(data, fieldName);
        waitForPageLoad();
        if (options.equalsIgnoreCase("No")) {
            coverwizard.executeScript("arguments[0].click();", coverwizard.livePremisesNoRadiobutton());
        } else if (options.equalsIgnoreCase("Yes")) {
            coverwizard.executeScript("arguments[0].click();", coverwizard.livePremisesYesRadiobutton());
        }
    }

    public void bbCoversSelection(List<List<String>> data, String fieldName) throws Throwable {
        String bbCoverVal = commonutil.datapicker(data, fieldName);
        waitForPageLoad();
        tradename = coverwizard.tradeNameTextbox().getAttribute("value");
        String[] coverSele = bbCoverVal.split(";");
        for (int j = 0; j < coverSele.length; j++) {
            if (coverSele[j].equalsIgnoreCase("Business Contents and stock")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.bbCoverBusinessContentsCheckbox());

            } else if (coverSele[j].equalsIgnoreCase("Your home")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.bbCoverYourHomeCheckbox());

            } else if (coverSele[j].equalsIgnoreCase("Your premises")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.bbCoverYourPremisesCheckbox());

            } else if (coverSele[j].equalsIgnoreCase("Your household contents")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.bbCoverYourhouseholdCheckbox());

            } else if (coverSele[j].equalsIgnoreCase("Business Interruption")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.bbCoverBusinessInterruptionCheckbox());

            } else if (coverSele[j].equalsIgnoreCase("Home emergency")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.bbCoverHomeEmergencyCheckbox());

            } else if (coverSele[j].equalsIgnoreCase("Cyber risks")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.bbCoverCyberRisksCheckbox());

            } else if (coverSele[j].equalsIgnoreCase("Theft of takings")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.bbCoverTheftoftakeCheckbox());

            } else if (coverSele[j].equalsIgnoreCase("Legal expenses")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.bbCoverLegalExpCheckbox());

            } else if (coverSele[j].equalsIgnoreCase("Theft by employees")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.bbCoverTheftbyempCheckbox());

            } else if (coverSele[j].equalsIgnoreCase("None")) {
                coverwizard.executeScript("arguments[0].click();", coverwizard.bbCoverNoneCheckbox());

            }
        }
    }

    public void bbHaveemployeeSelection(List<List<String>> data, String fieldName) throws Throwable {
        String haveEmp = commonutil.datapicker(data, fieldName);
        waitForPageLoad();
        if (haveEmp.equalsIgnoreCase("No")) {
            coverwizard.executeScript("arguments[0].click();", coverwizard.bbHaveEmpNoRadiobutton());
        } else if (haveEmp.equalsIgnoreCase("Yes")) {
            coverwizard.executeScript("arguments[0].click();", coverwizard.bbHaveEmpYesRadiobutton());
        }
    }
}