package co.uk.directlinegroup.evo.utils;

import org.openqa.selenium.WebElement;

public class CarddetailsUtil {

    public static String policyno = null;

    public static void policyNumber(WebElement property) throws Throwable {
        policyno = property.getText();
    }
}