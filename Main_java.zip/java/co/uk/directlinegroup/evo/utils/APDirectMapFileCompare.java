package co.uk.directlinegroup.evo.utils;

import org.junit.Assert;
import org.openqa.selenium.support.ui.Select;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class APDirectMapFileCompare extends Reader_AP{

    public Reader_AP AP_rd;


    public static void main(String[] args){
        Reader_AP AP_rd = new Reader_AP();

        String csvSplitBy = ",";
        String xmlinvoice_received_date = "";
        String getCellValue = null;
        String xmlinvoice_date = null;
        String vendor_site_code = null;
        String Vendor_Name = null;
        String getprofileValue = null;

        String xfilepath=  "C:\\Test\\AP XML Files\\AQUA_BD12_20180426_000002.xml";
        try {
            // ----------- read XML File ----------------------------
            File inputFile = new File(xfilepath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

            NodeList nList = doc.getElementsByTagName("dlg_ap_invoice_header");
            System.out.println("----------------------------");

            for(int j=0; j<nList.getLength();j++){
                Node nNode = nList.item(j);
                System.out.println("\nCurrent Element :" + nNode.getNodeName());
                if(nNode.getNodeType() == Node.ELEMENT_NODE){
                    Element eElement = (Element) nNode;
                    String xmlId = eElement
                            .getElementsByTagName("id")
                            .item(0)
                            .getTextContent();

                    // --------- Read the csv file ------------------
                    Scanner out = new Scanner(new BufferedReader(new FileReader("C:\\Test\\AP_CSV\\AP_Trans.csv")));
                    while(out.hasNextLine()){
                        String data = out.nextLine();
                        String[] value = data.split(csvSplitBy);

                        for(int csv=0; csv < value.length;csv++){
                            if(value[csv].equals(xmlId)){
                                String xmlID = eElement
                                        .getElementsByTagName("id")
                                        .item(0)
                                        .getTextContent();

                                Assert.assertTrue("XML id :-" + xmlID + " is matching with CSV File:-" + value[csv] ,value[csv].equals(xmlID));
                                if (value[csv].equals(xmlID)) {
                                    System.out.println("XML id :-" + xmlID + " is matching with CSV File:-" + value[csv] + " ------------ > PASS");

                                    csv++;
                                } else {
                                    System.out.println("id is not matching with CSV File:-" + value[csv]+ " ------------ > FAIL");
                                }

                                //------------ validate Invoice Number ---------------
                                String xmlpolicy_num = eElement
                                        .getElementsByTagName("policy_num")
                                        .item(0)
                                        .getTextContent();

                                String xmlclaimnumber = eElement
                                        .getElementsByTagName("claimnumber")
                                        .item(0)
                                        .getTextContent();

                                String xmlcc_public_id = eElement
                                        .getElementsByTagName("cc_public_id")
                                        .item(0)
                                        .getTextContent();

                                String InvoiceNumber = xmlpolicy_num+"~"+ xmlclaimnumber+"~"+xmlcc_public_id;

                                if (value[csv].equals(InvoiceNumber)) {
                                    System.out.println("Invoice Number :- " + InvoiceNumber + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Invoice Number :- " + InvoiceNumber + " is not matching with CSV File:-" + value[csv] + " ------ > FAIL");
                                }

                                //------------ validate Invoice Date ---------------
                                String xmlcreate_dt = eElement
                                        .getElementsByTagName("create_dt")
                                        .item(0)
                                        .getTextContent();

                                boolean xmlinvoicedate = eElement
                                        .getElementsByTagName("invoice_date").equals(0);
                                if(!xmlinvoicedate){
                                    xmlinvoice_date = xmlcreate_dt;
                                }else
                                {
                                    xmlinvoice_date = eElement
                                            .getElementsByTagName("invoice_date")
                                            .item(0)
                                            .getTextContent();
                                }

                                if(!xmlinvoice_date.isEmpty()){
                                    xmlinvoice_date = xmlinvoice_date;
                                }
                                else{
                                    xmlinvoice_date = xmlcreate_dt;
                                }

                                if (value[csv].equals(xmlinvoice_date)) {
                                    System.out.println("Invoice Date :- " + xmlinvoice_date + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                    csv++;
                                } else {
                                    System.out.println("source is not matching with CSV File:-" + value[csv]+ " ------------ > FAIL");
                                }

                                //------------ validate Invoice received Date ---------------
                                boolean blninvoice_received_date = eElement
                                        .getElementsByTagName("invoice_received_date").equals(0);
                                if (!blninvoice_received_date) {
                                    xmlinvoice_received_date = xmlcreate_dt;
                                    if (value[csv].equals(xmlinvoice_received_date)) {
                                        System.out.println("XML Invoice Received Date1 :- " + xmlinvoice_received_date + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                        csv++;
                                    } else {
                                        System.out.println("source is not matching with CSV File:-" + value[csv]+ " ------------ > FAIL");
                                    }

                                } else {
                                    xmlinvoice_received_date = eElement
                                            .getElementsByTagName("invoice_received_date")
                                            .item(0)
                                            .getTextContent();

                                    if (!xmlinvoice_received_date.isEmpty()) {
                                        xmlinvoice_received_date = xmlinvoice_received_date;
                                    }

                                    if (value[csv].equals(xmlinvoice_received_date)) {
                                        System.out.println("XML Invoice Received Date2 :- " + xmlinvoice_received_date + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                        csv++;
                                    } else {
                                        System.out.println("source is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                    }
                                }
                                //------------ validate Vendor site code  ---------------
                                String xmlpayee_Type = eElement
                                        .getElementsByTagName("payee_type")
                                        .item(0)
                                        .getTextContent();

                                if(xmlpayee_Type.equals("TPS") || xmlpayee_Type.equals("TPI")){
                                    String xmlvendor_site_cd = eElement
                                            .getElementsByTagName("vendor_site_cd")
                                            .item(0)
                                            .getTextContent();

                                    getCellValue =  AP_rd.lookUpAPreference_AP(xmlpayee_Type,"AP_Vendor",2,5);
                                    getCellValue = getCellValue+xmlvendor_site_cd;
                                    System.out.println("With vendor id"+getCellValue);
                                    System.out.println("vendor id and with site code:- " + getCellValue + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                    csv++;
                                }else if(!xmlpayee_Type.equals("TPS") || !xmlpayee_Type.equals("TPI")) {
                                    getCellValue =  AP_rd.lookUpAPreference_AP(xmlpayee_Type,"AP_Vendor",2,5);
                                    vendor_site_code = getCellValue;
                                    System.out.println("vendor site code :- " + getCellValue + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                    csv++;
                                }else{
                                    System.out.println("vendor site code :- " + getCellValue + " is not matching with CSV File:-" + value[csv] + " ------ > PASS");
                                }

                                //-------------- Validate vendor Name ------------------
                                Vendor_Name =  AP_rd.lookUpAPreference_AP(vendor_site_code,"AP_Vendor_details",2,3);
                                if(value[csv].equals(Vendor_Name)){
                                    System.out.println("Vendor Name"+Vendor_Name);
                                    csv++;
                                }else{
                                    System.out.println("Vendor Name not matching"+Vendor_Name);
                                }

                                //------------ validate invoice_amount  ---------------
                                String xmlinvoice_amount = eElement
                                        .getElementsByTagName("invoice_gross_amount")
                                        .item(0)
                                        .getTextContent();
                                double invoice_amt = Double.parseDouble(xmlinvoice_amount);
                                double invoice_amount = Math.round(invoice_amt*100.0)/100.0;
                                double csv_amt = Double.parseDouble(value[csv]);
                                if(csv_amt==(invoice_amount)){
                                    System.out.println("invoice_gross_amount "+ xmlinvoice_amount);
                                    csv++;
                                }else{
                                    System.out.println("invoice_gross_amount not matching"+ xmlinvoice_amount);
                                    csv++;
                                }

                                //------------ validate invoice_currency_code  ---------------
                                String xmlinvoice_currency_code = eElement
                                        .getElementsByTagName("invoice_currency_cd")
                                        .item(0)
                                        .getTextContent();
                                String invoice_currency_code = xmlinvoice_currency_code.toUpperCase();
                                if(value[csv].equals(invoice_currency_code)){
                                    System.out.println("invoice_currency_code "+ invoice_currency_code);
                                    csv++;
                                }else{
                                    System.out.println("invoice_currency_code not matching"+ invoice_currency_code);
                                    csv++;
                                }

                                //------------ validate exchange_rate  ---------------
                                String xmlexchange_rate = eElement
                                        .getElementsByTagName("exchange_rate")
                                        .item(0)
                                        .getTextContent();
                                if(xmlinvoice_currency_code.equals("GBP")){
                                    if(value[csv].equals("null")){
                                        System.out.println("exchange_rate should be null"+ value[csv]+"Pass");
                                        csv++;
                                    }else{
                                        System.out.println("exchange_rate should be null"+ value[csv]+"Fail");
                                        csv++;
                                    }
                                }else if(!xmlinvoice_currency_code.equals("GBP")){
                                    if(value[csv].equals(xmlinvoice_currency_code)){
                                        System.out.println("exchange_rate "+ xmlexchange_rate+"Pass");
                                        csv++;
                                    }else{
                                        System.out.println("exchange_rate "+ xmlexchange_rate +"Fail");
                                        csv++;
                                    }
                                }

                                //--------------- validate attribute_category --------------------
                                String xmlpayment_method_cd = eElement
                                        .getElementsByTagName("payment_method_cd")
                                        .item(0)
                                        .getTextContent();

                                getCellValue =  AP_rd.lookUpAPreference_AP(xmlpayment_method_cd,"FSH DC lookup",2,5);

                                if(getCellValue.contains("WIRE")){
                                    getCellValue = "WIRE";
                                }else if(getCellValue.contains("EFT")){
                                    getCellValue = "EFT";
                                }else if(getCellValue.contains("CHECK")){
                                    getCellValue = "CHECK";
                                }

                                switch (getCellValue){

                                    case "WIRE":
                                        getprofileValue =  AP_rd.lookUpAPreference_AP("RBSI_WIRE_ATTRIBUTE_CATEGORY","Common Lookup",0,1);
                                        break;
                                    case "EFT":
                                        getprofileValue =  AP_rd.lookUpAPreference_AP("RBSI_EFT_ATTRIBUTE_CATEGORY","Common Lookup",0,1);
                                        break;
                                    case "CHECK":
                                        getprofileValue =  AP_rd.lookUpAPreference_AP("RBSI_CHEQUE_ATTRIBUTE_CATEGORY","Common Lookup",0,1);
                                        break;
                                    default:
                                        getprofileValue =  AP_rd.lookUpAPreference_AP("RBSI_CHEQUE_ATTRIBUTE_CATEGORY","Common Lookup",0,1);
                                        break;
                                }

                                if(value[csv].equals(getprofileValue)){
                                    System.out.println("csv Value " +value[csv]+ "lookup"+ getprofileValue);
                                    csv++;
                                }else{
                                    System.out.println("csv Value not matching" +value[csv]+ "lookup"+ getprofileValue);
                                    csv++;
                                }

                                //--------------- validate attribute1 --------------------
                                if(!xmlpayee_Type.equals("TPS") || (!xmlpayee_Type.equals("TPI"))) {
                                    String xmlpayee_description = eElement
                                            .getElementsByTagName("payee_description")
                                            .item(0)
                                            .getTextContent();
                                    if(value[csv].equals(xmlpayee_description)){
                                        System.out.println("csv Value " + value[csv]+ "xml value "+ xmlpayee_description +"---Pass");
                                        csv++;
                                    }else {
                                        System.out.println("csv Value " + value[csv]+ "xml value "+ xmlpayee_description +"---Fail");
                                        csv++;
                                    }
                                }else if(xmlpayee_Type.equals("TPS") || (xmlpayee_Type.equals("TPI"))){
                                    System.out.println("attribute1 should be Null ------ Pass");
                                    csv++;
                                }else{
                                    System.out.println("attribute1 not Null ------ Fail");
                                    csv++;
                                }

                                //--------------- validate attribute2 --------------------
                                if(!xmlpayee_Type.equals("TPS") || (!xmlpayee_Type.equals("TPI"))) {
                                    String xmlpayee_address_line1 = eElement
                                            .getElementsByTagName("payee_address_line1")
                                            .item(0)
                                            .getTextContent();
                                    if(value[csv].equals(xmlpayee_address_line1)){
                                        System.out.println("csv Value " + value[csv]+ "xml value "+ xmlpayee_address_line1 +"---Pass");
                                        csv++;
                                    }else {
                                        System.out.println("csv Value " + value[csv]+ "xml value "+ xmlpayee_address_line1 +"---Fail");
                                        csv++;
                                    }
                                }else if(xmlpayee_Type.equals("TPS") || (xmlpayee_Type.equals("TPI"))){
                                    System.out.println("attribute1 should be Null ------ Pass");
                                    csv++;
                                }else{
                                    System.out.println("attribute1 not Null ------ Fail");
                                    csv++;
                                }





                            }


                        }
                    }

                }


            }

        }catch (ParserConfigurationException | SAXException | IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }



}





