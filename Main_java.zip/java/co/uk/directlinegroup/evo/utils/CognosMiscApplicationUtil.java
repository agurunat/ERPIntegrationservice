package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_CC_Search;
import co.uk.directlinegroup.evo.pages.Obj_CognosMiscApplication;

public class CognosMiscApplicationUtil {

    private Obj_CC_Search ccSearch = new Obj_CC_Search();
    private Obj_CognosMiscApplication obj_CognosMiscApplication = new Obj_CognosMiscApplication();

    public String getPolicyNumber() throws Throwable {
        ccSearch.passedVerificaitionButton().click();
        ccSearch.ccPageLoad();
        return obj_CognosMiscApplication.ccSearchedPolicyNumber().getText();
    }

}
