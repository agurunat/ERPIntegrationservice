package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.*;

/**
 * Created by 289949 on 10/11/2017.
 */
public class OPRUtil {
    private Obj_Generalinformation obj_generalInformation = new Obj_Generalinformation();
    private Obj_Coverwizard obj_coverwizard = new Obj_Coverwizard();
    private CommonUtil obj_commonUtil = new CommonUtil();


    public static String strEmail, strFirstName, strSecondName, policyNumber, strBusinessName;
    public String haveEmployee, strCovers, strHelpText, strValidateHelpText;

    public void fillCoverWizardSectionforOPR(String appication,String trade,String tradeName, String runBusiness, boolean haveEmployees, boolean employersLiability, String covers) throws Throwable {
        if(appication.equals("WJ")){
            switch (trade)
            {
                case "Generic Wizard":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.getQuoteOnlineLink());
                    break;
                case "hb":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.hbLink());
                    break;
                case "bb":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbLink());
                    break;
                case "Office":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.offoiceConsultantLink());
                    break;
                case "retail":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.retailLink());
                    break;
                case "food retail":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.foodRetailLink());
                    break;
            }
        }
        obj_coverwizard.switchWindow();
        obj_generalInformation.pageLoading();
        if(trade.equals("null")||appication.equals("CC")){
            obj_commonUtil.switchFrame("sagepay");
        }
        obj_coverwizard.tradeNameTextbox().clear();
        obj_coverwizard.tradeNameTextbox().sendKeys(tradeName);
        obj_coverwizard.wizardTradeList().click();
        if (!runBusiness.equals("")) {
            String[] arrrunBusiness = runBusiness.split("#");
            for(int i=0;i<arrrunBusiness.length;i++){
                obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.sellProductRunBusinessCoversCommonOPR(arrrunBusiness[i]));
                }
            if(trade.equals("retail")){
                obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.retailLivepremisesNextbutton());
            }else{
                obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbLivepremisesNextbutton());
            }
            }
        if (haveEmployees) {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbHaveEmpYesRadiobutton());
            if (employersLiability) {
                obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.oprEmployersLiabilityCoverYesRadiobutton());
            } else {
                obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.oprEmployersLiabilityCoverNoRadiobutton());
            }
        } else {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.oprEmployersLiabilityCoverNoRadiobutton());
        }
        String[] cover = covers.split("#");
        for (int i = 0; i < cover.length; i++) {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversCheckbox(cover[i]));
        }
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversContinueButton());
    }


}
