package co.uk.directlinegroup.evo.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import co.uk.directlinegroup.evo.pages.Obj_Generalinformation;
import co.uk.directlinegroup.evo.pages.Obj_ProfessionalLiability;
import com.usmanhussain.habanero.framework.AbstractPage;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

/**
 * Created by 445607 on 11/8/2017.
 */
public class ProfessionalLiabilityUtil extends AbstractPage {

    private String strText,strQuestion, strHelpText;

    public Obj_ProfessionalLiability obj_professionalLiability = new Obj_ProfessionalLiability();
    private Obj_Generalinformation obj_generalInformation = new Obj_Generalinformation();
    private CommonUtil commonutil = new CommonUtil();

    public void professionalLiabilitySection(String CoverProfessionalLiability) throws Throwable {
        HashMap<String, String> ProfessionalLiabilityElements = new LinkedHashMap<String, String>();
        String[] ProfessionalLiabilityFields = CoverProfessionalLiability.split("#");
        for (int i = 1; i <= ProfessionalLiabilityFields.length; i++) {
            String[] ProfessionalLiabilityValues = ProfessionalLiabilityFields[i - 1].split(";");
            ProfessionalLiabilityElements.put(ProfessionalLiabilityValues[0], ProfessionalLiabilityValues[1]);
        }

        List<String> ProfessionalLiabilityQuestions = new ArrayList<>(ProfessionalLiabilityElements.keySet());
        for (String ProfessionalLiabilityQuestion : ProfessionalLiabilityQuestions) {
            switch (ProfessionalLiabilityQuestion) {
                case "BusinessRegistered":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.businessRegisteredYesNo(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion)));
                    obj_generalInformation.pageLoading();
                    break;
                case "RelevantQualification":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.relevantQualificationsYesNo(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion)));
                    obj_generalInformation.pageLoading();
                    break;
                case "ReplacingOrExpiryPolicy":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.replacePLYesNo(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion)));
                    obj_generalInformation.pageLoading();
                    break;
                case "RetroactiveDateHistory":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.retroactiveHistoryYesNo(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion)));
                    obj_generalInformation.pageLoading();
                    break;
                case "RetroactiveDateText":
                    obj_professionalLiability.retroactiveDateTxtBox().sendKeys(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion));
                    commonutil.tabKeypress();
                    obj_generalInformation.pageLoading();
                    break;
                case "ProfessionalLiabilityCover":
                    new Select(obj_professionalLiability.PLCoverDropdown()).selectByVisibleText(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion));
                    break;
                case "LiabilityClaim":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.PLClaimYesNo(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion)));
                    break;
                case "LiabilityClaimIssue":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.PLClaimIssueYesNo(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion)));
                    break;
                case "Next":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.PLNextButton());
                    obj_generalInformation.pageLoading();
            }
        }

    }

    public void professionalLiabilityAccordianCheck(String presentNotPresent) throws Throwable {
        if (presentNotPresent.equalsIgnoreCase("Present")) {
            if (obj_professionalLiability.professionalLiabilityCover().isDisplayed()) {
                Assert.assertTrue("Professional liability accordion present", true);
            } else {
                Assert.assertTrue("Professional liability accordion not present", false);
            }
        } else if (presentNotPresent.equalsIgnoreCase("Not Present")) {
            int eleSize = obj_professionalLiability.professionalLiabilityCoverNotPresent().size();
            if (eleSize == 0) {
                Assert.assertTrue("Professional liability accordion not present", true);
            } else {
                Assert.assertTrue("Professional liability accordion present", false);
            }
        }

    }

    public void questionAndRequiredMessageValidation(List<List<String>> data) throws Throwable {
        for (int i = 0; i < data.size(); i++) {
            switch (data.get(i).get(1)) {
                case "BusinessCarryOut":
                    String strBusinessCarryOut = obj_professionalLiability.businessCarryOutQuestion().get(0).getText();
                    Assert.assertTrue("BusinessCarryOut question is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strBusinessCarryOut.replace(" ", "").replace(",", "")));
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.PLNextButton());
                    if (obj_professionalLiability.requiredMsgBusinessCarryOut().isDisplayed()) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "BusinessCarryOutNotPresent":
                    if (!obj_professionalLiability.businessCarryOutQuestion().get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
                case "RIBA":
                    String strRIBA = obj_professionalLiability.RIBALbl().get(0).getText();
                    Assert.assertTrue("RIBA question is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strRIBA.replace(" ", "").replace(",", "")));
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.PLNextButton());
                    if (obj_professionalLiability.reqMsgRIBA().isDisplayed()) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "BusinessWorkArea":
                    String strBusinessWorkArea = obj_professionalLiability.businessWorkAreaLbl().get(0).getText();
                    Assert.assertTrue("BusinessWorkArea question is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strBusinessWorkArea.replace(" ", "").replace(",", "")));
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.PLNextButton());
                    if (obj_professionalLiability.reqMsgBusinessWorkArea().isDisplayed()) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "BusinessWorkAreaHT":
                    strText = (String) (getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.businessWorkAreaHelpText());
                    Assert.assertTrue("Business work area HelpText is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "ContractsWriting":
                    String strContractsWriting = obj_professionalLiability.contractWritingLbl().get(0).getText();
                    Assert.assertTrue("ContractsWriting question is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strContractsWriting.replace(" ", "").replace(",", "")));
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.PLNextButton());
                    if (obj_professionalLiability.reqMsgContractsWriting().isDisplayed()) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "ContractsWritingHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.contractWritingHelpText());
                    Assert.assertTrue("Contract writing HelpText is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "ConstructionValue":
                    String strConstructionValue = obj_professionalLiability.constructionValueLbl().get(0).getText();
                    Assert.assertTrue("ConstructionValue question is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strConstructionValue.replace(" ", "").replace(",", "")));
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.PLNextButton());
                    if (obj_professionalLiability.reqMsgConstructionValue().isDisplayed()) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "ConstructionValueHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.constructionValueHelpText());
                    Assert.assertTrue("Construction value HelpText is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "RIBANotPresent":
                    if (!obj_professionalLiability.RIBALbl().get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
                case "BusinessWorkAreaNotPresent":
                    if (!obj_professionalLiability.businessWorkAreaLbl().get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
                case "ContractsWritingNotPresent":
                    if (!obj_professionalLiability.contractWritingLbl().get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
                case "ConstructionValueNotPresent":
                    if (!obj_professionalLiability.constructionValueLbl().get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
            }
        }
    }

    public void fillPLCoverDetails(String PLValues, int i) throws Exception {
        HashMap<String, String> ProfessionalLiabilityElements = new LinkedHashMap<String, String>();
        String[] ProfessionalLiabilityFields = PLValues.split("#");
        for (i = 1; i <= ProfessionalLiabilityFields.length; i++) {
            String[] ProfessionalLiabilityValues = ProfessionalLiabilityFields[i - 1].split(";");
            ProfessionalLiabilityElements.put(ProfessionalLiabilityValues[0], ProfessionalLiabilityValues[1]);
        }

        List<String> ProfessionalLiabilityQuestions = new ArrayList<>(ProfessionalLiabilityElements.keySet());
        for (String ProfessionalLiabilityQuestion : ProfessionalLiabilityQuestions) {
            switch (ProfessionalLiabilityQuestion) {
                case "BusinessRegistered":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.businessRegisteredYesNo(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion)));
                    obj_generalInformation.pageLoading();
                    break;
                case "BusinessRegisteredPresent":
                    strText = obj_professionalLiability.businessRegisteredQuestion().getText();
                    strQuestion = "Is your business registered and based in the UK?";
                    Assert.assertTrue("BusinessRegistered question is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "RelevantQualification":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.relevantQualificationsYesNo(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion)));
                    obj_generalInformation.pageLoading();
                    break;
                case "ReplacingOrExpiryPolicy":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.replacePLYesNo(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion)));
                    obj_generalInformation.pageLoading();
                    break;
                case "RetroactiveDateHistory":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.retroactiveHistoryYesNo(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion)));
                    obj_generalInformation.pageLoading();
                    break;
                case "RetroactiveDateText":
                    obj_professionalLiability.retroactiveDateTxtBox().sendKeys(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion));
                    commonutil.tabKeypress();
                    obj_generalInformation.pageLoading();
                    break;
                case "ProfessionalLiabilityCover":
                    new Select(obj_professionalLiability.PLCoverDropdown()).selectByVisibleText(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "LiabilityClaim":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.PLClaimYesNo(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion)));
                    obj_generalInformation.pageLoading();
                    break;
                case "LiabilityClaimIssue":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.PLClaimIssueYesNo(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion)));
                    obj_generalInformation.pageLoading();
                    break;
                case "TradeGroup1":
                    String tradeGroupValues[] = ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion).split(",");

                    HashMap<String, String> tradeGroupVal = new LinkedHashMap<String, String>();
                    for (i = 1; i <= tradeGroupValues.length; i++) {
                        String[] tradeGroup1 = tradeGroupValues[i - 1].split(":");
                        tradeGroupVal.put(tradeGroup1[0], tradeGroup1[1]);
                    }
                    List<String> tradeGroup1Questions = new ArrayList<>(tradeGroupVal.keySet());
                    for (String tradeGroupQuestn : tradeGroup1Questions) {

                        switch (tradeGroupQuestn) {
                            case "ACA": //Specific for chattered accountant
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.qualifiedACA(tradeGroupVal.get(tradeGroupQuestn)));
                                obj_generalInformation.pageLoading();
                                break;
                            case "LargestFee":
                                obj_professionalLiability.largestFee().sendKeys(tradeGroupVal.get(tradeGroupQuestn));
                                commonutil.tabKeypress();
                                obj_generalInformation.pageLoading();
                                break;
                            case "CorporateTaxWork":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.corporateTaxWork(tradeGroupVal.get(tradeGroupQuestn)));
                                obj_generalInformation.pageLoading();
                                break;
                            case "WorkCarriedOutSecretarial":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.workCarriedOutSecretarial(tradeGroupVal.get(tradeGroupQuestn)));
                                obj_generalInformation.pageLoading();
                                break;
                            case "WorkCarriedOutLloydsOfLondon":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.workCarriedOutLloydsOfLondon(tradeGroupVal.get(tradeGroupQuestn)));
                                obj_generalInformation.pageLoading();
                                break;
                            case "ProbateOrEstateAdmin":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.probateOrEstateAdmin(tradeGroupVal.get(tradeGroupQuestn)));
                                obj_generalInformation.pageLoading();
                                break;
                            case "TaxAvoidance":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.taxAvoidance(tradeGroupVal.get(tradeGroupQuestn)));
                                obj_generalInformation.pageLoading();
                                break;
                        }
                    }
                    break;
                case "TradeGroup2":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.mortgageTaxAdvice(ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion)));
                    obj_generalInformation.pageLoading();
                    break;
                case "TradeGroup3":
                    String tradeGroupValues3[] = ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion).split(",");
                    HashMap<String, String> tradeGroup3 = new LinkedHashMap<String, String>();
                    for (i = 1; i <= tradeGroupValues3.length; i++) {
                        String[] tradeGroup = tradeGroupValues3[i - 1].split(":");
                        tradeGroup3.put(tradeGroup[0], tradeGroup[1]);
                    }
                    List<String> tradeGroupQuestions = new ArrayList<>(tradeGroup3.keySet());
                    for (String tradeGroupQues : tradeGroupQuestions) {

                        switch (tradeGroupQues) {

                            case "RIBA":   //Specific to Architect
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.RIBA(tradeGroup3.get(tradeGroupQues)));
                                obj_generalInformation.pageLoading();
                                break;
                            case "BusinessWorkArea":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.businessWorkArea(tradeGroup3.get(tradeGroupQues)));
                                obj_generalInformation.pageLoading();
                                break;
                            case "ConstructionValue":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.constructionValue(tradeGroup3.get(tradeGroupQues)));
                                obj_generalInformation.pageLoading();
                                break;
                            case "ContractWriting":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.contractWriting(tradeGroup3.get(tradeGroupQues)));
                                obj_generalInformation.pageLoading();
                                break;

                        }
                    }
                    break;
                case "TradeGroup4":
                    String tradeGroupValues4[] = ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion).split(",");
                    HashMap<String, String> tradeGroup4 = new LinkedHashMap<String, String>();
                    for (i = 1; i <= tradeGroupValues4.length; i++) {
                        String[] tradeGroup = tradeGroupValues4[i - 1].split(":");
                        tradeGroup4.put(tradeGroup[0], tradeGroup[1]);
                    }
                    List<String> tradeGroup4Questions = new ArrayList<>(tradeGroup4.keySet());
                    for (String tradeGroupQues : tradeGroup4Questions) {
                        switch (tradeGroupQues) {
                            case "FinancialLoss":   //Specific to Architect
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.financialLoss(tradeGroup4.get(tradeGroupQues)));
                                obj_generalInformation.pageLoading();
                                break;
                            case "BusinessDesign":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.businessDesign(tradeGroup4.get(tradeGroupQues)));
                                obj_generalInformation.pageLoading();
                                break;
                            case "WorkConnection":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.workConnection(tradeGroup4.get(tradeGroupQues)));
                                obj_generalInformation.pageLoading();
                                break;
                            case "FinancialLossQuestion":
                                strText = obj_professionalLiability.financialLossQuestion().get(0).getText();
                                strQuestion ="Could the failure of any of your business' products or services result in an immediate financial loss for your client(s)?";
                                Assert.assertTrue("FinancialLossQuestion is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                                break;
                            case "FinancialLossHT":
                                strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_professionalLiability.financialLossHT());
                                strHelpText="For instance, could the failure cause immediate system shut down or down time to trading systems or booking software?";
                                Assert.assertTrue("FinancialLossHT is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                                break;
                            case "BusinessDesignQuestion":
                                strText = obj_professionalLiability.businessDesignQuestion().get(0).getText();
                                strQuestion ="Does your business design or provide services for: manufacturing process control-games development-financial live trading systems-specialist network security work including penetration testing";//
                                Assert.assertTrue("BusinessDesignQuestion is displayed", strQuestion.replace(" ", "").replace("-","").replace(",", "").replace("\n","").equalsIgnoreCase(strText.replace(" ", "").replace("\n","").replace(",", "")));
                                break;
                            case "BusinessDesignHT":
                                strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_professionalLiability.businessDesignHT());
                                strHelpText="Manufacturing process control includes the control of any hardware, machinery or other aspect of a production line or production process. Games development includes any new gaming software. Financial live trading systems involves systems or processes which can be used to place orders for financial products. ";
                                Assert.assertTrue("BusinessDesignHelpText is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                                break;
                            case "WorkConnectionQuestion":
                                strText = obj_professionalLiability.workConnectionQuestion().get(0).getText();
                                strQuestion ="Do you undertake work in connection with the nuclear industry?";
                                Assert.assertTrue("WorkConnectionQuestion is displayed", strQuestion.replace(" ", "").replace("-","").replace(",", "").replace("\n","").equalsIgnoreCase(strText.replace(" ", "").replace("\n","").replace(",", "")));
                                break;
                            case "FinancialLossRequired":
                                String strFinancialLoss = obj_professionalLiability.financialLossRequired().getText();
                                if(strFinancialLoss.equalsIgnoreCase("Required")){

                                    Assert.assertTrue("Required Error Message is displayed", true);
                                }else
                                {
                                    Assert.assertTrue("Required Error Message is not displayed", false);
                                }
                                break;
                            case "BusinessDesignRequired":
                                String strBusinessDesign = obj_professionalLiability.businessDesignRequired().getText();
                                if(strBusinessDesign.equalsIgnoreCase("Required")){

                                    Assert.assertTrue("Required Error Message is displayed", true);
                                }else
                                {
                                    Assert.assertTrue("Required Error Message is not displayed", false);
                                }
                                break;
                            case "FinancialLossNotPresent":
                                if (!obj_professionalLiability.financialLossQuestion().get(0).isDisplayed()) {
                                    Assert.assertTrue("financialLossQuestion not present", true);
                                } else {
                                    Assert.assertTrue("financialLossQuestion present", false);
                                }
                                break;
                            case "BusinessDesignNotPresent":
                                if (!obj_professionalLiability.businessDesignQuestion().get(0).isDisplayed()) {
                                    Assert.assertTrue("businessDesignQuestion not present", true);
                                } else {
                                    Assert.assertTrue("businessDesignQuestion present", false);
                                }
                                break;

                        }
                    }
                    break;
                case "TradeGroup5":
                    String tradeGroupValues5[] = ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion).split(",");
                    HashMap<String, String> tradeGroup5 = new LinkedHashMap<String, String>();
                    for (i = 1; i <= tradeGroupValues5.length; i++) {
                        String[] tradeGroup = tradeGroupValues5[i - 1].split(":");
                        tradeGroup5.put(tradeGroup[0], tradeGroup[1]);
                    }
                    List<String> tradeGroup5Questions = new ArrayList<>(tradeGroup5.keySet());
                    for (String tradeGroupQues : tradeGroup5Questions) {

                        switch (tradeGroupQues) {

                            case "WorkSpecs":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.workSpecs(tradeGroup5.get(tradeGroupQues)));
                                //Objects to be added
                                obj_generalInformation.pageLoading();
                                break;
                            case "ClientSignOff":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.clientSignOff(tradeGroup5.get(tradeGroupQues)));
                                obj_generalInformation.pageLoading();
                                break;
                            case "GuaranteedArrivalDate":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.GuaranteedArrivalDate(tradeGroup5.get(tradeGroupQues)));
                                obj_generalInformation.pageLoading();
                                break;
                            case "WorkSpecsQuestion":
                                strText = obj_professionalLiability.workSpecsQuestion().get(0).getText();
                                strQuestion ="Do you always use a written work specification and document any variations from it?";
                                Assert.assertTrue("WorkSpecsQuestion is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                              break;
                            case "WorkSpecsHT":
                                strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_professionalLiability.workSpecsHelpText());
                                strHelpText="Work specifications may be standard or bespoke for each client, but if they're not in writing detailing the services agreed then you must tell us. Any changes to the services/specification must also be documented rather than just agreed verbally.";
                                Assert.assertTrue("WorkSpecsHelpText is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                                break;
                            case "ClientSignOffQuestion":
                                strText = obj_professionalLiability.clientSignOffQuestion().get(0).getText();
                                strQuestion ="Do you always get client sign off before print, publication, launch or the delivery of content?";
                                Assert.assertTrue("ClientSignOffQuestion is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                                break;
                            case "ClientSignOffHT":
                                strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_professionalLiability.clientSignOffHelpText());
                                strHelpText="You must get client sign-off before a document is printed or due to go live if online.";
                                Assert.assertTrue("ClientSignOffHelpText is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                                break;
                            case "GuaranteedArrivalDateQuestion":
                                strText = obj_professionalLiability.guaranteedArrivalDateQuestion().get(0).getText();
                                strQuestion ="Are you involved in any 100% mailings contracts with a guaranteed arrival date? This could include things like share certificates or pension statements.";
                                Assert.assertTrue("GuaranteedArrivalDateQuestion is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                                break;
                            case "GuaranteedArrivalDateHT":
                                strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_professionalLiability.guaranteedArrivalDateHelpText());
                                strHelpText="100% mailings only include documents which are guaranteed to be received by the correct recipient, for instance dividend payments.";
                                Assert.assertTrue("GuaranteedArrivalDateHelpText is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                                break;
                            case "ValidateRequiredErrorMsgTradeGroup5":
                                if(obj_professionalLiability.tradeGroup5ErrorMsg().size()==3){
                                    Assert.assertTrue("3 Required Error Message are displayed",true);

                                }else{
                                    Assert.assertTrue("3 Required Error Message are not displayed",false);
                                }
                               break;

                            case "WorkSpecsQuestionNotPresent":
                                if (!obj_professionalLiability.workSpecsQuestion().get(0).isDisplayed()) {
                                    Assert.assertTrue("WorkSpecsQuestion not present", true);
                                } else {
                                    Assert.assertTrue("WorkSpecQuestion present", false);
                                }
                                break;
                            case "ClientSignOffQuestionNotPresent":
                                if (!obj_professionalLiability.clientSignOffQuestion().get(0).isDisplayed()) {
                                    Assert.assertTrue("ClientSignOffQuestion not present", true);
                                } else {
                                    Assert.assertTrue("ClientSignOffQuestion present", false);
                                }
                                break;
                            case "GuaranteedArrivalDateQuestionNotPresent":
                                if (!obj_professionalLiability.guaranteedArrivalDateQuestion().get(0).isDisplayed()) {
                                    Assert.assertTrue("GuaranteedArrivalDateQuestion not present", true);
                                } else {
                                    Assert.assertTrue("GuaranteedArrivalDateQuestion present", false);
                                }
                                break;
                        }
                    }
                    break;
                case "TradeGroup6":
                    String tradeGroupValues6[] = ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion).split(",");
                    HashMap<String, String> tradeGroup6 = new LinkedHashMap<String, String>();
                    for (i = 1; i <= tradeGroupValues6.length; i++) {
                        String[] tradeGroup = tradeGroupValues6[i - 1].split(":");
                        tradeGroup6.put(tradeGroup[0], tradeGroup[1]);
                    }
                    List<String> tradeGroup6Questions = new ArrayList<>(tradeGroup6.keySet());
                    for (String tradeGroupQues : tradeGroup6Questions) {

                        switch (tradeGroupQues) {

                            case "CommercialEstateAgency":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.commercialEstateAgencyYesNo(tradeGroup6.get(tradeGroupQues)));                                                            obj_generalInformation.pageLoading();
                                break;
                            case "SurveyOrValuation":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.surveyOrValuationYesNo(tradeGroup6.get(tradeGroupQues)));
                                obj_generalInformation.pageLoading();
                                break;
                            case "SurveyOrValuationQuestionPresent":
                                strText = obj_professionalLiability.surveyOrValuationQuestion().getText();
                                strQuestion ="Have you or will you carry out any survey or valuation work other than for establishing a market value?";
                                Assert.assertTrue("SurveyOrValuationQuestion is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                                break;
                            case "SurveyOrValuationQuestionNotPresent":
                                if (!obj_professionalLiability.surveyOrValuation().get(0).isDisplayed()) {
                                    Assert.assertTrue("SurveyOrValuationQuestion not present", true);
                                } else {
                                    Assert.assertTrue("SurveyOrValuationQuestion present", false);
                                }
                                break;
                            case "SurveyOrValuationHT":

                                strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.SurveyOrValuationHelpText());
                                strHelpText="This doesn't include market appraisals to provide a value for a property up for sale. If the business carries out any surveys or valuations for a mortgage or structural survey you must tell us.";
                                Assert.assertTrue("SurveyOrValuationHelpText is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                                break;

                            case "CommercialEstateAgencyQuestionPresent":
                                strText = obj_professionalLiability.commercialEstateAgencyQuestion().getText();
                                strQuestion ="Is 50% or more of your business income from commercial estate agency and commercial property management?";
                                Assert.assertTrue("CommercialEstateAgencyQuestion is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                                break;
                            case "CommercialEstateAgencyQuestionNotPresent":
                                if (!obj_professionalLiability.commercialEstateAgency().get(0).isDisplayed()) {
                                    Assert.assertTrue("CommercialEstateAgencyQuestion not present", true);
                                } else {
                                    Assert.assertTrue("CommercialEstateAgencyQuestion present", false);
                                }
                                break;
                            case "CommercialEstateAgencyHT":
                                strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.commercialEstateAgencyHelpText());
                                strHelpText="This doesn't include income from residential estate agency or residential property management.";
                                Assert.assertTrue("CommercialEstateAgencyHelpText is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                                break;

                            case "ValidateRequiredErrorMsgTradeGroup6":
                                if(obj_professionalLiability.tradeGroup6ErrorMsg().size()==2){
                                    Assert.assertTrue("2 Required Error Message are displayed",true);

                                }else{
                                    Assert.assertTrue("2 Required Error Message are not displayed",false);
                                }
                                break;

                        }
                    }
                    break;



                case "TradeGroupMisc":
                    String tradeGroupMiscValues[] = ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion).split(",");
                    HashMap<String, String> tradeGroupMisc = new LinkedHashMap<String, String>();
                    for (i = 1; i <= tradeGroupMiscValues.length; i++) {
                        String[] tradeGroup = tradeGroupMiscValues[i - 1].split(":");
                        tradeGroupMisc.put(tradeGroup[0], tradeGroup[1]);
                    }
                    List<String> tradeGroupMiscQuestions = new ArrayList<>(tradeGroupMisc.keySet());
                    for (String tradeGroupMiscQues : tradeGroupMiscQuestions) {
                        switch (tradeGroupMiscQues) {
                            case "SettleClaims":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.settleClaims(tradeGroupMisc.get(tradeGroupMiscQues)));
                                obj_generalInformation.pageLoading();
                                break;
                            case "FinancialSettlement":
                                obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.financialSettlement(tradeGroupMisc.get(tradeGroupMiscQues)));
                                obj_generalInformation.pageLoading();
                                break;
                            case "SettleClaimsQuesPresent":
                                strText = obj_professionalLiability.settleClaimsQuestion().get(0).getText();
                                strQuestion ="Are you authorised to settle claims without referral?";
                                Assert.assertTrue("SettleClaimsQuesPresent is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                                break;
                            case "FinancialSettlementQuesPresent":
                                strText = obj_professionalLiability.financialSettlementQuestion().get(0).getText();
                                strQuestion ="Are you authorised to make financial settlement without referral?";
                                Assert.assertTrue("SettleClaimsQuesPresent is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                                break;
                            case "SettleClaimsQuesNotPresent":
                                if(!obj_professionalLiability.settleClaimsQuestion().get(0).isDisplayed()){Assert.assertTrue("Question not present",true);}else{Assert.assertTrue("Question present",false);}
                                break;
                            case "FinancialSettlementQuesNotPresent":
                                if(!obj_professionalLiability.financialSettlementQuestion().get(0).isDisplayed()){Assert.assertTrue("Question not present",true);}else{Assert.assertTrue("Question present",false);}
                                break;
                        }
                    }
                    break;

                case "RelevantQualificationPresent":
                    strText = obj_professionalLiability.relevantQualificationQuestion().getText();
                    strQuestion ="Do you have the relevant qualifications or at least 3 years practical experience in your profession?";
                    Assert.assertTrue("RelevantQualifications is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "RelevantQualificationNotPresent":
                    if (!obj_professionalLiability.relevantQualification().get(0).isDisplayed()) {
                        Assert.assertTrue("RelevantQualifications not present", true);
                    } else {
                        Assert.assertTrue("RelevantQualifications present", false);
                    }
                    break;
                case "RelevantQualificationHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.relevantQualificationHelpText());
                    strHelpText="If you don't have the relevant qualifications, then 3 years experience is acceptable.";
                    Assert.assertTrue("RelevantQualificationsHelpText is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "ReplacePLPresent":
                    strText = obj_professionalLiability.replacePL().getText();
                    strQuestion="Will this policy be replacing an existing Professional Indemnity policy or one that's expired in the past 30 days?";
                    Assert.assertTrue("ReplaceProfesstionalLiability is displayed",strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "ReplacePLHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.replacePLHelpText());
                    strHelpText="If this policy isn't replacing an existing Professional Indemnity policy, claims will be covered from the start date of the new policy.";
                    Assert.assertTrue("ReplacingProfesstionalLiabilityHelpText is displayed",strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "RetroactiveHistoryNotPresent":
                    int size = obj_professionalLiability.retroactiveHist().size();
                    if (size == 0) {
                        Assert.assertTrue("RetroactiveHistoryQuestion is not displayed", true);
                    } else {
                        Assert.assertTrue("RetroactiveHistoryQuestion is displayed", false);
                    }
                    break;
                case "RetroactiveDateNotPresent":
                    int fieldSize = obj_professionalLiability.retroactiveDateQuestionSize().size();
                    if (fieldSize == 0) {
                        Assert.assertTrue("RetroactiveDateQuestion is not displayed", true);
                    } else {
                        Assert.assertTrue("RetroactiveDateQuestion is displayed", false);
                    }
                    break;
                case "RetroactiveHistoryPresent":
                    strText = obj_professionalLiability.retroactiveHistory().getText();
                    strQuestion="Is there a retroactive date on your previous Professional Indemnity schedule?";
                    Assert.assertTrue("RetroactiveHistory is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "RetroactiveHistoryHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.retroactiveHistoryHelpText());
                    strHelpText="The retroactive date should be clearly shown on your Professional Indemnity policy schedule.";
                    Assert.assertTrue("RetroactiveHistoryHelpText is displayed",strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "RetroactiveDatePresent":
                    strText = obj_professionalLiability.retroactiveDateQuestion().getText();
                    strQuestion="What's the retroactive date on your previous policy?";
                    Assert.assertTrue("RetroactiveDate is displayed",strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "RetroactiveDateHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.retroactiveDateHelpText());
                    strHelpText="The retroactive date should be clearly shown on your Professional Indemnity policy schedule.";
                    Assert.assertTrue("RetroactiveDateHelpText is displayed",strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "RetroactiveErrMsg":
                    commonutil.tabKeypress();
                    obj_generalInformation.pageLoading();
                    strText = obj_professionalLiability.retroactiveDateErrMsg().getText();
                    String errorMessage = "The retroactive date can't be in the future";
                    Assert.assertTrue("RetroactiveErrorMessage is displayed", errorMessage.equalsIgnoreCase(strText));
                    break;
                case "ProfessionalLiabilityDDLPresent":
                    strText = obj_professionalLiability.professLiabQuestion().getText();
                    strQuestion="How much Professional Indemnity cover would you like?";
                    Assert.assertTrue("ProfessionalLiabilityQuestion is displayed",strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "ProfessionalLiabilityDDLHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.professLiabQuestionHT());
                    strHelpText="Covers your business if your clients lose money or their business' reputation is damaged as a result of mistakes in advice, designs or services that you supply. We'll cover any compensation due and your legal costs for defending the claim.";
                    Assert.assertTrue("ProfessionalLiabilityQuestionHelpText is displayed",strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "ProfessionalLiabilityDrpDownValidation":
                    List<WebElement> plValues = new Select(obj_professionalLiability.PLCoverDropdown()).getOptions();
                    String ddlValues = "£100,000;£250,000;£500,000;£750,000;£1,000,000;£2,000,000;£5,000,000";
                    String[] checkValues = ddlValues.split(";");
                    for (int pl = 0; pl < checkValues.length; pl++) {
                        if (checkValues[pl].equalsIgnoreCase(plValues.get(pl + 1).getText().replace("\n", "").trim())) {
                            Assert.assertTrue("ProfessionalLiabilityDrpDown values are displayed", true);
                        } else {
                            Assert.assertTrue("ProfessionalLiabilityDrpDown values are not displayed", false);
                        }

                    }
                    break;
                case "ProfessionalLiabilityClaimPresent":
                    strText = obj_professionalLiability.professionalLiabilityClaimQues().getText();
                    strQuestion = "Has anyone informed you that they're intending to make a professional Indemnity claim against you?";
                    Assert.assertTrue("ProfessionalLiabilityClaim question is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;

                case "ProfessionalLiabilityClaimHelpText":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_professionalLiability.professionalLiabilityClaimHelpText());
                    strHelpText="If any of your clients have informed you they're considering taking legal action you must tell us.";
                    Assert.assertTrue("ProfessionalLiabilityClaim help text is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "ProfessionalLiabilityClaimAgainstPresent":
                    strText = obj_professionalLiability.professionalLiabilityClaimAgainstQues().getText();
                    strQuestion = "Are you aware of any issues in your work which could result in a claim against you?";
                    Assert.assertTrue("ProfessionalLiabilityClaimAgainst question is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "ProfessionalLiabilityClaimAgainstHelpText":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.professionalLiabilityClaimAgainstHelpText());
                    strHelpText = "If you're aware of any circumstances which could result in a professional liability claim, such as a letter from a solicitor or an expression of dissatisfaction from a client, then you must tell us.";
                    Assert.assertTrue("ProfessionalLiabilityClaim help text is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "LargestFeePresent":
                    strText = obj_professionalLiability.largestFeeQuestionPresent().getText();
                    strQuestion = "What's the largest fee you've received from a single client since you started trading?";
                    Assert.assertTrue("LargestFee question is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "LargestFeeHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.largestFeeHelpText());
                    strHelpText = "This is the largest gross fee which you've received. It may not necessarily have been in the last year. For new start ups please use an estimate of what you expect your largest gross fee to be.";
                    Assert.assertTrue("largestFeeHelpText is displayed", strText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "TaxWorkPresent":
                    strText = obj_professionalLiability.taxWorkQuestionPresent().getText();
                    strQuestion = "Is less than 20% of your fees related to corporate tax work (excluding VAT or personal tax advice)?";
                    Assert.assertTrue("TaxWork question is displayed",strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "TaxWorkHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.taxWorkHelpText());
                    strHelpText = "This shouldn't include income from personal tax or VAT work, only pure corporate tax work you've done.";
                    Assert.assertTrue("taxWorkHelpText is displayed",strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "WorkInRelationPresent":
                    strText = obj_professionalLiability.workInRelationQuestionPresent().getText();
                    strQuestion = "Have you carried out work in relation to: secretarial and share registration-executorships and trusteeships-insolvencies, liquadations and receiverships-investment business/financial services work-mergers/acquisitions-disposals-directorships-probate work and estate administration";
                    Assert.assertTrue("WorkInRelation question is displayed", strQuestion.replace("-", "").replace(" ", "").replace(",", "").replace(":", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "").replace("\n", "").replace(":", "")));
                    break;
                case "WorkInRelationHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.workInRelationHelpText());
                    strHelpText = "If your business activities involves, has involved or is expected to involve any services listed then you must tell us.";
                    Assert.assertTrue("workInRelationHelpText is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "LloydsPresent":
                    strText = obj_professionalLiability.lloydsQuestionPresent().getText();
                    strQuestion = "Have you carried out work in relation to:Lloyd's of London or any Lloyd's managing agents or members' agents-clients in the entertainment industry-quoted companies or public limited companies";
                    Assert.assertTrue("Lloyds question is displayed", strQuestion.replace(" ", "").replace(",", "").replace(":", "").replace("-", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "").replace("\n", "").replace(":", "")));
                    break;
                case "LloydsHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.lloydsHelpText());
                    strHelpText = "If your business activities involves, has involved or is expected to involve any services for the clients listed then you must tell us. 'Clients in the entertainment industry' means clients who are household names.";
                    Assert.assertTrue("lloydsHelpText is displayed",strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "AuthorisedPresent":
                    strText = obj_professionalLiability.authorisedQuestionPresent().getText();
                    strQuestion = "Is anyone in your business authorised to carry out probate or estate administration work or do you intend to in the future?";
                    Assert.assertTrue("Authorised question is displayed",strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "AuthorisedHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.authorisedHelpText());
                    strQuestion = "If anyone in your business is authorised or intends to become authorised to carry out probate or estate administration work, you must tell us.";
                    Assert.assertTrue("authorisedHelpText is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "TaxPlanningPresent":
                    strText = obj_professionalLiability.taxPlanningQuestionPresent().getText();
                    strQuestion = "Have you, or do you intend to work on, any tax planning schemes which could be considered as tax avoidance? This includes any involvement in tax planning schemes as well as acting as an introducer to these types of schemes.";
                    Assert.assertTrue("TaxPlanning question is displayed",strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "TaxPlanningHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.taxPlanningHelpText());
                    strHelpText = "If anyone in your business is involved in tax planning schemes you must tell us. This includes acting as an introducer to these types of schemes. Please go to the HMRC website www.hmrc.gov.uk to find what's considered tax avoidance.";
                    Assert.assertTrue("taxPlanningHelpText is displayed", strHelpText.replace(".", "").replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(".", "").replace(" ", "").replace(",", "")));
                    break;
                case "ACCAQualifiedPresent":
                    strText = obj_professionalLiability.aCCAQuestionPresent().getText();
                    strQuestion = "Are you ACA/ICAEW or ACCA qualified?";
                    Assert.assertTrue("ACCAQualified question is displayed",strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "ACCAQualifiedHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.aCCAHelpText());
                    strHelpText="";
                    Assert.assertTrue("ACCAQualifiedHT is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;

                case "ACCAQualifiedNotPresent":
                    if (!obj_professionalLiability.aCCAQuestion().get(0).isDisplayed()) {
                        Assert.assertTrue("aCCAQuestion not present", true);
                    } else {
                        Assert.assertTrue("aCCAQuestion present", false);
                    }
                    break;
                case "AuthorisedNotPresent":
                    if (!obj_professionalLiability.authorisedQuestion().get(0).isDisplayed()) {
                        Assert.assertTrue("authorisedQuestion not present", true);
                    } else {
                        Assert.assertTrue("authorisedQuestion present", false);
                    }
                    break;
                case "LloydsNotPresent":
                    if (!obj_professionalLiability.lloydsQuestion().get(0).isDisplayed()) {
                        Assert.assertTrue("lloydsQuestion not present", true);
                    } else {
                        Assert.assertTrue("lloydsQuestion present", false);
                    }
                    break;
                case "WorkInNotPresent":
                    if (!obj_professionalLiability.workInQuestion().get(0).isDisplayed()) {
                        Assert.assertTrue("workInQuestion not present", true);
                    } else {
                        Assert.assertTrue("workInQuestion present", false);
                    }
                    break;
                case "TaxWorkNotPresent":
                    if (!obj_professionalLiability.taxWorkQuestion().get(0).isDisplayed()) {
                        Assert.assertTrue("taxWorkQuestion not present", true);
                    } else {
                        Assert.assertTrue("taxWorkQuestion present", false);
                    }
                    break;
                case "LargestFeeNotPresent":
                    if (!obj_professionalLiability.largestFeeQuestion().get(0).isDisplayed()) {
                        Assert.assertTrue("largestFeeQuestion not present", true);
                    } else {
                        Assert.assertTrue("largestFeeQuestion present", false);
                    }
                    break;

                case "TaxPlanningNotPresent":
                    if (!obj_professionalLiability.taxPlanningQuestion().get(0).isDisplayed()) {
                        Assert.assertTrue("taxPlanningQuestion not present", true);
                    } else {
                        Assert.assertTrue("taxPlanningQuestion present", false);
                    }
                    break;
                case "LargestFeeRequired":
                    String strFeeReq = obj_professionalLiability.largestFeeRequired().getText();
                    if(strFeeReq.equalsIgnoreCase("Required")){

                        Assert.assertTrue("Required Error Message is displayed", true);
                    }else
                    {
                        Assert.assertTrue("Required Error Message is not displayed", false);
                    }
                    break;
                case "TaxWorkRequired":
                    String strTaxReq = obj_professionalLiability.taxWorkRequired().getText();
                    if(strTaxReq.equalsIgnoreCase("Required")){

                        Assert.assertTrue("Required Error Message is displayed", true);
                    }else
                    {
                        Assert.assertTrue("Required Error Message is not displayed", false);
                    }
                    break;
                case "WorkInRelationRequired":
                    String strWorkIn = obj_professionalLiability.workInRelationRequired().getText();
                    if(strWorkIn.equalsIgnoreCase("Required")){

                        Assert.assertTrue("Required Error Message is displayed", true);
                    }else
                    {
                        Assert.assertTrue("Required Error Message is not displayed", false);
                    }
                    break;
                case "LloydsRequired":
                    String strLloyd = obj_professionalLiability.lloydsRequired().getText();
                    if(strLloyd.equalsIgnoreCase("Required")){

                        Assert.assertTrue("Required Error Message is displayed", true);
                    }else
                    {
                        Assert.assertTrue("Required Error Message is not displayed", false);
                    }
                    break;
                case "AuthorisedRequired":
                    String strAuth = obj_professionalLiability.authorisedRequired().getText();
                    if(strAuth.equalsIgnoreCase("Required")){

                        Assert.assertTrue("Required Error Message is displayed", true);
                    }else
                    {
                        Assert.assertTrue("Required Error Message is not displayed", false);
                    }
                    break;
                case "TaxPlanningRequired":
                    String strTaxPlan = obj_professionalLiability.taxPlanningRequired().getText();
                    if(strTaxPlan.equalsIgnoreCase("Required")){

                        Assert.assertTrue("Required Error Message is displayed", true);
                    }else
                    {
                        Assert.assertTrue("Required Error Message is not displayed", false);
                    }
                    break;
                case "ACCAQualifiedRequired":
                    String strQual = obj_professionalLiability.aCCAQualifiedRequired().getText();
                    if(strQual.equalsIgnoreCase("Required")){

                        Assert.assertTrue("Required Error Message is displayed", true);
                    }else
                    {
                        Assert.assertTrue("Required Error Message is not displayed", false);
                    }
                    break;

                case "BusinessCarryOutQuestion":
                    strText = obj_professionalLiability.businessCarryOutQuestion().get(0).getText();
                    strQuestion="Does your business carry out any of the following: legal advice, consultancy for offshore entities, insolvency, mortgage, tax advice, insurance, investment, mergers and acquisitions or management of construction projects?";
                    Assert.assertTrue("BusinessCarryOut question is displayed",strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.PLNextButton());
                    break;
                case "BusinessCarryOutRequired":
                    if (obj_professionalLiability.requiredMsgBusinessCarryOut().isDisplayed()) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "BusinessCarryOutNotPresent":
                    if (!obj_professionalLiability.businessCarryOutQuestion().get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
                case "RIBAQuestion":
                    String strRIBA = obj_professionalLiability.RIBALbl().get(0).getText();
                    strQuestion="Are you a member of ARB or RIBA?";
                    Assert.assertTrue("RIBA question is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strRIBA.replace(" ", "").replace(",", "")));
                    break;
                case "RIBARequired":
                    if (obj_professionalLiability.reqMsgRIBA().isDisplayed()) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "BusinessWorkAreaQuestion":
                    String strBusinessWorkArea = obj_professionalLiability.businessWorkAreaLbl().get(0).getText();
                    strQuestion="Does your business work in any of the following areas: nuclear, chemical, mining, offshore, tunnelling, bridges, railways, swimming pools,high rise projects over 18 metres or golf courses?";
                    Assert.assertTrue("BusinessWorkArea question is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strBusinessWorkArea.replace(" ", "").replace(",", "")));
                    break;
                case "BusinessWorkAreaRequired":
                    if (obj_professionalLiability.reqMsgBusinessWorkArea().isDisplayed()) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "BusinessWorkAreaHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.businessWorkAreaHelpText());
                    strHelpText="If any of your work involves/has involved or is expected to involve any of the areas listed then you must tell us.";
                    Assert.assertTrue("Business work area HelpText is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "ContractsWritingQuestion":
                    String strContractsWriting = obj_professionalLiability.contractWritingLbl().get(0).getText();
                    strQuestion="Are all contracts in writing?";
                    Assert.assertTrue("ContractsWriting question is displayed",strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strContractsWriting.replace(" ", "").replace(",", "")));
                    break;
                case "ContractsWritingRequired":
                    if (obj_professionalLiability.reqMsgContractsWriting().isDisplayed()) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "ContractsWritingHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.contractWritingHelpText());
                    strHelpText="Contracts may be standard or bespoke for each client but they must be in writing.";
                    Assert.assertTrue("Contract writing HelpText is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "ConstructionValueQuestion":
                    String strConstructionValue = obj_professionalLiability.constructionValueLbl().get(0).getText();
                    strQuestion="Do you work on contracts with a total construction value of more than £2 million?";
                    Assert.assertTrue("ConstructionValue question is displayed",strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strConstructionValue.replace(" ", "").replace(",", "")));
                    break;
                case "ConstructionValueRequired":
                    if (obj_professionalLiability.reqMsgConstructionValue().isDisplayed()) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "ConstructionValueHT":
                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_professionalLiability.constructionValueHelpText());
                    strHelpText="The contract value is the overall construction value not just the value of your involvement. For instance, if you're involved in the interior design on a new house, the contract value would be that of the house not just the interior design.";
                    Assert.assertTrue("Construction value HelpText is displayed",strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "RIBANotPresent":
                    if (!obj_professionalLiability.RIBALbl().get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
                case "BusinessWorkAreaNotPresent":
                    if (!obj_professionalLiability.businessWorkAreaLbl().get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
                case "ContractsWritingNotPresent":
                    if (!obj_professionalLiability.contractWritingLbl().get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
                case "ConstructionValueNotPresent":
                    if (!obj_professionalLiability.constructionValueLbl().get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;

                case "PLAccordionNotPresent":
                    //validating whether Prof Liability accordian is not present
                    if (!obj_professionalLiability.profLiabilityAccordion("Professional Liability").isDisplayed()) {
                        Assert.assertTrue("Accordion not present", true);
                    } else {
                        Assert.assertTrue("Accordion present", false);
                    }
                    break;
                case "PLAccordionRemove":
                    //Removing the PL Accordion cover

                    String popUPOption = ProfessionalLiabilityElements.get(ProfessionalLiabilityQuestion);
                    String popUPText="Are you sure you'd like to remove this cover? If you change your mind later you can always add it back in on the Quote Summary page.";
                    if (obj_professionalLiability.bitButton().get(0).isDisplayed()) {
                        Assert.assertTrue("Bin button present", true);
                        obj_professionalLiability.executeScript("arguments[0].click();",obj_professionalLiability.bitButton().get(0));
                        obj_generalInformation.pageLoading();

                        //Validating the popup text message
                        if(popUPText.replace(" ","").equalsIgnoreCase(obj_professionalLiability.profLiabilityPopUpText().getText().replace("\n","").replace(" ",""))) {
                            Assert.assertTrue("PopUp text is matched", true);
                        }else{
                            Assert.assertTrue("PopUp text is not matched", false);
                        }
                        //Selecting the option Yes/No for popup
                        if(!popUPOption.equalsIgnoreCase("")){
                            obj_professionalLiability.executeScript("arguments[0].click();",obj_professionalLiability.profLiabilityPopUpYesNoOption(popUPOption));
                            obj_generalInformation.pageLoading();
                            Assert.assertTrue("Popup option clicked", true);


                        }else{
                            Assert.assertTrue("Popup option not clicked/Input is not passed", false);
                        }

                    } else {
                        Assert.assertTrue("Bin button not present", false);
                    }
                    break;

                case "Next":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.PLNextButton());
                    obj_generalInformation.pageLoading();
                    break;

            }
        }
    }

    public void requiredInPI(List<List<String>> data) throws Throwable {
        obj_generalInformation.executeScript("arguments[0].click();", obj_professionalLiability.PLNextButton());
        obj_generalInformation.pageLoading();
        for (int i = 0; i < data.size(); i++) {
            switch (data.get(i).get(1)) {
                case "LargestFeeRequired":
                    String strFeeReq = obj_professionalLiability.largestFeeRequired().getText();
                    Assert.assertTrue("LargestFeeRequired is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strFeeReq.replace(" ", "").replace(",", "")));
                    break;
                case "TaxWorkRequired":
                    String strTaxReq = obj_professionalLiability.taxWorkRequired().getText();
                    Assert.assertTrue("TaxWorkRequired is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strTaxReq.replace(" ", "").replace(",", "")));
                    break;
                case "WorkInRelationRequired":
                    String strWorkIn = obj_professionalLiability.workInRelationRequired().getText();
                    Assert.assertTrue("WorkInRelationRequired is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strWorkIn.replace(" ", "").replace(",", "")));
                    break;
                case "LloydsRequired":
                    String strLloyds = obj_professionalLiability.lloydsRequired().getText();
                    Assert.assertTrue("LloydsRequired is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strLloyds.replace(" ", "").replace(",", "")));
                    break;
                case "AuthorisedRequired":
                    String strAuth = obj_professionalLiability.authorisedRequired().getText();
                    Assert.assertTrue("AuthorisedRequired is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strAuth.replace(" ", "").replace(",", "")));
                    break;
                case "TaxPlanningRequired":
                    String strTaxPlan = obj_professionalLiability.taxPlanningRequired().getText();
                    Assert.assertTrue("AuthorisedRequired is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strTaxPlan.replace(" ", "").replace(",", "")));
                    break;
                case "ACCAQualifiedRequired":
                    String strQual = obj_professionalLiability.aCCAQualifiedRequired().getText();
                    Assert.assertTrue("ACCAQualifiedRequired is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strQual.replace(" ", "").replace(",", "")));
                    break;

            }
        }
    }
}
