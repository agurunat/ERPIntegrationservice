package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_Intersetedparty;
import com.usmanhussain.habanero.framework.AbstractPage;

import java.util.List;

public class InterestedpartyUtil extends AbstractPage {

    private CommonUtil commonutil = new CommonUtil();
    private Obj_Intersetedparty intersetedparty = new Obj_Intersetedparty();

    public void interestedParties(List<List<String>> data, String fieldName) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        if (StrVal.equalsIgnoreCase("Yes")) {
            intersetedparty.executeScript("arguments[0].click();", intersetedparty.addPartyYesRadiobutton());
        } else {
            intersetedparty.executeScript("arguments[0].click();", intersetedparty.addPartyNoRadiobutton());
        }
    }
}