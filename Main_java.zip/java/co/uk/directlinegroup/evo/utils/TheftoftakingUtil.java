package co.uk.directlinegroup.evo.utils;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

/**
 * Created by 323835 on 6/8/2017.
 */
public class TheftoftakingUtil {

    private CommonUtil commonutil = new CommonUtil();

    public void theftoftaking(List<List<String>> data, String fieldName, WebElement property) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        String val = "£";
        String ss = val.concat(StrVal);
        new Select((property)).selectByVisibleText(ss);
    }

}
