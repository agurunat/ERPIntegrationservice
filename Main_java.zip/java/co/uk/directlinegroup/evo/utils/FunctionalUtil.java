package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.*;
import org.junit.Assert;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Pattern;

import static com.usmanhussain.habanero.framework.AbstractPage.getDriver;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.lessThan;
import static org.seleniumhq.jetty7.io.nio.SelectorManager.LOG;

public class FunctionalUtil {

    public static String strEmail, strFirstName, strSecondName, policyNumber = "", strBusinessName = "", policyNumberMegaScript = "", editedValue;
    public String haveEmployee, strCovers, strHelpText, strValidateHelpText;
    private Obj_Generalinformation obj_generalInformation = new Obj_Generalinformation();
    private Obj_Peoplebusiness obj_peoplebusiness = new Obj_Peoplebusiness();
    private Obj_Liabilitycover obj_liabilitycover = new Obj_Liabilitycover();
    private Obj_Importantstatement obj_impornantstatement = new Obj_Importantstatement();
    private Obj_Claims obj_claims = new Obj_Claims();
    private Obj_Coverwizard obj_coverwizard = new Obj_Coverwizard();
    private Obj_Createcustomer obj_createCustomer = new Obj_Createcustomer();
    private Obj_Businesspremises obj_businessPremises = new Obj_Businesspremises();
    private CommonUtil obj_commonUtil = new CommonUtil();
    private Obj_Propertyaway obj_propertyAway = new Obj_Propertyaway();
    private Obj_Quotesummary obj_quoteSummary = new Obj_Quotesummary();
    private BusinesspremisesUtil obj_businessPremisesUtil = new BusinesspremisesUtil();
    private Obj_BusinessInterruption obj_businessInterruption = new Obj_BusinessInterruption();
    private Obj_Theftoftaking obj_theftOfTakings = new Obj_Theftoftaking();
    private Obj_Createaccount obj_createAccount = new Obj_Createaccount();
    private CreateaccountUtil createAccountUtil = new CreateaccountUtil();
    private Obj_Intersetedparty obj_interestedParty = new Obj_Intersetedparty();
    private Obj_Contacts obj_contacts = new Obj_Contacts();
    private Obj_Paymentselection obj_paymentSelection = new Obj_Paymentselection();
    private Obj_Directdebit obj_directDebit = new Obj_Directdebit();
    private Obj_Paymentinformation obj_paymentInformation = new Obj_Paymentinformation();
    private Obj_Carddetails obj_cardDetails = new Obj_Carddetails();
    private GeneralinformationUtil obj_generalInformationUtil = new GeneralinformationUtil();
    private Obj_PostQuote obj_postquote = new Obj_PostQuote();
    private Obj_Treatments obj_treatments = new Obj_Treatments();
    private Obj_CC_Search ccSearch = new Obj_CC_Search();
    private Obj_SaveAndExit obj_saveExit = new Obj_SaveAndExit();
    private CCSearchUtil ccsearchUtil = new CCSearchUtil();
    private Obj_SS_Login obj_ss_login = new Obj_SS_Login();
    private Obj_BusinessInteruptionThirdParty thirdPartyBI = new Obj_BusinessInteruptionThirdParty();
    private Obj_Notes obj_notes = new Obj_Notes();
    private Obj_BusinessInteruptionThirdParty businessInteruptionThirdParty = new Obj_BusinessInteruptionThirdParty();
    private PeoplebusinessUtil peoplebusinesutil = new PeoplebusinessUtil();
    private ProfessionalLiabilityUtil professionalLiabilityUtil = new ProfessionalLiabilityUtil();
    public static int f = 0;
    private String strText, question, strQuestion, strReqMsg, typeOfBuild, typeOfBuildOut;
    private Obj_Importantstatement obj_importantstatement = new Obj_Importantstatement();
    public Obj_ProfessionalLiability obj_professionalLiability = new Obj_ProfessionalLiability();
    public static float Premium1, Premium4;
    public String[] cover;


    public void fillCoverWizardSection() {
        obj_coverwizard.tradeNameTextbox().sendKeys("Hotel");
        obj_coverwizard.tradeNameSelect().click();
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.livePremisesYesRadiobutton());
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbLivepremisesNextbutton());
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbHaveEmpNoRadiobutton());
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbCoverNoneCheckbox());
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversContinueButton());
    }


    public void fillCoverWizardSectionBIBB() {
        obj_coverwizard.tradeNameTextbox().sendKeys("Hotel");
        obj_coverwizard.tradeNameSelect().click();
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.livePremisesYesRadiobutton());
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbLivepremisesNextbutton());
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbHaveEmpNoRadiobutton());
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbCoverBICheckbox());
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversContinueButton());
    }

    public void fillCoverWizardSectionBI() {
        obj_coverwizard.tradeNameTextbox().sendKeys("Actuary");
        obj_coverwizard.tradeNameSelect().click();
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.livePremisesYesRadiobutton());
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbLivepremisesNextbutton());
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbHaveEmpNoRadiobutton());
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbCoverBICheckbox());
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversContinueButton());
    }


    public void fillCoverWizardSectionHnB() throws Throwable {
        obj_coverwizard.tradeNameTextbox().sendKeys("beautician");
        obj_coverwizard.tradeNameSelect().click();
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.mobileCheckbox());
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.businessNextButton());
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.noEmployeesRadiobutton());
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.noneCheckbox());
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversContinueButton());
    }

    public void fillCoverWizardSection(String CoverWizard) throws Throwable {
        HashMap<String, String> CoverWizardElements = new LinkedHashMap<String, String>();
        String[] CoverWizardFields = CoverWizard.split("#");
        for (int i = 1; i <= CoverWizardFields.length; i++) {
            String[] CoverWizardValues = CoverWizardFields[i - 1].split(";");
            CoverWizardElements.put(CoverWizardValues[0], CoverWizardValues[1]);
        }

        List<String> CoverWizardQuestions = new ArrayList<>(CoverWizardElements.keySet());
        for (String CoverWizardQuestion : CoverWizardQuestions) {
            switch (CoverWizardQuestion) {
                case "Frame":
                    obj_commonUtil.switchFrame("sagepay");
                    obj_coverwizard.tradeNameTextbox().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                    obj_coverwizard.wizardTradeList().click();
                    break;
                case "TradeName":
                    obj_coverwizard.tradeNameTextbox().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                    obj_coverwizard.wizardTradeList().click();
                    break;
                case "RunYourBusinessFrom":
                    String[] businessFromCheckbox = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < businessFromCheckbox.length; i++) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.businessFromCheckbox(businessFromCheckbox[i]));
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.businessNextButton());
                    obj_generalInformation.pageLoading();
                    break;
                case "HaveEmployee":
                    String[] haveEmployee = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < haveEmployee.length; i++) {
                        if (haveEmployee[i].equalsIgnoreCase("Permanent employee(s)")) {
                            haveEmployee[i] = "perm";
                        } else if (haveEmployee[i].equalsIgnoreCase("Temporary employee(s)")) {
                            haveEmployee[i] = "temp";
                        } else if (haveEmployee[i].equalsIgnoreCase("Permanent & temporary employees")) {
                            haveEmployee[i] = "both";
                        } else if (haveEmployee[i].equalsIgnoreCase("No")) {
                            haveEmployee[i] = "employee_no";
                        }
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.haveEmployeesButton(haveEmployee[i]));
                    }
                    break;
                case "EmployerLiabilityHB":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.employersLiabilityCoverRadiobutton(CoverWizardElements.get(CoverWizardQuestion)));
                    obj_generalInformation.pageLoading();
                    break;
                case "LivePremises":
                    if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Y")) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.livePremisesYesRadiobutton());
                    } else {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.livePremisesNoRadiobutton());
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbLivepremisesNextbutton());
                    break;
                case "Employees":
                    if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Y")) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbHaveEmpYesRadiobutton());
                    } else {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbHaveEmpNoRadiobutton());
                    }
                    break;
                case "EmployersLiability":
                    if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Y")) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbEmployersLiabilityCoverYesRadiobutton());
                    } else {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbEmployersLiabilityCoverNoRadiobutton());
                    }
                    break;
                case "Covers":
                    String[] covers = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < covers.length; i++) {
                        obj_generalInformation.pageLoading();
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversCheckbox(covers[i]));
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversContinueButton());
                    break;
                case "CoversHB":
                    String[] coversHB = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < coversHB.length; i++) {
                        obj_generalInformation.pageLoading();
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversCheckboxHB(coversHB[i]));
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversContinueButton());
                    break;
            }
        }
    }

    public void fillCoverWizardOfficeSection(String CoverWizard) throws Throwable {
        HashMap<String, String> CoverWizardElements = new LinkedHashMap<String, String>();
        String[] CoverWizardFields = CoverWizard.split("#");
        for (int i = 1; i <= CoverWizardFields.length; i++) {
            String[] CoverWizardValues = CoverWizardFields[i - 1].split(";");
            CoverWizardElements.put(CoverWizardValues[0], CoverWizardValues[1]);
        }

        List<String> CoverWizardQuestions = new ArrayList<>(CoverWizardElements.keySet());
        for (String CoverWizardQuestion : CoverWizardQuestions) {
            switch (CoverWizardQuestion) {
                case "TradeType":
                    switch ((CoverWizardElements.get(CoverWizardQuestion)).split(";")[0]) {
                        case "Generic Wizard":
                            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.getQuoteOnlineLink());
                            obj_coverwizard.switchWindow();
                            obj_generalInformation.pageLoading();
                            break;
                        case "hb":
                            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.hbLink());
                            obj_coverwizard.switchWindow();
                            obj_generalInformation.pageLoading();
                            break;
                        case "bb":
                            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbLink());
                            obj_coverwizard.switchWindow();
                            obj_generalInformation.pageLoading();
                            break;
                        case "Office":
                            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.offoiceConsultantLink());
                            obj_coverwizard.switchWindow();
                            obj_generalInformation.pageLoading();
                            break;
                        case "retail":
                            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.retailLink());
                            obj_coverwizard.switchWindow();
                            obj_generalInformation.pageLoading();
                            break;
                        case "food retail":
                            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.foodRetailLink());
                            obj_coverwizard.switchWindow();
                            obj_generalInformation.pageLoading();
                            break;
                    }
                    break;
                case "Frame":
                    obj_commonUtil.switchFrame("sagepay");
                    break;
                case "TradeName":
                    if (CoverWizardElements.get(CoverWizardQuestion).equalsIgnoreCase("Furniture retail")) {
                        obj_coverwizard.tradeNameTextbox().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                        obj_coverwizard.wizardTradeListFurniture().click();
                    } else if (CoverWizardElements.get(CoverWizardQuestion).equalsIgnoreCase("Accountant")) {
                        obj_coverwizard.tradeNameTextbox().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                        obj_coverwizard.wizardTradeListAcct().click();
                    } else {
                        obj_coverwizard.tradeNameTextbox().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                        Thread.sleep(5000);
                        obj_coverwizard.wizardTradeList().click();
                        Thread.sleep(5000);
                    }
                    break;
                case "CoverBasketValidation":
                    String tradeType = CoverWizardElements.get(CoverWizardQuestion);
                    if (tradeType.equalsIgnoreCase("Office")) {
                        int intSize = obj_coverwizard.basketStatus().size();
                        if (intSize > 0) {
                            Assert.assertTrue("Basket is empty", true);
                        }
                    } else if (tradeType.equalsIgnoreCase("Retail") || tradeType.equalsIgnoreCase("HB")) {
                        String strPLText = "Public and Products Liability";
                        String strPL = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_coverwizard.wizardCoverBasketPL());
                        Assert.assertTrue(strPL + "is displayed", strPLText.equalsIgnoreCase(strPL));
                    } else {
                        if (tradeType.equalsIgnoreCase("BB")) {
                            String strPLText = "Public and Products Liability";
                            String strPL = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_coverwizard.wizardCoverBasketPL());
                            Assert.assertTrue(strPL + "is displayed", strPLText.equalsIgnoreCase(strPL));
                            String strGEText = "Guest effects";
                            String strGE = ((String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_coverwizard.wizardCoverBasketGE())).trim();
                            Assert.assertTrue(strGE + "is displayed", strGEText.equalsIgnoreCase(strGE));
                            String strBCSText = "Business contents and stock";
                            String strBCS = ((String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_coverwizard.businessContentAndStock()));
                            Assert.assertTrue(strBCS + "is displayed", strBCSText.equalsIgnoreCase(strBCS));
                        }
                    }
                    break;
                case "RunYourBusinessFrom":
                    String[] businessFromCheckbox = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < businessFromCheckbox.length; i++) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.businessFromCheckbox(businessFromCheckbox[i]));
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.businessNextButton());
                    obj_generalInformation.pageLoading();
                    break;
                case "HaveEmployee":
                    String[] haveEmployees = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < haveEmployees.length; i++) {
                        if (haveEmployees[i].equalsIgnoreCase("Permanent employee(s)")) {
                            haveEmployees[i] = "perm";
                        } else if (haveEmployees[i].equalsIgnoreCase("Temporary employee(s)")) {
                            haveEmployees[i] = "temp";
                        } else if (haveEmployees[i].equalsIgnoreCase("Permanent & temporary employees")) {
                            haveEmployees[i] = "both";
                        } else if (haveEmployees[i].equalsIgnoreCase("No")) {
                            haveEmployees[i] = "employee_no";
                        }
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.haveEmployeesButton(haveEmployees[i]));
                    }
                    break;
                case "EmployerLiabilityHB":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.employersLiabilityCoverRadiobutton(CoverWizardElements.get(CoverWizardQuestion)));
                    obj_generalInformation.pageLoading();
                    break;
                case "LivePremises":
                    if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Y")) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.livePremisesYesRadiobutton());
                    } else {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.livePremisesNoRadiobutton());
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbLivepremisesNextbutton());
                    break;
                case "Employees":
                    if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Y")) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbHaveEmpYesRadiobutton());
                    } else {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbHaveEmpNoRadiobutton());
                    }
                    break;
                case "EmployersLiability":
                    if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Y")) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.employersLiabilityCoverYesRadiobutton());
                    } else {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.employersLiabilityCoverNoRadiobutton());
                    }
                    break;
                case "Covers":
                    String[] covers = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < covers.length; i++) {
                        obj_generalInformation.pageLoading();
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversCheckbox(covers[i]));
                    }
                    if (!CoverWizard.contains("Continue;N")) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversContinueButton());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "CoversHB":
                    String[] coversHB = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < coversHB.length; i++) {
                        obj_generalInformation.pageLoading();
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversCheckboxHB(coversHB[i]));
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversContinueButton());
                    obj_generalInformation.pageLoading();
                    break;
                case "CoversNotPresent":
                    String[] CoversNotPresent = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < CoversNotPresent.length; i++) {
                        int size = obj_coverwizard.coversNames(CoversNotPresent[i]).size();
                        if (size == 0) {
                            Assert.assertTrue("Specific cover is not present", true);

                        } else {
                            Assert.assertTrue("Specific cover is present", false);
                        }

                    }
                    break;
                case "ProfessioanalIndemnityDecline":
                    if (CoverWizardElements.get(CoverWizardQuestion).equalsIgnoreCase("Present")) {
                        strQuestion = obj_coverwizard.piDeclineContent().get(0).getText();
                        strText = "Sorry, due to your trade we're unable to offer you Professional Indemnity cover, but please pick which other covers you'd like.Things do change, though, so next time you're looking for cover for Professional Indemnity, please contact us and we'll see if we can help.";
                        Assert.assertTrue("Professional indemnity decline content present", strQuestion.replace(" ", "").replace("\n", "").equalsIgnoreCase(strText.replace(" ", "")));
                    } else if (CoverWizardElements.get(CoverWizardQuestion).equalsIgnoreCase("NotPresent")) {
                        Assert.assertTrue("Professional indemnity decline content not present", !obj_coverwizard.piDeclineContent().get(0).isDisplayed());

                    }
                    break;
                case "CoversPresent":
                    String[] CoversPresent = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < CoversPresent.length; i++) {
                        int size = obj_coverwizard.coversNames(CoversPresent[i]).size();
                        if (size == 1) {
                            Assert.assertTrue("Specific cover is present", true);

                        } else {
                            Assert.assertTrue("Specific cover is not present", false);
                        }
                    }
                    break;
                case "BasketEmpty":
                    int intSize = obj_coverwizard.basketStatus().size();
                    if (intSize > 0) {
                        Assert.assertTrue("Basket is empty", true);
                    }
                    break;

                case "TradeDeclineValidation":
                    String strDecline = obj_coverwizard.sellProductDecline().getText();
                    String strExpected = CoverWizardElements.get(CoverWizardQuestion);
                    String expText = strDecline.replace(" ", "").replace(",", "").replace("-", "").replace(".", "").replace("'", "").replace("\n", "");
                    String actText = strExpected.replace(" ", "").replace(",", "").replace("-", "").replace(".", "").replace("'", "").replace("\n", "");
                    if (expText.equals(actText)) {
                        Assert.assertTrue("Decline message present", true);
                    } else {
                        Assert.assertTrue("Decline message not present", false);
                    }
                    break;
                case "sellProductDatavalues":
                    Assert.assertTrue(obj_generalInformation.sellProductValidation().get(0).getAttribute("checked"), true);
                    String[] sellProductDataPoints = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    String sellProductdata = obj_generalInformation.sellProductValidation().get(0).getText();
                    String[] sellProductdataApplication = sellProductdata.split("\n");
                    for (int i = 0; i < sellProductDataPoints.length; i++) {
                        for (int j = 0; j < sellProductdataApplication.length; j++) {
                            if (sellProductDataPoints[i].equalsIgnoreCase(sellProductdataApplication[j])) {
                                Assert.assertTrue("Displayed", true);
                            } else {
                                Assert.assertFalse(false);
                            }
                        }
                    }
                    break;
                case "updateSellProductErrorMessage":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.sellProductRunBusinessCoverOPRMobileFood());
                    String text = obj_generalInformation.gideclineMessage().getText();
                    if (text.equalsIgnoreCase(CoverWizardElements.get(CoverWizardQuestion))) {
                        Assert.assertTrue("Error Message is displayed", true);
                    } else {
                        Assert.assertTrue("Error Message is displayed", false);
                    }
                    obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.sellProductRunBusinessCoverOPRMobileFood());
                    break;
                case "validateSellProductQuestionNotDisplayed":
                    obj_commonUtil.waitForPageLoad();
                    int element = obj_generalInformation.sellProductValidation().size();
                    if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Displayed")) {
                        if (element == 1) {
                            String elementValue = obj_generalInformation.sellProductValidation().get(0).getText();
                            Assert.assertTrue(elementValue + "is displayed", true);
                        } else {
                            Assert.assertTrue("Element is not Present", false);
                        }
                    } else if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("NotDisplayed")) {

                        if (element == 0) {
                            Assert.assertTrue("Element is not Present", true);
                        } else {
                            Assert.assertTrue("Element is Present", false);
                        }
                    }
                    break;
                case "PICoverTextValidation":
                    String strCoverText = obj_coverwizard.plcoverText().get(0).getText();
                    String strExpectedText = "Sorry, due to your trade we're unable to offer you Professional Indemnity cover, but please pick which other covers you'd like. Things do change, though, so next time you're looking for cover for Professional Indemnity, please contact us and we'll see if we can help.";
                    String expCoverText = strCoverText.replace(" ", "").replace(",", "").replace("-", "").replace(".", "").replace("'", "").replace("\n", "");
                    String actCoverText = strExpectedText.replace(" ", "").replace(",", "").replace("-", "").replace(".", "").replace("'", "").replace("\n", "");
                    if (expCoverText.equals(actCoverText)) {
                        Assert.assertTrue("Validation message present", true);
                    } else {
                        Assert.assertTrue("Validation message not present", false);
                    }
                    break;
                case "PICoverTextValidationNotPresent":
                    int strCoverTextNotPresent = obj_coverwizard.plcoverText().size();
                    if (strCoverTextNotPresent == 0) {
                        Assert.assertTrue("Validation message is not present", true);
                    } else {
                        Assert.assertTrue("Validation message is present", false);
                    }
                    break;

                case "ValidateDeclineMessage":

                    String declineMsg = "We're sorry but based on what you told us, we're unable to offer you business insurance. Things do change, though, so next time you're looking for insurance, please contact us and we'll see if we can help.";
                    String declineMessage = obj_coverwizard.sellProductDecline().getText();
                    if (declineMessage.equals(declineMsg)) {
                        Assert.assertTrue("Decline message present", true);
                    } else {
                        Assert.assertTrue("Decline message not present", false);
                    }

                    break;
                case "CoverHelptext":
                    if (CoverWizardElements.get(CoverWizardQuestion).equalsIgnoreCase("Present")) {
                        strHelpText = "Covers your business if your clients lose money or their business' reputation is damaged as a result of mistakes in advice, designs or services that you supply.We'll cover any compensation due and your legal costs for defending the claim. ";
                        strValidateHelpText = obj_coverwizard.coverHelpText().get(0).getText();
                        Assert.assertTrue("Help text", strHelpText.replace(" ", "").equalsIgnoreCase(strValidateHelpText.replace(" ", "").replace("\n", "")));
                    }
                    break;
            }
        }
    }

    public void fillGeneralInformationOfficeSection(String CoverWizard) throws Throwable {
        HashMap<String, String> CoverWizardElements = new LinkedHashMap<String, String>();
        String[] CoverWizardFields = CoverWizard.split("#");
        for (int i = 1; i <= CoverWizardFields.length; i++) {
            String[] CoverWizardValues = CoverWizardFields[i - 1].split(";");
            CoverWizardElements.put(CoverWizardValues[0], CoverWizardValues[1]);
        }

        List<String> CoverWizardQuestions = new ArrayList<>(CoverWizardElements.keySet());
        for (String CoverWizardQuestion : CoverWizardQuestions) {
            switch (CoverWizardQuestion) {
                case "AnythingElse":
                    Thread.sleep(5000);
                    obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anyThingElseRadioButton(CoverWizardElements.get(CoverWizardQuestion)));
                    Thread.sleep(3000);
                    break;
                case "BusinessName":
                    obj_generalInformation.businessNameTextbox().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                    break;
                case "Title":
                    new Select(obj_generalInformation.titleDropdown()).selectByVisibleText(CoverWizardElements.get(CoverWizardQuestion));
                    break;
                case "FN":
                    obj_generalInformation.firstNameTextbox().sendKeys(obj_generalInformationUtil.randomFirstName());
                    break;
                case "SN":
                    strSecondName = obj_generalInformationUtil.randomSecondName();
                    obj_generalInformation.lastNameTextbox().sendKeys(strSecondName);
                    break;
                case "BusinessType":
                    new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText(CoverWizardElements.get(CoverWizardQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "Subsidaries":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesRadiobutton(CoverWizardElements.get(CoverWizardQuestion)));
                    break;
                case "BusinessTrade":
                    new Select(obj_generalInformation.tradeDropdownListValue()).selectByVisibleText(CoverWizardElements.get(CoverWizardQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "TurnOverLastYear":
                    String strValuee = CoverWizardElements.get(CoverWizardQuestion);
                    strValuee = strValuee.replace("*", "£");
                    new Select(obj_generalInformation.giLastTurnOverDropDown()).selectByVisibleText(strValuee);
                    obj_generalInformation.pageLoading();
                    break;
                case "TurnOverNextYear":
                    String strValueeNext = CoverWizardElements.get(CoverWizardQuestion);
                    strValuee = strValueeNext.replace("*", "£");
                    new Select(obj_generalInformation.giNextTurnOverDropDown()).selectByVisibleText(strValuee);
                    obj_generalInformation.pageLoading();
                    break;
                case "TurnOver":
                    String strValue = CoverWizardElements.get(CoverWizardQuestion);
                    strValue = strValue.replace("*", "£");
                    new Select(obj_generalInformation.giTurnOverDropDown()).selectByVisibleText(strValue);
                    obj_generalInformation.pageLoading();
                    break;
                case "TurnOverValue":
                    obj_generalInformation.giTurnOverValue().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "TurnOverValueNext":
                    obj_generalInformation.giTurnOverValueNext().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "PostCode":
                    obj_generalInformation.postcodeTextbox().clear();
                    obj_generalInformation.postcodeTextbox().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                    obj_generalInformation.findAddressButton().click();
                    Thread.sleep(4000);
                    new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByIndex(1);
                    obj_generalInformation.pageLoading();
                    obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.WFHDropdown());
                    obj_generalInformation.pageLoading();
                    break;
                case "PostCodeOtherTrade":
                    obj_generalInformation.postcodeTextbox().clear();
                    obj_generalInformation.postcodeTextbox().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                    obj_generalInformation.findAddressButton().click();
                    Thread.sleep(4000);
                    new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByIndex(1);
                    obj_generalInformation.pageLoading();
                    break;
                case "RunYourBusinessFrom":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.businessFromCheckbox(CoverWizardElements.get(CoverWizardQuestion)));
                    obj_generalInformation.pageLoading();
                    break;
                case "ManualWork":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.manualWork(CoverWizardElements.get(CoverWizardQuestion)));
                    break;
                case "BusinessWork":
                    new Select(obj_generalInformation.businessWorkLocDropdown()).selectByIndex(Integer.parseInt(CoverWizardElements.get(CoverWizardQuestion)));
                    break;
            }
        }
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillGeneralInformationOfficeSectionWithNext(String CoverWizard) throws Throwable {
        if (!CoverWizard.equalsIgnoreCase("null")) {
            HashMap<String, String> CoverWizardElements = new LinkedHashMap<String, String>();
            String[] businessValues;
            String[] CoverWizardFields = CoverWizard.split("#");

            for (int i = 1; i <= CoverWizardFields.length; i++) {
                String[] CoverWizardValues = CoverWizardFields[i - 1].split(";");
                CoverWizardElements.put(CoverWizardValues[0], CoverWizardValues[1]);
            }

            List<String> CoverWizardQuestions = new ArrayList<>(CoverWizardElements.keySet());
            for (String CoverWizardQuestion : CoverWizardQuestions) {
                switch (CoverWizardQuestion) {
                    case "AnythingElse": //Multiple trade - split all trades with '&' delimiter
                        Thread.sleep(5000);
                        String tradeList[] = CoverWizardElements.get(CoverWizardQuestion).split("&");
                        if (tradeList[0].equalsIgnoreCase("Y")) {
                            for (int trade = 1; trade < tradeList.length; trade++) {
                                obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anyThingElseRadioButton(tradeList[0]));
                                obj_generalInformation.pageLoading();
                                obj_generalInformation.tradeNameTextbox().sendKeys(tradeList[trade]);
                                obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.addMultipleTradeNameSelect(tradeList[trade]));
                                obj_generalInformation.pageLoading();
                            }
                        } else {
                            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anyThingElseRadioButton(CoverWizardElements.get(CoverWizardQuestion)));
                            Thread.sleep(3000);
                        }
                        break;
                    case "BusinessName":
                        strBusinessName = obj_generalInformationUtil.randomFirstName();
                        obj_generalInformation.businessNameTextbox().sendKeys(strBusinessName);
//                        System.out.println(strBusinessName);   //Priya: Needed to check policy number incase of documents test cases
                        break;
                    case "Title":
                        new Select(obj_generalInformation.titleDropdown()).selectByVisibleText(CoverWizardElements.get(CoverWizardQuestion));
                        break;
                    case "FN":
                        if (!CoverWizardElements.get(CoverWizardQuestion).equalsIgnoreCase("null") && !CoverWizardElements.get(CoverWizardQuestion).equalsIgnoreCase("Y")) {
                            obj_generalInformation.firstNameTextbox().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                        } else {
                            strFirstName = obj_generalInformationUtil.randomFirstName();
                            obj_generalInformation.firstNameTextbox().sendKeys(strFirstName);
                        }
                        break;


                    case "SN":
                        if (!CoverWizardElements.get(CoverWizardQuestion).equalsIgnoreCase("null") && !CoverWizardElements.get(CoverWizardQuestion).equalsIgnoreCase("Y")) {
                            obj_generalInformation.lastNameTextbox().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                        } else {
                            strSecondName = obj_generalInformationUtil.randomSecondName();
                            obj_generalInformation.lastNameTextbox().sendKeys(strSecondName);
                        }
                        break;
                    case "BusinessType":
                        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText(CoverWizardElements.get(CoverWizardQuestion));
                        obj_generalInformation.pageLoading();
                        break;
                    case "Subsidaries":
                        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesRadiobutton(CoverWizardElements.get(CoverWizardQuestion)));
                        break;
                    case "BusinessTrade":
                        new Select(obj_generalInformation.tradeDropdownListValue()).selectByVisibleText(CoverWizardElements.get(CoverWizardQuestion));
                        obj_generalInformation.pageLoading();
                        break;
                    case "TurnOverLastYear":
                        String strValuee = CoverWizardElements.get(CoverWizardQuestion);
                        strValuee = strValuee.replace("*", "£");
                        new Select(obj_generalInformation.giLastTurnOverDropDown()).selectByVisibleText(strValuee);
                        obj_generalInformation.pageLoading();
                        break;
                    case "TurnOverNextYear":
                        String strValueeNext = CoverWizardElements.get(CoverWizardQuestion);
                        strValuee = strValueeNext.replace("*", "£");
                        new Select(obj_generalInformation.giNextTurnOverDropDown()).selectByVisibleText(strValuee);
                        obj_generalInformation.pageLoading();
                        break;
                    case "TurnOver":
                        String strValue = CoverWizardElements.get(CoverWizardQuestion);
                        strValue = strValue.replace("*", "£");
                        new Select(obj_generalInformation.giTurnOverDropDown()).selectByVisibleText(strValue);
                        obj_generalInformation.pageLoading();
                        break;
                    case "TurnOverValue":
                        obj_generalInformation.giTurnOverValue().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                        obj_generalInformation.pageLoading();
                        break;
                    case "TurnOverValueNext":
                        obj_generalInformation.giTurnOverValueNext().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                        obj_generalInformation.pageLoading();
                        break;
                    case "PostCode":
                        obj_generalInformation.postcodeTextbox().clear();
                        obj_generalInformation.postcodeTextbox().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                        obj_generalInformation.findAddressButton().click();
                        //obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
                        Thread.sleep(4000);
                        new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByIndex(1);
                        obj_generalInformation.pageLoading();
//                    obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.mobileDropdown());
//                    obj_generalInformation.pageLoading();
                        break;
                    case "EnterAddressManually":
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.enterAddressButton());
                        obj_generalInformation.pageLoading();
                        String addressSplit[] = CoverWizardElements.get(CoverWizardQuestion).split("_");
                        for (int i = 0; i < 1; i++) {
                            obj_generalInformation.firstLineAddress().sendKeys(addressSplit[i]);
                            obj_generalInformation.pageLoading();
                            obj_commonUtil.tabKeypress();
                            obj_generalInformation.pageLoading();
                            obj_generalInformation.secondLineAddress().sendKeys(addressSplit[i + 1]);
                            obj_generalInformation.pageLoading();
                            obj_commonUtil.tabKeypress();
                            obj_generalInformation.pageLoading();
                            obj_generalInformation.addressTown().sendKeys(addressSplit[i + 2]);
                            obj_generalInformation.pageLoading();
                            obj_commonUtil.tabKeypress();
                            obj_generalInformation.pageLoading();
                            obj_generalInformation.addressCounty().sendKeys(addressSplit[i + 3]);
                            obj_generalInformation.pageLoading();
                            obj_commonUtil.tabKeypress();
                            obj_generalInformation.pageLoading();
                            new Select(obj_generalInformation.addressCountry()).selectByVisibleText(addressSplit[i + 4]);
                            obj_generalInformation.pageLoading();
                        }
                        break;
                    case "ManualWork":
                        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.manualWork(CoverWizardElements.get(CoverWizardQuestion)));
                        break;
                    case "RunYourBusinessFrom":
                        String[] businessFromCheckbox = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                        for (int i = 0; i < businessFromCheckbox.length; i++) {
                            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.businessFromCheckbox(businessFromCheckbox[i]));
                            obj_generalInformation.pageLoading();
                        }
                        break;
                    case "BusinessWork":
                        new Select(obj_generalInformation.businessWorkLocDropdown()).selectByIndex(Integer.parseInt(CoverWizardElements.get(CoverWizardQuestion)));
                        obj_generalInformation.pageLoading();
                        break;
                    case "Next":
                        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
                        obj_generalInformation.pageLoading();
                        break;
                    case "TwelveMonthTermPolicy":
                        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.twelveMonthPolicy(CoverWizardElements.get(CoverWizardQuestion)));
                        obj_generalInformation.pageLoading();
                        break;
                    case "RunBusinessCheck":

                        //Checking whether checkboxes are checked which is already choosed in coverd wizard
                        businessValues = CoverWizardElements.get(CoverWizardQuestion).split(":");

                        for (int i = 0; i < businessValues.length; i++) {

                            String businessTexts = obj_generalInformation.runBusinessCheckBoxes().get(0).getText();

                            String[] businessTextValues = businessTexts.split("\n");

                            for (int j = 0; j < businessTextValues.length; j++) {

                                String idValue = obj_generalInformation.runBusinessCheck(businessTextValues[j]).getAttribute("for");

                                String check = obj_generalInformation.runBusinessCheckInput(idValue).getAttribute("checked");

                                if (businessTextValues[j].equalsIgnoreCase(businessValues[i])) {

                                    if (check.equalsIgnoreCase("true")) {

                                        Assert.assertTrue(businessValues[i] + " is checked", true);

                                    } else {
                                        Assert.assertTrue(businessValues[i] + " is not checked", false);
                                    }

                                }


                            }
                        }

                        break;


                    case "OtherBusiness":
                        //Selecting the other checkboxes for runYourBusiness on GI page based on the input

                        businessValues = CoverWizardElements.get(CoverWizardQuestion).split(":");
                        for (int i = 0; i < businessValues.length; i++) {

                            String businessTexts = obj_generalInformation.runBusinessCheckBoxes().get(0).getText();

                            String[] businessTextValues = businessTexts.split("\n");

                            for (int j = 0; j < businessTextValues.length; j++) {

                                if (businessValues[i].equalsIgnoreCase(businessTextValues[j])) {
                                    obj_generalInformation.runBusinessCheck(businessTextValues[j]).click();
                                    obj_generalInformation.pageLoading();
                                    break;
                                }


                            }

                        }


                        break;

                    case "OtherSellProducts":
                        obj_generalInformation.pageLoading();
                        businessValues = CoverWizardElements.get(CoverWizardQuestion).split(":");
                        for (int i = 0; i < businessValues.length; i++) {

                            String businessTexts = obj_generalInformation.sellProductValidation().get(0).getText();

                            String[] businessTextValues = businessTexts.split("\n");

                            for (int j = 0; j < businessTextValues.length; j++) {

                                if (businessValues[i].equalsIgnoreCase(businessTextValues[j])) {
                                    obj_generalInformation.runBusinessCheck(businessTextValues[j]).click();
                                    obj_generalInformation.pageLoading();
                                    break;
                                }


                            }

                        }


                        break;

                    case "VerifyRunYourBusinessOption":
                        obj_generalInformation.runBusinessCheckBox();
                        businessValues = CoverWizardElements.get(CoverWizardQuestion).split(":");
                        for (int i = 0; i < businessValues.length; i++) {

                            String businessTexts = obj_generalInformation.runBusinessCheckBoxes().get(0).getText();

                            String[] businessTextValues = businessTexts.split("\n");

                            for (int j = 0; j < businessTextValues.length; j++) {

                                if (businessTextValues[j].equalsIgnoreCase(businessValues[i])) {

                                    Assert.assertTrue("Sell Your products related business Options are present in GI", true);
                                    f++;
                                    break;
                                }

                            }


                        }

                        if (f != 3) {
                            Assert.assertTrue("Sell Your products related business Options are mismatch in GI", false);
                        }

                        break;

                    case "RunYourBusinessNotPresent":

                        if (obj_generalInformation.runBusinessCheckBoxes().size() == 0) {

                            Assert.assertTrue("Where do you run your business from is not Present in GI", true);

                        } else {
                            Assert.assertTrue("Where do you run your business from is Present in GI", false);

                        }

                        break;

                    case "ValidateErrorMessage":
                        String errorMsg = obj_generalInformation.runYourBusinessErrorMessage().getText();
                        if (errorMsg.equalsIgnoreCase("Required")) {

                            Assert.assertTrue("Required Error Message is displayed", true);
                        } else {
                            Assert.assertTrue("Required Error Message is not displayed", false);
                        }

                        break;
                    case "ManualWorkQues":
                        question = "Do you, or any of your employees, do any manual work?";
                        strText = obj_generalInformation.manualWorkQuestion().get(0).getText();
                        Assert.assertTrue("ManualWorkQuestion is displayed", question.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                        break;
                    case "ManualWorkHelpText":
                        question = "Please answer yes if you carry out any manual work at your premises or away from your premises.";
                        strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_generalInformation.manualWorkQuestionHT().get(0));
                        Assert.assertTrue("ManualWorkHelpText is displayed", question.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                        break;
                    case "ITConsultant":
                        question = "We mean manual work other than small IT hardware repairs.";
                        strText = obj_generalInformation.staticTextForITConsult().get(0).getText();
                        Assert.assertTrue("ITConsultant static text is displayed", question.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                        break;
                    case "EstateProperty":
                        question = "We mean manual work other than putting up or taking down 'For sale' and 'To let' signs.";
                        strText = obj_generalInformation.staticTextForEstateProperty().get(0).getText();
                        Assert.assertTrue("Estate agency,Property letting,Property management trades related static text is displayed", question.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                        break;

                    case "WindowDresserQues":
                        question = "We mean manual work other than window dressing.";
                        strText = obj_generalInformation.staticTextForWindowDresser().get(0).getText();
                        Assert.assertTrue("WindowDresser static text is displayed", question.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                        break;

                    case "StaticQuestionNotPresent":
                        question = "We mean manual work other than small IT hardware repairs.#We mean manual work other than putting up or taking down 'For sale' and 'To let' signs.#We mean manual work other than window dressing.";
                        String[] staticQues = question.split("#");
                        for (int j = 0; j < staticQues.length; j++) {
                            if (staticQues[j].contains("IT hardware")) {

                                if (!obj_generalInformation.staticTextForITConsult().get(0).isDisplayed()) {
                                    Assert.assertTrue("Static text IT Consultant is not displayed ", true);
                                } else {
                                    Assert.assertTrue("Static text IT Consultant is displayed ", false);
                                }
                            } else if (staticQues[j].contains("For sale")) {
                                if (!obj_generalInformation.staticTextForEstateProperty().get(0).isDisplayed()) {
                                    Assert.assertTrue("Static text EstateAgent is not displayed ", true);
                                } else {
                                    Assert.assertTrue("Static text EstateAgent is displayed ", false);
                                }
                            } else if (staticQues[j].contains("window dressing")) {

                                if (!obj_generalInformation.staticTextForWindowDresser().get(0).isDisplayed()) {
                                    Assert.assertTrue("Static text WindowDresser is not displayed ", true);
                                } else {
                                    Assert.assertTrue("Static text WindowDresser is displayed ", false);
                                }

                            }


                        }
                        break;
                    case "ManualWorkNotPresent":

                        if (!obj_generalInformation.manualWorkQuestion().get(0).isDisplayed()) {
                            Assert.assertTrue("ManualWorkQuestion is not displayed", true);
                        } else {
                            Assert.assertTrue("ManualWorkHT is displayed", false);
                        }

                        break;

                    case "ManualWorkHTNotPresent":

                        if (!obj_generalInformation.manualWorkQuestionHT().get(0).isDisplayed()) {
                            Assert.assertTrue("ManualWorkHT is not displayed", true);
                        } else {
                            Assert.assertTrue("ManualWorkHT is displayed", false);
                        }


                        break;
                    case "GIQuestionHelpText":

                        String[] quesAndHT = CoverWizardElements.get(CoverWizardQuestion).split(":");

                        for (int q = 0; q < quesAndHT.length; q++) {

                            switch (quesAndHT[q]) {

                                case "EstimatedGross":

                                    question = "What's the estimated gross turnover of your business for the next financial year?";
                                    strText = obj_generalInformation.giNextYearTurnOverQuestionText().getText();
                                    Assert.assertTrue("Next Year Turn Over Question Text Message is displayed", strText.replace(" ", "").replace(",", "").equalsIgnoreCase(question.replace(" ", "").replace(",", "")));
                                    break;

                                case "EstimatedGrossHT":

                                    question = "Turnover means the money paid or payable to you for goods your business has sold and delivered, and for services you've provided";
                                    strText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_generalInformation.giNextYearTurnOverHelpText());
                                    Assert.assertTrue("Help Text Message is displayed", question.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                                    break;

                                case "PleaseTellEstimatedGrossQues":

                                    question = "Please tell us the estimated gross turnover for your business for the next financial year";
                                    strText = obj_generalInformation.giPlsTellUsText().getText();
                                    Assert.assertTrue("Please Tell us Gross TurnOver Text Message is displayed", question.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));

                                    break;
                            }
                        }
                        break;

                    case "ValidateGrossLastFinanceDropDwn":

                        strText = "Up to *25,000;*25,001 - *50,000;*50,001 - *75,000;*75,001 - *100,000;*100,001 - *150,000;*150,001 - *200,000;*200,001 - *250,000;*250,001 - *500,000;*500,001 - *750,000;*750,001 - *1,000,000;Over *1,000,000";

                        String[] arrValue = strText.split(";");

                        Select dropDwnValues = new Select(obj_generalInformation.giNextTurnOverDropDown());
                        List<WebElement> Options = dropDwnValues.getOptions();

                        if (arrValue.length == Options.size() - 1) {

                            for (int i = 0; i < arrValue.length; i++) {

                                String strPoundValue = arrValue[i].replace("*", "£");

                                Assert.assertTrue("DropDown values are matched", strPoundValue.equals(Options.get(i + 1).getText().trim().replace("\n", "")));
                            }


                        } else {
                            Assert.assertTrue("DropDown values are not matched", false);
                        }

                        break;

                    case "LastYearTurnoverHelpText":
                        String strhelpText = "Turnover means the money paid or payable to you for goods your business has sold and delivered, and for services you've provided";
                        String script = "return arguments[0].innerText";
                        String strHT = (String) ((JavascriptExecutor) getDriver).executeScript(script, obj_generalInformation.lastYearTurnOverHelpText());
                        if (strhelpText.replace(" ", "").equalsIgnoreCase(strHT.replace(" ", ""))) {
                            Assert.assertTrue("Help Text Message is displayed", true);
                        } else {
                            Assert.assertTrue("Help Text Message is not displayed correctly", false);
                        }
                        break;

                    case "TurnOverNextErrorMessage":
                        Assert.assertTrue(obj_generalInformation.giErrorMsgGreaterThan1Mill().getText().equalsIgnoreCase(CoverWizardElements.get(CoverWizardQuestion)));
                        break;
                    case "ValidateAnythingElseOtherTradeQues":

                        if (!CoverWizardElements.get(CoverWizardQuestion).equalsIgnoreCase("") && !CoverWizardElements.get(CoverWizardQuestion).equalsIgnoreCase("null")) {
                            String[] arrtext = CoverWizardElements.get(CoverWizardQuestion).split(":");
                            obj_generalInformation.anythingElseYesRadiobutton().click();
                            obj_generalInformation.pageLoading();
                            for (int i = 0; i < arrtext.length; i++) {
                                obj_coverwizard.GIQuestionCheck(arrtext[i]);
                            }
                        }
                        break;

                    case "ValidateTradesOnGI":

                        String[] arrTrade = CoverWizardElements.get(CoverWizardQuestion).split("@");

                        String[] trades = arrTrade[1].split(":");

                        if (arrTrade[0].equalsIgnoreCase("changing")) {

                            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.changeTrade());
                            obj_generalInformation.pageLoading();

                            for (int j = 0; j < trades.length; j++) {
                                obj_generalInformation.businessTradeTextBox().clear();
                                obj_generalInformation.businessTradeTextBox().sendKeys(trades[j]);

                                int size = obj_generalInformation.multiTradeAutocompleteCount(trades[j]).size();
                                if (size == 0) {
                                    Assert.assertTrue("Other trades are not displayed", true);
                                } else {
                                    Assert.assertTrue("Other trades are displayed", false);
                                }

                            }
                        } else if (!arrTrade[0].equalsIgnoreCase("changing")) {
                            String[] specificTrades = arrTrade[1].split(":");
                            obj_generalInformation.anythingElseYesRadiobutton().click();
                            obj_generalInformation.pageLoading();
                            for (int j = 0; j < specificTrades.length; j++) {
                                obj_generalInformation.businessTradeTextBox().clear();
                                obj_generalInformation.businessTradeTextBox().sendKeys(specificTrades[j]);

                                int size = obj_generalInformation.multiTradeAutocompleteCount(specificTrades[j]).size();
                                if (size == 0) {
                                    Assert.assertTrue("Other trades are not displayed", true);
                                } else {
                                    Assert.assertTrue("Other trades are displayed", false);
                                }

                            }

                        }

                        break;

                    case "DeclineTradeValidation":
                        String strText = obj_generalInformation.tanningSalonErrorMsg().getText();
                        String exp = CoverWizardElements.get(CoverWizardQuestion);
                        String expText = exp.replace(" ", "").replace(",", "").replace("-", "").replace(".", "").replace("'", "").replace("\n", "");
                        String actText = strText.replace(" ", "").replace(",", "").replace("-", "").replace(".", "").replace("'", "").replace("\n", "");
                        Assert.assertTrue("Required referral message is displayed", expText.equals(actText));
                        break;
                    case "ChangeTradeDeclineValidation":
                        String inputData[] = CoverWizardElements.get(CoverWizardQuestion).split("&");
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.changeTrade());
                        obj_generalInformation.pageLoading();
                        obj_generalInformation.businessTradeTextBox().sendKeys(inputData[0]);
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.selectTradeAutoPopulate());
                        obj_generalInformation.pageLoading();
                        String declineText = obj_generalInformation.changeTradeDeclineMsg().getText();
                        String expected = inputData[1].replace(" ", "").replace(",", "").replace("-", "").replace(".", "").replace("'", "").replace("\n", "");
                        String actual = declineText.replace(" ", "").replace(",", "").replace("-", "").replace(".", "").replace("'", "").replace("\n", "");
                        Assert.assertTrue("Required referral message is displayed", expected.equals(actual));
                        break;
                    case "ChangeTrade":
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.changeTrade());
                        obj_generalInformation.pageLoading();
                        obj_generalInformation.businessTradeTextBox().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.selectTradeAutoPopulate());
                        obj_generalInformation.pageLoading();
                        break;
                }
            }
        }

    }


    public void fillGeneralInformationOfficeSectionBI(String CoverWizard) throws Throwable {
        HashMap<String, String> CoverWizardElements = new LinkedHashMap<String, String>();
        String[] CoverWizardFields = CoverWizard.split("#");
        for (int i = 1; i <= CoverWizardFields.length; i++) {
            String[] CoverWizardValues = CoverWizardFields[i - 1].split(";");
            CoverWizardElements.put(CoverWizardValues[0], CoverWizardValues[1]);
        }

        List<String> CoverWizardQuestions = new ArrayList<>(CoverWizardElements.keySet());
        for (String CoverWizardQuestion : CoverWizardQuestions) {
            switch (CoverWizardQuestion) {
                case "AnythingElse":
                    Thread.sleep(5000);
                    obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anyThingElseRadioButton(CoverWizardElements.get(CoverWizardQuestion)));
                    Thread.sleep(3000);
                    break;
                case "BusinessName":
                    obj_generalInformation.businessNameTextbox().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                    break;
                case "Title":
                    new Select(obj_generalInformation.titleDropdown()).selectByVisibleText(CoverWizardElements.get(CoverWizardQuestion));
                    break;
                case "FN":
                    obj_generalInformation.firstNameTextbox().sendKeys(obj_generalInformationUtil.randomFirstName());
                    break;
                case "SN":
                    strSecondName = obj_generalInformationUtil.randomSecondName();
                    obj_generalInformation.lastNameTextbox().sendKeys(strSecondName);
                    break;
                case "BusinessType":
                    new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText(CoverWizardElements.get(CoverWizardQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "Subsidaries":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesRadiobutton(CoverWizardElements.get(CoverWizardQuestion)));
                    break;
                case "BusinessTrade":
                    new Select(obj_generalInformation.tradeDropdownListValue()).selectByVisibleText(CoverWizardElements.get(CoverWizardQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "TurnOverLastYear":
                    String strValuee = CoverWizardElements.get(CoverWizardQuestion);
                    strValuee = strValuee.replace("*", "£");
                    new Select(obj_generalInformation.giLastTurnOverDropDown()).selectByVisibleText(strValuee);
                    obj_generalInformation.pageLoading();
                    break;
                case "TurnOverNextYear":
                    String strValueeNext = CoverWizardElements.get(CoverWizardQuestion);
                    strValuee = strValueeNext.replace("*", "£");
                    new Select(obj_generalInformation.giNextTurnOverDropDown()).selectByVisibleText(strValuee);
                    obj_generalInformation.pageLoading();
                    break;
                case "TurnOver":
                    String strValue = CoverWizardElements.get(CoverWizardQuestion);
                    strValue = strValue.replace("*", "£");
                    new Select(obj_generalInformation.giTurnOverDropDown()).selectByVisibleText(strValue);
                    obj_generalInformation.pageLoading();
                    break;
                case "TurnOverValue":
                    obj_generalInformation.giTurnOverValue().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "TurnOverValueNext":
                    obj_generalInformation.giTurnOverValueNext().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "PostCode":
                    obj_generalInformation.postcodeTextbox().clear();
                    obj_generalInformation.postcodeTextbox().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                    obj_generalInformation.findAddressButton().click();
                    //obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
                    Thread.sleep(4000);
                    new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByIndex(1);
                    obj_generalInformation.pageLoading();
                    //  obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.mobileDropdown());
                    obj_generalInformation.pageLoading();
                    break;
                case "ManualWork":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.manualWork(CoverWizardElements.get(CoverWizardQuestion)));
                    break;
                case "BusinessWork":
                    new Select(obj_generalInformation.businessWorkLocDropdown()).selectByIndex(Integer.parseInt(CoverWizardElements.get(CoverWizardQuestion)));
                    break;
            }
        }
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void errorMessage(String GIErrorMessages) {
        String text = obj_generalInformation.giErrorMessage().getText();
        if (text.equalsIgnoreCase(GIErrorMessages)) {
            Assert.assertTrue("Error Message is displayed", true);
        } else {
            Assert.assertTrue("Error Message is displayed", false);
        }
    }

    public void lastYearTurnOverValidation() {
        new Select(obj_generalInformation.tradeDropdownListValue()).selectByVisibleText("2");
        obj_generalInformation.pageLoading();
        String strValue = "Up to *25,000;*25,001 - *50,000;*75,001 - *100,000;*100,001 - *150,000;*200,001 - *250,000;*250,001 - *500,000;*500,001 - *750,000;*750,001 - *1,000,000;Over *1,000,000";
        String strhelpText = "Turnover means the money paid or payable to you for goods your business has sold and delivered, and for services you've provided";
        String[] arrValue = strValue.split(";");
        for (int i = 0; i < arrValue.length - 1; i++) {
            String strPoundValue = arrValue[i].replace("*", "£");
            new Select(obj_generalInformation.giLastTurnOverDropDown()).selectByVisibleText(strPoundValue);
            obj_generalInformation.pageLoading();
        }
        String script = "return arguments[0].innerText";
        String strText = (String) ((JavascriptExecutor) getDriver).executeScript(script, obj_generalInformation.lastYearTurnOverHelpText());
        if (strhelpText.replace(" ", "").equalsIgnoreCase(strText.replace(" ", ""))) {
            Assert.assertTrue("Help Text Message is displayed", true);
        } else {
            Assert.assertTrue("Help Text Message is not displayed correctly", false);
        }
    }

    public void generalInformationQuestion(String Trade, String Text) {
        if (Text.equalsIgnoreCase("changing")) {
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.changeTrade());
            obj_generalInformation.pageLoading();
        } else if (!Text.equalsIgnoreCase("") && !Text.equalsIgnoreCase("null")) {
            String[] arrtext = Text.split("#");
            obj_generalInformation.anythingElseYesRadiobutton().click();
            obj_generalInformation.pageLoading();
            for (int i = 0; i < arrtext.length; i++) {
                obj_coverwizard.GIQuestionCheck(arrtext[i]);
            }
        }
        String[] arrTrade = Trade.split("#");
        String[] arrValidTrade = arrTrade[0].split(";");
        String[] arrInvalidTrade = arrTrade[1].split(";");
        for (int j = 0; j < arrValidTrade.length; j++) {
            if (!arrValidTrade[j].equals("")) {
                obj_generalInformation.otherTradeTextbox().clear();
                obj_generalInformation.otherTradeTextbox().sendKeys(arrValidTrade[j]);
                obj_generalInformation.multiTradeAutocompleteList(arrValidTrade[j]);
            }
        }
        for (int j = 0; j < arrInvalidTrade.length; j++) {
            if (!arrInvalidTrade[j].equals("")) {
                if (Text.equalsIgnoreCase("changing")) {
                    obj_generalInformation.businessTradeTextBox().clear();
                    obj_generalInformation.businessTradeTextBox().sendKeys(arrInvalidTrade[j]);
                } else {
                    obj_generalInformation.otherTradeTextbox().clear();
                    obj_generalInformation.otherTradeTextbox().sendKeys(arrInvalidTrade[j]);
                }
                int size = obj_generalInformation.multiTradeAutocompleteCount(arrInvalidTrade[j]).size();
                if (size == 0) {
                    Assert.assertTrue("Other trades are not displayed", true);
                } else {
                    Assert.assertTrue("Other trades are displayed", false);
                }
            }
        }
    }

    public void fillCoverWizardSectionForHnB(String tradeName, String workBusiness, String haveEmployees, String employeeLiabilityCover, String covers) {
        obj_coverwizard.tradeNameTextbox().sendKeys(tradeName);
        obj_coverwizard.tradeNameSelect().click();
        String[] businessFromCheckbox = workBusiness.split("#");
        for (int i = 0; i < businessFromCheckbox.length; i++) {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.businessFromCheckbox(businessFromCheckbox[i]));
        }
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.businessNextButton());
        obj_generalInformation.pageLoading();
        if (haveEmployees.equalsIgnoreCase("No")) {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.noEmployeesRadiobutton());

        } else {
            if (haveEmployees.equalsIgnoreCase("Permanent employee(s)")) {
                haveEmployee = "perm";
            } else if (haveEmployees.equalsIgnoreCase("Temporary employee(s)")) {
                haveEmployee = "temp";
            } else if (haveEmployees.equalsIgnoreCase("Permanent & temporary employees")) {
                haveEmployee = "both";
            } else if (haveEmployees.equalsIgnoreCase("No")) {
                haveEmployee = "employee_no";
            }
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.haveEmployeesButton(haveEmployee));
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.ClkemployersLiabilityCoverRadiobutton(employeeLiabilityCover));
        }
        String[] cover = covers.split("#");
        for (int i = 0; i < cover.length; i++) {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversCheckboxHB(cover[i]));
        }
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversContinueButton());
    }

    public void fillGeneralInformationSection(String hb) throws Exception {
        if (hb.contains(";")) {
            String[] strTradeChange = hb.split(";");
            if (strTradeChange[1].equalsIgnoreCase("bb")) {
                tradeChangeBB();
                obj_generalInformation.executeScript("arguments[0].click()", obj_generalInformation.tradeSelectGI(strTradeChange[2], Integer.parseInt(strTradeChange[3])));
                obj_generalInformation.pageLoading();
            } else {
                tradeChangeHB();
                if (strTradeChange[2].contains(":")) {
                    String[] strMultiTradeChange = strTradeChange[2].split(":");
                    obj_generalInformation.executeScript("arguments[0].click()", obj_generalInformation.tradeSelectGI(strMultiTradeChange[0], Integer.parseInt(strTradeChange[3])));
                    obj_generalInformation.pageLoading();
                } else {
                    obj_generalInformation.executeScript("arguments[0].click()", obj_generalInformation.tradeSelectGI(strTradeChange[2], Integer.parseInt(strTradeChange[3])));
                    obj_generalInformation.pageLoading();
                }
            }
            if (strTradeChange[2].contains(":")) {
                for (int i = 1; i < strTradeChange[2].split(":").length; i++) {
                    String[] strMultiTradeChange = strTradeChange[2].split(":");
                    obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseYesRadiobutton());
                    obj_generalInformation.pageLoading();
                    obj_generalInformation.otherTradeTextbox().sendKeys(strMultiTradeChange[i]);
                    obj_generalInformation.otherTradeSelect(strMultiTradeChange[i]).click();
                    obj_generalInformation.pageLoading();
                }
            }
        }
        if (hb.contains(";")) {
            String[] strTradeChange = hb.split(";");
            if (strTradeChange[1].equalsIgnoreCase("hb")) {
                obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
                obj_generalInformation.pageLoading();
                new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText("Anywhere in the UK, Channel Islands and the Isle of Man");
            }
        }
        if (hb.equalsIgnoreCase("hb")) {
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
            obj_generalInformation.pageLoading();
            new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText("Anywhere in the UK, Channel Islands and the Isle of Man");
        }
        if (hb.equalsIgnoreCase("RT")) {
            new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText("Anywhere in the UK, Channel Islands and the Isle of Man");
        }
        strBusinessName = obj_generalInformationUtil.randomFirstName();
        obj_generalInformation.businessNameTextbox().sendKeys(strBusinessName);
        obj_commonUtil.tabKeypress();
        new Select(obj_generalInformation.titleDropdown()).selectByVisibleText("Mr");
        strFirstName = obj_generalInformationUtil.randomFirstName();
        obj_generalInformation.firstNameTextbox().sendKeys(strFirstName);
        obj_commonUtil.tabKeypress();
        GeneralinformationUtil.firstName(obj_generalInformation.firstNameTextbox());
        strSecondName = obj_generalInformationUtil.randomSecondName();
        obj_generalInformation.lastNameTextbox().sendKeys(strSecondName);
        GeneralinformationUtil.lastName(obj_generalInformation.lastNameTextbox());
        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText("Sole business owner");
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
        obj_generalInformation.pageLoading();
        new Select(obj_generalInformation.tradeDropdownListValue()).selectByVisibleText("2");
        obj_generalInformation.pageLoading();
        obj_generalInformation.postcodeTextbox().sendKeys("AB10 1AH");
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
        Thread.sleep(3000);
        new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByIndex(1);
        obj_generalInformation.pageLoading();
//        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.mobileDropdown());
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillGeneralInformationSpecificValue(String tradeName, String anythingElse, String businessName, String title, String firstName, String lastName, String typeOfBusiness, String subsidiaries, String yearsTrading, String postCode, String businessRunFromChoice, String whereBusinessWork) throws Exception {
        if (!businessName.equalsIgnoreCase("null")) {
            obj_generalInformation.businessNameTextbox().sendKeys(businessName);
            new Select(obj_generalInformation.titleDropdown()).selectByVisibleText(title);
            strFirstName = obj_generalInformationUtil.randomFirstName();
            obj_generalInformation.firstNameTextbox().sendKeys(strFirstName);
            obj_commonUtil.tabKeypress();
            strSecondName = obj_generalInformationUtil.randomSecondName();
            obj_generalInformation.lastNameTextbox().sendKeys(strSecondName);
            obj_generalInformation.postcodeTextbox().sendKeys(postCode);
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
            obj_generalInformation.pageLoading();
            new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByValue("1");
            obj_generalInformation.pageLoading();
        }
        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText(typeOfBusiness);
        obj_generalInformation.pageLoading();
        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesRadiobutton(subsidiaries));
        obj_generalInformation.pageLoading();
        new Select(obj_generalInformation.businessTradeDropdown()).selectByVisibleText(yearsTrading);
        obj_generalInformation.pageLoading();
        if (tradeName.equalsIgnoreCase("B&B") || tradeName.equalsIgnoreCase("OPR")) {
            if (!businessRunFromChoice.equalsIgnoreCase("null")) {
                String[] arrbusinessfromchoice = businessRunFromChoice.split("#");
                for (int i = 0; i < businessRunFromChoice.split("#").length; i++) {
                    obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.businessFromCheckbox(arrbusinessfromchoice[i]));
                    obj_generalInformation.pageLoading();
                }
            }
        }
        if (tradeName.equalsIgnoreCase("hb") || (tradeName.equalsIgnoreCase("h&b"))) {
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anyThingElseRadioButton(anythingElse));
            obj_generalInformation.pageLoading();
            new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText(whereBusinessWork);
        }
        if (tradeName.equalsIgnoreCase("OPR")) {
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anyThingElseRadioButton(anythingElse));
            obj_generalInformation.pageLoading();
            new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText(whereBusinessWork);
            obj_generalInformation.pageLoading();
        }
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillGeneralInformationSpecificValue(String tradeName, String anythingElse, String businessName, String title, String firstName, String lastName, String typeOfBusiness, String subsidiaries, String yearsTrading, String postCode, String businessRunFromChoice, String whereBusinessWork, String addTrade) throws Exception {
        if (!businessName.equalsIgnoreCase("null")) {
            strBusinessName = obj_generalInformationUtil.randomFirstName();
            obj_generalInformation.businessNameTextbox().sendKeys(strBusinessName);
            new Select(obj_generalInformation.titleDropdown()).selectByVisibleText(title);
            obj_generalInformation.firstNameTextbox().sendKeys(firstName);
            obj_generalInformation.lastNameTextbox().sendKeys(lastName);
            obj_generalInformation.postcodeTextbox().sendKeys(postCode);
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
            obj_generalInformation.pageLoading();
            new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByValue("1");
            obj_generalInformation.pageLoading();
        }
        if (!typeOfBusiness.equalsIgnoreCase("null")) {
            new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText(typeOfBusiness);
            obj_generalInformation.pageLoading();
        }
        if (!subsidiaries.equalsIgnoreCase("null")) {
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesRadiobutton(subsidiaries));
            obj_generalInformation.pageLoading();
        }
        if ((!yearsTrading.equalsIgnoreCase("null"))) {
            new Select(obj_generalInformation.businessTradeDropdown()).selectByVisibleText(yearsTrading);
            obj_generalInformation.pageLoading();
        }
        if (tradeName.equalsIgnoreCase("B&B")) {
            if (!businessRunFromChoice.equalsIgnoreCase("null")) {
                String[] arrbusinessfromchoice = businessRunFromChoice.split("#");
                for (int i = 0; i < businessRunFromChoice.split("#").length; i++) {
                    obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.businessFromCheckbox(arrbusinessfromchoice[i]));
                    obj_generalInformation.pageLoading();
                }
            }

        }
        //  obj_generalInformation.pageLoading();
        if (tradeName.equalsIgnoreCase("hb")) {
            if (anythingElse.equalsIgnoreCase("Y")) {
                String tradeList[] = addTrade.split(";");
                for (int trade = 0; trade < tradeList.length; trade++) {
                    //    obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anyThingElseRadioButton(anythingElse));
                    obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseYesRadiobutton());

                    obj_generalInformation.pageLoading();
                    obj_generalInformation.tradeNameTextbox().sendKeys(tradeList[trade]);
                    obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.addMultipleTradeNameSelect(tradeList[trade]));
//                    obj_generalInformation.addMultipleTradeNameSelect(tradeList[trade]).click();
                    obj_generalInformation.pageLoading();
                }
            } else {
                obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
                obj_generalInformation.pageLoading();
            }
            if (!whereBusinessWork.equalsIgnoreCase("null")) {
                new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText(whereBusinessWork);
            }

        }
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void tradeChangeBB() throws Exception {
        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.changeTrade());
        obj_commonUtil.waitForPageLoad();
        obj_generalInformation.businessTradeTextBox().sendKeys("e");
        int sizeOfList = obj_generalInformation.autoCompleteList().size();
        if (sizeOfList == 3) {
            Assert.assertTrue("B&B trades are displayed", true);
        } else {
            Assert.assertTrue(false);
        }
        for (int i = 0; i < sizeOfList; i++) {
            String strList = obj_generalInformation.autoCompleteList().get(i).getText();
        }
    }

    public void tradeChangeHB() throws Exception {
        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.changeTrade());
        obj_generalInformation.pageLoading();
        obj_generalInformation.businessTradeTextBox().sendKeys("a");
        int sizeOfList = obj_generalInformation.autoCompleteList().size();
        if (sizeOfList == 11) {
            Assert.assertTrue("B&B trades are displayed", true);
        } else {
            Assert.assertTrue(false);
        }
        for (int i = 0; i < sizeOfList; i++) {
            String strList = obj_generalInformation.autoCompleteList().get(i).getText();
        }
    }

    public void tradeChangeoffice(String tradename) throws Exception {
        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.changeTrade());
        obj_generalInformation.pageLoading();
        obj_generalInformation.businessTradeTextBox().sendKeys(tradename);
        obj_generalInformation.autoCompleteTrade(tradename).click();
        obj_generalInformation.pageLoading();
    }

    public void tradeUnChangeoffice(String tradename) throws Exception {
        obj_generalInformation.pageLoading();
        obj_generalInformation.businessTradeTextBox().clear();
        obj_generalInformation.businessTradeTextBox().sendKeys(tradename);
        obj_generalInformation.autoCompleteTrade(tradename).click();
        obj_generalInformation.pageLoading();
    }

    public void tradeNegativeChangeoffice(String tradename) throws Exception {
        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.changeTrade());
        obj_generalInformation.pageLoading();
        obj_generalInformation.businessTradeTextBox().sendKeys("a");
        int sizeOfList = obj_generalInformation.autoCompleteList().size();
        switch (tradename) {
            case "Office":
                if (sizeOfList == 4) {
                    Assert.assertTrue("Trades other than Office are not displayed", true);
                } else {
                    Assert.assertTrue(false);
                }
                break;
            case "retail":
                if (sizeOfList == 13) {
                    Assert.assertTrue("Trades other than retail are not displayed", true);
                } else {
                    Assert.assertTrue(false);
                }
                break;
            case "Generic wizard":
                if (sizeOfList == 6) {
                    Assert.assertTrue("Trades other than retail are not displayed", true);
                } else {
                    Assert.assertTrue(false);
                }
                break;
        }
    }


    public void tradeSelectionHB() throws Exception {
        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseYesRadiobutton());
        obj_generalInformation.otherTradeTextbox().sendKeys("a");
        int sizeOfList = obj_generalInformation.autoCompleteList().size();
        if (sizeOfList == 10) {
            Assert.assertTrue("B&B trades are displayed", true);
        } else {
            Assert.assertTrue(false);
        }
        for (int i = 0; i < sizeOfList; i++) {
            String strList = obj_generalInformation.autoCompleteList().get(i).getText();
        }
    }

    public void tradeChange(String strTrade) throws Exception {
        if (!strTrade.equalsIgnoreCase("null")) {
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.changeTrade());
            obj_generalInformation.pageLoading();
            obj_generalInformation.businessTradeTextBox().sendKeys(strTrade);
            obj_generalInformation.multiTradeAutocompleteList(strTrade).click();
            obj_generalInformation.pageLoading();
        }
    }

    public void fillPeopleInYourBusinessSection() throws Exception {
        new Select(obj_peoplebusiness.toldUsBuisnessDropdownbox()).selectByVisibleText("No employees");
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
    }

    public void fillPeopleInYourBusinessSection(String SelfEmployedPeople) throws Exception {
        new Select(obj_peoplebusiness.toldUsBuisnessDropdownbox()).selectByVisibleText("No employees");
        obj_generalInformation.pageLoading();
        if (!SelfEmployedPeople.equalsIgnoreCase("null")) {
            obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.selfEmployedPeople(SelfEmployedPeople));
        }
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
    }

    public void fillPremisesSectionWithSpecificValues(int iterations, String tradeName, String postCode, String addressType, String premiseType, String premisesOnlyOccupiped, String buildingOccupied, String haveATM, String applyToYourBusiness, String insureAnyOutbuilding, String yourBuildingAddCover, String yourBuildingValue, String businessContentAddCover, String businessContenValue, String stockAddCover, String stockValue, String buildingTypeValue, String propertyBuilt, String premiseGrade1, String walls, String wallsMade, String roofs, String openFirePlace, String outbuildingFirePlace, String outElectricHeater, String portableElectricHeater, String subsidenceCover) throws Exception {
        fillPremiseSection(iterations, tradeName, postCode, addressType, premiseType, premisesOnlyOccupiped, buildingOccupied, haveATM, applyToYourBusiness, insureAnyOutbuilding, yourBuildingAddCover, yourBuildingValue, businessContentAddCover, businessContenValue, stockAddCover, stockValue, buildingTypeValue, propertyBuilt, premiseGrade1, walls, wallsMade, roofs, openFirePlace, outbuildingFirePlace, outElectricHeater, portableElectricHeater, subsidenceCover);
    }

    public void fillGIScreen(String application, String tradeName) {
        if (!application.equalsIgnoreCase("null")) {
            switch (application) {
                case "WJ":
                    if (tradeName.equalsIgnoreCase("B&B")) {
                        strBusinessName = obj_generalInformationUtil.randomFirstName();
                        obj_generalInformation.businessNameTextbox().sendKeys(strBusinessName);
                        new Select(obj_generalInformation.titleDropdown()).selectByVisibleText("Miss");
                        obj_generalInformation.firstNameTextbox().sendKeys("firstName");
                        obj_generalInformation.lastNameTextbox().sendKeys("lastName");
                        obj_generalInformation.postcodeTextbox().sendKeys("AB101AH");
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByValue("1");
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText("Sole business owner");
                        obj_generalInformation.pageLoading();
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTradeDropdown()).selectByVisibleText("2");
                        obj_generalInformation.pageLoading();
                    } else if (tradeName.equalsIgnoreCase("H&B")) {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
                        obj_generalInformation.pageLoading();
                        strBusinessName = obj_generalInformationUtil.randomFirstName();
                        obj_generalInformation.businessNameTextbox().sendKeys(strBusinessName);
                        new Select(obj_generalInformation.titleDropdown()).selectByVisibleText("Miss");
                        obj_generalInformation.firstNameTextbox().sendKeys("firstName");
                        obj_generalInformation.lastNameTextbox().sendKeys("lastName");
                        obj_generalInformation.postcodeTextbox().sendKeys("AB101AH");
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByValue("1");
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText("Sole business owner");
                        obj_generalInformation.pageLoading();
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTradeDropdown()).selectByVisibleText("2");
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText("Anywhere in the UK, Channel Islands and the Isle of Man");
                    }
                    break;
                default:
                    if (tradeName.equalsIgnoreCase("B&B")) {
                        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText("Sole business owner");
                        obj_generalInformation.pageLoading();
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTradeDropdown()).selectByVisibleText("2");
                        obj_generalInformation.pageLoading();
                    } else if (tradeName.equalsIgnoreCase("H&B")) {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText("Sole business owner");
                        obj_generalInformation.pageLoading();
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTradeDropdown()).selectByVisibleText("2");
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText("Anywhere in the UK, Channel Islands and the Isle of Man");
                    }
            }
            obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
            obj_generalInformation.pageLoading();
        }
    }

    public void fillsPeopleBusinessSection() throws Exception {
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
    }

    public void fillsPeopleBusinessSectionBI() throws Exception {

        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
    }


    public void fillsPeopleBusiness(String trade) throws Exception {
        if (trade.equalsIgnoreCase("BB")) {
            obj_peoplebusiness.empWorkBusinessText().sendKeys("3");
            obj_generalInformation.pageLoading();
        } else {
            obj_peoplebusiness.empWorkBusinessText().sendKeys("3");
            obj_commonUtil.tabKeypress();
            obj_generalInformation.pageLoading();
            obj_peoplebusiness.empAdminWorkTextbox().sendKeys("1");
            obj_commonUtil.tabKeypress();
            obj_generalInformation.pageLoading();
        }
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
    }

    public void fillPeopleScreen(String peopleValue) throws Throwable {
        HashMap<String, String> peopleFields = new LinkedHashMap<String, String>();
        String[] peopleField = peopleValue.split("#");
        for (int a = 1; a <= peopleField.length; a++) {
            String[] peopleValues = peopleField[a - 1].split(";");
            peopleFields.put(peopleValues[0], peopleValues[1]);
        }
        List<String> peopleQuestions = new ArrayList<>(peopleFields.keySet());
        for (String questions : peopleQuestions) {
            switch (questions) {
                case "YouHaveToldUsYourBusiness":
                    obj_peoplebusiness.toldUsBuisnessDropdownbox().sendKeys(peopleFields.get(questions));
                    obj_generalInformation.pageLoading();
                    break;
                case "director":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_peoplebusiness.directorBusinessTextbox());
                    obj_peoplebusiness.directorBusinessTextbox().sendKeys(peopleFields.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_generalInformation.pageLoading();
                    break;
                case "DirectorManualWorkQuestion":
                    if (peopleFields.get(questions).equalsIgnoreCase("Present")) {
                        strQuestion = obj_peoplebusiness.partnerDirectorManualWorkQuestion().get(0).getText();
                        strText = "How many of the directors do any manual work?";
                        Assert.assertTrue("DirectorManualWorkQuestion is displayed", strQuestion.replace("\n", "").replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    } else if (peopleFields.get(questions).equalsIgnoreCase("Not Present")) {
                        if (!obj_peoplebusiness.partnerDirectorManualWorkQuestion().get(0).isDisplayed()) {
                            Assert.assertTrue("Question not present", true);
                        } else {
                            Assert.assertTrue("Question present", false);
                        }
                    }
                    break;
                case "EmpManualWorkValidation":
                    if (peopleFields.get(questions).equalsIgnoreCase("Present")) {
                        String validationDir = obj_peoplebusiness.empManualWorkValidaiton().get(0).getText();
                        if (validationDir.equals("The number of employees doing manual work can't be higher than the total number of employees in your business")) {
                            Assert.assertTrue("Validation present", true);
                        } else {
                            Assert.assertTrue("Validation not present", false);
                        }
                    }
                    break;
                case "EmpDirManualWorkValidation":
                    if (peopleFields.get(questions).equalsIgnoreCase("Present")) {
                        String validationDir = obj_peoplebusiness.empDirManualWorkValidaiton().get(0).getText();
                        if (validationDir.equals("The number of employees doing manual work can't be higher than the total number of employees in your business")) {
                            Assert.assertTrue("Validation present", true);
                        } else {
                            Assert.assertTrue("Validation not present", false);
                        }
                    }
                    break;
                case "PartnerDirManualWorkValidaiton":
                    if (peopleFields.get(questions).equalsIgnoreCase("Present")) {
                        String validationDir = obj_peoplebusiness.partnerDirectorManualWorkValidation().get(0).getText();
                        if (validationDir.equals("The number of partners or directors doing manual work can't be higher than the total number of partners or directors in your business")) {
                            Assert.assertTrue("Validation present", true);
                        } else {
                            Assert.assertTrue("Validation not present", false);
                        }
                    }
                    break;
                case "DirectorManualWorkHelpTextPresent":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_peoplebusiness.partnerDirectorManualWorkHelpText());
                    strHelpText = "Please count all directors who do any manual work.";
                    Assert.assertTrue("Help Text is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "admindirector":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_peoplebusiness.directorAdminTextbox());
                    obj_peoplebusiness.directorAdminTextbox().sendKeys(peopleFields.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_generalInformation.pageLoading();
                    break;
                case "noOfEmp":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_peoplebusiness.empWorkBusinessTextbox());
                    obj_peoplebusiness.empWorkBusinessTextbox().sendKeys(peopleFields.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_generalInformation.pageLoading();
                    break;
                case "EmployeeManualWork":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_peoplebusiness.employeeManualWork());
                    obj_peoplebusiness.employeeManualWork().clear();
                    obj_peoplebusiness.employeeManualWork().sendKeys(peopleFields.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_generalInformation.pageLoading();
                    break;
                case "EmployeeManualWorkQuestion":
                    if (peopleFields.get(questions).equalsIgnoreCase("Present")) {
                        strText = obj_peoplebusiness.employeeManualWorkQuestion().get(0).getText();
                        strQuestion = "How many of your employees do any manual work?";
                        Assert.assertTrue("EmployeeManualWorkQuestion is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    } else if (peopleFields.get(questions).equalsIgnoreCase("Not Present")) {
                        if (!obj_peoplebusiness.employeeManualWorkQuestion().get(0).isDisplayed()) {
                            Assert.assertTrue("Question not present", true);
                        } else {
                            Assert.assertTrue("Question present", false);
                        }
                    }
                    break;
                case "EmployeeManualWorkHelpTextPresent":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_peoplebusiness.employeeManualWorkHelpText());
                    strHelpText = "Please count all employees who do any manual work.";
                    Assert.assertTrue("Help Text is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "adminEmp":
                    obj_peoplebusiness.empAdminWorkTextbox().sendKeys(peopleFields.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_generalInformation.pageLoading();
                    break;
                case "partner":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_peoplebusiness.employeeExcludeDirectorsTextbox());
                    obj_peoplebusiness.directorBusinessTextbox().sendKeys(peopleFields.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_generalInformation.pageLoading();
                    break;
                case "PartnerOrDirectorManualWork":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_peoplebusiness.partnerDirectorManualWork());
                    obj_peoplebusiness.partnerDirectorManualWork().clear();
                    obj_peoplebusiness.partnerDirectorManualWork().sendKeys(peopleFields.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_generalInformation.pageLoading();
                    break;
                case "PartnerManualWorkQuestion":
                    if (peopleFields.get(questions).equalsIgnoreCase("Present")) {
                        strText = obj_peoplebusiness.partnerDirectorManualWorkQuestion().get(0).getText();
                        strQuestion = "How many of the partners do any manual work?";
                        Assert.assertTrue("PartnerManualWorkQuestion is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    } else if (peopleFields.get(questions).equalsIgnoreCase("Not Present")) {
                        if (!obj_peoplebusiness.partnerDirectorManualWorkQuestion().get(0).isDisplayed()) {
                            Assert.assertTrue("Question not present", true);
                        } else {
                            Assert.assertTrue("Question present", false);
                        }
                    }
                    break;
                case "PartnerManualWorkHelpTextPresent":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_peoplebusiness.partnerDirectorManualWorkHelpText());
                    strHelpText = "Please count all partners who do any manual work.";
                    Assert.assertTrue("Help Text is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace("\n", "").replace(" ", "").replace(",", "")));
                    break;
                case "partnerAdmin":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_peoplebusiness.directorBusinessTextbox());
                    obj_peoplebusiness.directorAdminTextbox().sendKeys(peopleFields.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_generalInformation.pageLoading();
                    break;
                case "EmployeeExcludeDirectors":
                    obj_peoplebusiness.employeeExcludeDirectorsTextbox().sendKeys(peopleFields.get(questions));
                    obj_generalInformation.pageLoading();
                    break;
                case "EmployeeExcludeDirectorsManualWork":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_peoplebusiness.employeeExDirManualWork());
                    obj_peoplebusiness.employeeExDirManualWork().clear();
                    obj_peoplebusiness.employeeExDirManualWork().sendKeys(peopleFields.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_generalInformation.pageLoading();
                    break;
                case "EmployeeExcludeDirectorsManualWorkQuestion":
                    if (peopleFields.get(questions).equalsIgnoreCase("Present")) {
                        strText = obj_peoplebusiness.employeeExDirManualWorkQuestion().get(0).getText();
                        strQuestion = "How many of your employees (excluding directors) do any manual work?";
                        Assert.assertTrue("EmployeeExcludeDirectorsManualWorkQuestion is displayed", strQuestion.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    } else if (peopleFields.get(questions).equalsIgnoreCase("Not Present")) {
                        if (!obj_peoplebusiness.employeeExDirManualWorkQuestion().get(0).isDisplayed()) {
                            Assert.assertTrue("Question not present", true);
                        } else {
                            Assert.assertTrue("Question present", false);
                        }
                    }
                    break;
                case "EmployeeExcludeDirectorsManualWorkHelpTextPresent":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_peoplebusiness.employeeExDirManualWorkHelpText());
                    strHelpText = "Please count all employees who do any manual work.";
                    Assert.assertTrue("Help Text is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "EmployeeExcludeAdminDirectors":
                    obj_peoplebusiness.employeeExcludeDirectorsAdminTextbox().sendKeys(peopleFields.get(questions));
                    obj_generalInformation.pageLoading();
                    break;
                case "50days":
                    obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.tempEmp50Days(peopleFields.get(questions)));
                    obj_generalInformation.pageLoading();
                    break;
                case "SelfEmployedPeople":
                    obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.selfEmployedPeople(peopleFields.get(questions)));
                    obj_generalInformation.pageLoading();
                    break;
                case "SelfEmployedQuestionPresent":
                    int objSize = obj_peoplebusiness.selfEmployedQuestion().size();
                    if (objSize > 0) {
                        Assert.assertTrue("Self employed question present", true);
                    } else {
                        Assert.assertTrue("Self employed question not present", false);
                    }
                    break;
                case "SelfEmployedQuestionNotPresent":
                    if (!(obj_peoplebusiness.selfEmployedQuestion().get(0).isDisplayed())) {
                        Assert.assertTrue("Self employed question not present", true);
                    } else {
                        Assert.assertTrue("Self employed question present", false);
                    }
                    break;
                case "NoOfSelfEmployedQuestionPresent":
                    int intObjSize = obj_peoplebusiness.noOfSelfEmployedQuestion().size();
                    if (intObjSize > 0) {
                        Assert.assertTrue("Self employed question present", true);
                    } else {
                        Assert.assertTrue("Self employed question not present", false);
                    }
                    break;
                case "NoOfSelfEmployedQuestionNotPresent":
                    if (!obj_peoplebusiness.noOfSelfEmployedQuestion().get(0).isDisplayed()) {
                        Assert.assertTrue("Self employed question not present", true);
                    } else {
                        Assert.assertTrue("Self employed question present", false);
                    }
                    break;
                case "coverInjuries":
                    obj_peoplebusiness.coverInjuriesYesRadiobutton().click();
                    obj_generalInformation.pageLoading();
                    break;
                case "SaveAndExit":
                    if ((peopleFields.get(questions)).equalsIgnoreCase("WJ")) {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_peoplebusiness.saveAndExitPeoplePL());
                        obj_generalInformation.pageLoading();
                        obj_generalInformation.executeScript("arguments[0].click();", obj_peoplebusiness.saveExitButtonPopUp());
                        obj_generalInformation.pageLoading();
                        saveandExit();
                    } else {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_peoplebusiness.saveAndExitPeoplePL());
                        obj_generalInformation.pageLoading();
                        obj_generalInformation.executeScript("arguments[0].click();", obj_peoplebusiness.saveExitButtonPopUp());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "WJ":
                    saveandExit();
                    break;
                case "Next":
                    obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
                    obj_generalInformation.pageLoading();
                    break;
                case "BinButtonValidate":

                    String screenLists[] = peopleFields.get(questions).split(":");
                    for (String screenList : screenLists) {
                        switch (screenList) {
                            case "Treatment":
                                if (obj_treatments.treatmentBinButton().isDisplayed()) {
                                    Assert.assertTrue("Bin button present", true);
                                } else {
                                    Assert.assertTrue("Bin button not present", false);
                                }
                                break;
                            case "BI third party":
                                if (thirdPartyBI.thirdPartyBinButton().isDisplayed()) {
                                    Assert.assertTrue("Bin button present", true);
                                } else {
                                    Assert.assertTrue("Bin button not present", false);
                                }
                                break;
                            case "BI":
                                if (obj_businessInterruption.binButtonBI().isDisplayed()) {
                                    Assert.assertTrue("Bin button present", true);
                                } else {
                                    Assert.assertTrue("Bin button not present", false);
                                }
                                break;
                            case "TOT":
                                if (obj_theftOfTakings.binButtonTOT().isDisplayed()) {
                                    Assert.assertTrue("Bin button present", true);
                                } else {
                                    Assert.assertTrue("Bin button not present", false);
                                }
                                break;
                        }

                    }
                    break;

                case "RemoveAccordian":

                    String coverList[] = peopleFields.get(questions).split(":");

                    for (int j = 0; j < coverList.length; j++) {

                        String validationMessage = coverList[coverList.length - 1];

                        switch (coverList[j]) {

                            case "Treatment":
                                obj_treatments.executeScript("arguments[0].click();", obj_treatments.treatmentBinButton());
                                obj_generalInformation.pageLoading();
                                if (!validationMessage.equalsIgnoreCase("Null")) {
                                    String messageActual = obj_treatments.validationPopUp().getText();
                                    String message[] = messageActual.split("\n\n");
                                    for (int i = 0; i < message.length; i++) {
                                        String validation[] = validationMessage.split("-");
                                        for (int k = 0; k < validation.length; k++) {
                                            if (i == k) {
                                                if (message[i].equals(validation[k])) {
                                                    Assert.assertTrue("Message matching", true);
                                                } else {
                                                    Assert.assertTrue("Message mismatch", false);
                                                }
                                            }
                                        }
                                    }
                                }
                                obj_treatments.executeScript("arguments[0].click();", obj_treatments.validationPopUpYesButton());
                                obj_generalInformation.pageLoading();
                                break;
                            case "BI third party":
                                thirdPartyBI.executeScript("arguments[0].click();", thirdPartyBI.thirdPartyBinButton());
                                if (!validationMessage.equalsIgnoreCase("Null")) {
                                    String messageActual = thirdPartyBI.validationPopUp().getText(); //need to update popup property
                                    String message[] = messageActual.split("\n\n");
                                    for (int i = 0; i < message.length; i++) {
                                        String validation[] = validationMessage.split("-");
                                        for (int k = 0; k < validation.length; k++) {
                                            if (i == k) {
                                                if (message[i].equals(validation[k])) {
                                                    Assert.assertTrue("Message matching", true);
                                                } else {
                                                    Assert.assertTrue("Message mismatch", false);
                                                }
                                            }
                                        }
                                    }
                                }
                                thirdPartyBI.executeScript("arguments[0].click();", thirdPartyBI.validationPopUpYesButton());
                                obj_generalInformation.pageLoading();
                                break;
                            case "BI":
                                obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.binButtonBI());
                                if (!validationMessage.equalsIgnoreCase("Null")) {
                                    String messageActual = obj_businessInterruption.validationPopUp().getText(); //need to update popup property
                                    String message[] = messageActual.split("\n\n");
                                    for (int i = 0; i < message.length; i++) {
                                        String validation[] = validationMessage.split("-");
                                        for (int k = 0; k < validation.length; k++) {
                                            if (i == k) {
                                                if (message[i].equals(validation[k])) {
                                                    Assert.assertTrue("Message matching", true);
                                                } else {
                                                    Assert.assertTrue("Message mismatch", false);
                                                }
                                            }
                                        }
                                    }
                                }
                                obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.validationPopUpYesButton());
                                obj_generalInformation.pageLoading();
                                break;
                            case "TOT":
                                obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.binButtonTOT());
                                obj_generalInformation.pageLoading();
                                if (!validationMessage.equalsIgnoreCase("Null")) {
                                    String messageActual = obj_theftOfTakings.validationPopUp().getText(); //need to update popup property
                                    String message[] = messageActual.split("\n\n");
                                    for (int i = 0; i < message.length; i++) {
                                        String validation[] = validationMessage.split("-");
                                        for (int k = 0; k < validation.length; k++) {
                                            if (i == k) {
                                                if (message[i].equals(validation[k])) {
                                                    Assert.assertTrue("Message matching", true);
                                                } else {
                                                    Assert.assertTrue("Message mismatch", false);
                                                }
                                            }
                                        }
                                    }
                                }
                                obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.validationPopUpYesButton());
                                obj_generalInformation.pageLoading();
                                break;
                        }
                    }

                    break;

                case "AdminDirectorPartnerQuestionNotPresent":

                    if (!obj_peoplebusiness.adminDirectorOrPartnerQuestion().get(0).isDisplayed()) {
                        Assert.assertTrue("AdminDirectorOrPartnerQuestion is not present", true);
                    } else {
                        Assert.assertTrue("AdminDirectorOrPartnerQuestion is present", false);
                    }

                    break;

                case "EmployeeExcludeAdminDirectorsQuestionNotPresent":
                    Assert.assertTrue("employeeExcludeAdminDirectorsAdminQuestion is not present", !obj_peoplebusiness.employeeExcludeAdminDirectorsQuestion().get(0).isDisplayed());
                    break;

                case "EmployeeAdminQuestionNotPresent":
                    Assert.assertTrue("EmployeeAdminQuestion is not present", !obj_peoplebusiness.empAdminQuestion().get(0).isDisplayed());
                    break;
                case "YouHaveToldUsYourBusinessQuestion":
                    question = "You've told us your business has:";
                    strText = obj_peoplebusiness.toldUsQuestion().getText();
                    Assert.assertTrue("YouHaveToldUsYourBusiness is displayed", question.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "YouHaveToldUsYourDDLValidation":
                    //Validating the DDL values which should contains only Employees, No employees
                    strText = "Employee(s);No employees";

                    String[] arrValue = strText.split(";");

                    Select dropDwnValues = new Select(obj_peoplebusiness.toldUsBuisnessDropdownbox());
                    List<WebElement> Options = dropDwnValues.getOptions();

                    if (arrValue.length == Options.size() - 1) {

                        for (int i = 0; i < arrValue.length; i++) {
                            Assert.assertTrue("DropDown values are matched", arrValue[i].equals(Options.get(i + 1).getText().trim().replace("\n", "")));
                        }
                    } else {
                        Assert.assertTrue("DropDown values are not matched", false);
                    }

                    break;
                case "YouHaveToldUsYourBusinessHT":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_peoplebusiness.toldUsQuestionHT());
                    strHelpText = "An employee is someone who works under an employment contract. If you’re not sure whether someone carrying out work for you is an employee, you can use this checklist to help you decide: https://www.gov.uk/employment-status/employee  If someone has no employment contract with you, they wouldn’t generally be considered to be an employee.  When answering this question, remember to include any seasonal employees. ";
                    Assert.assertTrue("YouHaveToldUsYourBusinessHelpText is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "").replace("\n", "")));
                    break;
                case "MoreThan50DaysQuestNotPresent":
                    Assert.assertTrue("MoreThan50DaysQuestion is not present", !obj_peoplebusiness.moreThan50DaysQuest().get(0).isDisplayed());
                    break;
                case "MoreThan50DaysContentNotPresent":
                    Assert.assertTrue("MoreThan50DaysContent is not present", !obj_peoplebusiness.moreThan50DaysContent().get(0).isDisplayed());
                    break;
                case "RequiredMsgValidation":
                    strReqMsg = obj_peoplebusiness.requiredMsg().getText();
                    if (strReqMsg.equals("Required")) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "EmployeeMaualWorkReq":
                    strReqMsg = obj_peoplebusiness.empManualRequiredMsg().getText();
                    if (strReqMsg.equals("Required")) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "PartnerOrDirectorMaualWorkReq":
                    strReqMsg = obj_peoplebusiness.partnerOrDirectorManualRequiredMsg().getText();
                    if (strReqMsg.equals("Required")) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "ExcluDirectorMaualWorkReq":
                    strReqMsg = obj_peoplebusiness.excluDirectorManualRequiredMsg().getText();
                    if (strReqMsg.equals("Required")) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "ValidationMessage":
                    String[] input = peopleFields.get(questions).split(":");
                    String strValidationMsg = obj_peoplebusiness.validationMessage().getText();
                    for (String validMsgs : input) {
                        if (strValidationMsg.contains("\n")) {
                            String[] msgValid = strValidationMsg.split("\n");
                            for (String strMsg : msgValid) {
                                if (strMsg.equals(validMsgs)) {
                                    Assert.assertTrue("Validation message present in application", true);
                                } else {
                                    Assert.assertTrue("Validation message not present in application", false);
                                }
                            }
                        } else if (strValidationMsg.equals(validMsgs)) {
                            Assert.assertTrue("Validation message present in application", true);
                        } else {
                            Assert.assertTrue("Validation message not present in application", false);
                        }
                    }
                    break;
                case "ELHelpText":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_peoplebusiness.elHelpText());
                    strHelpText = "Covers you for accidental injury to your employees arising from the work they do for you. This cover’s legally required if you have employees. See here for more detail on the laws about Employers' Liability insurance. http://www.hse.gov.uk/pubns/hse40.pdf";
                    Assert.assertTrue("ELHelpText is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    break;
                case "NoOfEmpHT":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_peoplebusiness.noOfEmpHelpText());
//                    strText=strText.replace(" ", "").replace("\n","").replace("\t","").replace(",", "");
                    strHelpText = "\n\t\tAn employee is someone who works under an employment contract. If you're not sure whether someone carrying out work for you is an employee, you can use this checklist to help you decide: https://www.gov.uk/employment-status/employee.\n\nWhen answering this question, remember to include any seasonal employees.\n\t";
//                    strHelpText=strHelpText.replace(" ", "").replace(",", "");
                    Assert.assertTrue("NoOfEmpHT is displayed", strText.equalsIgnoreCase(strHelpText));
//                    Assert.assertTrue("NoOfEmpHT is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n","").replace("\t","").replace(",", "")));
                    break;
            }
        }
    }

    public void fillTreatmentsBusiness() {
        obj_treatments.peopleProvideTreatmentTextBox().sendKeys("3");
        obj_generalInformation.pageLoading();
        obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.anyOtherTreatmentNoButton());
        obj_generalInformation.pageLoading();
        obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.qualificationYesButton());
        obj_generalInformation.pageLoading();
        obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillTreatmentsBusiness(String TreatmentSaveExit, String Application) throws Throwable {
        obj_treatments.peopleProvideTreatmentTextBox().sendKeys("3");
        obj_commonUtil.tabKeypress();
        obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.anyOtherTreatmentNoButton());
        obj_generalInformation.pageLoading();
        obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.qualificationYesButton());
        obj_generalInformation.pageLoading();
        if (TreatmentSaveExit.equalsIgnoreCase("Y")) {
            obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.saveAndExit());
            obj_generalInformation.pageLoading();
            obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.saveAndExitPopUp());
            obj_generalInformation.pageLoading();
            if (Application.equalsIgnoreCase("WJ")) {
                saveandExit();
            }
        } else {
            obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.nextButton());
            obj_generalInformation.pageLoading();
        }
    }

    public void fillTreatmentsSection(String TreatmentSaveExit, String Application) throws Throwable {
        obj_treatments.executeScript("arguments[0].click()", obj_treatments.anyTreatmentNoButton());
        obj_generalInformation.pageLoading();
        obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.qualificationYesButton());
        obj_generalInformation.pageLoading();
        if (TreatmentSaveExit.equalsIgnoreCase("Y")) {
            obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.saveAndExit());
            obj_generalInformation.pageLoading();
            obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.saveAndExitPopUp());
            obj_generalInformation.pageLoading();
            if (Application.equalsIgnoreCase("Trade")) {
                saveandExit();
            }
        } else {
            obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.nextButton());
            obj_generalInformation.pageLoading();
        }
    }

    public void fillLiabilityCoverSection() throws Exception {
        new Select(obj_liabilitycover.public_LiabilitycoverDropdown()).selectByValue("1000000");
        String strtext = obj_liabilitycover.productsOutsideukDropdownList().getText();
        if (strtext.trim().equalsIgnoreCase("No")) {
            new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("No");
        } else if (strtext.trim().equalsIgnoreCase("UK only")) {
            new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("UK only");
        } else if (strtext.trim().equalsIgnoreCase("I don't sell products")) {
            new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("UK only");
        } else {
            new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("No");
        }
        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.liabilityCoverNextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillLiabilityCoverSectionWithSaveExit(String fillLiability) throws Exception {
        LinkedHashMap<String, String> fillLiabilityElements = new LinkedHashMap<String, String>();
        String[] fillLiabilityFields = fillLiability.split("#");
        for (int a = 1; a <= fillLiabilityFields.length; a++) {
            String[] fillLiabilityValues = fillLiabilityFields[a - 1].split(";");
            fillLiabilityElements.put(fillLiabilityValues[0], fillLiabilityValues[1]);
        }
        List<String> fillLiabilityQuestions = new ArrayList<>(fillLiabilityElements.keySet());
        for (String questions : fillLiabilityQuestions) {
            switch (questions) {
                case "PLLimit":
                    new Select(obj_liabilitycover.public_LiabilitycoverDropdown()).selectByValue(fillLiabilityElements.get(questions));
                    break;
                case "OutsideUK":
                    new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText(fillLiabilityElements.get(questions));
                    obj_generalInformation.pageLoading();
                    break;
                case "SaveExit":
                    if (fillLiabilityElements.get(questions).equalsIgnoreCase("WJ")) {
                        obj_liabilitycover.executeScript("arguments[0].click()", obj_liabilitycover.saveExitButton());
                        obj_generalInformation.pageLoading();
                        obj_liabilitycover.executeScript("arguments[0].click()", obj_liabilitycover.saveExitPopUpButton());
                        obj_generalInformation.pageLoading();
                        saveandExit();
                    } else {
                        obj_liabilitycover.executeScript("arguments[0].click()", obj_liabilitycover.saveExitButton());
                        obj_generalInformation.pageLoading();
                        obj_liabilitycover.executeScript("arguments[0].click()", obj_liabilitycover.saveExitPopUpButton());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "Next":
                    obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.liabilityCoverNextButton());
                    obj_generalInformation.pageLoading();
                    break;
                case "ValidatePLCoverLimit":
                    Select dropDwnValues = new Select(obj_liabilitycover.public_LiabilitycoverDropdown());
                    String validationActual = (dropDwnValues.getFirstSelectedOption().getText()).trim();
                    if (validationActual.equals(fillLiabilityElements.get(questions))) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "PostSaveandExit":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
                    obj_generalInformation.pageLoading();
                    obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
                    obj_generalInformation.pageLoading();
                    break;
                case "OutsideUKNotPresent":
                    if (!(obj_liabilitycover.outsideUKQuestion().get(0).isDisplayed())) {
                        Assert.assertTrue("OutsideUK question not present", true);
                    } else {
                        Assert.assertTrue("OutsideUK question present", false);
                    }
                    break;
                case "BinButton":
                    if (fillLiabilityElements.get(questions).equalsIgnoreCase("Present")) {
                        if (obj_liabilitycover.binButton().get(0).isDisplayed()) {
                            Assert.assertTrue("Bin button present", true);
                        }
                    } else if (fillLiabilityElements.get(questions).equalsIgnoreCase("Not Present")) {
                        if (!obj_liabilitycover.binButton().get(0).isDisplayed()) {
                            Assert.assertTrue("Bin button not present", true);
                        }
                    }
                    break;
                case "DeletePLCover":
                    if (fillLiabilityElements.get(questions).equalsIgnoreCase("Yes")) {
                        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.binButton().get(0));
                        String strWarningMsg = obj_liabilitycover.warningMsg().getText();
                        String strTrimed = strWarningMsg.replace(" ", "").replace("?", "").replace(",", "").replace("'", "");
                        if (strTrimed.equals("AreyousureyoudliketoremovethiscoverIfyouchangeyourmindlateryoucanalwaysadditbackinontheQuoteSummarypage")) {
                            Assert.assertTrue("Warning message matching", true);
                        }
                        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.yesOrNo("Yes"));
                        obj_generalInformation.pageLoading();
                    } else if (fillLiabilityElements.get(questions).equalsIgnoreCase("No")) {
                        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.binButton().get(0));
                        String strWarningMsg = obj_liabilitycover.warningMsg().getText();
                        String strTrimed = strWarningMsg.replace(" ", "").replace("?", "").replace(",", "").replace("'", "");
                        if (strTrimed.equals("AreyousureyoudliketoremovethiscoverIfyouchangeyourmindlateryoucanalwaysadditbackinontheQuoteSummarypage")) {
                            Assert.assertTrue("Warning message matching", true);
                        }
                        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.yesOrNo("No"));
                        obj_generalInformation.pageLoading();
                    }
                    break;
            }
        }
    }

    public void fillLiabilityCoverSection(String saveAndExit) throws Throwable {
        new Select(obj_liabilitycover.public_LiabilitycoverDropdown()).selectByValue("2000000");
        String strtext = obj_liabilitycover.productsOutsideukDropdownList().getText();
        if (strtext.trim().equalsIgnoreCase("No")) {
            new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("No");
            obj_generalInformation.pageLoading();
        } else {
            new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("UK only");
            obj_generalInformation.pageLoading();
        }
        if (saveAndExit.equalsIgnoreCase("Y")) {
            obj_liabilitycover.executeScript("arguments[0].click()", obj_liabilitycover.saveExitButton());
            obj_generalInformation.pageLoading();
            obj_liabilitycover.executeScript("arguments[0].click()", obj_liabilitycover.saveExitPopUpButton());
            obj_generalInformation.pageLoading();
//            saveandExit();
        } else {
            obj_liabilitycover.executeScript("arguments[0].click()", obj_liabilitycover.saveExitButton());
            obj_generalInformation.pageLoading();
            obj_liabilitycover.executeScript("arguments[0].click()", obj_liabilitycover.saveExitPopUpButton());
            obj_generalInformation.pageLoading();
        }
    }

    public void fillPremiseSection(String premiseValue, int i) throws Throwable {
        String validationTxt;
        HashMap<String, String> premiseFields = new LinkedHashMap<String, String>();
        String[] premiseField = premiseValue.split("#");
        for (int a = 1; a <= premiseField.length; a++) {
            String[] premiseValues = premiseField[a - 1].split(";");
            premiseFields.put(premiseValues[0], premiseValues[1]);
        }
        List<String> premiseQuestions = new ArrayList<>(premiseFields.keySet());
        for (String premiseQuestion : (premiseQuestions))
            switch (premiseQuestion) {
                case "PostCode":
                    obj_businessPremises.postCodetextbox(i).clear();
                    obj_businessPremises.postCodetextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.findAddressButton(i));
                    obj_generalInformation.pageLoading();
                    break;
                case "BusinessPremiseAddress":
                    boolean flag = false;
//                    new Select(obj_businessPremises.selectAddressDropdown(i)).selectByVisibleText(premiseFields.get(premiseQuestion));
                    Select address = new Select(obj_businessPremises.selectAddressDropdown(i));
                    List<WebElement> addressVal = address.getOptions();
                    for (int k = 0; k < addressVal.size(); k++) {
                        String addressLine = premiseFields.get(premiseQuestion).replace("\n", "").replace(" ", "");
                        String addressOption = addressVal.get(k).getText().replace("\n", "").replace(" ", "");
                        if (addressOption.equals(addressLine)) {
                            addressVal.get(k).click();
                            obj_generalInformation.pageLoading();
                            flag = true;
                            break;
                        }
                    }
                    if (flag == false) {
                        addressVal.get(1).click();
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "EnterAddressManually":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.enterAddressManually());
                    obj_generalInformation.pageLoading();
                    String addressSplit[] = premiseFields.get(premiseQuestion).split("_");
                    for (int j = 0; j < 1; j++) {
                        obj_businessPremises.firstLineAddress().sendKeys(addressSplit[i]);
                        obj_generalInformation.pageLoading();
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.secondLineAddress().sendKeys(addressSplit[i + 1]);
                        obj_generalInformation.pageLoading();
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.addressTown().sendKeys(addressSplit[i + 2]);
                        obj_generalInformation.pageLoading();
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.addressCounty().sendKeys(addressSplit[i + 3]);
                        obj_generalInformation.pageLoading();
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                        new Select(obj_businessPremises.addressCountry()).selectByVisibleText(addressSplit[i + 4]);
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "PremiseType":
                    new Select(obj_businessPremises.selectPremisesTypeDropdown(i)).selectByVisibleText(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "IsThisYourHome":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.strPremiseIsThisYourHome(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "PremiseOccupiedByYourBusiness":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.premiseOccupiedByYourBusiness(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "BuildingOccupiedByYourBusiness":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.buildingOccupiedByYourBusiness(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "TradeSelection":
                    if (obj_businessPremises.trade(i).isDisplayed()) {
                        int rowcount = obj_businessPremises.tradeTableRow().size();
                        for (int n = 1; n <= rowcount; n++) {
                            if (obj_businessPremises.tradeselect(i, n).isDisplayed()) {
                                obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.tradeselect(i, n));
                                obj_businessPremises.pageLoading();
                            } else if (!obj_businessPremises.tradeselect(i, n).isDisplayed()) {
                                obj_businessPremises.pageLoading();
                            }
                        }
                    }
                    break;
                case "multipleTradeDynamicSelection":
                    String multipleTradesList[] = (premiseFields.get(premiseQuestion)).split(":");
                    for (int multiTradeSelection = 0; multiTradeSelection < multipleTradesList.length; multiTradeSelection++) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_businessPremises.tradeselect(i, Integer.parseInt((multipleTradesList[multiTradeSelection]))));
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "InsureAnyOutBuildings":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.insureAnyOutBuilding(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "Accomodation":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.accomodation(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "Alcohol":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.alcohol(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "ApplyToYourBusiness":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_businessPremises.applyToYpurBusiness(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "ATM":
                    new Select(obj_businessPremises.selectATM(i)).selectByVisibleText(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "MainBuildingYourBuilding":
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("null")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.mainbuildingBuildingCoverRemoveButton(i));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    } else if (obj_businessPremises.yourBuildingAddCoverLink(i).isDisplayed()) {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_businessPremises.yourBuildingAddCoverLink(i));
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.yourBuildingValueTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                    } else {
                        obj_businessPremises.yourBuildingValueTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                    }
                    break;
                case "OutBuildingYourBuilding":
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("null")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outbuildingBuildingCoverRemoveButton(i));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    } else if (obj_businessPremises.outBuildingyourBuildingAddCoverLink(i).isDisplayed()) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outBuildingyourBuildingAddCoverLink(i));
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.outBuildingYourBuildingTextBox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                    } else {
                        obj_businessPremises.outBuildingYourBuildingTextBox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                    }
                    break;
                case "BuildingFixtures":
                    if (obj_businessPremises.yourBuildingAddCoverLink(i).isDisplayed()) {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_businessPremises.yourBuildingAddCoverLink(i));
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.yourBuildingValueTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                    } else {
                        obj_businessPremises.yourBuildingValueTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                    }
                    break;
                case "YourGlass":
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("null")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.mainbuildingGlassRemoveButton(i));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    } else if (obj_businessPremises.buildingShopAddCoverLink(i).isDisplayed()) {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_businessPremises.buildingShopAddCoverLink(i));
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.buildingShopValueTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_businessPremises.buildingShopValueTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                    }
                    break;
                case "OutbuildingYourGlass":
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("null")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outbuildingGlassRemoveButton(i));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_businessPremises.outbuildingShopAddCoverLink(i));
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.outbuildingShopValueTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "OutbuildingYourFittings":
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("null")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outbuildingFittingsRemoveButton(i));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    } else {

                        obj_generalInformation.executeScript("arguments[0].click();", obj_businessPremises.outbuildingfittingAddCoverLink(i));
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.outbuildingfittingValueTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "OutbuildingPropertyBuilt":
                    new Select(obj_businessPremises.outbuildingPropertyBuiltDrodown(i)).selectByVisibleText(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "YourFittings":
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("null")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.mainbuildingFittingsRemoveButton(i));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    } else if (obj_businessPremises.buildingfittingAddCoverLink(i).isDisplayed()) {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_businessPremises.buildingfittingAddCoverLink(i));
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.buildingfittingValueTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_businessPremises.buildingfittingValueTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                    }
                    break;

                case "MainBuildingBusinessContent":
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("null")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.mainBuildingBusinessContentRemoveButton(i));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    } else if (!getDriver.findElement(By.id("C6__BUT_487C210376DC00A33351584_R" + i)).isDisplayed()) {
//                        if (!getDriver.findElement(By.id("C6__QUE_487C210376DC00A33351576_R" + i)).isDisplayed()) {
                        obj_businessPremises.businessContentValueTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.businessContentAddCoverLink(i));
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.businessContentValueTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "MainBusinessContentExcluWines":
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("NotPresent")) {
                        strText = obj_businessPremises.businessContentLabel(i).getText();
                        strQuestion = "Your business contents and stock excluding wines and spirits";
                        Assert.assertTrue(!strText.equalsIgnoreCase(strQuestion));
                    }
                    break;
                case "MainBusinessContentExcluElect":
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("NotPresent")) {
                        strText = obj_businessPremises.businessContentLabel(i).getText();
                        strQuestion = "Your business contents excluding electrical items";
                        Assert.assertTrue(!strText.equalsIgnoreCase(strQuestion));
                    }
                    break;
                case "Wines":
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("NotPresent")) {
                        strText = obj_businessPremises.stockLabel(i).getText();
                        strQuestion = "Your stock of wines and spirits";
                        Assert.assertTrue(!strText.equalsIgnoreCase(strQuestion));
                    }
                    break;
                case "ElectricalItems":
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("NotPresent")) {
                        strText = obj_businessPremises.stockLabel(i).getText();
                        strQuestion = "Your electrical items";
                        Assert.assertTrue(!strText.equalsIgnoreCase(strQuestion));
                    }
                    break;
                case "MainBusinessContentRemoveBtn":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Present")) {
                        Assert.assertTrue(obj_businessPremises.mainBuildingBusinessContentRemoveButton(i).isDisplayed());
                    }
                    break;
                case "OutBusinessContentRemoveBtn":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Present")) {
                        Assert.assertTrue(obj_businessPremises.outBuildingBusinessContentRemoveButton(i).isDisplayed());
                    }
                    break;
                case "MainStockRemoveBtn":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Present")) {
                        Assert.assertTrue(obj_businessPremises.stocksRemoveCoverButton(i).isDisplayed());
                    }
                    break;
                case "OutStockRemoveBtn":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Present")) {
                        Assert.assertTrue(obj_businessPremises.outBuildingStockRemoveButton(i).isDisplayed());
                    }
                    break;
                case "MainBusinessContentAddBtn":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Present")) {
                        Assert.assertTrue(obj_businessPremises.excludingElectricItemsAddCoverButton(i).isDisplayed());
                    }
                    break;
                case "OutBusinessContentAddBtn":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Present")) {
                        Assert.assertTrue(obj_businessPremises.outBusninessContentAddCover(i).isDisplayed());
                    }
                    break;
                case "MainStockAddBtn":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Present")) {
                        Assert.assertTrue(obj_businessPremises.stocksAddCoverButton(i).isDisplayed());
                    }
                    break;
                case "OutStockAddBtn":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Present")) {
                        Assert.assertTrue(obj_businessPremises.outStockAddCover(i).isDisplayed());
                    }
                    break;
                case "MainBuildingYourStock":
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("null")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.mainBuildingStockRemoveButton(i));
                        obj_generalInformation.pageLoading();
                    } else {
                        if (!obj_businessPremises.stockAddCoverLink(i).isDisplayed()) {
                            obj_businessPremises.stockValueTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                            obj_commonUtil.tabKeypress();
                            obj_generalInformation.pageLoading();
                        } else {
                            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.stockAddCoverLink(i));
                            obj_generalInformation.pageLoading();
                            obj_businessPremises.stockValueTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                            obj_commonUtil.tabKeypress();
                            obj_generalInformation.pageLoading();
                        }
                    }
                    break;
                case "MainBuildingYourStockWineSpirits":
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("null")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.mainBuildingStockRemoveButton(i));
                        obj_generalInformation.pageLoading();
                    } else {
                        if (!obj_businessPremises.stockWSAddCoverLink(i).isDisplayed()) {
                            obj_businessPremises.stockValueSpiritTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                            obj_commonUtil.tabKeypress();
                            obj_generalInformation.pageLoading();
                        } else {
                            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.stockWSAddCoverLink(i));
                            obj_generalInformation.pageLoading();
                            obj_businessPremises.stockValueSpiritTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                            obj_commonUtil.tabKeypress();
                            obj_generalInformation.pageLoading();
                        }
                    }
                    break;
                case "OutBuildingYourStockWineSpirits":
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("null")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outBuildingStockWSRemoveButton(i));
                        obj_generalInformation.pageLoading();
                    } else {
                        if (!obj_businessPremises.outbuildingStockWSAddCoverLink(i).isDisplayed()) {
                            obj_businessPremises.outbuildingStockValueSpiritTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                            obj_commonUtil.tabKeypress();
                            obj_generalInformation.pageLoading();
                        } else {
                            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outbuildingStockWSAddCoverLink(i));
                            obj_generalInformation.pageLoading();
                            obj_businessPremises.outbuildingStockValueSpiritTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                            obj_commonUtil.tabKeypress();
                            obj_generalInformation.pageLoading();
                        }
                    }
                    break;
                case "MainBuildingHouseholdContent":
                    if (!obj_businessPremises.householdContentAddCoverLink(i).isDisplayed()) {
                        obj_businessPremises.householdContentValueTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.householdContentAddCoverLink(i));
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.householdContentValueTextbox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "OutBuildingBusinessContent":
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("null")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outBuildingBusinessContentRemoveButton(i));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    } else if (!obj_businessPremises.outBusninessContentAddCover(i).isDisplayed()) {
                        obj_businessPremises.outBusinessContentTextBox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outBusninessContentAddCover(i));
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.outBusinessContentTextBox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "OutBuildingYourStock":
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("null")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outBuildingStockRemoveButton(i));
                        obj_generalInformation.pageLoading();
                    } else {
                        if (!obj_businessPremises.outStockAddCover(i).isDisplayed()) {
                            obj_businessPremises.outBusinessStockTextBox(i).sendKeys(premiseFields.get(premiseQuestion));
                            obj_commonUtil.tabKeypress();
                            obj_generalInformation.pageLoading();
                        } else {
                            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outStockAddCover(i));
                            obj_generalInformation.pageLoading();
                            obj_businessPremises.outBusinessStockTextBox(i).sendKeys(premiseFields.get(premiseQuestion));
                            obj_commonUtil.tabKeypress();
                            obj_generalInformation.pageLoading();
                        }
                    }
                    break;
                case "OutBuildingHouseholdContent":
                    if (!obj_businessPremises.outHouseholdContentAddCover(i).isDisplayed()) {
                        obj_businessPremises.outHouseholdContentTextBox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                    } else {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outHouseholdContentAddCover(i));
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.outHouseholdContentTextBox(i).sendKeys(premiseFields.get(premiseQuestion));
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "IndividualItemOfHouseHold":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.individualItemOfHouseHold(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "Named Items":
                    String[] NamedItemValues = (premiseFields.get(premiseQuestion)).split(":");
                    for (int j = 0; j < 1; j++) {
                        String[] namedItem = NamedItemValues[j].split("_");
                        obj_generalInformation.executeScript("arguments[0].click();", obj_businessPremises.premiseNamedItemAddButton(i));
//                        obj_businessPremises.premiseNamedItemAddButton(i).click();
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.premiseTypeOfItem().sendKeys(namedItem[0]);
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.premiseValueOfItem().sendKeys(namedItem[1]);
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.premiseItemDescription().sendKeys(namedItem[2]);
                        obj_generalInformation.pageLoading();
//                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.premiseItemKept(namedItem[3]));
//                        obj_generalInformation.pageLoading();
                        obj_generalInformation.executeScript("arguments[0].click();", obj_businessPremises.premiseNamedItemPopUpAddButton());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "AddItem":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_businessPremises.premiseNamedItemAddButton(i));
                    obj_generalInformation.pageLoading();
                    break;
                case "ItemType":
                    obj_businessPremises.premiseTypeOfItem().sendKeys(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "ItemValue":
                    obj_businessPremises.premiseValueOfItem().sendKeys(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "ItemDesc":
                    obj_businessPremises.premiseItemDescription().sendKeys(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "ItemKept":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.premiseItemKept(premiseFields.get(premiseQuestion)));
                    obj_generalInformation.pageLoading();
                    break;
                case "PopupAddItem":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_businessPremises.premiseNamedItemPopUpAddButton());
                    obj_generalInformation.pageLoading();
                    break;
                case "AddAnotherItem":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.premiseAddAnotherNamedItemButton(i));
                    obj_generalInformation.pageLoading();
                    break;
                case "MainBuildingUsedFor":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Guest accommodation & residential")) {
                        String expStr = "Guest accommodation & residential";
                        new Select(obj_businessPremises.mainBuildingUsageDDL(i)).selectByVisibleText(expStr);
                        obj_generalInformation.pageLoading();
                    } else {
                        new Select(obj_businessPremises.mainBuildingUsageDDL(i)).selectByVisibleText(premiseFields.get(premiseQuestion));
                        obj_generalInformation.pageLoading();
                    }
                    break;


                case "BuildingUsageFreeFormat":
                    obj_businessPremises.buiildingUsageFreeformattext(i).sendKeys(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "OutBuildingUsedFor":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Guest accommodation residential")) {
                        String expStr = "Guest accommodation & residential";
                        new Select(obj_businessPremises.outBuildingUsageDropDown(i)).selectByVisibleText(expStr);
                        obj_generalInformation.pageLoading();
                    } else {
                        new Select(obj_businessPremises.outBuildingUsageDropDown(i)).selectByVisibleText(premiseFields.get(premiseQuestion));
                        obj_generalInformation.pageLoading();
                    }
                    break;

                case "OutBuildingUsageFreeFormat":
                    obj_businessPremises.outbuildingUsageFreeformattext(i).sendKeys(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "MainBuildingBedRoom":
                    new Select(obj_businessPremises.selectBedRoomDropdownMain(i)).selectByVisibleText(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "MainBuildingBedRoomFreeFormat":
                    obj_businessPremises.bedRoomFreeFormatMain(i).sendKeys(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "OutBuildingBedRoom":
                    new Select(obj_businessPremises.selectBedRoomDropdownOut(i)).selectByVisibleText(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "OutBuildingBedRoomFreeFormat":
                    obj_businessPremises.bedRoomFreeFormatOut(i).sendKeys(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "MainBuildingSelfCatering":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Y")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.mainSelfCateringQuestionYesRadioButton(i));
                        obj_generalInformation.pageLoading();
                    } else if (premiseFields.get(premiseQuestion).equalsIgnoreCase("N")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.mainSelfCateringQuestionNoRadioButton(i));
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "BuildingType":
                    new Select(obj_businessPremises.buildingTypedDrodown(i)).selectByVisibleText(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "PropertyBuilt":
                    new Select(obj_businessPremises.propertyBuiltDrodown(i)).selectByVisibleText(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "OutBuildingSelfCatering":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Y")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outSelfCateringQuestionYesRadioButton(i));
                        obj_generalInformation.pageLoading();
                    } else if (premiseFields.get(premiseQuestion).equalsIgnoreCase("N")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outSelfCateringQuestionNoRadioButton(i));
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "MainBuildingPremisegrade1":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Y")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.premiseGradeYesRadiobutton(i));
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.premiseGradeNoRadiobutton(i));
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "WallConcrete":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.wallsMade(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "OutBuildingWallConcrete":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outBuildingWallsMade(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "WallTimber":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Y")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.wallMaterialYesRadiobutton(i));
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.wallMaterialNoRadiobutton(i));
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "AddWall":
                    int p;
                    String addWallMaterial[] = premiseFields.get(premiseQuestion).split(",");
                    String addWallMaterialvalue[] = premiseFields.get(premiseQuestion).split(":");
                    if (Integer.parseInt(addWallMaterialvalue[1]) == 1) {
                        p = 1;
                    } else {
                        p = 2;
                    }
                    for (int j = 0; j < addWallMaterial.length; j++) {
                        obj_businessPremises.addWallMainButton(p).click();
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.wallmaterialdropdown().sendKeys(addWallMaterial[j]);
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.wallMaterialPopupAddMaterial().click();
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "OutBuildingWallTimber":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outBuildingWallTimber(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "AddWallOutBuilding":
                    String addWallMaterialOutBuilding[] = premiseFields.get(premiseQuestion).split(",");
                    for (int j = 0; j < addWallMaterialOutBuilding.length; j++) {
                        obj_businessPremises.addWallOutButton().click();
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.wallMaterialOutDropdown().sendKeys(addWallMaterialOutBuilding[j]);
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.addWallOutPopUp().click();
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "Roofs":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Y")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.roofMaterialYesRadiobutton(i));
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.roofMaterialNoRadiobutton(i));
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "AddRoofs":
                    String addRoofMaterial[] = premiseFields.get(premiseQuestion).split(",");
                    for (int j = 0; j < addRoofMaterial.length; j++) {
                        obj_businessPremises.addRoofMainButton().click();
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.roofMaterialDropdown().sendKeys(addRoofMaterial[j]);
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.addRoofPopUp().click();
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "OutBuildingRoofs":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outBuildingRoofs(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "AddRoofsOutBuilding":
                    String addRoofMaterialOutBuilding[] = premiseFields.get(premiseQuestion).split(",");
                    for (int j = 0; j < addRoofMaterialOutBuilding.length; j++) {
                        obj_businessPremises.addRoofOutButton().click();
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.roofOutDropdown().sendKeys(addRoofMaterialOutBuilding[j]);
                        obj_generalInformation.pageLoading();
                        obj_businessPremises.addRoofOutPopUp().click();
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "SecurityFeature":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_businessPremises.homeBurglarOption(i));
                    obj_generalInformation.pageLoading();
                    break;
                case "SecurityFeatureMainBuildingNone":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.securityFeatureMainBuildingNone(i));
                    obj_generalInformation.pageLoading();
                    break;

                case "BurglarAlarm":
                    new Select(obj_businessPremises.alarmType(i)).selectByVisibleText(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "AlarmUnderyourBusiness":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_businessPremises.alarmUnderyourBusiness(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "PoliceResponse":
                    new Select(obj_businessPremises.policeResponse(i)).selectByVisibleText(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "AlarmMaintians":
                    new Select(obj_businessPremises.alarmMaintenance(i)).selectByVisibleText(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "SecurityFeatureHome":
                    String[] type = (premiseFields.get(premiseQuestion)).split(":");
                    for (String securityTypes : type) {
                        if (securityTypes.equalsIgnoreCase("CCTV with 24 hour recording")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.homeCctvOption(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypes.equalsIgnoreCase("Burglar alarm")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.homeBurglarOption(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypes.equalsIgnoreCase("None of the above")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.homeNoneOption(i));
                            obj_generalInformation.pageLoading();
                        }
                    }
                    break;
                case "SecurityFeatureHomeOutBuilding":
                    String[] type1 = (premiseFields.get(premiseQuestion)).split(":");
                    for (String securityTypes : type1) {
                        if (securityTypes.equalsIgnoreCase("CCTV with 24 hour recording")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.homeCctvOptionOut(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypes.equalsIgnoreCase("Burglar alarm")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.homeBurglarOptionOut(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypes.equalsIgnoreCase("None of the above")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.homeNoneOptionOut(i));
                            obj_generalInformation.pageLoading();
                        }
                    }
                    break;
                case "SecurityFeatureCommercialOutbuilding":
                    String[] securityTypeOutbuilding = (premiseFields.get(premiseQuestion)).split(":");
                    for (String securityTypesOut : securityTypeOutbuilding) {
                        if (securityTypesOut.equalsIgnoreCase("CCTV with 24 hour recording")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.saloncctvOptionOut(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypesOut.equalsIgnoreCase("Burglar alarm")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.salonBurglarOptionOut(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypesOut.equalsIgnoreCase("None of the above")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.salonNoneOptionOut(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypesOut.equalsIgnoreCase("Bars and grilles")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.salonBarsOut(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypesOut.equalsIgnoreCase("Steel-lined external doors")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.salonSteelOut(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypesOut.equalsIgnoreCase("Metal roller shutter")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.salonMetalOut(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypesOut.equalsIgnoreCase("Enclosed within a shopping centre")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.salonShoppingOut(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypesOut.equalsIgnoreCase("You, members of your family or your employees live above the premises")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.salonFamilyOut(i));
                            obj_generalInformation.pageLoading();
                        }
                    }
                    break;
                case "SecurityFeatureCommercial":
                    String[] securityType = (premiseFields.get(premiseQuestion)).split(":");
                    for (String securityTypes : securityType) {
                        if (securityTypes.equalsIgnoreCase("CCTV with 24 hour recording")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.saloncctvOption(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypes.equalsIgnoreCase("Burglar alarm")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.salonBurglarOption(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypes.equalsIgnoreCase("None of the above")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.salonNoneOption(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypes.equalsIgnoreCase("Bars and grilles")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.salonBars(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypes.equalsIgnoreCase("Steel-lined external doors")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.salonSteel(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypes.equalsIgnoreCase("Metal roller shutter")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.salonMetal(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypes.equalsIgnoreCase("Enclosed within a shopping centre")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.salonShopping(i));
                            obj_generalInformation.pageLoading();
                        } else if (securityTypes.equalsIgnoreCase("You, members of your family or your employees live above the premises")) {
                            obj_commonUtil.clickbyJS(obj_businessPremises.salonFamily(i));
                            obj_generalInformation.pageLoading();
                        }
                    }
                    break;
                case "AlarmTypeQuestion":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Present")) {
                        strQuestion = obj_businessPremises.alarmTypeQuestionMain(i).get(0).getText();
                        strText = "Please select your type of burglar alarm?";
                        Assert.assertTrue("AlarmTypeQuestion is displayed", strQuestion.replace("\n", "").replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    } else if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("NotPresent")) {
                        Assert.assertTrue(!obj_businessPremises.alarmTypeQuestionMain(i).get(0).isDisplayed());
                    }
                    break;
                case "AlarmSoleCtrlQuestion":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Present")) {
                        strQuestion = obj_businessPremises.alarmUnderyourBusinessQuestionMain(i).get(0).getText();
                        strText = "Is the alarm under your business' sole control?";
                        Assert.assertTrue("AlarmSoleCtrlQuestion is displayed", strQuestion.replace("\n", "").replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    } else if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("NotPresent")) {
                        Assert.assertTrue(!obj_businessPremises.alarmUnderyourBusinessQuestionMain(i).get(0).isDisplayed());
                    }
                    break;
                case "HomeTypeQuestion":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Present")) {
                        strQuestion = obj_businessPremises.buildingTypeQuestionMain(i).get(0).getText();
                        strText = "Building type";
                        Assert.assertTrue("HomeTypeQuestion is displayed", strQuestion.replace("\n", "").replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    } else if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("NotPresent")) {
                        Assert.assertTrue(!obj_businessPremises.buildingTypeQuestionMain(i).get(0).isDisplayed());
                    }
                    break;
                case "HomeTypeRequired":
                    strReqMsg = obj_businessPremises.homeTypeRequired(i).get(0).getText();
                    if (strReqMsg.equals("Required")) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "AlarmPoliceResponseQues":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Present")) {
                        strQuestion = obj_businessPremises.policeResponseQuestionMain(i).get(0).getText();
                        strText = "Does your alarm have police response?";
                        Assert.assertTrue("AlarmPoliceResponseQues is displayed", strQuestion.replace("\n", "").replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    } else if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("NotPresent")) {
                        Assert.assertTrue(!obj_businessPremises.policeResponseQuestionMain(i).get(0).isDisplayed());
                    }
                    break;
                case "AlarmMaintainQues":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Present")) {
                        strQuestion = obj_businessPremises.alarmMaintainQuestionMain(i).get(0).getText();
                        strText = "Who maintains the alarm?";
                        Assert.assertTrue("AlarmMaintainQues is displayed", strQuestion.replace("\n", "").replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    } else if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("NotPresent")) {
                        Assert.assertTrue(!obj_businessPremises.alarmMaintainQuestionMain(i).get(0).isDisplayed());
                    }
                    break;
                case "OutBuildingPremiseGrade1":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Y")) {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outPremiseGradeYesRadiobutton(i));
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outPremiseGradeNoRadiobutton(i));
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "MainBuildingFirePlace":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.portableElectricHeater(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "AddMethodOfHeating":
                    String addMethodOfHeating[] = premiseFields.get(premiseQuestion).split(":");
                    for (int j = 0; j < addMethodOfHeating.length; j++) {
                        String addMethodOfHeatingValue[] = addMethodOfHeating[j].split(",");
                        obj_businessPremises.addheatingButton().click();
                        obj_generalInformation.pageLoading();
                        for (int k = 0; k < addMethodOfHeatingValue.length; k++) {
                            if (k == 0) {
                                obj_businessPremises.heatingTypeDropdown().sendKeys(addMethodOfHeatingValue[k]);
                                obj_generalInformation.pageLoading();
                            } else {
                                obj_businessPremises.fuelTypeDropdown().sendKeys(addMethodOfHeatingValue[k]);
                                obj_generalInformation.pageLoading();
                            }
                        }
                        obj_businessPremises.addHeatPopUp().click();
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "MainBuildingPortableElectricHeater":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.portableElectricHeater(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "SecurityFeatureOutBuildingNone":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.securityFeatureOutBuildingNone(i));
                    obj_generalInformation.pageLoading();
                    break;
                case "OutBuildingFirePlace":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outbuildingFirePlace(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "OutBuildingElectricHeater":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outbuildingElectricHeater(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "AddMethodOfHeatingOutBuilding":
                    String addMethodOfHeatingOutBuilding[] = premiseFields.get(premiseQuestion).split(":");
                    for (int j = 0; j < addMethodOfHeatingOutBuilding.length; j++) {
                        String addMethodOfHeatingValue[] = addMethodOfHeatingOutBuilding[j].split(",");
                        obj_businessPremises.addheatingOutButton().click();
                        obj_generalInformation.pageLoading();
                        for (int k = 0; k < addMethodOfHeatingValue.length; k++) {
                            if (k == 0) {
                                obj_businessPremises.heatingTypeOutDropdown().sendKeys(addMethodOfHeatingValue[k]);
                                obj_generalInformation.pageLoading();
                            } else {
                                obj_businessPremises.fuelTypeOutDropdown().sendKeys(addMethodOfHeatingValue[k]);
                                obj_generalInformation.pageLoading();
                            }
                        }
                        obj_businessPremises.addHeatOutPopUp().click();
                        obj_generalInformation.pageLoading();
                    }
                    break;


                case "SubsidenceCover":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.subsidenceCover(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "Next":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.nextButton());
                    // This has been removed once the application becomes stable
                    Thread.sleep(10000);
                    obj_generalInformation.pageLoading();
                    break;
                case "AddAnotherPremises":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.addAnotherPremise());
                    obj_generalInformation.pageLoading();
                    break;
                case "SaveAndExit":
                    obj_businessPremises.executeScript("arguments[0].click()", obj_businessPremises.saveAndExit());
                    obj_generalInformation.pageLoading();
                    obj_businessPremises.executeScript("arguments[0].click()", obj_businessPremises.saveAndExitPopUp());
                    obj_generalInformation.pageLoading();
                    if ((premiseFields.get(premiseQuestion)).equalsIgnoreCase("Y")) {
                        saveandExit();
                    }
                    break;
                case "ChangeResponse":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.insureAnyOutBuilding(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "NamedItems":
                    verificationOfGradeListedQuestionInPremisesScreen();
                    validationTxt = "When deciding on the value, you should use the amount it would cost to replace the item with a new one.";
                    peoplebusinesutil.validateHelpTextPresent(validationTxt, obj_businessPremises.popupItemValueHelpText());
                    obj_generalInformation.executeScript("arguments[0].click();", obj_businessPremises.premiseNamedItemPopUpAddButton());
                    obj_generalInformation.pageLoading();
                    break;
                case "Grade1":
                    validationTxt = "If you’re not sure whether your property is listed, you can check on this website: http://www.britishlistedbuildings.co.uk/";
                    peoplebusinesutil.validateHelpTextPresent(validationTxt, obj_businessPremises.gradeQuesHelpText());
                    break;

                case "BuildingCover":
                    validationTxt = "Covers damage to your building, including rebuilding it if it was damaged beyond repair. As standard, we’ll pay to repair or replace your boiler if it breaks down (excludes wear and tear) and it's used for business purposes.\n\nThe rebuild cost isn’t the market value. It’s the cost of completely rebuilding your property, to put it back to its previous condition. If you’re not sure of the rebuild cost, you can get this from a qualified surveyor, your mortgage adviser or letting agent, or a recent property survey. For residential properties, the Association of British Insurers’ rebuilding cost calculator might be helpful.http://abi.bcis.co.uk/";
                    peoplebusinesutil.validateHelpTextPresent(validationTxt, obj_businessPremises.yourBuildingQuesText());
                    break;


                case "BuildingFixFitGlass":
                    validationTxt = "Covers damage to your building, including rebuilding it if it was damaged beyond repair. As standard, we’ll pay to repair or replace your boiler if it breaks down (excludes wear and tear) and it's used for business purposes.\n\nThe cover includes all fixed glass, blinds and signs. Fixtures and fittings covers, for example, counters and fixed display shelves.\n\nThe rebuild cost isn’t the market value. It’s the cost of completely rebuilding your property, to put it back to its previous condition. If you’re not sure of the rebuild cost, you can get this from a qualified surveyor, your mortgage adviser or letting agent, or a recent property survey.";
                    peoplebusinesutil.validateHelpTextPresent(validationTxt, obj_businessPremises.yourBuildingQuesText());
                    break;
                case "Yourglass":
                    validationTxt = "This includes all fixed glass, blinds and signs.";
                    peoplebusinesutil.validateHelpTextPresent(validationTxt, obj_businessPremises.glassHelpText());
                    break;
                case "YourFixFit":
                    validationTxt = "Fixtures and fittings covers, for example, counters and fixed display shelves.";
                    peoplebusinesutil.validateHelpTextPresent(validationTxt, obj_businessPremises.fixturesFittings());
                    break;

                case "ExcludingElectricalItemsQues":
                    validationTxt = "Your business contents excluding electrical items";
                    peoplebusinesutil.validateHelpTextPresent(validationTxt, obj_businessPremises.excludingElectricalItemsQues(i));
                    break;
                case "ExcludingElectricalItemsHT":
                    validationTxt = "For instance office furniture, files, papers and art";
                    peoplebusinesutil.validateHelpTextPresent(validationTxt, obj_businessPremises.excludingElectricalItemsHT(i));
                    break;

                case "ElectricalItemsQues":
                    validationTxt = "Your electrical items";
                    peoplebusinesutil.validateHelpTextPresent(validationTxt, obj_businessPremises.electricalItemsQues(i));
                    break;
                case "ElectricalItemsHT":
                    validationTxt = "For instance computers, laptops, projectors and screens on the premises";
                    peoplebusinesutil.validateHelpTextPresent(validationTxt, obj_businessPremises.electricalItemsHT(i));
                    break;
                case "ExcludingElectricalItemsRemoveCoverCheck":
                    obj_businessPremisesUtil.removeCoverBtnTextBoxEnableCheck(obj_businessPremises.excludingElectricItemsRemoveCoverButton(i), obj_businessPremises.excludingElectricItemsTextBox(i));
                    break;
                case "ElectricalItemsRemoveCoverCheck":
                    obj_businessPremisesUtil.removeCoverBtnTextBoxEnableCheck(obj_businessPremises.electricItemsRemoveCoverButton(i), obj_businessPremises.stockValueSpiritTextbox(i));
                    break;
                case "ExcludingElectricalItemsAddCoverCheck":
                    obj_businessPremisesUtil.addCoverBtnCheck(obj_businessPremises.excludingElectricItemsAddCoverButton(i));
                    break;
                case "ElectricalItemsAddCoverCheck":
                    obj_businessPremisesUtil.addCoverBtnCheck(obj_businessPremises.electricItemsAddCoverButton(i));
                    break;
                case "StockAddCoverCheck":
                    obj_businessPremisesUtil.addCoverBtnCheck(obj_businessPremises.stocksAddCoverButton(i));
                    break;
                case "StockQues":
                    validationTxt = "Your stock";
                    peoplebusinesutil.validateHelpTextPresent(validationTxt, obj_businessPremises.stockQues(i));
                    break;
                case "StockHT":
                    validationTxt = "Raw materials or products you might sell";
                    peoplebusinesutil.validateHelpTextPresent(validationTxt, obj_businessPremises.stocksHelpText(i));
                    break;
                case "StockRetailHT":
                    validationTxt = "Raw materials or products you sell";
                    peoplebusinesutil.validateHelpTextPresent(validationTxt, obj_businessPremises.stocksHelpText(i));
                    break;
                case "StockRemoveCoverCheck":
                    obj_businessPremisesUtil.removeCoverBtnTextBoxEnableCheck(obj_businessPremises.stocksRemoveCoverButton(i), obj_businessPremises.stocksTextBox(i));
                    break;
                case "Premises":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.premisesClick(premiseFields.get(premiseQuestion)));
                    break;
                case "SubsidenceCoverHistory":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.subsidenceCoverHistory(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "SubsidenceCoverProximity":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.subsidenceCoverProximity(premiseFields.get(premiseQuestion), i));
                    obj_generalInformation.pageLoading();
                    break;
                case "GlassHT":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_businessPremises.glassHelpText());
                    strHelpText = "This includes all fixed glass, blinds and signs.";
                    Assert.assertTrue("GlassHT is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    break;
                case "AccomodationHT":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_businessPremises.accomodationHelpText());
                    strHelpText = "For example, food or drink available to guests not staying overnight, catering away from the premises, children’s play areas, swimming pools and private function rooms. If you're not sure, give us a call.";
                    Assert.assertTrue("AccomodationHT is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    break;
                case "OtherInsureHT":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_businessPremises.insureBuildingHT());
                    strHelpText = "You can choose which buildings to insure at your premises. These might include the main building, and other buildings such as additional guest accommodation, gyms, games rooms, function rooms, and indoor swimming pools and hot tubs.";
                    Assert.assertTrue("OtherInsureHT is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    break;
                case "BusinessContentandStockHT":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_businessPremises.businessContentStockHT());
                    strHelpText = "This covers contents used for your business, such as beds, curtains, linen, wardrobes and dressing tables in guest bedrooms, plus computers etc you use in running your business. As standard, we’ll extend your cover to include equipment breakdown, which pays to repair or replace things like washer dryers and fridge freezers (excludes wear and tear). Stock is things like food, beers and toiletries you provide for your guests. When deciding on how much insurance you need, you should use the amount it'd cost to buy new replacements.";
                    Assert.assertTrue("BusinessContentandStockHT is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    break;
                case "BusinessContentHT":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_businessPremises.businessContentStockHT());
                    strHelpText = "For instance, display cabinets, point of sale equipment, and PCs etc";
                    Assert.assertTrue("BusinessContent Help Text is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    break;
                case "WinesSpiritsHT":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_businessPremises.winesandSpiritHT());
                    strHelpText = "You should only include wines and spirits you provide for your guests.";
                    Assert.assertTrue("WinesSpiritsHT is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    break;
                case "SelfCateringHT":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_businessPremises.selfCaterHT());
                    strHelpText = "Self-catering facilities are things like hobs and ovens. If your guests only have access to electric kettles and/or microwaves, you should answer 'no' to this question.";
                    Assert.assertTrue("SelfCateringHT is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    break;
                case "BuildingUsedHT":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_businessPremises.buildingUsageHelpText());
                    strHelpText = "Please tell us what this building is used for. If it's used for more than one thing, choose 'Other' from the list, and tell us all of the things the building's used for. If you're not sure which option to choose, give us a call or start a web chat.";
                    Assert.assertTrue("BuildingUsedHT is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    break;
                case "BedRoomHT":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_businessPremises.bedroomHT());
                    strHelpText = "Please enter the number of bedrooms in the building, including both guest bedrooms and bedrooms used by you and your family and staff members. If a room originally intended to be a bedroom has been converted into, say, a study or playroom, then it should be counted as a bedroom. If you've converted a room not originally intended to be a bedroom (for example a reception room or an integral garage) into a bedroom, please don't count it as a bedroom.";
                    Assert.assertTrue("BedRoomHT is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    break;
                case "AssumpContent":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("PremiseHomeAssumpContent")) {
                        strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_businessPremises.homeAssumpContent(i));
                        strHelpText = "We've assumed the following about your premises, please agree if all of the below statements are true: The premises are only occupied by your business and as a home by your family.During the year, the premises will not be vacant for more than 30 consecutive days.The walls are built solely of brick, stone, concrete or timber frame with brick or stone.Other than flat roofs, the building is roofed solely of slates, tiles, asphalt, concrete, metal or other incombustible materials.The premises are heated only by a fixed gas or oil central heating system, an electric storage heating system, portable electric heaters or an open fire.The premises are not Grade 1 listed in England and Wales, Category A in Scotland, Grade A in Northern Ireland, or the equivalent in the Channel Islands and Isle of Man. I agree I disagree";
                        Assert.assertTrue("PremiseHomeAssumpContent is displayed", strHelpText.replace(" ", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "")));
                    } else if (premiseFields.get(premiseQuestion).equalsIgnoreCase("PremiseCommAssumpContent")) {
                        strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_businessPremises.commAssumpContent(i));
                        strHelpText = "We've assumed the following about your premises, please agree if all of the below statements are true: During the year, the premises will not be vacant for more than 30 consecutive days.The premises do not have an external ATM.The walls are built solely of brick, stone, concrete or glass.Other than flat roofs, the building is roofed solely of slates, tiles, asphalt, concrete, metal or other incombustible materials.The premises are heated only by a fixed gas or oil central heating system, an electric storage heating system or portable electric heaters.The premises are not Grade 1 listed in England and Wales, Category A in Scotland, Grade A in Northern Ireland, or the equivalent in the Channel Islands and Isle of Man. I agree I disagree";
                        Assert.assertTrue("PremiseCommAssumpContent is displayed", strHelpText.replace(" ", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "")));
                    }
                    break;
                case "AssumptionButton":
                    if (premiseFields.get(premiseQuestion).equalsIgnoreCase("Y")) {
                        obj_impornantstatement.executeScript("arguments[0].click()", obj_businessPremises.assumpAgree(i));
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_impornantstatement.executeScript("arguments[0].click()", obj_businessPremises.assumpDisagree(i));
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "RequiredMsgValidation":
                    strReqMsg = obj_peoplebusiness.assumptionRequired().getText();
                    if (strReqMsg.equals("Required")) {
                        Assert.assertTrue(true);
                    } else {
                        Assert.assertTrue(false);
                    }
                    break;
                case "TypeOfBuilding":
                    new Select(obj_businessPremises.typeOfBuildingDDL(i)).selectByVisibleText(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "TypeOfBuildingDDLValidation":
                    String[] Options = {"Main Building", "Outbuilding"};
                    Select ddlValues = new Select(obj_businessPremises.typeOfBuildingDDL(i));
                    List<WebElement> ddlOptions = ddlValues.getOptions();
                    if (ddlOptions.size() == 3) {

                        for (int d = 0; d < ddlOptions.size() - 1; d++) {

                            if (Options[d].equalsIgnoreCase(ddlOptions.get(d + 1).getText().trim())) {
                                Assert.assertTrue(Options[d] + " Option is present", true);
                            } else {
                                Assert.assertTrue(Options[d] + " Option is not present", false);
                            }
                        }
                    } else {
                        Assert.assertTrue("DDL Options Size is mismatch", false);
                    }

                    break;

                case "TypeOfBuildingQuestionPresent":
                    strText = obj_businessPremises.typeOfBuildingQuestion(i).get(0).getText();
                    strHelpText = "What type of building is this?";
                    Assert.assertTrue("MainBuilding Question is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "TypeOfBuildingQuestionNotPresent":
                    if (!obj_businessPremises.typeOfBuildingQuestion(i).get(0).isDisplayed()) {
                        Assert.assertTrue("What type of building is this Question is not present", true);
                    } else {
                        Assert.assertTrue("What type of building is this Question is  present", false);
                    }

                    break;
                case "TypeOfBuildingHelpTextPresent":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_businessPremises.typeOfBuildingHelpText(i));
                    strHelpText = "Please tell us whether this is your main building or an outbuilding. Outbuildings include things like converted garages or stables, summerhouses, sheds and workshops. If you're not sure which option to choose, give us a call or start a web chat.";
                    Assert.assertTrue("MainBuilding HelpText is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    break;
                case "TypeOfBuildingHelpTextNotPresent":
                    int intSize = obj_businessPremises.typeOfBuildingHT(i).size();
                    if (intSize == 0) {
                        Assert.assertTrue("HelpText is not present", true);
                    }
                    break;
                case "TypeOfBuildingOut":
                    new Select(obj_businessPremises.typeOfBuildingOutDDL(i)).selectByVisibleText(premiseFields.get(premiseQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "TypeOfBuildingOutQuestionPresent":
                    strText = obj_businessPremises.typeOfBuildingOutQuestion(i).get(0).getText();
                    strHelpText = "What type of building is this?";
                    Assert.assertTrue("OutBuilding Question is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    break;
                case "MainBuildingErrorMsg":
                    typeOfBuild = obj_businessPremises.typeOfBuildingReqMsg(i).getText();
                    typeOfBuildOut = obj_businessPremises.typeOfBuildingOutReqMsg(i).getText();
                    if (typeOfBuild.equals("You can only add one main building") && typeOfBuildOut.equals("You can only add one main building")) {
                        Assert.assertTrue("Specific error message is appear", true);
                    } else {
                        Assert.assertTrue("Specific error message is not appear", false);
                    }
                    break;

                case "TypeOfBuildingOutQuestionNotPresent":
                    if (!obj_businessPremises.typeOfBuildingOutQuestion(i).get(0).isDisplayed()) {
                        Assert.assertTrue("What type of building is this Question is not present", true);
                    } else {
                        Assert.assertTrue("What type of building is this Question is  present", false);
                    }
                    break;
                case "TypeOfBuildingOutHelpTextPresent":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_businessPremises.typeOfBuildingOutHelpText(i));
                    strHelpText = "Please tell us whether this is your main building or an outbuilding. Outbuildings include things like converted garages or stables, summerhouses, sheds and workshops. If you're not sure which option to choose, give us a call or start a web chat.";
                    Assert.assertTrue("OutBuildingHelpText is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    break;
                case "TypeOfBuildingOutHelpTextNotPresent":
                    int intHT = obj_businessPremises.typeOfBuildingOutHT(i).size();
                    if (intHT == 0) {
                        Assert.assertTrue("HelpText is not present", true);
                    }
                    break;
                case "BuildingUsedForQuestNotPresent":
                    if (obj_businessPremises.mainBuildingUsageDropDownLabel(i).size() == 0) {
                        Assert.assertTrue("What is this building used for is not present", true);
                    } else {
                        Assert.assertTrue("What is this building used for is present", false);
                    }
                    break;
                case "BuildingHeadingPresent":
                    String buildings[] = premiseFields.get(premiseQuestion).split("%");
                    for (String buildingNumber : buildings) {
                        if (buildingNumber.equalsIgnoreCase("Building 1")) {
                            if (obj_businessPremises.buildings1Heading(i).get(0).isDisplayed() && obj_businessPremises.buildings1Heading1(i).get(0).isDisplayed()) {
                                Assert.assertTrue("Building1 heading displayed", true);
                            }
                        } else if (buildingNumber.equalsIgnoreCase("Building 2")) {
                            if (obj_businessPremises.buildings2Heading(i).get(0).isDisplayed() && obj_businessPremises.buildings2Heading2(i).get(0).isDisplayed()) {
                                Assert.assertTrue("Building2 heading displayed", true);
                            }
                        }
                    }
                    break;
                case "BuildingHeadingNotPresent":
                    String building[] = premiseFields.get(premiseQuestion).split("%");
                    for (String buildingNumbers : building) {
                        if (buildingNumbers.equalsIgnoreCase("Building 1")) {
                            if (!obj_businessPremises.buildings1Heading(i).get(0).isDisplayed()) {
                                Assert.assertTrue("Building1 heading not displayed", true);
                            }
                        } else if (buildingNumbers.equalsIgnoreCase("Building 2")) {
                            if (!obj_businessPremises.buildings2Heading(i).get(0).isDisplayed()) {
                                Assert.assertTrue("Building2 heading not displayed", true);
                            }
                        }
                    }
                    break;
                case "PremisesTypeQuesPresent":
                    if (obj_businessPremises.premisesTypeQues(i).get(0).isDisplayed()) {
                        Assert.assertTrue("Question present", true);
                    } else {
                        Assert.assertTrue("Question not present", false);
                    }
                    break;
                case "PremisesTypeQuesNotPresent":
                    if (!obj_businessPremises.premisesTypeQues(i).get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
                case "BuildingTypeQuesPresent":
                    if (obj_businessPremises.buildingTypeQues(i).get(0).isDisplayed()) {
                        Assert.assertTrue("Question present", true);
                    } else {
                        Assert.assertTrue("Question not present", false);
                    }
                    break;
                case "BuildingTypeQuesNotPresent":
                    if (!obj_businessPremises.buildingTypeQues(i).get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
                case "PremisesOccupiedQuesPresent":
                    if (obj_businessPremises.premisesOccupiedQues(i).get(0).isDisplayed()) {
                        Assert.assertTrue("Question present", true);
                    } else {
                        Assert.assertTrue("Question not present", false);
                    }
                    break;
                case "PremisesOccupiedQuesNotPresent":
                    if (!obj_businessPremises.premisesOccupiedQues(i).get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
                case "BuildingOccupiedQuesPresent":
                    if (obj_businessPremises.buildingOccupiedQues(i).get(0).isDisplayed()) {
                        Assert.assertTrue("Question present", true);
                    } else {
                        Assert.assertTrue("Question not present", false);
                    }
                    break;
                case "BuildingOccupiedQuesNotPresent":
                    if (obj_businessPremises.buildingOccupiedQues(i).size() == 0) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
                case "TradeSelectionQuesPresent":
                    if (obj_businessPremises.tradeSelectionQues(i).get(0).isDisplayed()) {
                        Assert.assertTrue("Question present", true);
                    } else {
                        Assert.assertTrue("Question not present", false);
                    }
                    break;
                case "TradeSelectionQuesNotPresent":
                    if (!obj_businessPremises.tradeSelectionQues(i).get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
                case "OtherPortionQuesPresent":
                    if (obj_businessPremises.otherPortionQues(i).get(0).isDisplayed()) {
                        Assert.assertTrue("Question present", true);
                    } else {
                        Assert.assertTrue("Question not present", false);
                    }
                    break;
                case "OtherPortionQuesNotPresent":
                    if (obj_businessPremises.otherPortionQues(i).size() == 0) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
                case "SoleAccessControlQuesPresent":
                    if (obj_businessPremises.soleAccessControlQues(i).get(0).isDisplayed()) {
                        Assert.assertTrue("Question present", true);
                    } else {
                        Assert.assertTrue("Question not present", false);
                    }
                    break;
                case "SoleAccessControlQuesNotPresent":
                    if (!obj_businessPremises.soleAccessControlQues(i).get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
                case "ApplyBusinessQuesPresent":
                    if (obj_businessPremises.applyBusinessQues(i).get(0).isDisplayed()) {
                        Assert.assertTrue("Question present", true);
                    } else {
                        Assert.assertTrue("Question not present", false);
                    }
                    break;
                case "ApplyBusinessQuesNotPresent":
                    if (!obj_businessPremises.applyBusinessQues(i).get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
                case "PropertyBuiltQuesPresent":
                    if (obj_businessPremises.propertyBuiltQues(i).get(0).isDisplayed()) {
                        Assert.assertTrue("Question present", true);
                    } else {
                        Assert.assertTrue("Question not present", false);
                    }
                    break;
                case "PropertyBuiltQuesNotPresent":
                    if (!obj_businessPremises.propertyBuiltQues(i).get(0).isDisplayed()) {
                        Assert.assertTrue("Question not present", true);
                    } else {
                        Assert.assertTrue("Question present", false);
                    }
                    break;
            }
    }

    public void verificationOfGradeListedQuestionInPremisesScreen() throws Throwable {
        //Add the NamedItem
        obj_generalInformation.executeScript("arguments[0].click();", obj_businessPremises.premiseNamedItemAddButton(1));
        obj_generalInformation.pageLoading();
        obj_businessPremises.premiseTypeOfItem().sendKeys("Antique");
        obj_generalInformation.pageLoading();
        obj_businessPremises.premiseValueOfItem().sendKeys("2501");
        obj_generalInformation.pageLoading();
        obj_businessPremises.premiseItemDescription().sendKeys("abc");
        obj_generalInformation.pageLoading();
    }

    public void fillsPeopleBusinessSection(String runBusiness) throws Exception {
        if (runBusiness.equals("Salon")) {
            obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.selfEmployeeNoRadiobutton());
            obj_generalInformation.pageLoading();
        }
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
    }

    public void fillPropertyAwayScreen(String PAvalues) throws Throwable {
        int f = 0;
        LinkedHashMap<String, String> PAvalue = new LinkedHashMap<String, String>();
        String[] peopleField = PAvalues.split("#");
        for (int a = 1; a <= peopleField.length; a++) {
            String[] peopleValues = peopleField[a - 1].split(";");
            PAvalue.put(peopleValues[0], peopleValues[1]);
        }
        List<String> peopleQuestions = new ArrayList<>(PAvalue.keySet());
        for (String questions : peopleQuestions) {
            switch (questions) {
                case "businessTools":
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.businessToolsEquipment(PAvalue.get(questions)));
                    obj_propertyAway.pageLoading();
                    break;
                case "toolsSumInsured":
                    obj_propertyAway.businessToolsEquipmentValueTextbox().sendKeys(PAvalue.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_propertyAway.pageLoading();
                    break;
                case "personalBelongings":
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureBelongings(PAvalue.get(questions)));
                    obj_propertyAway.pageLoading();
                    break;
                case "belongingsSumInsured":
                    obj_propertyAway.personalBelongingsTextbox().sendKeys(PAvalue.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_propertyAway.pageLoading();
                    break;
                case "stocks":
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureYourStock(PAvalue.get(questions)));
                    obj_propertyAway.pageLoading();
                    break;
                case "stocksSumInsured":
                    obj_propertyAway.stockAwayTextbox().sendKeys(PAvalue.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_propertyAway.pageLoading();
                    break;
                case "stocksAtTransit":
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureStocksAtTransit(PAvalue.get(questions)));
                    obj_propertyAway.pageLoading();
                    break;
                case "transitSumInsured":
                    obj_propertyAway.stockAtTransitTextbox().sendKeys(PAvalue.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_propertyAway.pageLoading();
                    break;
                case "contentAndStock":
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.businessToolsEquipment(PAvalue.get(questions)));
                    obj_propertyAway.pageLoading();
                    break;
                case "contentStockSumInsured":
                    obj_propertyAway.businessToolsEquipmentValueTextbox().sendKeys(PAvalue.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_propertyAway.pageLoading();
                    break;
                case "InsureAnyIndividualItem":
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureAnyIndividualItem(PAvalue.get(questions)));
                    obj_propertyAway.pageLoading();
                    break;
                case "Named Items":
                    String[] NamedItemValues = (PAvalue.get(questions)).split(",");
                    for (int j = 0; j < 1; j++) {
                        String[] namedItem = NamedItemValues[j].split(":");
                        obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.propertyAwayAddItemRadiobutton());
                        obj_propertyAway.pageLoading();
                        obj_propertyAway.insureAnyIndividualPopupItemGroup().sendKeys(namedItem[0]);
                        obj_propertyAway.pageLoading();
                        obj_propertyAway.insureAnyIndividualPopupTypeofItem().sendKeys(namedItem[1]);
                        obj_propertyAway.pageLoading();
                        obj_propertyAway.insureAnyIndividualPopupItemValue().sendKeys(namedItem[2]);
                        obj_propertyAway.pageLoading();
                        obj_propertyAway.insureAnyIndividualPopupDescribe().sendKeys(namedItem[3]);
                        obj_propertyAway.pageLoading();
                        obj_propertyAway.insureAnyIndividualPopupAddItem().click();
                        obj_propertyAway.pageLoading();
                    }
                    break;
                case "AddItem":
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.propertyAwayAddItemRadiobutton());
                    obj_propertyAway.pageLoading();
                    break;
                case "ItemGroup":
                    obj_propertyAway.insureAnyIndividualPopupItemGroup().sendKeys(PAvalue.get(questions));
                    obj_propertyAway.pageLoading();
                    break;
                case "IndividualItem":
                    obj_propertyAway.insureAnyIndividualPopupTypeofItem().sendKeys(PAvalue.get(questions));
                    obj_propertyAway.pageLoading();
                    break;
                case "ItemValue":
                    obj_propertyAway.insureAnyIndividualPopupItemValue().sendKeys(PAvalue.get(questions));
                    obj_propertyAway.pageLoading();
                    break;
                case "ItemDesc":
                    obj_propertyAway.insureAnyIndividualPopupDescribe().sendKeys(PAvalue.get(questions));
                    obj_propertyAway.pageLoading();
                    break;
                case "AddItemPopup":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_propertyAway.insureAnyIndividualPopupAddItem());
                    obj_propertyAway.pageLoading();
                    break;
                case "AddAnotherItem":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_propertyAway.addAnotherItemButton());
                    obj_propertyAway.pageLoading();
                    break;

                case "SaveAndExit":
                    if ((PAvalue.get(questions)).equalsIgnoreCase("N")) {
                        obj_propertyAway.executeScript("arguments[0].click()", obj_propertyAway.saveAndExit());
                        obj_propertyAway.pageLoading();
                        obj_propertyAway.executeScript("arguments[0].click()", obj_propertyAway.saveAndExitPopUp());
                        f = 1;
                        obj_propertyAway.pageLoading();
                    } else {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_propertyAway.saveAndExit());
                        obj_propertyAway.pageLoading();
                        obj_generalInformation.executeScript("arguments[0].click();", obj_propertyAway.saveAndExitPopUp());
                        f = 1;
                        obj_propertyAway.pageLoading();
                        saveandExit();
                    }
                    break;
                case "Next":
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.nextButton());
                    obj_propertyAway.pageLoading();
                    break;
                case "PersonalBelongingHT":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_propertyAway.personalBelongHelpText());
                    strHelpText = "For instance, while you're visiting suppliers' premises, or at exhibitions or trade fairs.";
                    Assert.assertTrue("BedRoomHT is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                    break;
            }
        }
        if (f == 0) {
            obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.nextButton());
            obj_propertyAway.pageLoading();
        }
    }

    public void fillPropertyAwayScreenwithoutNext(String PAvalues) throws Throwable {
        int f = 0;//If save and Exit is used f value will ensure next won't click
        LinkedHashMap<String, String> PAvalue = new LinkedHashMap<String, String>();
        String[] peopleField = PAvalues.split("#");
        for (int a = 1; a <= peopleField.length; a++) {
            String[] peopleValues = peopleField[a - 1].split(";");
            PAvalue.put(peopleValues[0], peopleValues[1]);
        }
        List<String> peopleQuestions = new ArrayList<>(PAvalue.keySet());
        for (String questions : peopleQuestions) {
            switch (questions) {
                case "businessTools":
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.businessToolsEquipment(PAvalue.get(questions)));
                    obj_propertyAway.pageLoading();
                    break;
                case "toolsSumInsured":
                    obj_propertyAway.businessToolsEquipmentValueTextbox().sendKeys(PAvalue.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_propertyAway.pageLoading();
                    break;
                case "personalBelongings":
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureBelongings(PAvalue.get(questions)));
                    obj_propertyAway.pageLoading();
                    break;
                case "belongingsSumInsured":
                    obj_propertyAway.personalBelongingsTextbox().sendKeys(PAvalue.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_propertyAway.pageLoading();
                    break;
                case "stocks":
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureYourStock(PAvalue.get(questions)));
                    obj_propertyAway.pageLoading();
                    break;
                case "stocksSumInsured":
                    obj_propertyAway.stockAwayTextbox().sendKeys(PAvalue.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_propertyAway.pageLoading();
                    break;
                case "stocksAtTransit":
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureStocksAtTransit(PAvalue.get(questions)));
                    obj_propertyAway.pageLoading();
                    break;
                case "transitSumInsured":
                    obj_propertyAway.stockAtTransitTextbox().sendKeys(PAvalue.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_propertyAway.pageLoading();
                    break;
                case "contentAndStock":
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.businessToolsEquipment(PAvalue.get(questions)));
                    obj_propertyAway.pageLoading();
                    break;
                case "contentStockSumInsured":
                    obj_propertyAway.businessToolsEquipmentValueTextbox().sendKeys(PAvalue.get(questions));
                    obj_commonUtil.tabKeypress();
                    obj_propertyAway.pageLoading();
                    break;
                case "InsureAnyIndividualItem":
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureAnyIndividualItem(PAvalue.get(questions)));
                    obj_propertyAway.pageLoading();
                    break;
                case "Named Items":
                    String[] NamedItemValues = (PAvalue.get(questions)).split(":");
                    for (int j = 0; j < 1; j++) {
                        obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.propertyAwayAddItemRadiobutton());
                        obj_propertyAway.pageLoading();
                        obj_propertyAway.insureAnyIndividualPopupItemGroup().sendKeys(NamedItemValues[0]);
                        obj_propertyAway.pageLoading();
                        obj_propertyAway.insureAnyIndividualPopupTypeofItem().sendKeys(NamedItemValues[1]);
                        obj_propertyAway.pageLoading();
                        obj_propertyAway.insureAnyIndividualPopupItemValue().sendKeys(NamedItemValues[2]);
                        obj_propertyAway.pageLoading();
                        obj_propertyAway.insureAnyIndividualPopupDescribe().sendKeys(NamedItemValues[3]);
                        obj_propertyAway.pageLoading();
                        obj_propertyAway.insureAnyIndividualPopupAddItem().click();
                        obj_propertyAway.pageLoading();
                    }
                    break;
                case "AddItem":
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.propertyAwayAddItemRadiobutton());
                    obj_propertyAway.pageLoading();
                    break;
                case "ItemGroup":
                    obj_propertyAway.insureAnyIndividualPopupItemGroup().sendKeys(PAvalue.get(questions));
                    obj_propertyAway.pageLoading();
                    break;
                case "IndividualItem":
                    obj_propertyAway.insureAnyIndividualPopupTypeofItem().sendKeys(PAvalue.get(questions));
                    obj_propertyAway.pageLoading();
                    break;
                case "ItemValue":
                    obj_propertyAway.insureAnyIndividualPopupItemValue().sendKeys(PAvalue.get(questions));
                    obj_propertyAway.pageLoading();
                    break;
                case "ItemDesc":
                    obj_propertyAway.insureAnyIndividualPopupDescribe().sendKeys(PAvalue.get(questions));
                    obj_propertyAway.pageLoading();
                    break;
                case "AddItemPopup":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_propertyAway.insureAnyIndividualPopupAddItem());
                    obj_propertyAway.pageLoading();
                    break;
                case "AddAnotherItem":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_propertyAway.addAnotherItemButton());
                    obj_propertyAway.pageLoading();
                    break;

                case "SaveAndExit":
                    if ((PAvalue.get(questions)).equalsIgnoreCase("N")) {
                        obj_propertyAway.executeScript("arguments[0].click()", obj_propertyAway.saveAndExit());
                        obj_propertyAway.pageLoading();
                        obj_propertyAway.executeScript("arguments[0].click()", obj_propertyAway.saveAndExitPopUp());
                        f = 1;
                        obj_propertyAway.pageLoading();
                    } else {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_propertyAway.saveAndExit());
                        obj_propertyAway.pageLoading();
                        obj_generalInformation.executeScript("arguments[0].click();", obj_propertyAway.saveAndExitPopUp());
                        f = 1;
                        obj_propertyAway.pageLoading();
                        saveandExit();
                    }
                    break;
                case "Next":
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.nextButton());
                    obj_propertyAway.pageLoading();
                    break;
            }
        }
    }


    public void fillBusinessInterruption() {
        obj_businessInterruption.grossTurnOverDropDown().sendKeys("£25,001 - £50,000");
        obj_propertyAway.pageLoading();
        obj_businessInterruption.monthOfCoverDropDown().sendKeys("18");
        obj_propertyAway.pageLoading();
        obj_generalInformation.executeScript("arguments[0].click();", obj_businessInterruption.businessInterruptionNextButton());
        obj_propertyAway.pageLoading();
    }

    public void fillBIScreen(String valueBI) {
        LinkedHashMap<String, String> BIvalue = new LinkedHashMap<String, String>();
        String[] BIField = valueBI.split("#");
        for (int a = 1; a <= BIField.length; a++) {
            String[] BIValues = BIField[a - 1].split(";");
            BIvalue.put(BIValues[0], BIValues[1]);
        }
        List<String> BIQuestions = new ArrayList<>(BIvalue.keySet());
        for (String questions : BIQuestions) {
            switch (questions) {
                case "TurnoverLimit":
                    new Select(obj_businessInterruption.grossTurnOverDropDown()).selectByVisibleText(BIvalue.get(questions));
                    obj_generalInformation.pageLoading();
                    break;
                case "TurnoverAmount":
                    obj_businessInterruption.grossTurnOverTextbox().sendKeys(BIvalue.get(questions));
                    obj_generalInformation.pageLoading();
                    break;
                case "IndemnityPeriod":
                    new Select(obj_businessInterruption.monthOfCoverDropDown()).selectByVisibleText(BIvalue.get(questions));
                    obj_generalInformation.pageLoading();
                    break;
                case "Next":
                    obj_saveExit.executeScript("arguments[0].click();", obj_businessInterruption.businessInterruptionNextButton());
                    obj_generalInformation.pageLoading();
                    break;
                case "AddSalonButton":
                    businessInteruptionThirdParty.rentChair().click();
                    obj_generalInformation.pageLoading();
                    break;
                case "SalonName":
                    businessInteruptionThirdParty.nameOfSaloon().sendKeys(BIvalue.get(questions));
                    break;
                case "SalonPostcode":
                    businessInteruptionThirdParty.postcode().sendKeys(BIvalue.get(questions));
                    businessInteruptionThirdParty.addSaloon().click();
                    obj_generalInformation.pageLoading();
                    break;
                case "ThirdPartyNextButton":
                    businessInteruptionThirdParty.nextbutton().click();
                    obj_generalInformation.pageLoading();
                    break;
            }
        }
    }

    public void fillTheftOfTakings() {
        obj_theftOfTakings.theftOfTakingDropdown().sendKeys("£2,500");
        obj_propertyAway.pageLoading();
        obj_generalInformation.executeScript("arguments[0].click();", obj_theftOfTakings.nextButton());
        obj_propertyAway.pageLoading();
    }

    public void fillTheftOfTakings(String theftOfTakingValue) {
        obj_theftOfTakings.theftOfTakingDropdown().sendKeys(theftOfTakingValue);
        obj_propertyAway.pageLoading();
        obj_generalInformation.executeScript("arguments[0].click();", obj_theftOfTakings.nextButton());
        obj_propertyAway.pageLoading();
    }

    public void fillImportantStatementsSection() throws Exception {
        obj_impornantstatement.executeScript("arguments[0].click();", obj_impornantstatement.agreeRadiobutton());
        obj_generalInformation.pageLoading();
        obj_impornantstatement.executeScript("arguments[0].click();", obj_impornantstatement.importantStatNextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillImportantStatementsSectionWithSaveExit(String importantStatement) throws Throwable {
        LinkedHashMap<String, String> ImportantStatementElements = new LinkedHashMap<String, String>();
        String[] ImportantStatementField = importantStatement.split("#");
        for (int a = 1; a <= ImportantStatementField.length; a++) {
            String[] importantStatementValues = ImportantStatementField[a - 1].split(";");
            ImportantStatementElements.put(importantStatementValues[0], importantStatementValues[1]);
        }
        List<String> ImportantStatementQuestions = new ArrayList<>(ImportantStatementElements.keySet());
        for (String questions : ImportantStatementQuestions) {
            switch (questions) {
                case "Agree":
                    if (ImportantStatementElements.get(questions).equalsIgnoreCase("Y")) {
                        obj_impornantstatement.executeScript("arguments[0].click()", obj_impornantstatement.agreeRadiobutton());
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_impornantstatement.executeScript("arguments[0].click()", obj_impornantstatement.disAgreeRadiobutton());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "SaveExit":
                    if (ImportantStatementElements.get(questions).equalsIgnoreCase("WJ")) {
                        obj_impornantstatement.executeScript("arguments[0].click()", obj_impornantstatement.importantStatSaveExitButton());
                        obj_generalInformation.pageLoading();
                        obj_impornantstatement.executeScript("arguments[0].click()", obj_impornantstatement.importantStatSaveExitPopUpButton());
                        obj_generalInformation.pageLoading();
                        saveandExit();
                    } else {
                        obj_impornantstatement.executeScript("arguments[0].click()", obj_impornantstatement.importantStatSaveExitButton());
                        obj_generalInformation.pageLoading();
                        obj_impornantstatement.executeScript("arguments[0].click()", obj_impornantstatement.importantStatSaveExitPopUpButton());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "Next":
                    obj_impornantstatement.executeScript("arguments[0].click()", obj_impornantstatement.importantStatNextButton());
                    obj_generalInformation.pageLoading();
                    break;

            }
        }
    }

    public void fillImportantStatementsSection(String saveAndExit) throws Throwable {
        obj_impornantstatement.executeScript("arguments[0].click();", obj_impornantstatement.agreeRadiobutton());
        obj_generalInformation.pageLoading();
        if (saveAndExit.equalsIgnoreCase("N")) {
            obj_impornantstatement.executeScript("arguments[0].click()", obj_impornantstatement.importantStatSaveExitButton());
            obj_generalInformation.pageLoading();
            obj_impornantstatement.executeScript("arguments[0].click()", obj_impornantstatement.importantStatSaveExitPopUpButton());
            obj_generalInformation.pageLoading();
        } else {
            obj_impornantstatement.executeScript("arguments[0].click()", obj_impornantstatement.importantStatSaveExitButton());
            obj_generalInformation.pageLoading();
            obj_impornantstatement.executeScript("arguments[0].click()", obj_impornantstatement.importantStatSaveExitPopUpButton());
            obj_generalInformation.pageLoading();
            saveandExit();
        }
    }

    public void fillPreviousLossesSection() throws Exception {
        obj_claims.executeScript("arguments[0].click();", obj_claims.previousLossesNoRadiobutton());
        obj_generalInformation.pageLoading();
        obj_claims.executeScript("arguments[0].click();", obj_claims.getQuoteButton());
        obj_generalInformation.pageLoading();
    }

    public void fillPreviousLossesSection(String SaveAndExit, String Application) throws Throwable {
        obj_claims.executeScript("arguments[0].click();", obj_claims.previousLossesNoRadiobutton());
        obj_generalInformation.pageLoading();
        obj_claims.executeScript("arguments[0].click();", obj_claims.getQuoteButton());
        Thread.sleep(2000);
        if (SaveAndExit.equalsIgnoreCase("N")) {
            obj_quoteSummary.executeScript("arguments[0].click()", obj_quoteSummary.QuoteSummarySaveAndExit());
            obj_generalInformation.pageLoading();
        } else {
            obj_quoteSummary.executeScript("arguments[0].click()", obj_quoteSummary.QuoteSummarySaveAndExit());
            obj_generalInformation.pageLoading();
            saveandExit();
        }
    }

    public void fillYourBusinessWithDefaultValues(String hb) throws Throwable {
        if (hb.equalsIgnoreCase("hb")) {
            fillInsuranceWizard("TradeName;hb:Hairdresser#RunYourBusinessFrom;Mobile business#HaveEmployee;employee_no#Covers;none#Continue;Y ");
        } else {
            fillInsuranceWizard("TradeName;bb:Bed and Breakfa#LivePremises;Y#Employees;N#Covers;homebuilding:household#Continue;Y");
        }
        fillGeneralInformationSection(hb);
        fillPeopleInYourBusinessSection();
        fillLiabilityCoverSection();
        if (hb.equalsIgnoreCase("bb")) {
            fillPremiseSection("PostCode;AB106TA#BusinessPremiseAddress;271 Union Grove, Aberdeen#IsThisYourHome;Y#Accomodation;N#Alcohol;N#ApplyToYourBusiness;None#InsureAnyOutBuildings;N#MainBuildingBusinessContent;2000#MainBuildingHouseholdContent;100#MainBuildingUsedFor;Guest accommodation only#MainBuildingBedRoom;2#MainBuildingSelfCatering;N#BuildingType;Bungalow (Detached)#MainBuildingPremisegrade1;N#WallTimber;Y#Roofs;Y#MainBuildingFirePlace;heatone#SubsidenceCover;N#Next;Y", 1);
            fillPropertyAwayScreen("businessTools;N#personalBelongings;N");
        }
        fillImportantStatementsSection();
        fillPreviousLossesSection();
        fillYourQuoteSection();
        fillInterestedPartySection();
        fillcontactSection();
        fillPaymentSection();
        fillDirectDebitSection();
        fillPaymentInformationDetails();
        fillCardDetailsSection("Amex");
    }

    /* public void fillCardDetailsSection() throws Throwable {
         Thread.sleep(3000);
         obj_commonUtil.switchFrame("wp-cl-custom-html-iframe");
         obj_cardDetails.cardNumberTextbox().sendKeys("5555555555554444");
         obj_cardDetails.cardVerificationCodeTextbox().click();
         obj_cardDetails.cardVerificationCodeTextbox().sendKeys("123");
         obj_generalInformation.pageLoading();
         new Select(obj_cardDetails.cardExpiryMMDropdown()).selectByVisibleText("05");
         obj_generalInformation.pageLoading();
         new Select(obj_cardDetails.cardExpiryYYYYDropdown()).selectByVisibleText("2025");
         obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.sppContinueButton());
         obj_generalInformation.pageLoading();
         Thread.sleep(5000);
         policyNumber = obj_cardDetails.policyNumberFetch().getText();
     }*/
    public void fillCardDetailsSection(String cardType) throws Throwable {
        Thread.sleep(3000);
        obj_commonUtil.switchFrame("wp-cl-custom-html-iframe");
        if (cardType.equalsIgnoreCase("Visa")) {
            obj_cardDetails.cardNumberTextbox().sendKeys("4444333322221111");
            obj_generalInformation.pageLoading();
            new Select(obj_cardDetails.cardExpiryMMDropdown()).selectByVisibleText("05");
            obj_generalInformation.pageLoading();
            new Select(obj_cardDetails.cardExpiryYYYYDropdown()).selectByVisibleText("2025");
            obj_cardDetails.cardVerificationCodeTextbox().click();
            obj_cardDetails.cardVerificationCodeTextbox().sendKeys("123");
            obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.sppContinueButton());
            obj_generalInformation.pageLoading();
            Thread.sleep(5000);

        } else if (cardType.equalsIgnoreCase("Amex")) {
            obj_cardDetails.cardNumberTextbox().sendKeys("34343434343434");
            obj_cardDetails.cardVerificationCodeTextbox().click();
            Thread.sleep(3000);
            obj_cardDetails.cardVerificationCodeTextbox().sendKeys("1711");
            obj_generalInformation.pageLoading();
            new Select(obj_cardDetails.cardExpiryMMDropdown()).selectByVisibleText("05");
            obj_generalInformation.pageLoading();
            new Select(obj_cardDetails.cardExpiryYYYYDropdown()).selectByVisibleText("2025");
            obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.sppContinueButton());
            obj_generalInformation.pageLoading();
            Thread.sleep(5000);

        } else if (cardType.equalsIgnoreCase("Mastercard")) {
            obj_cardDetails.cardNumberTextbox().sendKeys("5555555555554444");
            obj_cardDetails.cardVerificationCodeTextbox().click();
            obj_cardDetails.cardVerificationCodeTextbox().sendKeys("123");
            obj_generalInformation.pageLoading();
            new Select(obj_cardDetails.cardExpiryMMDropdown()).selectByVisibleText("05");
            obj_generalInformation.pageLoading();
            new Select(obj_cardDetails.cardExpiryYYYYDropdown()).selectByVisibleText("2025");
            obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.sppContinueButton());
            obj_generalInformation.pageLoading();
            Thread.sleep(5000);

        } else if (cardType.equalsIgnoreCase("Maestro")) {
            obj_cardDetails.cardNumberTextbox().sendKeys("6759649826438453");
            obj_cardDetails.cardVerificationCodeTextbox().click();
            obj_cardDetails.cardVerificationCodeTextbox().sendKeys("123");
            obj_generalInformation.pageLoading();
            new Select(obj_cardDetails.cardExpiryMMDropdown()).selectByVisibleText("05");
            obj_generalInformation.pageLoading();
            new Select(obj_cardDetails.cardExpiryYYYYDropdown()).selectByVisibleText("2025");
            obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.sppContinueButton());
            obj_generalInformation.pageLoading();
            Thread.sleep(5000);
        }
        obj_commonUtil.switchFrameIfAvailable("sagepay");
        policyNumber = obj_cardDetails.policyNumberFetch().getText();
    }


    public void fillCardDetailsSectionVisa(String cardType) throws Throwable {
        Thread.sleep(3000);
        obj_commonUtil.switchFrame("wp-cl-custom-html-iframe");
        if (cardType.equalsIgnoreCase("Visa")) {
            obj_cardDetails.cardNumberTextbox().sendKeys("4444333322221111");
            Thread.sleep(2000);
            obj_generalInformation.pageLoading();
            new Select(obj_cardDetails.cardExpiryMMDropdown()).selectByVisibleText("05");
            obj_generalInformation.pageLoading();
            new Select(obj_cardDetails.cardExpiryYYYYDropdown()).selectByVisibleText("2025");
            obj_generalInformation.pageLoading();
            Thread.sleep(2000);
            obj_cardDetails.cardVerificationCodeTextbox().click();
            Thread.sleep(2000);
            obj_cardDetails.cardVerificationCodeTextbox().sendKeys("123");
            obj_generalInformation.pageLoading();
            Thread.sleep(2000);
            obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.sppContinueButton());
            obj_generalInformation.pageLoading();
            Thread.sleep(5000);

        }
    }


    public void fillPaymentInformationDetails() {
        obj_paymentInformation.cardBelongsToYesRadiobutton().click();
        obj_generalInformation.pageLoading();
        obj_paymentInformation.cardPermissionYesRadiobutton().click();
        obj_generalInformation.pageLoading();
        obj_paymentInformation.cardHolderNameTextbox().click();
        obj_paymentInformation.cardHolderNameTextbox().sendKeys("Smokecard");
        obj_generalInformation.pageLoading();
        obj_paymentInformation.billingAddressYesRadiobutton().click();
        obj_generalInformation.pageLoading();
        obj_paymentInformation.executeScript("arguments[0].click();", obj_paymentInformation.PaymentInfoNextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillDirectDebitSection() {
        obj_directDebit.directdebitYesRadiobutton().click();
        obj_generalInformation.pageLoading();
        obj_directDebit.sortCodeTextbox().click();
        obj_directDebit.sortCodeTextbox().sendKeys("090126");
        obj_generalInformation.pageLoading();
        obj_directDebit.accountNumberTextbox().click();
        obj_directDebit.accountNumberTextbox().sendKeys("02948723");
        obj_generalInformation.pageLoading();
        obj_directDebit.installmentdayTextbox().click();
        obj_directDebit.installmentdayTextbox().sendKeys("20");
        obj_generalInformation.pageLoading();
        obj_directDebit.executeScript("arguments[0].click();", obj_directDebit.paymentInformationNextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillPaymentSection() {
        obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.monthlyLink());
        obj_generalInformation.pageLoading();
        obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.acceptRadiobutton());
        obj_generalInformation.pageLoading();
        obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.renewRadiobutton());
        obj_generalInformation.pageLoading();
        obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.understoodRadiobutton());
        obj_generalInformation.pageLoading();
        obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.paymentScreenNextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillcontactSection() {
        obj_contacts.executeScript("arguments[0].click();", obj_contacts.makeChangesNoRadiobutton());
        obj_generalInformation.pageLoading();
        if (obj_postquote.contactNextButton1().get(0).isDisplayed()) {
            obj_postquote.contactNextButton().click();
            obj_generalInformation.pageLoading();
            //SeasonalStock
            new Select(obj_postquote.seasonalStockMonth1()).selectByVisibleText("May");
            obj_generalInformation.pageLoading();
            new Select(obj_postquote.seasonalStockMonth2()).selectByVisibleText("June");
            obj_generalInformation.pageLoading();
            obj_contacts.checkOutButton().click();
            obj_generalInformation.pageLoading();
        } else {
            obj_contacts.checkOutButton().click();
            obj_generalInformation.pageLoading();
        }
    }

    public void fillLiabilityCoverSectionUKOnly() throws Exception {
        new Select(obj_liabilitycover.public_LiabilitycoverDropdown()).selectByValue("1000000");
        obj_generalInformation.pageLoading();
        String strtext = obj_liabilitycover.productsOutsideukDropdownList().getText();
        if (strtext.trim().equalsIgnoreCase("No")) {
            new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("No");
        } else {
            new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("UK only");
        }
        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.liabilityCoverNextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillInterestedPartySection() {
        obj_interestedParty.executeScript("arguments[0].click();", obj_interestedParty.addPartyNoRadiobutton());
        obj_generalInformation.pageLoading();
        obj_interestedParty.executeScript("arguments[0].click();", obj_interestedParty.addPartyNextButton());
        obj_generalInformation.pageLoading();
    }

    public void yourQuoteRepopulate(String Application) throws Throwable {
        obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.reviewConfirmButton());
        Thread.sleep(3000);
        if (Application.equalsIgnoreCase("WJ")) {
            obj_createAccount.executeScript("arguments[0].click();", obj_createAccount.createAccountButton());
            obj_generalInformation.pageLoading();
            saveandExit();
        }
        obj_createAccount.executeScript("arguments[0].click();", obj_createAccount.createAccountNextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillYourQuoteSection() throws Throwable {
        obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.reviewConfirmButton());
        Thread.sleep(3000);
        if (obj_createAccount.createAccountButton().isDisplayed()) {
            obj_createAccount.executeScript("arguments[0].click();", obj_createAccount.createAccountButton());
            obj_generalInformation.pageLoading();
            saveandExit();
        }
        obj_createAccount.executeScript("arguments[0].click();", obj_createAccount.createAccountNextButton());
        obj_generalInformation.pageLoading();
    }

    public void saveandExit() throws NoSuchElementException {
        strEmail = createAccountUtil.randomemail();
//        System.out.println(strEmail);
        obj_generalInformation.pageLoading();
        obj_createAccount.contactEmailTextbox().sendKeys(strEmail);
        obj_commonUtil.tabKeypress();
        obj_generalInformation.pageLoading();
        obj_createAccount.confirmEmailTextbox().sendKeys(strEmail);
        obj_commonUtil.tabKeypress();
        obj_generalInformation.pageLoading();
        obj_createAccount.telephoneNumberTextbox().sendKeys("07584768389");
        obj_commonUtil.tabKeypress();
        obj_generalInformation.pageLoading();
        obj_createAccount.emailRadiobutton().click();
        obj_generalInformation.pageLoading();
        obj_createAccount.saveExitButton().click();
        obj_generalInformation.pageLoading();
    }

    public void fillCCCreateContact(String BusinessName) throws Throwable {
        if (!BusinessName.equalsIgnoreCase("null")) {
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.createNewCustomerButton());
            obj_generalInformation.pageLoading();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.corporateContact());
            obj_createCustomer.tradeNametextbox().sendKeys(BusinessName);
            new Select(obj_createCustomer.addressTypeButton()).selectByVisibleText("Business");
            new Select(obj_createCustomer.countryTextbox()).selectByVisibleText("Scotland");
            obj_generalInformation.pageLoading();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.postCodeTextbox());
            Thread.sleep(1000);
            obj_createCustomer.postCodeTextbox().sendKeys("E11DU");
            obj_generalInformation.pageLoading();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.findAddressButton());
            Select address = new Select(obj_createCustomer.selectAddressDropdown());
            List<WebElement> addressVal = address.getOptions();
            addressVal.get(0).click();
            obj_generalInformation.ccpageLoading();
            new Select(obj_createCustomer.titleContactDetailsDropdown()).selectByVisibleText("Mr");
            obj_generalInformation.pageLoading();
            strFirstName = obj_generalInformationUtil.randomFirstName();
            obj_createCustomer.firstnameContactDetailsTextbox().sendKeys(strFirstName);
            obj_generalInformation.pageLoading();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.lastnameContactDetailstextbox());
            obj_generalInformation.pageLoading();
            strSecondName = obj_generalInformationUtil.randomSecondName();
            obj_createCustomer.lastnameContactDetailstextbox().sendKeys(strSecondName);
            obj_generalInformation.pageLoading();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.mobileBusinessTextbox());
            obj_generalInformation.pageLoading();
            obj_createCustomer.authorisedContactMobile().sendKeys("07584768389");
            obj_commonUtil.tabKeypress();
            strEmail = createAccountUtil.randomemail();
            obj_createCustomer.authorisedContactEmail().sendKeys(strEmail);
            obj_commonUtil.tabKeypress();
            obj_createCustomer.mobileBusinessTextbox().sendKeys("07584768389");
            obj_generalInformation.pageLoading();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.emailBusinessTextbox());
            Thread.sleep(1000);
            obj_createCustomer.emailBusinessTextbox().sendKeys("abcd@gmail.com");
            obj_createCustomer.waitForPageLoad();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.marketingPreferenceNoRadiobutton());
            obj_generalInformation.pageLoading();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.correspondenceByMailRadiobutton());
            obj_generalInformation.pageLoading();
            obj_createCustomer.smsNotificationCheckbox().click();
            obj_generalInformation.pageLoading();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.saveButtonButton());
            Thread.sleep(2000);
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.newQuoteButton());
            obj_generalInformation.pageLoading();
            Thread.sleep(2000);
            obj_commonUtil.switchFrame("sagepay");
        }
    }

    public void fillPremiseSection(int iteration, String tradeName, String postCode, String addressType, String premiseType, String premisesOnlyOccupiped, String buildingOccupied, String haveATM, String applyToYourBusiness, String insureAnyOutbuilding, String yourBuildingAddCover, String yourBuildingValue, String businessContentAddCover, String businessContenValue, String stockAddCover, String stockValue, String buildingTypeValue, String propertyBuilt, String premiseGrade1, String walls, String wallsMade, String roofs, String openFirePlace, String outbuildingFirePlace, String outElectricHeater, String portableElectricHeater, String subsidenceCover) throws Exception {
        obj_generalInformation.pageLoading();
        obj_businessPremises.postCodetextbox(iteration).sendKeys(postCode);
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.findAddressButton(iteration));
        obj_generalInformation.pageLoading();
        new Select(obj_businessPremises.selectAddressDropdown(iteration)).selectByVisibleText(addressType);
        obj_generalInformation.pageLoading();
        if (tradeName.equalsIgnoreCase("H&B")) {
            new Select(obj_businessPremises.selectPremisesTypeDropdown(iteration)).selectByVisibleText(premiseType);
            obj_generalInformation.pageLoading();
            switch (premiseType) {
                case "home business":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.premisesOnlyOccupiped(premisesOnlyOccupiped, iteration));
                    obj_generalInformation.pageLoading();
                    break;
                case "commercial premises":
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.buildingOccupied(buildingOccupied, iteration));
                    obj_generalInformation.pageLoading();
                    new Select(obj_businessPremises.selectATM(iteration)).selectByVisibleText(haveATM);
            }
        }
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.applyToYpurBusiness(applyToYourBusiness, iteration));
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.insureAnyOutBuilding(insureAnyOutbuilding, iteration));
        obj_generalInformation.pageLoading();
        yourBuildingAddCover(iteration, yourBuildingAddCover, yourBuildingValue);
        obj_generalInformation.pageLoading();
        businessContentAddCover(iteration, businessContentAddCover, businessContenValue);
        obj_generalInformation.pageLoading();
        stockAddCover(iteration, stockAddCover, stockValue);
        obj_generalInformation.pageLoading();
        buildingTypeDropDown(iteration, buildingTypeValue);
        obj_generalInformation.pageLoading();
        propertyBuilt(iteration, propertyBuilt);
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.premiseGrade1(premiseGrade1, iteration));
        obj_generalInformation.pageLoading();
        wallsMadeTimber(walls, iteration);
        obj_generalInformation.pageLoading();
        isWallsMade(wallsMade, iteration);
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.roofs(roofs, iteration));
        obj_generalInformation.pageLoading();
        openFirePlace(openFirePlace, iteration);
        obj_generalInformation.pageLoading();
        outbuildingFirePlace(outbuildingFirePlace, iteration);
        obj_generalInformation.pageLoading();
        outbuildingElectricHeater(outElectricHeater, iteration);
        obj_generalInformation.pageLoading();
        portableElectricHeater(portableElectricHeater, iteration);
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.subsidenceCover(subsidenceCover, iteration));
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.nextButton());
        Thread.sleep(1000);
    }

    public void outbuildingElectricHeater(String outElectricHeater, int iteration) {
        if (!outElectricHeater.equalsIgnoreCase("null")) {
            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outbuildingElectricHeater(outElectricHeater, iteration));
        }
    }

    public void outbuildingFirePlace(String outbuildingFirePlace, int iteration) {
        if (!outbuildingFirePlace.equalsIgnoreCase("null")) {
            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outbuildingFirePlace(outbuildingFirePlace, iteration));
        }
    }

    public void premiseBBFunctionality(List<List<String>> data) throws Throwable {
        for (int i = 1; i < data.size(); i++) {
            obj_commonUtil.setValue(data.get(i), data.get(0), "PostCode", obj_businessPremises.postCodetextbox(i));
            obj_commonUtil.clickbyJS(obj_businessPremises.findAddressButton(i));
            obj_businessPremises.pageLoading();
            obj_commonUtil.selectElement(data.get(i), data.get(0), "SelectAddress", obj_businessPremises.selectAddressDropdown(i));
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.premisetype(data.get(i), data.get(0), "PremisesType", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.riskAddress(data.get(i), data.get(0), "IsthisAlsoYourHome", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.accomodation(data.get(i), data.get(0), "Accomodation", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.commercialSoleOccupancy(data.get(i), data.get(0), "SoleOccupancy", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.occupancyType(data, "OccupancyType");
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.soleControl(data, "SoleControl", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.alcoholLicense(data.get(i), data.get(0), "AlcoholLicense", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.applyToBusiness(data.get(i), data.get(0), "ApplySole", i);
            obj_businessPremises.pageLoading();
            obj_commonUtil.selectElement(data.get(i), data.get(0), "ATM", obj_businessPremises.selectATM(i));
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.outBuilding(data.get(i), data.get(0), "OutBuilding", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.commMainBuildingUsage(data.get(i), data.get(0), "Mainbuilding_BuildingUsage", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.outBuildingUsage(data.get(i), data.get(0), "Outbuilding_BuildingUsage", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.mainBuildingFreeFormat(data.get(i), data.get(0), "PleaseTellUsBuildingUsedFor", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.bedRoomMain(data.get(i), data.get(0), "MainBuilding_BedRoom", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.bedRoomNumberMain(data.get(i), data.get(0), "MainBuilding_BedRoomNumber", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.bedRoomOut(data.get(i), data.get(0), "OutBuilding_BedRoom", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.bedRoomNumberOut(data.get(i), data.get(0), "OutBuilding_BedRoomNumber", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.mainBuildingShopFitting(data, "MainBuilding_BuildingShopFitting", obj_businessPremises.yourBuildingValueTextbox(i), i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.mainBuildingShop(data, "MainBuilding_ShopFrontGlass", obj_businessPremises.buildingShopValueTextbox(i), i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.mainBuildingFitting(data, "MainBuilding_FixturesFitting", obj_businessPremises.buildingfittingValueTextbox(i), i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.mainBusinessContent(data.get(i), data.get(0), "MainBuilding_BusinessContentValue", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.mainStock(data.get(i), data.get(0), "MainBuilding_StockValue", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.WinesSpiritMain(data.get(i), data.get(0), "MainBuilding_StockWSValue", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.WinesSpiritOut(data.get(i), data.get(0), "OutBuilding_StockWSValue", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.mainHousehold(data.get(i), data.get(0), "MainBuilding_HouseholdContent", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.outBusinessContent(data.get(i), data.get(0), "OutBuilding_BusinessContentValue", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.selfCateringMain(data.get(i), data.get(0), "MainBuilding_SelfCatering", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.selfCateringOut(data.get(i), data.get(0), "OutBuilding_SelfCatering", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.outStock(data.get(i), data.get(0), "OutBuilding_StockValue", i);
            obj_businessPremises.pageLoading();
            obj_commonUtil.selectElement(data.get(i), data.get(0), "BuildingType", obj_businessPremises.buildingTypedDrodown(i));
            obj_businessPremises.pageLoading();
            obj_commonUtil.selectElement(data.get(i), data.get(0), "PropertyBuilt", obj_businessPremises.propertyBuiltDrodown(i));
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.premiseGrade(data.get(i), data.get(0), "PremiseGrade1", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.commWallMaterial(data.get(i), data.get(0), "Walls", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.wallMaterial(data.get(i), data.get(0), "WallsMade", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.commRoofMaterial(data.get(i), data.get(0), "Roofs", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.storageHeating(data.get(i), data.get(0), "heating", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.heating(data.get(i), data.get(0), "MainBuilding_FirePlace", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.commercialSecurityFeature(data.get(i), data.get(0), "SecurityFeature", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.burglarType(data.get(i), data.get(0), "BurglarType", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.underControl(data.get(i), data.get(0), "UnderControl", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.policeResponse(data.get(i), data.get(0), "PoliceResponse", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.maintenance(data.get(i), data.get(0), "Maintenance", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.outPremiseGrade(data.get(i), data.get(0), "OutBuilding_PremiseGrade1", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.outWallMaterial(data.get(i), data.get(0), "OutBuilding_Walls", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.outRoofMaterial(data.get(i), data.get(0), "OutBuilding_Roofs", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.firePlaceout(data.get(i), data.get(0), "OutBuilding_FirePlace", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.electricheaterout(data.get(i), data.get(0), "OutBuilding_ElectricHeater", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.subsidenceCover(data.get(i), data.get(0), "SubsidenceCover", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.addAnotherPremises(data.get(i), data.get(0), "AddAnotherPremise", i);
            obj_businessPremises.pageLoading();
            obj_businessPremisesUtil.next(data.get(i), data.get(0), "Next");
            obj_businessPremises.pageLoading();
        }
    }

    public void fillPropertyAwayFromPremise(String tradeName, String insureBusinessTools, String personalBelongings, String insureStocks, String insureStocksAtTransit, String insureContentAndStock, String sumInsured, String SaveExit) throws Throwable {
        if ((SaveExit.equalsIgnoreCase("No")) || (SaveExit.equalsIgnoreCase("null"))) {
            if ((tradeName.equalsIgnoreCase("HB")) || (tradeName.equalsIgnoreCase("H&B"))) {
                if (!insureBusinessTools.equalsIgnoreCase("null")) {
                    if (insureBusinessTools.equalsIgnoreCase("Y")) {
                        obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.businessToolsEquipmentYesRadiobutton());
                        obj_generalInformation.pageLoading();
                    } else if (insureBusinessTools.equalsIgnoreCase("N")) {
                        obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.businessToolsEquipmentNoRadiobutton());
                        obj_generalInformation.pageLoading();
                    }
                }
                if (!personalBelongings.equalsIgnoreCase("null")) {
                    if (personalBelongings.equalsIgnoreCase("Y")) {
                        obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.personalBelongingsYes());
                        obj_generalInformation.pageLoading();
                    } else if (personalBelongings.equalsIgnoreCase("N")) {
                        obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.personalBelongingsNo());
                        obj_generalInformation.pageLoading();
                    }
                }
                if (!insureStocks.equalsIgnoreCase("null")) {
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureYourStock(insureStocks));
                    obj_generalInformation.pageLoading();
                }
                if (!insureStocksAtTransit.equalsIgnoreCase("null")) {
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureStocksAtTransit(insureStocksAtTransit));
                    obj_generalInformation.pageLoading();
                }
            } else if ((tradeName.equalsIgnoreCase("B&B") || (tradeName.equalsIgnoreCase("BB")))) {
                if (!insureContentAndStock.equalsIgnoreCase("null")) {
                    if (insureContentAndStock.equalsIgnoreCase("Yes")) {
                        obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.contentAndStockYes());
                        obj_generalInformation.pageLoading();
                        obj_propertyAway.contentAndStockTextbox().sendKeys(sumInsured);
                        obj_generalInformation.pageLoading();
                    } else if (insureContentAndStock.equalsIgnoreCase("No")) {
                        obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.contentAndStockNo());
                    }
                }
                if (!insureBusinessTools.equalsIgnoreCase("null")) {
                    obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.businessToolsEquipment(insureBusinessTools));
                    obj_generalInformation.pageLoading();
                }
            }
            obj_propertyAway.nextButton().click();
            obj_generalInformation.pageLoading();
        } else {
            obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.saveAndExit());
            obj_generalInformation.pageLoading();
            obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.saveAndExitPopUp());
            obj_generalInformation.pageLoading();
            saveandExit();
        }
    }

    public void fillPropertyAwayFromPremiseHB(String insureBusinessTools, String toolsAmt, String insureStocks, String StockAmt, String insureStocksAtTransit, String TransitAmt, String InsureItem, String itemGroup, String itemType, String itemValue, String itemDesc, String personalBelongings, String belongingValue) throws Exception {
        if (!insureBusinessTools.equalsIgnoreCase("null")) {
            if (insureBusinessTools.equalsIgnoreCase("Yes")) {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.businessToolsEquipmentYesRadiobutton());
                obj_generalInformation.pageLoading();
                obj_propertyAway.businessToolsEquipmentValueTextbox().sendKeys(toolsAmt);
                obj_commonUtil.tabKeypress();
                obj_generalInformation.pageLoading();
            } else if (insureBusinessTools.equalsIgnoreCase("No")) {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.businessToolsEquipmentNoRadiobutton());
                obj_generalInformation.pageLoading();
            }
        }
        if (!insureStocks.equalsIgnoreCase("null")) {
            if (insureStocks.equalsIgnoreCase("Yes")) {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureYourStockYesRadiobutton());
                obj_generalInformation.pageLoading();
                obj_propertyAway.insureYourStockValueTextbox().sendKeys(StockAmt);
                obj_commonUtil.tabKeypress();
                obj_generalInformation.pageLoading();
            } else {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureYourStockNoRadiobutton());
                obj_generalInformation.pageLoading();
            }
        }
        if (!insureStocksAtTransit.equalsIgnoreCase("null")) {
            if (insureStocksAtTransit.equalsIgnoreCase("Yes")) {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.TransitViaThirdPartyYesRadiobutton());
                obj_generalInformation.pageLoading();
                obj_propertyAway.transitViaThirdPartyValueTextbox().sendKeys(TransitAmt);
                obj_commonUtil.tabKeypress();
                obj_generalInformation.pageLoading();
            } else {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.TransitViaThirdPartyNoRadiobutton());
                obj_generalInformation.pageLoading();
            }
        }
        if (!InsureItem.equalsIgnoreCase("null")) {
            if (InsureItem.equalsIgnoreCase("Yes")) {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureItemYesRadiobutton());
                obj_generalInformation.pageLoading();
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.propertyAwayAddItemRadiobutton());
                obj_generalInformation.pageLoading();
                new Select(obj_propertyAway.ItemGroup()).selectByVisibleText(itemGroup);
                obj_generalInformation.pageLoading();
                new Select(obj_propertyAway.ItemType()).selectByVisibleText(itemType);
                obj_generalInformation.pageLoading();
                obj_propertyAway.ItemValue().sendKeys(itemValue);
                obj_generalInformation.pageLoading();
                obj_propertyAway.ItemDesc().sendKeys(itemDesc);
                obj_generalInformation.pageLoading();
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.AddItem());
                obj_generalInformation.pageLoading();
            } else {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureItemNoRadiobutton());
                obj_generalInformation.pageLoading();
            }
        }
        if (!personalBelongings.equalsIgnoreCase("null")) {
            if (personalBelongings.equalsIgnoreCase("Yes")) {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.personalBelongingsYes());
                obj_generalInformation.pageLoading();
                obj_propertyAway.personalBelongingValueTextbox().sendKeys(belongingValue);
                obj_commonUtil.tabKeypress();
                obj_generalInformation.pageLoading();
            } else if (personalBelongings.equalsIgnoreCase("No")) {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.personalBelongingsNo());
                obj_generalInformation.pageLoading();
            }
        }
        obj_generalInformation.pageLoading();
        obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void propertyBuilt(int iteration, String propertyBuilt) {
        if (!propertyBuilt.equalsIgnoreCase("null")) {
            new Select(obj_businessPremises.propertyBuiltDrodown(iteration)).selectByVisibleText(propertyBuilt);
        }
    }

    public void openFirePlace(String openFirePlace, int iteration) {
        if (!openFirePlace.equalsIgnoreCase("null")) {
            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.portableElectricHeater(openFirePlace, iteration));
        }
    }

    public void portableElectricHeater(String portableElectricHeater, int iteration) {
        if (!portableElectricHeater.equalsIgnoreCase("null")) {
            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.portableElectricHeater(portableElectricHeater, iteration));
        }
    }

    public void isWallsMade(String wallsMade, int iteration) {
        if (!wallsMade.equalsIgnoreCase("null")) {
            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.wallsMade(wallsMade, iteration));
            obj_generalInformation.pageLoading();
        }
    }

    public void wallsMadeTimber(String walls, int iteration) {
        if (!walls.equalsIgnoreCase("null")) {
            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.walls(walls, iteration));
            obj_generalInformation.pageLoading();
        }
    }

    public void buildingTypeDropDown(int iteration, String buildingTypeValue) {
        if (!buildingTypeValue.equalsIgnoreCase("null")) {
            new Select(obj_businessPremises.buildingTypedDrodown(iteration)).selectByVisibleText(buildingTypeValue);
            obj_generalInformation.pageLoading();
        }
    }

    public void stockAddCover(int iteration, String stockAddCover, String stockValue) {
        if (!stockAddCover.equalsIgnoreCase("null")) {
            if (obj_businessPremises.stockAddCoverLink(iteration).isDisplayed()) {
                obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.stockAddCoverLink(iteration));
                obj_businessPremises.pageLoading();
            }
            obj_businessPremises.stockValueTextboxVal(iteration).sendKeys(stockValue);
            obj_businessPremises.pageLoading();
        } else {
            if (obj_businessPremises.stockValueRemovebutton(iteration).isDisplayed()) {
                obj_businessPremises.stockValueRemovebutton(iteration).click();
            }
        }
    }

    public void yourBuildingAddCover(int iteration, String addCover, String yourBuildingValue) throws Exception {
        if (!addCover.equalsIgnoreCase("null")) {
            if (addCover.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.yourBuildingAddCoverLink(iteration));
                obj_businessPremises.pageLoading();
                obj_businessPremises.yourBuildingValueTextbox(iteration).sendKeys(yourBuildingValue);
                obj_commonUtil.tabKeypress();
                obj_businessPremises.pageLoading();
            } else {
                obj_businessPremises.yourBuildingValueTextbox(iteration).sendKeys(yourBuildingValue);
            }
        }
    }

    public void businessContentAddCover(int iteration, String businessContentAddCover, String businessContenValue) throws Exception {
        if (!businessContentAddCover.equalsIgnoreCase("null")) {
            if (businessContentAddCover.equalsIgnoreCase("Yes")) {
                obj_businessPremises.businessContentAddCoverLink(iteration).click();
                obj_businessPremises.pageLoading();
                obj_businessPremises.businessContentValueTextbox(iteration).sendKeys(businessContenValue);
                obj_commonUtil.tabKeypress();
                obj_businessPremises.pageLoading();
            } else {
                obj_businessPremises.businessContentValueTextbox(iteration).sendKeys(businessContenValue);
            }
        }
    }

    public void fillBISection() throws Exception {
        new Select(obj_businessInterruption.grossTurnOverDropDown()).selectByVisibleText("£25,001 - £50,000");
        obj_generalInformation.pageLoading();
        new Select(obj_businessInterruption.monthOfCoverDropDown()).selectByVisibleText("12");
        obj_generalInformation.pageLoading();
        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.businessInterruptionNextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillBISectionValue() throws Exception {
        new Select(obj_businessInterruption.grossTurnOverDropDown()).selectByVisibleText("£75,001 - £100,000");
        obj_generalInformation.pageLoading();
        new Select(obj_businessInterruption.monthOfCoverDropDown()).selectByVisibleText("6");
        obj_generalInformation.pageLoading();
        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.businessInterruptionNextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillBISectionValue1() throws Exception {
        new Select(obj_businessInterruption.grossTurnOverDropDown()).selectByVisibleText("£50,001 - £75,000");
        obj_generalInformation.pageLoading();
        new Select(obj_businessInterruption.monthOfCoverDropDown()).selectByVisibleText("18");
        obj_generalInformation.pageLoading();
        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.businessInterruptionNextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillBISectionValue2() throws Exception {
        new Select(obj_businessInterruption.grossTurnOverDropDown()).selectByVisibleText("£150,001 - £200,000");
        obj_generalInformation.pageLoading();
        new Select(obj_businessInterruption.monthOfCoverDropDown()).selectByVisibleText("24");
        obj_generalInformation.pageLoading();
        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.businessInterruptionNextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillTOTSection() throws Exception {
        String pound = "£";
        String valTOT = pound.concat("2,500");
        new Select(obj_theftOfTakings.theftOfTakingDropdown()).selectByVisibleText(valTOT);
        obj_generalInformation.pageLoading();
        obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.nextButton());
        obj_generalInformation.pageLoading();
    }


    public void fillTOTSection1() throws Exception {
        String pound = "£";
        String valTOT = pound.concat("1,000");
        new Select(obj_theftOfTakings.theftOfTakingDropdown()).selectByVisibleText(valTOT);
        obj_generalInformation.pageLoading();
        obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void premiseNext() {
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.nextButton());
        obj_businessPremises.pageLoading();
    }

    public void UserchecksAutoPopulatedTrade(String tradeWord) {
        obj_coverwizard.wizardTradeNameTextBox().sendKeys(tradeWord);
        obj_generalInformation.pageLoading();
        String strList = obj_coverwizard.wizardTradeList().getText();
        if (strList.contains("Hair and beauty therapist\nHairdresser")) {
            Assert.assertTrue("Correct  trade  displayed", true);
        } else if (!strList.contains("Hair and beauty therapist\nHairdresser")) {
            Assert.assertTrue(false);
        }
        obj_coverwizard.tradeNameTextbox().clear();
    }

    public void UserchecksCoverList() {
        int size = obj_coverwizard.CoverList().size();
        for (int i = 0; i < size; i++) {
            String strList = obj_coverwizard.CoverList().get(i).getText();
            if (strList.contains("Hair and beauty treatments liability") || strList.contains("Business Stock") || strList.contains("Theft of takings") || strList.contains("Business Interruption") || strList.contains("Business tools and equipment") || strList.contains("None")) {
                Assert.assertTrue("Correct  covers  displayed", true);
            } else {
                Assert.assertTrue(false);
            }
        }
    }

    public void yourDetails() {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.YourDetailsNext());
        obj_generalInformation.pageLoading();
    }

    public void employersLiabilityRepopulate() throws Exception {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.ExemptERM());
        obj_generalInformation.pageLoading();
        obj_postquote.ERMnum().sendKeys("123/a234");
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.ELNext());
        obj_generalInformation.pageLoading();
    }

    public void employersLiability() throws Exception {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.businessaAddressNoButton());
        obj_generalInformation.postcodeTextbox().sendKeys("AB10 1AH");
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
        Thread.sleep(3000);
        new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByValue("1");
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.ExemptERM());
        obj_generalInformation.pageLoading();
        obj_postquote.ERMnum().sendKeys("123/a234");
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.ELNext());
        obj_generalInformation.pageLoading();
    }

    public void intrestedParties() {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.InterestedPartyNoButton());
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.InterestedPartyNext());
        obj_generalInformation.pageLoading();
    }

    public void intrestedPartiesSaveAndExit() {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.InterestedPartyNoButton());
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.saveExitContact());
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.saveExitPopUpButtonContact());
        obj_generalInformation.pageLoading();
    }

    public void contacts() {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.ContactsNoButton());
        obj_generalInformation.pageLoading();
        if (obj_postquote.Contactsnextbutton().isDisplayed()) {
            obj_postquote.executeScript("arguments[0].click();", obj_postquote.Contactsnextbutton());
            obj_generalInformation.pageLoading();
        }
        obj_postquote.executeScript("arguments[0].click()", obj_postquote.checkOutButton());
    }

    public void contactsSaveAndExit() {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.ContactsNoButton());
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.saveExitContact());
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.saveExitPopUpButtonContact());
        obj_generalInformation.pageLoading();
    }

    public void checkOut() {
        obj_generalInformation.pageLoading();
        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.checkOutButton());
        obj_generalInformation.pageLoading();
    }

    public void partners() throws Exception {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.addpartner());
        obj_generalInformation.pageLoading();
        String Str1 = obj_generalInformationUtil.randomFirstName();
        new Select(obj_postquote.partnerTitle()).selectByVisibleText("Mr");
        obj_commonUtil.tabKeypress();
        obj_postquote.partnerFirstName().sendKeys(Str1);
        obj_commonUtil.tabKeypress();
        obj_postquote.partnerLastName().sendKeys(Str1);
        obj_commonUtil.tabKeypress();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.partnerAddButton());
        obj_generalInformation.pageLoading();
        for (int i = 1; i < 10; i++) {
            if (obj_postquote.partnerAddAnotherPartnerButton().isDisplayed()) {
                String Str2 = obj_generalInformationUtil.randomFirstName();
                obj_postquote.executeScript("arguments[0].click();", obj_postquote.partnerAddAnotherPartnerButton());
                obj_generalInformation.pageLoading();
                new Select(obj_postquote.partnerTitle()).selectByVisibleText("Mr");
                obj_commonUtil.tabKeypress();
                obj_postquote.partnerFirstName().sendKeys(Str2);
                obj_commonUtil.tabKeypress();
                obj_postquote.partnerLastName().sendKeys(Str2);
                obj_commonUtil.tabKeypress();
                obj_postquote.executeScript("arguments[0].click();", obj_postquote.partnerAddButton());
                obj_generalInformation.pageLoading();
            }
        }
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.partnernextButton());
        obj_generalInformation.pageLoading();
    }

    public void searchPolicy() throws Throwable {
        ccSearch.policyNumberTextbox().sendKeys(policyNumber);
        ccSearch.executeScript("arguments[0].click();", ccSearch.searchButton());
        ccSearch.ccPageLoad();
        ccSearch.policySelectionLink().click();
        ccSearch.ccPageLoad();
        ccSearch.authorizContanctselectionLink().click();
        ccSearch.ccPageLoad();
    }

    public void searchPolicy(String policyNo) throws Throwable {
        ccSearch.policyNumberTextbox().sendKeys(policyNo);
        ccSearch.executeScript("arguments[0].click();", ccSearch.searchButton());
        ccSearch.ccPageLoad();
        ccSearch.policySelectionLink().click();
        ccSearch.ccPageLoad();
        ccSearch.authorizContanctselectionLink().click();
        ccSearch.ccPageLoad();
        Thread.sleep(2000);
        if (obj_notes.passVerf().isDisplayed()) {
            obj_notes.executeScript("arguments[0].click();", obj_notes.passVerf());
        }
    }


    public void searchPolicyWithOtherFields(String name) throws Throwable {
        if (name.equalsIgnoreCase("businessName")) {
            obj_coverwizard.searchbusinessTextbox().sendKeys(strBusinessName);
        } else if (name.equalsIgnoreCase("firstName") || name.equalsIgnoreCase("lastName")) {
            ccSearch.ccSearchFirstName().sendKeys(strFirstName);
            ccSearch.ccSearchLastName().sendKeys(strSecondName);
        }

        ccSearch.executeScript("arguments[0].click();", ccSearch.searchButton());
        ccSearch.ccPageLoad();
        ccSearch.policySelectionLink().click();
        ccSearch.ccPageLoad();
        ccSearch.authorizContanctselectionLink().click();
        ccSearch.ccPageLoad();

    }


    public void passwordSetEmailOption() throws Throwable {
        ccSearch.passedVerificaitionButton().click();
        ccSearch.ccPageLoad();
        ccSearch.executeScript("arguments[0].click()", ccSearch.documentsLinkclick());
        ccSearch.ccPageLoad();
        ccsearchUtil.passwordSetEmailSelection();
        obj_ss_login.emailAddressTextbox().sendKeys(strEmail);
        obj_commonUtil.tabKeypress();
        obj_ss_login.newPasswordTextbox().sendKeys("Lolipop@123");
        obj_commonUtil.tabKeypress();
        obj_ss_login.confirmPasswordTextbox().sendKeys("Lolipop@123");
        obj_ss_login.emailSignInButton().click();
        ccSearch.ccPageLoad();
    }

    public void passwordSetEmailOption(String Application) throws Throwable {
        ccSearch.passedVerificaitionButton().click();
        ccSearch.ccPageLoad();
        ccSearch.executeScript("arguments[0].click()", ccSearch.documentsLinkclick());
        ccSearch.ccPageLoad();
        if (Application.equalsIgnoreCase("CC")) {
            obj_createCustomer.executeScript("arguments[0].click()", obj_createCustomer.manageUserAccount());
            ccSearch.ccPageLoad();
            obj_createCustomer.executeScript("arguments[0].click()", obj_createCustomer.createUserAccount());
            ccSearch.ccPageLoad();
            obj_createCustomer.executeScript("arguments[0].click()", obj_createCustomer.manageUserAccountCancelButton());
            ccSearch.ccPageLoad();
            ccSearch.executeScript("arguments[0].click()", ccSearch.documentsLinkclick());
            ccSearch.ccPageLoad();
        }
        ccsearchUtil.passwordSetEmailSelection();
        obj_ss_login.emailAddressTextbox().sendKeys(strEmail);
        obj_commonUtil.tabKeypress();
        obj_ss_login.newPasswordTextbox().sendKeys("Lolipop@123");
        obj_commonUtil.tabKeypress();
        obj_ss_login.confirmPasswordTextbox().sendKeys("Lolipop@123");
        obj_ss_login.emailSignInButton().click();
        ccSearch.ccPageLoad();
        obj_ss_login.executeScript("arguments[0].click()", obj_ss_login.continueQuote());
        ccSearch.ccPageLoad();
    }

    public void goBackAndEditTheQuote() {
        obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.goBackAndEditTheQuote());
        obj_generalInformation.pageLoading();
        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.liabilityCoverNextButton());
        obj_generalInformation.pageLoading();
        obj_treatments.executeScript("arguments[0].click();", obj_treatments.nextButton());
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.nextButton());
        obj_generalInformation.pageLoading();
        obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.nextButton());
        obj_generalInformation.pageLoading();
        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.businessInterruptionNextButton());
        obj_generalInformation.pageLoading();
        obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.nextButton());
        obj_generalInformation.pageLoading();
        obj_impornantstatement.executeScript("arguments[0].click();", obj_impornantstatement.importantStatNextButton());
        obj_generalInformation.pageLoading();
    }

    public void ccfillLiabilityCoverSection(String strSave) throws Exception {
        new Select(obj_liabilitycover.public_LiabilitycoverDropdown()).selectByValue("1000000");
        String strtext = obj_liabilitycover.productsOutsideukDropdownList().getText();
        if (strtext.trim().equalsIgnoreCase("No")) {
            new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("No");
        } else {
            new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("UK only");
        }
        if (!strSave.equalsIgnoreCase("")) {
            obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.saveExitButton());
            obj_generalInformation.pageLoading();
        } else {
            obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.liabilityCoverNextButton());
            obj_generalInformation.pageLoading();
        }
    }

    public void searchPolicyEditQuote() throws Throwable {
        ccSearch.ccSearchFirstName().sendKeys(strFirstName);
        ccSearch.ccSearchLastName().sendKeys(strSecondName);
        ccSearch.executeScript("arguments[0].click();", ccSearch.searchButton());
        ccSearch.ccPageLoad();
        ccSearch.policySelectionLink().click();
        ccSearch.ccPageLoad();
        ccSearch.authorizContanctselectionLink().click();
        ccSearch.ccPageLoad();
    }

    public void searchPolicyEditQuote(String FirstName, String LastName) throws Throwable {
        ccSearch.ccSearchFirstName().sendKeys(FirstName);
        ccSearch.ccSearchLastName().sendKeys(LastName);
        ccSearch.executeScript("arguments[0].click();", ccSearch.searchButton());
        ccSearch.ccPageLoad();
        ccSearch.policySelectionLink().click();
        ccSearch.ccPageLoad();
        ccSearch.authorizContanctselectionLink().click();
        ccSearch.ccPageLoad();
        ccSearch.verifyButton().click();
        ccSearch.ccPageLoad();
    }

    public void editQuote() throws Throwable {
        ccSearch.passedVerificaitionButton().click();
        ccSearch.ccPageLoad();
        ccSearch.ManagequoteButton().click();
        ccSearch.editButton().click();
        ccSearch.ccPageLoad();
    }

    public void saveandExit(String screen, String application) throws Throwable {
        if (application.equalsIgnoreCase("WJ")) {
            switch (screen) {
                case "People":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonImportantStatements());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopupPeople());
                    obj_generalInformation.pageLoading();
                    saveandExit();
                    obj_generalInformation.pageLoading();
                    break;
                case "Liability":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonImportantStatements());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopup());
                    obj_generalInformation.pageLoading();
                    saveandExit();
                    obj_generalInformation.pageLoading();
                    break;
                case "Treatment":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonTreatment());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopup());
                    obj_generalInformation.pageLoading();
                    saveandExit();
                    obj_generalInformation.pageLoading();
                    break;
                case "Premises":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonPremises());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopup());
                    obj_generalInformation.pageLoading();
                    saveandExit();
                    obj_generalInformation.pageLoading();
                    break;
                case "PropertyAway":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonPropertyAway());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopup());
                    obj_generalInformation.pageLoading();
                    saveandExit();
                    obj_generalInformation.pageLoading();
                    break;
                case "ImportantStatement":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonImportantStatements());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopup());
                    obj_generalInformation.pageLoading();
                    saveandExit();
                    obj_generalInformation.pageLoading();
                    break;
                case "Claims":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonImportantStatements());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonImportantStatements());
                    obj_generalInformation.pageLoading();
                    saveandExit();
                    obj_generalInformation.pageLoading();
                    break;
                case "PostQuote":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonPostQuote());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopupPostQuote());
                    obj_generalInformation.pageLoading();
                    break;
            }
        } else if (application.equalsIgnoreCase("CC")) {
            switch (screen) {
                case "PostQuote":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonPostQuote());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopupPostQuoteSS());
                    obj_generalInformation.pageLoading();
                    break;
            }
        } else {
            obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonImportantStatements());
            obj_generalInformation.pageLoading();
            obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopup());
            obj_generalInformation.pageLoading();
        }
    }

    public void trdeSelectQuesHB(String tradeWord) throws Exception {
        obj_coverwizard.tradeNameTextbox().sendKeys(tradeWord);
        obj_generalInformation.pageLoading();
        String strList = obj_coverwizard.TradeList().getText();
        if (strList.contains("Hair and beauty therapist\nHairdresser")) {
            Assert.assertTrue("Correct  trade  displayed", true);
        } else if (!strList.contains("Hair and beauty therapist\nHairdresser")) {
            Assert.assertTrue(false);
        }
        obj_coverwizard.tradeNameTextbox().clear();
    }

    public void fillInsuranceWizard(String CoverWizard) {
        HashMap<String, String> CoverWizardElements = new LinkedHashMap<String, String>();
        String[] CoverWizardFields = CoverWizard.split("#");
        for (int i = 1; i <= CoverWizardFields.length; i++) {
            String[] CoverWizardValues = CoverWizardFields[i - 1].split(";");
            CoverWizardElements.put(CoverWizardValues[0], CoverWizardValues[1]);
        }

        List<String> CoverWizardQuestions = new ArrayList<>(CoverWizardElements.keySet());
        for (String CoverWizardQuestion : CoverWizardQuestions) {
            switch (CoverWizardQuestion) {
                case "TradeName":
                    String[] strTradeType = CoverWizardElements.get(CoverWizardQuestion).split(":");
                    obj_coverwizard.wizardTradeNameTextBox().sendKeys(strTradeType[1]);
                    obj_coverwizard.wizardTradeList().click();
                    break;
                case "SellYourProducts":
                    String[] sellYourProducts = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < sellYourProducts.length; i++) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardSellYourProductsCheckBox(sellYourProducts[i]));
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.WizardSellYourProductsNext());
                    obj_generalInformation.pageLoading();
                    break;
                case "RunYourProductFrom":
                    String[] strRunYourProductFrom = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < strRunYourProductFrom.length; i++) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardRunYourProductFromCheckBox(strRunYourProductFrom[i]));
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardRunYourProductFromNext());
                    obj_generalInformation.pageLoading();
                    break;
                case "RunYourBusinessFrom":
                    String[] businessFromCheckbox = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < businessFromCheckbox.length; i++) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardBusinessFromCheckbox(businessFromCheckbox[i]));
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardRunYourProductFromNext());
                    obj_generalInformation.pageLoading();
                    break;
                case "HaveEmployee":
                    String[] haveEmployees = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < haveEmployees.length; i++) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardHaveEmployeesButton(haveEmployees[i]));
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "EmployersLiability":
                    if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Y")) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardEmployersLiabilityCoverYesRadiobutton());
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardEmployersLiabilityCoverNoRadiobutton());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "LivePremises":
                    if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Y")) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardIsThisAlsoYourHomeYesRadioButton());
                    } else {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardIsThisAlsoYourHomeNoRadioButton());
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardRunYourProductFromNext());
                    break;

                case "Employees":
                    if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Y")) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardBBHaveEmpYesRadioButton());
                    } else {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardBBHaveEmpNoRadioButton());
                    }
                    break;
                case "Covers":
                    String[] covers = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < covers.length; i++) {
                        obj_generalInformation.pageLoading();
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardCovers(covers[i]));
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "Continue":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardContinueButton());
                    break;
            }
        }
    }

    public void insuranceWizardValidation(String CoverWizard) {
        HashMap<String, String> CoverWizardElements = new LinkedHashMap<String, String>();
        String[] CoverWizardFields = CoverWizard.split("#");
        for (int i = 1; i <= CoverWizardFields.length; i++) {
            String[] CoverWizardValues = CoverWizardFields[i - 1].split(";");
            CoverWizardElements.put(CoverWizardValues[0], CoverWizardValues[1]);
        }
        String[] strTradeType = new String[0];
        List<String> CoverWizardQuestions = new ArrayList<>(CoverWizardElements.keySet());
        for (String CoverWizardQuestion : CoverWizardQuestions) {
            switch (CoverWizardQuestion) {
                case "TradeName":
                    strTradeType = CoverWizardElements.get(CoverWizardQuestion).split(":");
                    Assert.assertTrue(obj_coverwizard.wizardCoverBasketEmpty().getText(), true);
                    obj_coverwizard.wizardTradeNameTextBox().sendKeys(strTradeType[1]);
                    obj_coverwizard.wizardTradeList().click();
                    obj_generalInformation.pageLoading();
//                    String strList = obj_coverwizard.TradeList().getText();//Need to check for Wizard
//                    if (strList.contains("Beauty therapist\nButcher\nClothing Retail\nHair and beauty therapist\nHairdresser\nNail technician")) {
//                        Assert.assertTrue("H&B Trade displayed", true);
//                    } else if (strList.contains("Guest House\nHotel")) {
//                        Assert.assertTrue("B&B Trade displayed", true);
//                    }
//                    obj_coverwizard.TradeList().click();//Need to check for Wizard
//                    Assert.assertTrue(obj_coverwizard.wizardCoverBasketArrow().isDisplayed());
//                    Assert.assertTrue(obj_coverwizard.wizardCoverBasketRedBox().isDisplayed());
                    if (strTradeType[0].equalsIgnoreCase("Retail") || strTradeType[0].equalsIgnoreCase("hb") || strTradeType[0].equalsIgnoreCase("bb")) {
                        String strPLText = "Public and Products Liability";
                        String strPL = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_coverwizard.wizardCoverBasketPL());
                        Assert.assertTrue(strPL + "is displayed", strPLText.equalsIgnoreCase(strPL));
                    } else if (strTradeType[0].equalsIgnoreCase("bb")) {
                        String strGEText = "Guest effects";
                        String strGE = ((String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_coverwizard.wizardCoverBasketGE())).trim();
                        Assert.assertTrue(strGE + "is displayed", strGEText.equalsIgnoreCase(strGE));
                    }
                    break;
                case "SellYourProducts":
                    String[] sellYourProducts = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < sellYourProducts.length; i++) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardSellYourProductsCheckBox(sellYourProducts[i]));
                    }
//                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.WizardSellYourProductsNext());
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardRunYourProductFromNext());
                    obj_generalInformation.pageLoading();
                    break;
                case "RunYourProductFrom":
                    String[] strRunYourProductFrom = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < strRunYourProductFrom.length; i++) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardRunYourProductFromCheckBox(strRunYourProductFrom[i]));
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardRunYourProductFromNext());
                    obj_generalInformation.pageLoading();
                    break;
                case "RunYourBusinessFrom":
                    String[] businessFromCheckbox = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < businessFromCheckbox.length; i++) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardBusinessFromCheckbox(businessFromCheckbox[i]));
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardRunYourProductFromNext());
                    obj_generalInformation.pageLoading();
                    break;
                case "HaveEmployee":
                    String[] haveEmployees = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < haveEmployees.length; i++) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardHaveEmployeesButton(haveEmployees[i]));
                    }
                    break;
                case "EmployersLiability":
                    if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Y")) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardEmployersLiabilityCoverYesRadiobutton());
                        Assert.assertTrue(obj_coverwizard.wizardCoverBasketEL().isDisplayed());
                    } else {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardEmployersLiabilityCoverNoRadiobutton());
                        Assert.assertFalse(obj_coverwizard.wizardCoverBasketEL().isDisplayed());
                    }
                    break;
                case "LivePremises":
                    if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Y")) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardIsThisAlsoYourHomeYesRadioButton());
                    } else {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardIsThisAlsoYourHomeNoRadioButton());
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardRunYourProductFromNext());
                    break;

                case "Employees":
                    if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Y")) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardBBHaveEmpYesRadioButton());
                    } else {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardBBHaveEmpNoRadioButton());
                    }
                    break;
                case "Covers":
                    String[] covers = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < covers.length; i++) {
                        obj_generalInformation.pageLoading();
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardCovers(covers[i]));
                        if (covers[i].equalsIgnoreCase("homebuilding")) {
                            strCovers = "homebuilding_basket";
                        } else if (covers[i].equalsIgnoreCase("household")) {
                            strCovers = "household_basket";
                        } else if (covers[i].equalsIgnoreCase("bi")) {
                            strCovers = "bi_basket";
                        } else if (covers[i].equalsIgnoreCase("tot")) {
                            strCovers = "tot_basket";
                        } else if (covers[i].equalsIgnoreCase("legal_exp")) {
                            strCovers = "legal_exp_basket";
                        } else if (covers[i].equalsIgnoreCase("salonbuild")) {
                            strCovers = "salonbuild_basket";
                        } else if (covers[i].equalsIgnoreCase("trt")) {
                            strCovers = "trt_basket";
                        } else if (covers[i].equalsIgnoreCase("stock")) {
                            strCovers = "stock_basket";
                        } else if (covers[i].equalsIgnoreCase("business_tools_equ")) {
                            strCovers = "business_tools_equ_basket";
                        } else if (covers[i].equalsIgnoreCase("business_cont")) {
                            strCovers = "business_cont_basket";
                        }
                        if (!covers[i].equalsIgnoreCase("none")) {
                            Assert.assertTrue(obj_coverwizard.wizardCoverBasketCovers(strCovers).isDisplayed());
                            if ((!strTradeType[0].equalsIgnoreCase("Retail")) && (!strTradeType[0].equalsIgnoreCase("Consultant"))) {
                                HelpTextValidation(strCovers);
                            }
                        }
                    }
                    break;
                case "CoversDeselect":
                    String[] coversDeselect = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < coversDeselect.length; i++) {
                        obj_generalInformation.pageLoading();
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardCovers(coversDeselect[i]));
                        if (coversDeselect[i].equalsIgnoreCase("homebuilding")) {
                            strCovers = "homebuilding_basket";
                        } else if (coversDeselect[i].equalsIgnoreCase("household")) {
                            strCovers = "household_basket";
                        } else if (coversDeselect[i].equalsIgnoreCase("bi")) {
                            strCovers = "bi_basket";
                        } else if (coversDeselect[i].equalsIgnoreCase("tot")) {
                            strCovers = "tot_basket";
                        } else if (coversDeselect[i].equalsIgnoreCase("legal_exp")) {
                            strCovers = "legal_exp_basket";
                        } else if (coversDeselect[i].equalsIgnoreCase("salonbuild")) {
                            strCovers = "salonbuild_basket";
                        } else if (coversDeselect[i].equalsIgnoreCase("trt")) {
                            strCovers = "trt_basket";
                        } else if (coversDeselect[i].equalsIgnoreCase("stock")) {
                            strCovers = "stock_basket";
                        } else if (coversDeselect[i].equalsIgnoreCase("business_tools_equ")) {
                            strCovers = "business_tools_equ_basket";
                        } else if (coversDeselect[i].equalsIgnoreCase("business_cont")) {
                            strCovers = "business_cont_basket";
                        }
//                        Assert.assertTrue(!obj_coverwizard.wizardCoverBasketCovers(strCovers).isDisplayed());
                    }
                    break;

                case "Continue":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardContinueButton());
                    break;
            }
        }
    }

    private void HelpTextValidation(String strCovers) {
        if (strCovers.equalsIgnoreCase("homebuilding_basket")) {
            strValidateHelpText = "Covers you for damage to your home and any outbuildings, including rebuilding it if it was damaged beyond repair. As standard, we'll also pay to repair or replace your boiler if it breaks down (excludes wear and tear) if it's used for business purposes.";
            obj_coverwizard.executeScript("arguments[0].click()", obj_coverwizard.wizardCoverBasketYourHomeHelpTextQuestion());
            strHelpText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_coverwizard.wizardCoverBasketYourHomeHelpText());
            Assert.assertTrue(strValidateHelpText.equals(strHelpText));
        } else if (strCovers.equalsIgnoreCase("household_basket")) {
            strValidateHelpText = "For instance, your home furniture, TV, smartphone, clothes, etc";
            obj_coverwizard.executeScript("arguments[0].click()", obj_coverwizard.wizardCoverBasketHouseHoldHelpTextQuestion());
            strHelpText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_coverwizard.wizardCoverBasketHouseHoldHelpText());
            Assert.assertTrue(strValidateHelpText.equals(strHelpText));
        } else if (strCovers.equalsIgnoreCase("bi_basket")) {
            strValidateHelpText = "Covers you for the reduced turnover if you’re unable to trade because of an insured cause such as a fire or flood, which damages your premises, equipment or stock.If you rent a chair or space in a salon, this covers the reduction in turnover or costs you incur to try to avoid losing turnover, or to reduce the amount of lost turnover if the property you use becomes unusable due to an insured cause such as flood or fire";
            obj_coverwizard.executeScript("arguments[0].click()", obj_coverwizard.wizardCoverBasketBIHelpTextQuestion());
            strHelpText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_coverwizard.wizardCoverBasketBIHelpText());
            String strHelptextVal = strHelpText.replace("\n", "");
            Assert.assertTrue(strValidateHelpText.equals(strHelptextVal));
        } else if (strCovers.equalsIgnoreCase("tot_basket")) {
            strValidateHelpText = "Cash, cheques etc stolen from your premises, in transit, from a safe, or in the personal possession of you or anyone working for the business";
            obj_coverwizard.executeScript("arguments[0].click()", obj_coverwizard.wizardCoverBasketTOTHelpTextQuestion());
            strHelpText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_coverwizard.wizardCoverBasketTOTHelpText());
            Assert.assertTrue(strValidateHelpText.equals(strHelpText));
        } else if (strCovers.equalsIgnoreCase("legal_exp_basket")) {
            strValidateHelpText = "Pays the legal costs of providing specialist lawyers and taking action against many common legal problems, for instance disputes with suppliers, clients or guests";
            obj_coverwizard.executeScript("arguments[0].click()", obj_coverwizard.wizardCoverBasketLegExpHelpTextQuestion());
            strHelpText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_coverwizard.wizardCoverBasketLegExpHelpText());
            Assert.assertTrue(strValidateHelpText.equals(strHelpText));
        } else if (strCovers.equalsIgnoreCase("salonbuild_basket")) {
            strValidateHelpText = "Covers you for damage to your building and any outbuildings, including rebuilding it if it was damaged beyond repair. As standard, we’ll also pay to repair or replace your boiler if it breaks down (excludes wear and tear) if it's used for business purposes.";
            obj_coverwizard.executeScript("arguments[0].click()", obj_coverwizard.wizardCoverBasketSalonHelpTextQuestion());
            strHelpText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_coverwizard.wizardCoverBasketSalonHelpText());
            Assert.assertTrue(strValidateHelpText.equals(strHelpText));
        } else if (strCovers.equalsIgnoreCase("trt_basket")) {
            strValidateHelpText = "Covers you for injury caused to your clients by the treatments you provide. You'll be able to choose which treatments to cover later.";
            obj_coverwizard.executeScript("arguments[0].click()", obj_coverwizard.wizardCoverBasketHairBeautyHelpTextQuestion());
            strHelpText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_coverwizard.wizardCoverBasketHairBeautyHelpText());
            Assert.assertTrue(strValidateHelpText.equals(strHelpText));
        } else if (strCovers.equalsIgnoreCase("stock_basket")) {
            strValidateHelpText = "Goods you sell, and materials used to make your products or provide your services";
            obj_coverwizard.executeScript("arguments[0].click()", obj_coverwizard.wizardCoverBasketStockHelpTextQuestion());
            strHelpText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_coverwizard.wizardCoverBasketStockHelpText());
            Assert.assertTrue(strValidateHelpText.equals(strHelpText));
        } else if (strCovers.equalsIgnoreCase("business_cont_basket")) {
            strValidateHelpText = "As standard, we give you equipment breakdown cover which pays to repair or replace things like washer dryers, hair removal equipment, vibromassage, Faradic current, and infrared skin treatment equipment (excludes wear and tear)";
            obj_coverwizard.executeScript("arguments[0].click()", obj_coverwizard.wizardCoverBasketBusinessContentHelpTextQuestion());
            strHelpText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].innerText", obj_coverwizard.wizardCoverBasketBusinessContentHelpText());
            Assert.assertTrue(strValidateHelpText.equals(strHelpText));
        }
    }


    public void fillOPRCoverWizard(String coversDetail) {
        HashMap<String, String> CoverWizardElements = new LinkedHashMap<String, String>();
        String[] CoverWizardFields = coversDetail.split("#");
        for (int i = 1; i <= CoverWizardFields.length; i++) {
            String[] CoverWizardValues = CoverWizardFields[i - 1].split(";");
            CoverWizardElements.put(CoverWizardValues[0], CoverWizardValues[1]);
        }
        List<String> CoverWizardQuestions = new ArrayList<>(CoverWizardElements.keySet());
        for (String CoverWizardQuestion : CoverWizardQuestions) {
            switch (CoverWizardQuestion) {
                case "TradeName":
                    obj_coverwizard.tradeNameTextbox().sendKeys(CoverWizardElements.get(CoverWizardQuestion));
                    obj_coverwizard.wizardTradeList().click();
                    break;
                case "SellProduct":
                    String[] sellProductList = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < sellProductList.length; i++) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.sellProductRunBusinessCoversCommonOPR(sellProductList[i]));
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.sellProductNextButton());
                    obj_generalInformation.pageLoading();
                    break;
                case "RunBusiness":
                    String[] runBusinessList = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < runBusinessList.length; i++) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.sellProductRunBusinessCoversCommonOPR(runBusinessList[i]));
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.businessNextButton());
                    obj_generalInformation.pageLoading();
                    break;
                case "HaveEmployee":
                    if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Permanent employee(s)")) {
                        CoverWizardQuestion = "perm";
                    } else if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Temporary employee(s)")) {
                        CoverWizardQuestion = "temp";
                    } else if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Permanent & temporary employees")) {
                        CoverWizardQuestion = "both";
                    } else if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("No")) {
                        CoverWizardQuestion = "employee_no";
                    }
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.haveEmployeesButton(CoverWizardQuestion));
                    break;
                case "ELCover":
                    if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("Yes")) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardEmployersLiabilityCoverYesRadiobutton());
                    } else if ((CoverWizardElements.get(CoverWizardQuestion)).equalsIgnoreCase("No")) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.wizardEmployersLiabilityCoverNoRadiobutton());
                    }
                    break;
                case "Covers":
                    String[] coversList = (CoverWizardElements.get(CoverWizardQuestion)).split(":");
                    for (int i = 0; i < coversList.length; i++) {
                        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.sellProductRunBusinessCoversCommonOPR(coversList[i]));
                    }
                    break;
                case "Continue":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversContinueButton());
                    obj_generalInformation.pageLoading();
                    break;
            }
        }
    }

    public void fillCoverWizardSectionforBnB(String appication, String trade, String tradeName, boolean livePremises, boolean haveEmployees, boolean employersLiability, String covers) throws Throwable {
        if (appication.equals("WJ")) {
            switch (trade) {
                case "Generic Wizard":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.getQuoteOnlineLink());
                    break;
                case "hb":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.hbLink());
                    break;
                case "bb":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbLink());
                    break;
                case "office consultant":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.offoiceConsultantLink());
                    break;
                case "retail":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.retailLink());
                    break;
                case "food retail":
                    obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.foodRetailLink());
                    break;
            }
        }
        obj_coverwizard.switchWindow();
        obj_generalInformation.pageLoading();
        if (trade.equals("null") || appication.equals("CC")) {
            obj_commonUtil.switchFrame("sagepay");
        }
        obj_coverwizard.tradeNameTextbox().clear();
        obj_coverwizard.tradeNameTextbox().sendKeys(tradeName);
        obj_generalInformation.pageLoading();
        obj_coverwizard.wizardTradeList().click();
        if (livePremises) {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.livePremisesYesRadiobutton());
        } else {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.livePremisesNoRadiobutton());
        }
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbLivepremisesNextbutton());
        if (haveEmployees) {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbHaveEmpYesRadiobutton());
            if (employersLiability) {
                obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbEmployersLiabilityCoverYesRadiobutton());
            } else {
                obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbEmployersLiabilityCoverNoRadiobutton());
            }
        } else {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbHaveEmpNoRadiobutton());
        }
        String[] cover = covers.split("#");
        for (int i = 0; i < cover.length; i++) {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversCheckbox(cover[i]));
        }
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversContinueButton());
    }


    public void fillCoverWizardSectionforBnB(String tradeName, boolean livePremises, boolean haveEmployees, boolean employersLiability, String covers) {
        obj_coverwizard.tradeNameTextbox().sendKeys(tradeName);
        obj_coverwizard.wizardTradeList().click();
        if (livePremises) {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.livePremisesYesRadiobutton());
        } else {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.livePremisesNoRadiobutton());
        }
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbLivepremisesNextbutton());
        if (haveEmployees) {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbHaveEmpYesRadiobutton());
            if (employersLiability) {
                obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbEmployersLiabilityCoverYesRadiobutton());
            } else {
                obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbEmployersLiabilityCoverNoRadiobutton());
            }
        } else {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.bbHaveEmpNoRadiobutton());
        }
        String[] cover = covers.split("#");
        for (int i = 0; i < cover.length; i++) {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversCheckbox(cover[i]));
        }
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversContinueButton());
    }


    public void NextYearTurnOverValidation(String GIQuestionText, String GIQuestionHelpText, String GIPlsTellUsText, String GITurnOverValue) throws InterruptedException {
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.giEdit());
        String text = obj_generalInformation.giNextYearTurnOverQuestionText().getText();
        String PlsTellUsText = obj_generalInformation.giPlsTellUsText().getText();

        String strValue = "Up to *25,000;*25,001 - *50,000;*75,001 - *100,000;*100,001 - *150,000;*200,001 - *250,000;*250,001 - *500,000;*500,001 - *750,000;*750,001 - *1,000,000;Over *1,000,000";
        if (text.equalsIgnoreCase(GIQuestionText)) {
            Assert.assertTrue("Next Year Turn Over Question Text Message is displayed", true);
        } else {
            Assert.assertTrue("Next Year Turn Over Question Text Message is displayed", false);
        }

        if (PlsTellUsText.equalsIgnoreCase(GIPlsTellUsText)) {
            Assert.assertTrue("Please Tell us Gross TurnOver Text Message is displayed", true);
        } else {
            Assert.assertTrue("Please Tell us Gross TurnOver Text Message is displayed", false);
        }
        String[] arrValue = strValue.split(";");
        for (int i = 0; i < arrValue.length; i++) {
            String strPoundValue = arrValue[i].replace("*", "£");
            new Select(obj_generalInformation.giNextTurnOverDropDown()).selectByVisibleText(strPoundValue);
            Thread.sleep(2000);
        }
        String script = "return arguments[0].innerText";
        String strText = (String) ((JavascriptExecutor) getDriver).executeScript(script, obj_generalInformation.giNextYearTurnOverHelpText());
        if (GIQuestionHelpText.replace(" ", "").equalsIgnoreCase(strText.replace(" ", ""))) {
            Assert.assertTrue("Help Text Message is displayed", true);
        } else {
            Assert.assertTrue("Help Text Message is displayed", false);
        }

        obj_generalInformation.giTurnOverValueNext().sendKeys(GITurnOverValue);


        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();


    }

    public void GiErrorValidation(String GIQuestionText, String GIPlsTellUsText, String GITurnOverValue, String ErrorMessage) {

        String ErrorMsgfrmAppl = "";
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.giEdit());
        String text = obj_generalInformation.giNextYearTurnOverQuestionText().getText();
        String PlsTellUsText = obj_generalInformation.giPlsTellUsText().getText();

        if (text.equalsIgnoreCase(GIQuestionText)) {
            Assert.assertTrue("Next Year Turn Over Question Text Message is displayed", true);
        } else {
            Assert.assertTrue("Next Year Turn Over Question Text Message is displayed", false);
        }

        if (PlsTellUsText.equalsIgnoreCase(GIPlsTellUsText)) {
            Assert.assertTrue("Please Tell us Gross TurnOver Text Message is displayed", true);
        } else {
            Assert.assertTrue("Please Tell us Gross TurnOver Text Message is displayed", false);
        }


        obj_generalInformation.giTurnOverValueNext().clear();
        obj_generalInformation.giTurnOverValueNext().sendKeys(GITurnOverValue);


        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();

        if (ErrorMessage.equalsIgnoreCase("Please enter a valid number")) {
            ErrorMsgfrmAppl = obj_generalInformation.giErrorMsgDecimal().getText();
        } else {
            ErrorMsgfrmAppl = obj_generalInformation.giErrorMsgGreaterThan1Mill().getText();
        }
        Assert.assertTrue(ErrorMsgfrmAppl.equalsIgnoreCase(ErrorMessage));


    }

    public void GiBITextValidation(String GIQuestionText, String GIPlsTellUsText) {

        String text = obj_businessInterruption.TurnOverQuestionText().getText();
        String PlsTellUsText = obj_businessInterruption.TurnOverPleaseTellText().getText();

        if (text.equalsIgnoreCase(GIQuestionText)) {
            Assert.assertTrue("Next Year Turn Over Question Text Message is displayed", true);
        } else {
            Assert.assertTrue("Next Year Turn Over Question Text Message is displayed", false);
        }

        if (PlsTellUsText.equalsIgnoreCase(GIPlsTellUsText)) {
            Assert.assertTrue("Please Tell us Gross TurnOver Text Message is displayed", true);
        } else {
            Assert.assertTrue("Please Tell us Gross TurnOver Text Message is displayed", false);
        }


        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();


    }

    public void BiTextValidation(String GIQuestionText, String GIPlsTellUsText, String GITurnOverValue) throws InterruptedException {
        // obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.giEdit());
        String ErrorMsgfrmAppl = "";
        String text = obj_businessInterruption.TurnOverQuestionText().getText();


        String strValue = "Up to *25,000;*25,001 - *50,000;*75,001 - *100,000;*100,001 - *150,000;*200,001 - *250,000;*250,001 - *500,000;*500,001 - *750,000;*750,001 - *1,000,000;Over *1,000,000";

        if (text.equalsIgnoreCase(GIQuestionText)) {
            Assert.assertTrue("Next Year Turn Over Question Text Message is displayed", true);
        } else {
            Assert.assertTrue("Next Year Turn Over Question Text Message is displayed", false);
        }


        String[] arrValue = strValue.split(";");
        for (int i = 0; i < arrValue.length; i++) {
            String strPoundValue = arrValue[i].replace("*", "£");
            new Select(obj_businessInterruption.grossTurnOverDropDown()).selectByVisibleText(strPoundValue);


            Thread.sleep(2000);
        }

        String PlsTellUsText = obj_businessInterruption.TurnOverPleaseTellText().getText();

        if (PlsTellUsText.equalsIgnoreCase(GIPlsTellUsText)) {
            Assert.assertTrue("Please Tell us Gross TurnOver Text Message is displayed", true);
        } else {
            Assert.assertTrue("Please Tell us Gross TurnOver Text Message is displayed", false);
        }


        obj_businessInterruption.grossTurnOverTextbox().clear();
        obj_businessInterruption.grossTurnOverTextbox().sendKeys(GITurnOverValue);


        // new Select(businessInterruption.monthOfCoverDropDown()).selectByVisibleText("6");

        //obj_generalInformation.pageLoading();
        //obj_coverwizard.executeScript("arguments[0].click();", businessInterruption.nxtBtnBI());

        // obj_generalInformation.pageLoading();


    }


    public void BiTextValidationNotPresent(String GIQuestionText, String GIPlsTellUsText, String GITurnOverValue) throws InterruptedException {
        // obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.giEdit());
        String ErrorMsgfrmAppl = "";
        String text = obj_businessInterruption.noOFMonthstext().getText();

        Assert.assertTrue(!text.equals(GIQuestionText));
        Assert.assertTrue(!text.equals(GIPlsTellUsText));


    }


    public void BiErrorValidation(String GIQuestionText, String GIPlsTellUsText, String GITurnOverValue, String ErrorMessage) throws InterruptedException {
        // obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.giEdit());
        String ErrorMsgfrmAppl = "";
        String text = obj_businessInterruption.TurnOverQuestionText().getText();


        String strValue = "Up to *25,000;*25,001 - *50,000;*75,001 - *100,000;*100,001 - *150,000;*200,001 - *250,000;*250,001 - *500,000;*500,001 - *750,000;*750,001 - *1,000,000;Over *1,000,000";

        if (text.equalsIgnoreCase(GIQuestionText)) {
            Assert.assertTrue("Next Year Turn Over Question Text Message is displayed", true);
        } else {
            Assert.assertTrue("Next Year Turn Over Question Text Message is displayed", false);
        }


        String[] arrValue = strValue.split(";");
        for (int i = 0; i < arrValue.length; i++) {
            String strPoundValue = arrValue[i].replace("*", "£");
            new Select(obj_businessInterruption.grossTurnOverDropDown()).selectByVisibleText(strPoundValue);


            Thread.sleep(2000);
        }

        String PlsTellUsText = obj_businessInterruption.TurnOverPleaseTellText().getText();

        if (PlsTellUsText.equalsIgnoreCase(GIPlsTellUsText)) {
            Assert.assertTrue("Please Tell us Gross TurnOver Text Message is displayed", true);
        } else {
            Assert.assertTrue("Please Tell us Gross TurnOver Text Message is displayed", false);
        }


        obj_businessInterruption.grossTurnOverTextbox().clear();
        obj_businessInterruption.grossTurnOverTextbox().sendKeys(GITurnOverValue);


        new Select(obj_businessInterruption.monthOfCoverDropDown()).selectByVisibleText("6");

        //obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_businessInterruption.nxtBtnBI());

        // obj_generalInformation.pageLoading();

        if (ErrorMessage.equalsIgnoreCase("Please enter a valid number")) {
            ErrorMsgfrmAppl = obj_businessInterruption.biErrorValidNumber_HB_BB().getText();
        } else {
            ErrorMsgfrmAppl = obj_businessInterruption.biErrorMsgGreaterThan1Mill_HB_BB().getText();
        }

        Assert.assertTrue(ErrorMsgfrmAppl.equalsIgnoreCase(ErrorMessage));


    }

    public void AddNotes(String Engagement, String Content) throws Throwable {
        obj_notes.AddnotesTitle().sendKeys(Engagement);
        obj_notes.AddnotesContent().sendKeys(Content);
        obj_notes.AddnotesSave().click();
        ccSearch.ccPageLoad();

    }


    public void CopyPasteNotes(String Engagement, String Content) throws Throwable {
        Actions a = new Actions(getDriver);
        obj_notes.AddnotesTitle().sendKeys(Engagement);
        a.sendKeys(obj_notes.AddnotesTitle(), Keys.chord(Keys.CONTROL, "a")).perform();
        a.sendKeys(Keys.chord(Keys.CONTROL, "c")).perform();
        //obj_notes.AddnotesTitle().clear();
        // a.sendKeys(Keys.chord(Keys.CONTROL,"v")).perform();
        a.sendKeys(obj_notes.AddnotesTitle(), Keys.chord(Keys.CONTROL, "v")).perform();
        //obj_notes.AddnotesTitle().sendKeys(Keys.chord(Keys.CONTROL,"a"),Keys.chord(Keys.CONTROL,"c"));
        obj_notes.AddnotesContent().sendKeys(Content);
        obj_notes.AddnotesSave().click();
        ccSearch.ccPageLoad();
    }

    public void viewNotes() throws Throwable {
        int intCount = getDriver.findElements(By.xpath("//*[starts-with(@id,'C2__C5__View-Policy-Notes_R')]")).size();
        ccSearch.ccPageLoad();
        for (int i = 1; i <= intCount; i++) {
            getDriver.findElement(By.xpath("//*[starts-with(@id,'C2__C5__View-Policy-Notes_R" + i + "')]")).click();
            ccSearch.ccPageLoad();
            getDriver.findElement(By.xpath("//*[starts-with(@id,'C2__C5__FMT_BFB16C4031DCD31D95733_R" + i + "')]")).isDisplayed();
            ccSearch.ccPageLoad();
        }
    }

    public void viewAllNotes() throws Throwable {
        obj_notes.viewAllNotes().click();
        ccSearch.ccPageLoad();
        int intCount = getDriver.findElements(By.xpath("//*[starts-with(@id,'C2__C5__View-Policy-Notes_R')]")).size();
        for (int i = 1; i <= intCount; i++) {
            getDriver.findElement(By.xpath("//*[starts-with(@id,'C2__C5__FMT_BFB16C4031DCD31D95733_R" + i + "')]")).isDisplayed();
        }
    }

    public void ViewAllNotesScrollBar() throws Throwable {

        int intCount = getDriver.findElements(By.xpath("//*[starts-with(@id,'C2__C5__View-Policy-Notes_R')]")).size();
        ccSearch.ccPageLoad();

        for (int i = 1; i <= intCount; i++) {
            WebElement element = getDriver.findElement(By.xpath("//*[starts-with(@id,'C2__C5__View-Policy-Notes_R" + i + "')]"));
            ((JavascriptExecutor) getDriver).executeScript("arguments[0].scrollIntoView();", element);
            ((JavascriptExecutor) getDriver).executeScript("arguments[0].click();", element);
            ccSearch.ccPageLoad();
            getDriver.findElement(By.xpath("//*[starts-with(@id,'C2__C5__FMT_BFB16C4031DCD31D95733_R" + i + "')]")).isDisplayed();
        }
    }


    public void viewNotesSingleView() throws Throwable {
        obj_notes.ViewNoteSingle().getText().equalsIgnoreCase("View");
        obj_notes.ViewNoteSingle().click();
        ccSearch.ccPageLoad();
    }

    public void viewNotesSingleClose() throws Throwable {
        obj_notes.ViewNoteSingle().getText().equalsIgnoreCase("Close");
        obj_notes.ViewNoteSingle().click();
        ccSearch.ccPageLoad();
    }

    public void ViewAllNotesText() throws Throwable {

        int intCount = getDriver.findElements(By.xpath("//*[starts-with(@id,'C2__C5__View-Policy-Notes_R')]")).size();
        for (int i = 1; i <= intCount; i++) {
            getDriver.findElement(By.xpath("//*[starts-with(@id,'C2__C5__View-Policy-Notes_R" + i + "')]")).getText().equalsIgnoreCase("View");
        }
    }

    public void CloseAllNotesText() throws Exception {

        int intCount = getDriver.findElements(By.xpath("//*[starts-with(@id,'C2__C5__View-Policy-Notes_R')]")).size();
        for (int i = 1; i <= intCount; i++) {
            getDriver.findElement(By.xpath("//*[starts-with(@id,'C2__C5__View-Policy-Notes_R" + i + "')]")).getText().equalsIgnoreCase("Close");
        }
    }

    public void viewAllNotesSingleClose() throws Exception {
        int intCount = getDriver.findElements(By.xpath("//*[starts-with(@id,'C2__C5__View-Policy-Notes_R')]")).size();
        obj_notes.ViewNoteSingle().getText().equalsIgnoreCase("Close");
        for (int i = 2; i <= intCount; i++) {
            getDriver.findElement(By.xpath("//*[starts-with(@id,'C2__C5__View-Policy-Notes_R" + i + "')]")).getText().equalsIgnoreCase("View");
            getDriver.findElement(By.xpath("//*[starts-with(@id,'C2__C5__FMT_BFB16C4031DCD31D95733_R" + i + "')]")).isDisplayed();
        }
    }

    public void fillPreviousLossScreen(String previousLossDetails) throws Throwable {
        HashMap<String, String> PreviousLossElements = new LinkedHashMap<String, String>();
        String[] PreviousLossFeilds = previousLossDetails.split("#");
        for (int i = 1; i <= PreviousLossFeilds.length; i++) {
            String[] CoverWizardValues = PreviousLossFeilds[i - 1].split(";");
            PreviousLossElements.put(CoverWizardValues[0], CoverWizardValues[1]);
        }
        List<String> PreviousLossQuestions = new ArrayList<>(PreviousLossElements.keySet());
        for (String PreviousLossQuestion : PreviousLossQuestions) {
            switch (PreviousLossQuestion) {
                case "PreviousLoss":
                    if (PreviousLossElements.get(PreviousLossQuestion).equalsIgnoreCase("Y")) {
                        obj_claims.executeScript("arguments[0].click();", obj_claims.previousLossesYesRadiobutton());
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_claims.executeScript("arguments[0].click();", obj_claims.previousLossesNoRadiobutton());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "AddLoss":
                    if (PreviousLossElements.get(PreviousLossQuestion).contains("&")) {
                        obj_claims.addALoss().click();
                        obj_generalInformation.pageLoading();
                        String LossList[] = PreviousLossElements.get(PreviousLossQuestion).split("&");
                        for (int i = 0; i < LossList.length; i++) {
                            if (i == 1) {
                                obj_claims.addAnotherLoss().click();
                                obj_generalInformation.pageLoading();
                            }
                            String LossListValues[] = LossList[i].split(":");
                            obj_claims.Lossdate().sendKeys(LossListValues[0]);
                            obj_generalInformation.pageLoading();
                            new Select(obj_claims.Cause()).selectByVisibleText(LossListValues[1]);
                            obj_generalInformation.pageLoading();
                            obj_claims.Lossamt().sendKeys(LossListValues[2]);
                            obj_generalInformation.pageLoading();
                            obj_claims.executeScript("arguments[0].click();", obj_claims.SettledYesbutton());
                            obj_generalInformation.pageLoading();
                            obj_claims.executeScript("arguments[0].click();", obj_claims.AddLossInternal());
                            obj_generalInformation.pageLoading();
                        }
                    } else {
                        obj_claims.addALoss().click();
                        obj_generalInformation.pageLoading();
                        String LossList[] = PreviousLossElements.get(PreviousLossQuestion).split(":");
                        obj_claims.Lossdate().sendKeys(LossList[0]);
                        obj_generalInformation.pageLoading();
                        new Select(obj_claims.Cause()).selectByVisibleText(LossList[1]);
                        obj_generalInformation.pageLoading();
                        obj_claims.Lossamt().sendKeys(LossList[2]);
                        obj_generalInformation.pageLoading();
                        obj_claims.executeScript("arguments[0].click();", obj_claims.SettledYesbutton());
                        obj_generalInformation.pageLoading();
                        obj_claims.executeScript("arguments[0].click();", obj_claims.AddLossInternal());
                        obj_generalInformation.pageLoading();
                    }
                    break;

                case "ValidationCauseOfLossDDL":
                    obj_claims.addALoss().click();
                    obj_generalInformation.pageLoading();
                    List<WebElement> dropDownList = new Select(obj_claims.causeOfLoss()).getOptions();
                    for (WebElement suggestion : dropDownList) {
                        String dropDownValues = suggestion.getText();
                        if (dropDownValues.trim().equalsIgnoreCase("Professional Liability")) {
                            Assert.assertTrue(true);
                        }
                    }
                    obj_claims.executeScript("arguments[0].click();", obj_claims.cancelLoss());
                    obj_generalInformation.pageLoading();
                    break;

                case "SaveExit":
                    if (PreviousLossElements.get(PreviousLossQuestion).equalsIgnoreCase("WJ")) {
                        obj_claims.executeScript("arguments[0].click();", obj_claims.SaveAndExit());
                        obj_generalInformation.pageLoading();
                        obj_claims.executeScript("arguments[0].click();", obj_claims.SaveAndExitpopupSS());
                        obj_generalInformation.pageLoading();
                        saveandExit();
                    } else {
                        obj_claims.executeScript("arguments[0].click();", obj_claims.SaveAndExit());
                        obj_generalInformation.pageLoading();
                        obj_claims.executeScript("arguments[0].click();", obj_claims.SaveAndExitpopupSS());
                        obj_generalInformation.pageLoading();
                    }
                    break;

                case "GetQuote":
                    obj_claims.executeScript("arguments[0].click()", obj_claims.getQuoteButton());
                    Thread.sleep(5000);
                    break;
                case "ReviewAndConfirm":
                    obj_quoteSummary.coverYouHaveChosen();
                    obj_quoteSummary.executeScript("arguments[0].click()", obj_quoteSummary.reviewConfirmButton());
                    obj_generalInformation.pageLoading();
                    break;
                case "DefaultPurchase":
                    fillYourQuoteSection();
                    fillInterestedPartySection();
                    fillcontactSection();
                    fillPaymentSection();
                    fillDirectDebitSection();
                    fillPaymentInformationDetails();
                    fillCardDetailsSection("Amex");
                    break;
                case "ChangeLoss":
                    obj_claims.executeScript("arguments[0].click()", obj_claims.changeLoss());
                    obj_generalInformation.pageLoading();
                    String LossListValues[] = PreviousLossElements.get(PreviousLossQuestion).split(":");
                    obj_claims.Lossdate().clear();
                    obj_claims.Lossdate().sendKeys(LossListValues[0]);
                    obj_generalInformation.pageLoading();
                    new Select(obj_claims.Cause()).selectByVisibleText(LossListValues[1]);
                    obj_generalInformation.pageLoading();
                    obj_claims.Lossamt().clear();
                    obj_claims.Lossamt().sendKeys(LossListValues[2]);
                    obj_generalInformation.pageLoading();
                    obj_claims.executeScript("arguments[0].click();", obj_claims.SettledYesbutton());
                    obj_generalInformation.pageLoading();
                    obj_claims.executeScript("arguments[0].click();", obj_claims.updateLossButton());
                    obj_generalInformation.pageLoading();
                    break;
            }
        }
    }

    public void fillTreatmentsBusinessScreen(String treatmentSectionValue) {
        HashMap<String, String> treatmentBusinessElements = new LinkedHashMap<String, String>();
        String[] treatmentBusinessFeilds = treatmentSectionValue.split("#");
        for (int i = 1; i <= treatmentBusinessFeilds.length; i++) {
            String[] CoverWizardValues = treatmentBusinessFeilds[i - 1].split(";");
            treatmentBusinessElements.put(CoverWizardValues[0], CoverWizardValues[1]);
        }
        List<String> treatmentBusinessQuestions = new ArrayList<>(treatmentBusinessElements.keySet());
        for (String treatmentBusinessQuestion : treatmentBusinessQuestions) {
            switch (treatmentBusinessQuestion) {
                case "AnyOtherTreatmentValue":
                    obj_treatments.peopleProvideTreatmentTextBox().sendKeys(treatmentBusinessElements.get(treatmentBusinessQuestion));
                    obj_generalInformation.pageLoading();
                    break;
                case "AnyOtherTreatment":
                    if ((treatmentBusinessElements.get(treatmentBusinessQuestion)).equalsIgnoreCase("Y")) {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.anyOtherTreatmentYesButton());
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.anyOtherTreatmentNoButton());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "AnyTreatments":
                    if ((treatmentBusinessElements.get(treatmentBusinessQuestion)).equalsIgnoreCase("Y")) {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.anyTreatmentYesButton());
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.anyTreatmentNoButton());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "AdditionalTreatment":
                    String treatmentList[] = treatmentBusinessElements.get(treatmentBusinessQuestion).split(":");
                    for (int i = 0; i < treatmentList.length; i++) {
                        if (i == 0) {
                            obj_treatments.executeScript("arguments[0].click();", obj_treatments.addTreatmentButton());
                            obj_generalInformation.pageLoading();
                        } else {
                            obj_treatments.executeScript("arguments[0].click();", obj_treatments.addAnotherTreatmentButton());
                            obj_generalInformation.pageLoading();
                        }
                        String treatmentValue[] = treatmentList[i].split(",");
                        for (int j = 0; j < treatmentList.length - 1; j++) {
                            for (int multitreatment = 0; multitreatment < treatmentList.length; multitreatment++) {
                                if (multitreatment == 0) {
                                    new Select(obj_treatments.treatmentDropdown()).selectByVisibleText(treatmentValue[multitreatment]);
                                    obj_generalInformation.pageLoading();
                                    obj_treatments.peoplePerformTreatmentTextBox().sendKeys(treatmentValue[multitreatment + 1]);
                                    obj_generalInformation.pageLoading();
                                    obj_treatments.executeScript("arguments[0].click();", obj_treatments.addTreatmentPopUpButton());
                                    obj_generalInformation.pageLoading();
                                }
                            }
                        }
                    }
                    break;
                case "Qualification":
                    if ((treatmentBusinessElements.get(treatmentBusinessQuestion)).equalsIgnoreCase("Y")) {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.qualificationYesButton());
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.qualificationNoButton());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "Next":
                    obj_generalInformation.executeScript("arguments[0].click();", obj_treatments.nextButton());
                    obj_generalInformation.pageLoading();
                    break;


            }
        }
    }

    public void fillPostQuoteScreens(String postQuoteValue) throws Throwable {
        HashMap<String, String> postQuoteElements = new LinkedHashMap<String, String>();
        String[] postQuoteFeilds = postQuoteValue.split("#");
        for (int i = 1; i <= postQuoteFeilds.length; i++) {
            String[] CoverWizardValues = postQuoteFeilds[i - 1].split(";");
            postQuoteElements.put(CoverWizardValues[0], CoverWizardValues[1]);
        }
        List<String> postQuoteQuestions = new ArrayList<>(postQuoteElements.keySet());
        for (String postQuoteQuestion : postQuoteQuestions) {
            switch (postQuoteQuestion) {
                case "CreateAccount":
                    if ((postQuoteElements.get(postQuoteQuestion)).equalsIgnoreCase("WJ")) {
                        obj_quoteSummary.executeScript("arguments[0].click()", obj_quoteSummary.createAccountButton());
                        obj_generalInformation.pageLoading();
                        saveandExit();
                    }
                    break;
                case "PostCode":
                    String ELValues[] = postQuoteElements.get(postQuoteQuestion).split(",");
                    for (int i = 0; i < ELValues.length; i++) {
                        if (ELValues[i].equalsIgnoreCase("businessAddress")) {
                            obj_postquote.businessaAddressYesButton().click();
                            obj_generalInformation.pageLoading();
                        } else if (ELValues[i].equalsIgnoreCase("postCode")) {
                            obj_generalInformation.postcodeTextbox().sendKeys("E11DU");
                            obj_generalInformation.pageLoading();
                            obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
                            obj_generalInformation.pageLoading();
                            Select address = new Select(obj_generalInformation.correspondenceAddressDropdown());
                            List<WebElement> addressVal = address.getOptions();
                            addressVal.get(1).click();
                            obj_generalInformation.pageLoading();
                        } else if (ELValues[i].equalsIgnoreCase("ExcemptERM")) {
                            obj_postquote.executeScript("arguments[0].click();", obj_postquote.ExemptERM());
                            obj_generalInformation.pageLoading();
                            obj_postquote.ERMnum().sendKeys("123/a234");
                            obj_generalInformation.pageLoading();
                        }
                    }
                    break;
                case "Next":
                    obj_postquote.executeScript("arguments[0].click();", obj_postquote.YourDetailsNext());
                    obj_generalInformation.pageLoading();
                    break;
                case "ELNext":
                    obj_postquote.executeScript("arguments[0].click();", obj_postquote.ELNext());
                    obj_generalInformation.pageLoading();
                    break;
                case "AddPartner":
                    String partners[] = postQuoteElements.get(postQuoteQuestion).split(":");
                    for (int i = 0; i < partners.length; i++) {
                        if (i == 0) {
                            obj_postquote.executeScript("arguments[0].click()", obj_postquote.addpartner());
                            obj_generalInformation.pageLoading();
                        } else {
                            obj_postquote.executeScript("arguments[0].click()", obj_postquote.partnerAddAnotherPartnerButton());
                            obj_generalInformation.pageLoading();
                        }
                        String partnersValues[] = partners[i].split(",");
                        for (int j = 0; j < partnersValues.length; j++) {
                            if (j == 0) {
                                obj_postquote.partnerTitle().sendKeys(partnersValues[j]);
                                obj_generalInformation.pageLoading();
                            } else if (j == 1) {
                                obj_postquote.partnerFirstName().sendKeys(partnersValues[j]);
                                obj_generalInformation.pageLoading();
                            } else {
                                obj_postquote.partnerLastName().sendKeys(partnersValues[j]);
                                obj_generalInformation.pageLoading();
                            }
                        }
                        obj_postquote.executeScript("arguments[0].click()", obj_postquote.partnerAddButton());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "PartnerNext":
                    obj_postquote.executeScript("arguments[0].click()", obj_postquote.partnernextButton());
                    obj_generalInformation.pageLoading();
                    break;
            }
        }
    }

    public void fillInterestedPartyScreen(String interetedPartyValue) {
        HashMap<String, String> interestedPartyElements = new LinkedHashMap<String, String>();
        String[] interestedPartyFeilds = interetedPartyValue.split("#");
        for (int i = 1; i <= interestedPartyFeilds.length; i++) {
            String[] CoverWizardValues = interestedPartyFeilds[i - 1].split(";");
            interestedPartyElements.put(CoverWizardValues[0], CoverWizardValues[1]);
        }
        List<String> interestedPartyQuestions = new ArrayList<>(interestedPartyElements.keySet());
        for (String interestedPartyQuestion : interestedPartyQuestions) {
            switch (interestedPartyQuestion) {
                case "AddAnyParties":
                    if ((interestedPartyElements.get(interestedPartyQuestion)).equalsIgnoreCase("Y")) {
                        obj_interestedParty.executeScript("arguments[0].click()", obj_interestedParty.addPartyYesRadiobutton());
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_interestedParty.executeScript("arguments[0].click()", obj_interestedParty.addPartyNoRadiobutton());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "AddInterestedParty":
                    String interestedParty[] = interestedPartyElements.get(interestedPartyQuestion).split(":");
                    for (int i = 0; i < interestedParty.length; i++) {
                        if (i == 0) {
                            obj_postquote.executeScript("arguments[0].click()", obj_postquote.addInterestedParty());
                            obj_generalInformation.pageLoading();
                        } else {
                            obj_postquote.executeScript("arguments[0].click()", obj_postquote.interestedPartyAddAnother());
                            obj_generalInformation.pageLoading();
                        }
                        String interestedPartyValue[] = interestedParty[i].split(",");
                        for (int j = 0; j < interestedPartyValue.length; j++) {
                            if (j == 0) {
                                obj_postquote.interestedPartyName().sendKeys(interestedPartyValue[j]);
                                obj_generalInformation.pageLoading();
                            } else if (j == 1) {
                                obj_postquote.postCodeTextBox().sendKeys(interestedPartyValue[j]);
                                obj_generalInformation.pageLoading();
                                obj_postquote.executeScript("arguments[0].click()", obj_postquote.findAddressButton());
                                obj_generalInformation.pageLoading();
                                Select address = new Select(obj_postquote.correspondenceAddressDropdown());
                                List<WebElement> addressVal = address.getOptions();
                                addressVal.get(1).click();
                                obj_generalInformation.pageLoading();
                            } else {
                                obj_postquote.natureOfInterestDropDown().sendKeys(interestedPartyValue[j]);
                                obj_generalInformation.pageLoading();
                            }
                        }
                        obj_postquote.executeScript("arguments[0].click()", obj_postquote.addButtonToSave());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "InterestedRemove":
                    obj_postquote.executeScript("arguments[0].click()", obj_postquote.interestedRemove());
                    obj_generalInformation.pageLoading();
                    break;
                case "InterestedNext":
                    obj_postquote.executeScript("arguments[0].click()", obj_postquote.InterestedPartyNext());
                    obj_generalInformation.pageLoading();
                    break;
            }
        }
    }

    public void fillcontactScreen(String contactScreenValue) {
        HashMap<String, String> contactScreenElements = new LinkedHashMap<String, String>();
        String[] contactScreenFeilds = contactScreenValue.split("#");
        for (int i = 1; i <= contactScreenFeilds.length; i++) {
            String[] CoverWizardValues = contactScreenFeilds[i - 1].split(";");
            contactScreenElements.put(CoverWizardValues[0], CoverWizardValues[1]);
        }
        List<String> contactScreenQuestions = new ArrayList<>(contactScreenElements.keySet());
        for (String contactScreenQuestion : contactScreenQuestions) {
            switch (contactScreenQuestion) {
                case "MakeChanges":
                    if ((contactScreenElements.get(contactScreenQuestion)).equalsIgnoreCase("Y")) {
                        obj_contacts.executeScript("arguments[0].click()", obj_contacts.makeChangesYesRadiobutton());
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_contacts.executeScript("arguments[0].click()", obj_contacts.makeChangesNoRadiobutton());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "AddContacts":
                    String additionalContact[] = contactScreenElements.get(contactScreenQuestion).split(":");
                    for (int i = 0; i < additionalContact.length; i++) {
                        if (i == 0) {
                            obj_postquote.executeScript("arguments[0].click()", obj_postquote.addContactButton());
                            obj_generalInformation.pageLoading();
                        } else {
                            obj_postquote.executeScript("arguments[0].click()", obj_postquote.addAnotherContactButton());
                            obj_generalInformation.pageLoading();
                        }
                        String additionalContactValues[] = additionalContact[i].split(",");
                        for (int j = 0; j < additionalContactValues.length; j++) {
                            if (j == 0) {
                                obj_postquote.contactTitle().sendKeys(additionalContactValues[j]);
                                obj_generalInformation.pageLoading();
                            } else if (j == 1) {
                                obj_postquote.contactFirstName().sendKeys(additionalContactValues[j]);
                                obj_generalInformation.pageLoading();
                            } else if (j == 2) {
                                obj_postquote.contactLasttName().sendKeys(additionalContactValues[j]);
                                obj_generalInformation.pageLoading();
                            } else {
                                obj_postquote.contactRelationship().sendKeys(additionalContactValues[j]);
                                obj_generalInformation.pageLoading();
                            }
                        }
                        obj_postquote.executeScript("arguments[0].click()", obj_postquote.addButtonToSaveContact());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "CheckOut":
                    obj_postquote.executeScript("arguments[0].click()", obj_postquote.checkOutButton());
                    obj_generalInformation.pageLoading();
                    break;
                case "Next":
                    obj_contacts.executeScript("arguments[0].click()", obj_postquote.contactNextButton());
                    obj_generalInformation.pageLoading();
                    break;
                case "SeasonalStock":
                    String seasonalStockValue[] = contactScreenElements.get(contactScreenQuestion).split(",");
                    new Select(obj_postquote.seasonalStockMonth1()).selectByVisibleText(seasonalStockValue[0]);
                    obj_generalInformation.pageLoading();
                    new Select(obj_postquote.seasonalStockMonth2()).selectByVisibleText(seasonalStockValue[1]);
                    obj_generalInformation.pageLoading();
                    break;
                case "ContactRemove":
                    obj_postquote.executeScript("arguments[0].click()", obj_postquote.contactRemove());
                    obj_generalInformation.pageLoading();
                    break;
            }
        }
    }

    public void fillPaymentScreen(String paymentScreenValue) throws Throwable {
        HashMap<String, String> paymentScreenElements = new LinkedHashMap<String, String>();
        String[] paymentScreenFeilds = paymentScreenValue.split("#");
        for (int i = 1; i <= paymentScreenFeilds.length; i++) {
            String[] CoverWizardValues = paymentScreenFeilds[i - 1].split(";");
            paymentScreenElements.put(CoverWizardValues[0], CoverWizardValues[1]);
        }
        List<String> paymentScreenQuestions = new ArrayList<>(paymentScreenElements.keySet());
        for (String paymentScreenQuestion : paymentScreenQuestions) {
            switch (paymentScreenQuestion) {
                case "PaymentType":
                    if ((paymentScreenElements.get(paymentScreenQuestion)).equalsIgnoreCase("Monthly")) {
                        obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.monthlyLink());
                        obj_generalInformation.pageLoading();
                        obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.acceptRadiobutton());
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.annualLink());
                        obj_generalInformation.pageLoading();
                    }
//                    obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.renewRadiobutton());
//                    obj_generalInformation.pageLoading();
//                    obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.understoodRadiobutton());
//                    obj_generalInformation.pageLoading();
//                    obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.paymentScreenNextButton());
//                    obj_generalInformation.pageLoading();
                    break;
                case "AutoRenew":
                    if ((paymentScreenElements.get(paymentScreenQuestion)).equalsIgnoreCase("Yes")) {
                        obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.understoodRadiobutton());
                        obj_generalInformation.pageLoading();
                        obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.paymentScreenNextButton());
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.renewRadiobutton());
                        obj_generalInformation.pageLoading();
                        obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.understoodRadiobutton());
                        obj_generalInformation.pageLoading();
                        obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.paymentScreenNextButton());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "DirectDebit":
                    String directDebitValues[] = paymentScreenElements.get(paymentScreenQuestion).split(":");
                    for (int i = 0; i < 1; i++) {
                        obj_directDebit.executeScript("arguments[0].click()", obj_directDebit.directdebitYesRadiobutton());
                        obj_generalInformation.pageLoading();
                        obj_directDebit.sortCodeTextbox().click();
                        obj_directDebit.sortCodeTextbox().sendKeys(directDebitValues[i]);
                        obj_generalInformation.pageLoading();
                        obj_directDebit.accountNumberTextbox().click();
                        obj_directDebit.accountNumberTextbox().sendKeys(directDebitValues[i + 1]);
                        obj_generalInformation.pageLoading();
                        obj_directDebit.installmentdayTextbox().click();
                        obj_directDebit.installmentdayTextbox().sendKeys(directDebitValues[i + 2]);
                        obj_generalInformation.pageLoading();
                        obj_directDebit.executeScript("arguments[0].click();", obj_directDebit.paymentInformationNextButton());
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "PaymentInformation":
                    obj_paymentInformation.cardBelongsToYesRadiobutton().click();
                    obj_generalInformation.pageLoading();
                    obj_paymentInformation.cardPermissionYesRadiobutton().click();
                    obj_generalInformation.pageLoading();
                    obj_paymentInformation.cardHolderNameTextbox().click();
                    obj_paymentInformation.cardHolderNameTextbox().sendKeys("Smokecard");
                    obj_commonUtil.tabKeypress();
                    obj_generalInformation.pageLoading();
                    obj_paymentInformation.billingAddressYesRadiobutton().click();
                    obj_generalInformation.pageLoading();
                    obj_paymentInformation.executeScript("arguments[0].click();", obj_paymentInformation.PaymentInfoNextButton());
                    obj_generalInformation.pageLoading();
                    break;
                case "CardDetails":
                    String cardDetailsValues[] = paymentScreenElements.get(paymentScreenQuestion).split(":");
                    for (int i = 0; i < 1; i++) {
                        obj_commonUtil.switchFrame("wp-cl-custom-html-iframe");
                        obj_cardDetails.cardNumberTextbox().sendKeys(cardDetailsValues[i]);
                        obj_generalInformation.pageLoading();
                        obj_cardDetails.cardExpiryMM(cardDetailsValues[i + 1]).click();
                        obj_generalInformation.pageLoading();
                        obj_cardDetails.cardExpiryYYYY(cardDetailsValues[i + 2]).click();
                        obj_generalInformation.pageLoading();
                        obj_cardDetails.cardVerificationCodeTextbox().sendKeys(cardDetailsValues[i + 3]);
                        obj_generalInformation.pageLoading();
                        obj_cardDetails.executeScript("arguments[0].click()", obj_cardDetails.sppContinueButton());
                        obj_generalInformation.pageLoading();
                        Thread.sleep(5000);
                        getDriver.switchTo().defaultContent();
                        obj_cardDetails.confirmationPaymentpage();
                        policyNumberMegaScript = obj_cardDetails.policyNumberFetch().getText();
//                        scenario.write(policyNumberMegaScript);
                    }
                    break;
                case "PaymentOptionPageDocument":
                    if (paymentScreenElements.get(paymentScreenQuestion).equalsIgnoreCase("PdfQuoteSummary")) {
                        obj_paymentSelection.pdfQuoteSummaryLink().click();
                        obj_generalInformation.pageLoading();
//                        obj_paymentSelection.pdfSaveIcon().click();
//                        for (String winHandle : getDriver.getWindowHandles()) {
//                            WebDriver getDriverTitle = getDriver.switchTo().window(winHandle);
//                        }
                    } else if (paymentScreenElements.get(paymentScreenQuestion).equalsIgnoreCase("PdfKeyFacts")) {
                        obj_paymentSelection.pdfKeyFactsLink().click();
                        obj_generalInformation.pageLoading();
                    } else if (paymentScreenElements.get(paymentScreenQuestion).equalsIgnoreCase("PdfSOF")) {
                        obj_paymentSelection.pdfSOFLink().click();
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_paymentSelection.pdfPolicyWordingLink().click();
                        obj_generalInformation.pageLoading();
                    }
                    break;
                case "PaymentConfirmationPageDocument":
                    if (paymentScreenElements.get(paymentScreenQuestion).equalsIgnoreCase("PdfPolicySchedule")) {
                        obj_cardDetails.executeScript("arguments[0].click()", obj_cardDetails.paymentConfirmationPolicySchedulePdf());
                        obj_generalInformation.pageLoading();
                    } else if (paymentScreenElements.get(paymentScreenQuestion).equalsIgnoreCase("PdfKeyFacts")) {
                        obj_cardDetails.executeScript("arguments[0].click()", obj_cardDetails.paymentConfirmationKeyFactsPdf());
                        obj_generalInformation.pageLoading();
                    } else if (paymentScreenElements.get(paymentScreenQuestion).equalsIgnoreCase("PdfSOF")) {
                        obj_cardDetails.executeScript("arguments[0].click()", obj_cardDetails.paymentConfirmationSOFPdf());
                        obj_generalInformation.pageLoading();
                    } else if (paymentScreenElements.get(paymentScreenQuestion).equalsIgnoreCase("PdfPolicyWording")) {
                        obj_cardDetails.executeScript("arguments[0].click()", obj_cardDetails.paymentConfirmationPolicyWordingPdf());
                        obj_generalInformation.pageLoading();
                    } else if (paymentScreenElements.get(paymentScreenQuestion).equalsIgnoreCase("PdfPPLCertificate")) {
                        obj_cardDetails.executeScript("arguments[0].click()", obj_cardDetails.paymentConfirmationPPLCertificatePdf());
                        obj_generalInformation.pageLoading();
                    } else {
                        obj_cardDetails.executeScript("arguments[0].click()", obj_cardDetails.paymentConfirmationCOCPdf());
                        obj_generalInformation.pageLoading();
                    }
                    break;
            }
        }

    }

    public void fillCCCreateContactWithSpecificPostcode(String postcode) throws Throwable {
        if (!postcode.equalsIgnoreCase("null")) {
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.createNewCustomerButton());
            obj_generalInformation.pageLoading();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.corporateContact());
            strBusinessName = obj_generalInformationUtil.randomBusinessName();
            obj_createCustomer.tradeNametextbox().sendKeys(strBusinessName);
            new Select(obj_createCustomer.addressTypeButton()).selectByVisibleText("Business");
            new Select(obj_createCustomer.countryTextbox()).selectByVisibleText("Scotland");
            obj_generalInformation.pageLoading();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.postCodeTextbox());
            Thread.sleep(1000);
            obj_createCustomer.postCodeTextbox().sendKeys(postcode);
            obj_generalInformation.pageLoading();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.findAddressButton());
            obj_generalInformation.ccpageLoading();
            Select address = new Select(obj_createCustomer.selectAddressDropdown());
            List<WebElement> addressVal = address.getOptions();
            addressVal.get(0).click();
            obj_createCustomer.address1Textbox();
            obj_generalInformation.ccpageLoading();
            new Select(obj_createCustomer.titleContactDetailsDropdown()).selectByVisibleText("Mr");
            obj_generalInformation.pageLoading();
            strFirstName = obj_generalInformationUtil.randomFirstName();
            obj_createCustomer.firstnameContactDetailsTextbox().sendKeys(strFirstName);
            obj_generalInformation.pageLoading();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.lastnameContactDetailstextbox());
            obj_generalInformation.pageLoading();
            strSecondName = obj_generalInformationUtil.randomSecondName();
            obj_createCustomer.lastnameContactDetailstextbox().sendKeys(strSecondName);
            obj_generalInformation.pageLoading();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.mobileBusinessTextbox());
            obj_generalInformation.pageLoading();
            obj_createCustomer.authorisedContactMobile().sendKeys("07466734846");
            obj_commonUtil.tabKeypress();
            strEmail = createAccountUtil.randomemail();
            obj_createCustomer.authorisedContactEmail().sendKeys(strEmail);
            obj_commonUtil.tabKeypress();
            obj_createCustomer.mobileBusinessTextbox().sendKeys("07466734846");
            obj_generalInformation.pageLoading();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.emailBusinessTextbox());
            Thread.sleep(1000);
            obj_createCustomer.emailBusinessTextbox().sendKeys(strEmail);
            obj_createCustomer.waitForPageLoad();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.marketingPreferenceNoRadiobutton());
            obj_generalInformation.pageLoading();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.correspondenceByMailRadiobutton());
            obj_generalInformation.pageLoading();
            obj_createCustomer.smsNotificationCheckbox().click();
            obj_generalInformation.pageLoading();
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.saveButtonButton());
            Thread.sleep(2000);
            obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.newQuoteButton());
            obj_generalInformation.pageLoading();
            Thread.sleep(2000);
            obj_commonUtil.switchFrame("sagepay");
        }
    }

    public float quoteSummeryPremiumCapture() {
        //commented by rao on 24Aug
        //obj_generalInformation.pageLoading();
        String premium = obj_quoteSummary.totalPremiumText().getText();
        String premiumValue[] = premium.split("£");
        String PremiumNumber = premiumValue[1];
        String premiumNum[] = PremiumNumber.split("[\\r\\n]+");
        float f = Float.parseFloat(premiumNum[0]);
        return f;
    }

    public void userSearchPolicyinCC(String searchbusiness) throws Throwable {
        if (!searchbusiness.equalsIgnoreCase("null")) {
            obj_coverwizard.searchbusinessTextbox().sendKeys(strBusinessName);
        } else {
            ccsearchUtil.setSearchvalue(CarddetailsUtil.policyno, ccSearch.policyNumberTextbox());
        }
        ccSearch.searchButton().click();
        ccSearch.ccPageLoad();
        ccSearch.policySelectionLink().click();
        ccSearch.ccPageLoad();
        ccSearch.authorizContanctselectionLink().click();
        ccSearch.ccPageLoad();
        ccSearch.passedVerificaitionButton().click();
        ccSearch.ccPageLoad();
    }


    public void coversInMoreOptions(String covers) throws Throwable {
        int f = 0;
        int sizeT;
        String actualValue = null;
        Thread.sleep(5000);
        if (obj_quoteSummary.coverYouHaveChosenPage().size() > 0) {
            Premium1 = quoteSummeryPremiumCapture();
        }
        String[] coverValue = covers.split("&");
        for (int iteration = 0; iteration < coverValue.length; iteration++) {
            LinkedHashMap<String, String> coverElement = new LinkedHashMap<String, String>();
            String[] coverField = coverValue[iteration].split("#");
            for (int a = 1; a <= coverField.length; a++) {
                String[] coverQSvalues = coverField[a - 1].split(";");
                coverElement.put(coverQSvalues[0], coverQSvalues[1]);
            }
            List<String> coversQS = new ArrayList<>(coverElement.keySet());
            for (String questions : coversQS) {
                switch (questions) {
                    case "Treatment":
                        if (obj_treatments.moreOptionTreatment().isDisplayed()) {
                            Assert.assertTrue("Treatment is present in more options", true);
                        } else {
                            Assert.assertTrue("Treatment is not present in more options", false);
                        }
                        break;
                    case "BI third party":
                        if (thirdPartyBI.moreOptionBIThirdParty().isDisplayed()) {
                            Assert.assertTrue("thirdPartyBI is present in more options", true);
                        } else {
                            Assert.assertTrue("thirdPartyBI is not present in more options", false);
                        }
                        break;
                    case "BI":
                        if (obj_businessInterruption.moreOptionBI().isDisplayed()) {
                            Assert.assertTrue("BI is present in more options", true);
                        } else {
                            Assert.assertTrue("BI is not present in more options", false);
                        }
                        break;
                    case "AddBI":
                        if (obj_businessInterruption.moreOptionBI().isDisplayed()) {
                            String BIvalues[] = coverElement.get(questions).split("=");
                            HashMap<String, String> BIelements = new LinkedHashMap<String, String>();
                            for (int i = 1; i <= BIvalues.length; i++) {
                                String[] BIInput = BIvalues[i - 1].split(":");
                                BIelements.put(BIInput[0], BIInput[1]);
                            }
                            List<String> valueBIinQS = new ArrayList<>(BIelements.keySet());
                            for (String BIQuestions : valueBIinQS) {

                                switch (BIQuestions) {
                                    case "Add":
                                        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.moreOptionAddBI());
                                        obj_generalInformation.pageLoading();
                                        break;
                                    case "TurnoverValue":
                                        obj_businessInterruption.moreOptionAddBIGrossTurnover().sendKeys(BIelements.get(BIQuestions));
                                        obj_propertyAway.pageLoading();
                                        break;
                                    case "TurnoverMonth":
                                        obj_businessInterruption.moreOptionAddBIMonths().sendKeys(BIelements.get(BIQuestions));
                                        obj_propertyAway.pageLoading();
                                        break;
                                    case "AddToQuote":
                                        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.moreOptionAddBIAddToQuote());
                                        obj_generalInformation.pageLoading();
                                        break;
                                }

                            }
                        }

                        break;
                    case "TOT":
                        if (obj_theftOfTakings.moreOptionTOT().isDisplayed()) {
                            Assert.assertTrue("TOT is Present", true);
                        } else {
                            Assert.assertTrue("TOT is not present", false);
                        }
                        break;
                    case "CoversPresentOrNotQuoteSummary":
                        //Checking whether the particular cover is present or not in QuoteSummary Page -Format CoversNotPresentQuoteSummary;Professional Liability:Present#Employers:Notpresent

                        String[] coverOptions = coverElement.get(questions).split("#");
                        for (int qs = 0; qs < coverOptions.length; qs++) {

                            String[] options = coverOptions[qs].split(":");

//                            switch (options[0]){
//
//                                case "Professional Liability":

                            if (options[1].equalsIgnoreCase("Present")) {

                                if (obj_quoteSummary.coversPresentOrNot(options[0]).size() != 0) {

                                    Assert.assertTrue("Cover is Present", true);
                                } else {
                                    Assert.assertTrue("Cover is not Present", false);
                                }
                            } else if (options[1].equalsIgnoreCase("NotPresent")) {

                                if (!obj_quoteSummary.coversPresentOrNot(options[0]).get(0).isDisplayed()) {

                                    Assert.assertTrue("Cover is not Present", true);
                                } else {
                                    Assert.assertTrue("Cover is Present", false);
                                }
                            } else {
                                Assert.assertTrue("Wrong input given", false);
                            }

//                                   break;


//                            }

                        }

                        break;
                    case "addTOT":
                        if (obj_theftOfTakings.moreOptionTOT().isDisplayed()) {
                            String TOTvalues[] = coverElement.get(questions).split("=");
                            HashMap<String, String> TOTelements = new LinkedHashMap<String, String>();
                            for (int i = 1; i <= TOTvalues.length; i++) {
                                String[] TOTInput = TOTvalues[i - 1].split(":");
                                TOTelements.put(TOTInput[0], TOTInput[1]);
                            }
                            List<String> valueTOTinQS = new ArrayList<>(TOTelements.keySet());
                            for (String TOTQuestions : valueTOTinQS) {

                                switch (TOTQuestions) {
                                    case "TOT":
                                        obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.moreOptionaddTOT());
                                        obj_generalInformation.pageLoading();
                                        break;
                                    case "TOTValue":
                                        obj_theftOfTakings.moreOptionaddTOTDropdown().sendKeys(TOTelements.get(TOTQuestions));
                                        obj_propertyAway.pageLoading();
                                        break;
                                    case "AddToQuote":
                                        obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.moreOptionaddTOTAddToQuote());
                                        obj_generalInformation.pageLoading();
                                        break;
                                }

                            }
                        }
                        break;
                    case "TheftOfTakingAccordian":
                        String nameAccordion4 = obj_businessPremises.totAccordian().get(0).getText();
                        if (obj_businessPremises.totAccordian().get(0).isDisplayed() && nameAccordion4.equals("Theft of takings")) {
                            Assert.assertTrue("Accordion present", true);
                        } else {
                            Assert.assertTrue("Accordion not present", false);
                        }
                        break;

                    case "addCLE":
                        String Legalvalues[] = coverElement.get(questions).split("&");
                        HashMap<String, String> LegalElements = new LinkedHashMap<String, String>();
                        for (int i = 1; i <= Legalvalues.length; i++) {
                            String[] LegalInput = Legalvalues[i - 1].split(":");
                            LegalElements.put(LegalInput[0], LegalInput[1]);
                        }
                        List<String> valueLegalinQS = new ArrayList<>(LegalElements.keySet());
                        for (String LegalQuestions : valueLegalinQS) {
                            switch (LegalQuestions) {
                                case "LegalExpense":
                                    new Select(obj_quoteSummary.legalExpencesDropdown()).selectByVisibleText(LegalElements.get(LegalQuestions));
                                    obj_generalInformation.pageLoading();
                                    break;
                                case "AddButton":
                                    obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.legalExpencesaddButton());
                                    obj_generalInformation.pageLoading();
                                    break;
                            }
                        }
                        break;
                    case "CrossSellDiscount":
                        float Premium01 = quoteSummeryPremiumCapture();
                        obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.crossSellDiscount());
                        obj_generalInformation.pageLoading();
                        break;
                    case "GoBackEdit":
                        //Clicking the gobackandEdit button if quote is declined
                        obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.goBackAndEditTheQuote());
                        obj_generalInformation.pageLoading();
                        break;

                    case "GoBackButton":
                        //Clicking the back button in Quote Summary
                        obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.quoteSummaryBackbutton());
                        obj_generalInformation.pageLoading();

                        break;

                    case "ProfessionalLibilityAccordionNotPresent":
                        //Validating whether ProfessionalLibilityAccordion is present or not
                        sizeT = obj_professionalLiability.eleAccordionProfLiability().size();
                        if (sizeT == 0) {
                            Assert.assertTrue("ProfessionalLibilityAccordion is not present", true);
                        } else {
                            Assert.assertTrue("ProfessionalLibilityAccordion is present", false);
                        }
                        break;

                    case "ProfessionalLibilityAccordionPresent":

                        sizeT = obj_professionalLiability.eleAccordionProfLiability().size();
                        if (sizeT != 0) {
                            Assert.assertTrue("ProfessionalLibilityAccordion is present", true);
                        } else {
                            Assert.assertTrue("ProfessionalLibilityAccordion is not present", false);
                        }
                        break;

                    case "TreatmentAccordionNotPresent":
                        sizeT = obj_treatments.eleAccordionTreatment().size();
                        if (sizeT == 0) {
                            Assert.assertTrue("Treatment screen not present", true);
                        } else {
                            Assert.assertTrue("Treatment screen present", false);
                        }
                        break;
                    case "BIThirdPartyAccordionNotPresent":
                        sizeT = thirdPartyBI.eleAccordionBITP().size();
                        if (sizeT == 0) {
                            Assert.assertTrue("Business Interruption @ 3rd party screen not present", true);
                        } else {
                            Assert.assertTrue("Business Interruption @ 3rd party screen present", false);
                        }
                        break;
                    case "BIAccordionNotPresent":
                        sizeT = obj_businessInterruption.eleAccordionBI().size();
                        if (sizeT == 0) {
                            Assert.assertTrue("Business Interruption screen not present", true);
                        } else {
                            Assert.assertTrue("Business Interruption screen present", false);
                        }
                        break;
                    case "TOTAccordionNotPresent":
                        sizeT = obj_theftOfTakings.eleAccordionTOT().size();
                        if (sizeT == 0) {
                            Assert.assertTrue("Theft of taking screen not present", true);
                        } else {
                            Assert.assertTrue("Theft of taking screen present", false);
                        }
                        break;
                    case "Business Premises":
                        String nameAccordion = obj_businessPremises.premisesAccorion(covers).getText();
                        if (obj_businessPremises.premisesAccorion(covers).isDisplayed() && nameAccordion.equals("Business Premises")) {
                            Assert.assertTrue("Accordion present", true);
                        } else {
                            Assert.assertTrue("Accordion not present", false);
                        }
                        break;
                    case "Business Property":
                        String nameAccordion1 = obj_businessPremises.commonAccordion(covers).getText();
                        if (obj_businessPremises.commonAccordion(covers).isDisplayed() && nameAccordion1.equals("Business Property")) {
                            Assert.assertTrue("Accordion present", true);
                        } else {
                            Assert.assertTrue("Accordion not present", false);
                        }
                        break;
                    case "Property away from the premises":
                        String nameAccordion2 = obj_businessPremises.commonAccordion(covers).getText();
                        if (obj_businessPremises.commonAccordion(covers).isDisplayed() && nameAccordion2.equals("Property away from the premises")) {
                            Assert.assertTrue("Accordion present", true);
                        } else {
                            Assert.assertTrue("Accordion not present", false);
                        }
                        break;
                    case "Add Property away from the premises":
                        if (obj_businessPremises.accordionPA().isDisplayed()) {
                            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.accordionPA());
                            obj_generalInformation.pageLoading();
                            String PAPvalues[] = coverElement.get(questions).split("=");
                            HashMap<String, String> PAPElements = new LinkedHashMap<String, String>();
                            for (int i = 1; i <= PAPvalues.length; i++) {
                                String[] PAPInput = PAPvalues[i - 1].split(":");
                                PAPElements.put(PAPInput[0], PAPInput[1]);
                            }
                            List<String> valuePAPinQS = new ArrayList<>(PAPElements.keySet());
                            for (String PAPQuestions : valuePAPinQS) {

                                switch (PAPQuestions) {
                                    case "Stock":
                                        obj_propertyAway.propertyAwayBusinessStockInQS().sendKeys(PAPElements.get(PAPQuestions));
                                        obj_generalInformation.pageLoading();
                                        break;
                                    case "AddToQuote":
                                        obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.PropertyAwayBusinessStockInQSAddtoQuote());
                                        obj_generalInformation.pageLoading();
                                        break;
                                }
                            }
                        }
                        break;
                    case "AccordionNotPresent":  //Premises
                        int size = obj_businessPremises.commonAccordionNotPresent().size();
                        if (size == 0) {
                            Assert.assertTrue("Accordion not present", true);
                        } else if (size > 0) {
                            Assert.assertTrue("Accordion preset", false);
                        }
                        break;
                    case "Your liability cover":
                        String nameAccordion3 = obj_businessPremises.plAccordion().get(0).getText();
                        if (obj_businessPremises.plAccordion().get(0).isDisplayed() && nameAccordion3.equals("Your liability cover")) {
                            Assert.assertTrue("Accordion present", true);
                        } else {
                            Assert.assertTrue("Accordion not present", false);
                        }
                        break;
                    case "YourLiabilityCoverNotPresent":
                        if (!obj_businessPremises.plAccordion().get(0).isDisplayed()) {
                            Assert.assertTrue("Accordion not present", true);
                        } else {
                            Assert.assertTrue("Accordion present", false);
                        }
                        break;


                    case "IncreaseInPremium":
                        float Premium2 = quoteSummeryPremiumCapture();
//                        System.out.println(Premium1);
//                        System.out.println(Premium2);
                        Assert.assertThat("Premium is increased after adding additional cover", Premium2, greaterThan(Premium1));
                        break;

                    case "PolicyLevelCoverCheck":
                        cover = coverElement.get(questions).split(":");
                        for (String coverEle : cover) {

                            switch (coverEle) {
                                // Validating the Professional Liablity under PolicyLevelCover Section on QuoteSummary
                                case "Professional Indemnity":
                                    String pl = obj_quoteSummary.professionalLiabilitypolicyLevelCovers(coverEle).get(0).getText();
                                    String[] plcover = pl.split("\n");
                                    //Validating the Professional Liability label
                                    if (plcover[0].equalsIgnoreCase("Professional Indemnity")) {
                                        Assert.assertTrue("Professional Indemnity label is present", true);
                                    } else {
                                        Assert.assertTrue("Professional Indemnity label is not present", false);
                                    }
                                    //Validating the excess amount
                                    if (pl.contains("Excess")) {
                                        if (plcover[12].contains("£")) {
                                            String[] excess = plcover[12].split("£");
                                            if (Integer.parseInt(excess[1]) != 0) {
                                                Assert.assertTrue("Excess amount is present", true);
                                            }
                                        } else {
                                            Assert.assertTrue("Excess amount is not present", false);
                                        }

                                    } else {
                                        if (plcover[11].contains("£")) {
                                            String[] excess = plcover[11].split("£");
                                            if (Integer.parseInt(excess[1]) != 0) {
                                                Assert.assertTrue("Excess amount is present", true);
                                            }
                                        } else {
                                            Assert.assertTrue("Excess amount is not present", false);
                                        }
                                    }

                                    //Validating the Annaul price amount
                                    if (pl.contains("Annual")) {
                                        String[] coverPremium = plcover[14].split("£");
                                        if (!coverPremium[1].equalsIgnoreCase("0.00")) {
                                            Assert.assertTrue("Premium amount is present", true);
                                        } else {
                                            Assert.assertTrue("Premium amount is displaying as 0.00", false);
                                        }
                                    } else {
                                        String[] coverPremium = plcover[12].split("£");
                                        if (!coverPremium[1].equalsIgnoreCase("0.00")) {
                                            Assert.assertTrue("Premium amount is present", true);
                                        } else {
                                            Assert.assertTrue("Premium amount is displaying as 0.00", false);
                                        }
                                    }


                                    break;


                            }
                        }


                        break;

                    case "RemoveCoverInQS":
//                        String[] options = coverElement.get(questions).split(":");
                        if (obj_quoteSummary.policyLevelprofessionalLiabilityBinButton().size() != 0) {
                            obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.policyLeveBinButton());
                            //Validating the Warning message
                            if (obj_quoteSummary.coverPopupWarningMsg().getText().equalsIgnoreCase("Are you sure you want to remove this?")) {
                                Assert.assertTrue("Popup Warning mesasge is present", true);
                            } else {
                                Assert.assertTrue("Popup Warning mesasge is not match", false);
                            }
//                            obj_quoteSummary.executeScript("arguments[0].click();",obj_quoteSummary.coverPopup(options[1]).get(0));
                            obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.removeYES());
                            obj_generalInformation.pageLoading();
                            Assert.assertTrue("Cover is removed in QuoteSummary", true);
                        } else {
                            Assert.assertTrue("BinButton is not present", false);
                        }

                        break;
                    case "ProfessionalLiablityHT":

                        strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_quoteSummary.professionalHelpText());
                        strHelpText = "Covers your business if your clients lose money or their business' reputation is damaged as a result of mistakes in advice, designs or services that you supply.We'll cover any compensation due and your legal costs for defending the claim.";
                        Assert.assertTrue("ProfessionalLiablityHT is displayed in QuoteSummary PolicyLevelCover", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                        break;
                    case "PublicLiablityHT":

                        strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_quoteSummary.publicLiabilityHelpText());
                        strHelpText = "CoversyourlegalliabilityforcompensationawardedtoaclaimantinconnectionwithyourbusinessforaccidentaldamagetopropertythatdoesntbelongtoyouaccidentalinjurytoyourguestsvisitorspeopleyouvisitandmembersofthepublicThiswouldincludethingslikeslipsandtrips";
                        Assert.assertTrue("PublicLiablityHT is displayed", strHelpText.equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "").replace("'", "").replace(":", "").replace("-", "").replace(".", "")));
                        break;

                    case "ProfessionalLiabilityLimitChange":

                        String limitValues[] = coverElement.get(questions).split(":");
                        for (String limit : limitValues) {

                            String beforePremium = obj_quoteSummary.professionalLiabilityPremium().getText();
                            new Select(obj_quoteSummary.professionalLiabilityLimitDrpDown()).selectByVisibleText(limit);
                            obj_generalInformation.pageLoading();

                            //If getting referral message or not
                            if (obj_quoteSummary.referralMsg().size() == 0) {
                                Assert.assertTrue("Referral message is not displayed", true);
                                String pl = obj_quoteSummary.professionalLiabilitypolicyLevelCovers("Professional Indemnity").get(0).getText();
                                String[] premium = pl.split("\n");
                                //Validating whether premium will change or not after changing the limit
                                if (!premium[12].equalsIgnoreCase(beforePremium)) {
                                    Assert.assertTrue("Premium amount got changed based on the limit", true);
                                } else {
                                    Assert.assertTrue("Premium amount not changed based on the limit", false);
                                }
                            }

                        }

                        break;

                    case "CoversPresentInMoreOptions":
                        //Validating particular covers are present or not under More Option
                        cover = coverElement.get(questions).split(":");
                        obj_quoteSummary.waitForPageLoad();
                        for (String coverName : cover) {
                            if (obj_quoteSummary.moreOptionsNoCovers().get(0).getText().contains(coverName)) {
                                Assert.assertTrue("cover present in More Options", true);
                            } else {
                                Assert.assertTrue("cover not present in More Options", false);
                            }

                        }


                        break;

                    case "ProfessionalLiabilityViaMoreOptions":
                        //Clicking the Enter Details link in Professional Liability under More Options then fills the PL accordion
                        String[] value = coverElement.get(questions).split("@");
                        if (value[0].equalsIgnoreCase("EnterDetails")) {
                            obj_quoteSummary.executeScript("arguments[0].click()", obj_quoteSummary.profLiabilityEnterDetails().get(0));
                        } else if (value[0].equalsIgnoreCase("PlusButton")) {
                            obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.profLiabilityPlusButton());
                        } else {
                            Assert.assertTrue("None of the Options are matched", false);
                        }
                        obj_generalInformation.pageLoading();
                        //Calling to fill specific accordion and traverse till quote summary
                        fillRetriveSection(value[1].replace(":", ";").replace("%", "#").replace("^", ":"), 1);
                        break;
                    case "PublicLiabilityViaMoreOptions":
                        new Select(obj_quoteSummary.publicLiabilityLimit()).selectByVisibleText(coverElement.get(questions));
                        obj_generalInformation.pageLoading();
                        obj_quoteSummary.executeScript("arguments[0].click()", obj_quoteSummary.publicLiabilityAdd());
                        obj_generalInformation.pageLoading();
                        break;

                    case "GoBackFillAllAccordion":
                        fillRetriveSection(coverElement.get(questions).replace(":", ";").replace("%", "#"), 1);
                        break;

                    case "SaveAndExit":
                        obj_quoteSummary.executeScript("arguments[0].click()", obj_quoteSummary.SaveAndExit());
                        obj_generalInformation.pageLoading();
                        saveandExit();
                        break;

                    case "removeBI":
                        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.removeBI());
                        obj_generalInformation.pageLoading();
                        obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.removeYES());
                        obj_generalInformation.pageLoading();
                        obj_quoteSummary.totalPremiumText();
//                        Thread.sleep(5000);
                        break;

                    case "removeTOT":
                        obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.removeTOT());
                        obj_generalInformation.pageLoading();
                        obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.removeYES());
                        obj_generalInformation.pageLoading();
                        break;

                    case "RemovePPLCover":
                        obj_businessInterruption.executeScript("arguments[0].click();", obj_quoteSummary.publicLiabilityBinBtn());
                        obj_generalInformation.pageLoading();
                        obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.removeYES());
                        obj_generalInformation.pageLoading();
                        break;

                    case "removeCLE":
                        obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.removeCLE());
                        obj_generalInformation.pageLoading();
                        obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.removeYES());
                        obj_generalInformation.pageLoading();
                        break;
                    case "removeEL":
                        obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.removeEL());
                        obj_generalInformation.pageLoading();
                        obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.removeYES());
                        obj_generalInformation.pageLoading();
                        break;
                    case "removeBusinessContentsAndStock":
                        obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.removeContentsAndStock());
                        obj_generalInformation.pageLoading();
                        obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.removeYES());
                        obj_generalInformation.pageLoading();
                        break;
                    case "DecreaseInPremium":
                        float Premium3 = quoteSummeryPremiumCapture();
//                    System.out.println(Premium01);
//                    System.out.println(Premium3);
                        Assert.assertThat("Premium is decreased after removing covers", Premium3, lessThan(Premium1));
                        break;
                    case "GINext":
                        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
                        obj_generalInformation.pageLoading();
                        break;
                    case "PeopleNext":
                        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
                        obj_generalInformation.pageLoading();
                        break;
                    case "PPLNext":
                        if (!coverElement.get(questions).equalsIgnoreCase("Yes")) {
                            new Select(obj_liabilitycover.public_LiabilitycoverDropdown()).selectByValue(coverElement.get(questions));
                            obj_generalInformation.pageLoading();
                        }
                        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.liabilityCoverNextButton());
                        obj_generalInformation.pageLoading();
                        break;
                    case "PremisesNext":
                        if (!coverElement.get(questions).equalsIgnoreCase("Yes")) {
                            obj_businessPremises.businessContentValueTextbox(1).clear();
                            obj_businessPremises.businessContentValueTextbox(1).sendKeys(coverElement.get(questions));
                            obj_commonUtil.tabKeypress();
                            obj_generalInformation.pageLoading();
                        }
                        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.nextButton());
                        obj_generalInformation.pageLoading();
                        break;
                    case "PANext":
                        if (!coverElement.get(questions).equalsIgnoreCase("Yes")) {
                            obj_propertyAway.businessToolsEquipmentValueTextbox().clear();
                            obj_propertyAway.businessToolsEquipmentValueTextbox().sendKeys(coverElement.get(questions));
                            obj_propertyAway.pageLoading();
                        }
                        obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.nextButton());
                        obj_propertyAway.pageLoading();
                        break;
                    case "ISNext":
                        obj_importantstatement.executeScript("arguments[0].click()", obj_importantstatement.importantStatNextButton());
                        obj_generalInformation.pageLoading();
                        break;
                    case "GetQuote":
                        obj_claims.executeScript("arguments[0].click()", obj_claims.getQuoteButton());
                        obj_generalInformation.pageLoading();
                        break;
                    case "ReviewAndConfirm":
                        obj_quoteSummary.coverYouHaveChosen();
                        obj_quoteSummary.executeScript("arguments[0].click()", obj_quoteSummary.reviewConfirmButton());
                        obj_generalInformation.pageLoading();
                        break;
                    case "UpdateContentSumInsured": //Can be used for both business tools and equipments and business content and stock
                        obj_quoteSummary.editPAContentLimit().clear();
                        obj_quoteSummary.editPAContentLimit().sendKeys(coverElement.get(questions));
                        editedValue = obj_quoteSummary.editPAContentLimit().getText();
                        obj_commonUtil.tabKeypress();
                        obj_generalInformation.pageLoading();
                        break;
                    case "ReferDecline":
                        if (coverElement.get(questions).equalsIgnoreCase("Yes")) {
                            LOG.info("Policy quoted successfully");
                        } else {
                            String strText = obj_quoteSummary.referralMsgTextOverAll().getText();
                            String expText = coverElement.get(questions).replace(" ", "").replace(",", "").replace("-", "").replace(".", "").replace("'", "").replace("\n", "");
                            String actText = strText.replace(" ", "").replace(",", "").replace("-", "").replace(".", "").replace("'", "").replace("\n", "");
                            Assert.assertTrue("Required referral message is displayed", expText.equals(actText));
                        }
                        break;
                    case "PAPValidation":
                        actualValue = obj_propertyAway.businessToolsEquipmentValueTextbox().getText();
                        if (editedValue.equalsIgnoreCase(actualValue)) {
                            Assert.assertTrue("Updated sum insured is reflected in User Journey", true);
                        } else {
                            Assert.assertTrue("Updated sum insured is not reflected in User Journey", false);
                        }
                        break;
                    case "GITrageChangeNext":
                        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.changeTrade());
                        obj_generalInformation.pageLoading();
                        obj_generalInformation.businessTradeTextBox().sendKeys(coverElement.get(questions));
                        obj_generalInformation.pageLoading();
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.addMultipleTradeNameSelect(coverElement.get(questions)));
                        obj_generalInformation.pageLoading();
                        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
                        obj_generalInformation.pageLoading();
                        break;
                    case "UpdatePublicLiabilityLimit":
//                        obj_commonUtil.switchFrame("sagepay");
                        Thread.sleep(5000);
                        new Select(obj_quoteSummary.publicLiabilityDropDown()).selectByValue(coverElement.get(questions));
                        obj_generalInformation.pageLoading();
                        break;
                    case "GoBackEditButton":
                        //Clicking the go back & edit button in Quote Summary
                        obj_quoteSummary.executeScript("arguments[0].click();", obj_quoteSummary.goBackAndEditTheQuote());
                        obj_generalInformation.pageLoading();
                        break;
                    case "YourQuoteBreadcrumb":
                        if ((coverElement.get(questions)).equalsIgnoreCase("Y")) {
                            obj_quoteSummary.executeScript("arguments[0].click()", obj_quoteSummary.YourQuoteBreadcrumb());
                            obj_generalInformation.pageLoading();
                        }
                        break;
                    case "YourBusinessBreadcrumb":
                        if ((coverElement.get(questions)).equalsIgnoreCase("Y")) {
                            obj_quoteSummary.executeScript("arguments[0].click()", obj_quoteSummary.YourBusinessBreadcrumb());
                            obj_generalInformation.pageLoading();
                        }
                        break;
                    case "QSPLHelpText":
                        strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_quoteSummary.qsPLHelpText());
                        strHelpText = "Covers your legal liability for compensation awarded to a claimant in connection with your business for:- accidental damage to property that doesn't belong to you- accidental injury to your guests, visitors, people you visit and members of the public. This would include things like slips and trips.This cover comes as standard on all our policies. ";
                        Assert.assertTrue("BedRoomHT is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                        break;
                    case "QSGlassHelpText":
                        obj_quoteSummary.premiseTabOne().click();
                        strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_quoteSummary.qsGlassHelpText());
                        strHelpText = "The cover includes all fixed glass, blinds and signs.";
                        Assert.assertTrue("BedRoomHT is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                        break;
                    case "QSBusinessContnentStockHelpText":
                        strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_quoteSummary.qsBusinessContnentStockHelpText());
                        strHelpText = "This covers contents used for your business, such as beds, curtains, linen, wardrobes and dressing tables in guest bedrooms, plus computers etc you use in running your business. As standard, we’ll extend your cover to include equipment breakdown, which pays to repair or replace things like washer dryers and fridge freezers (excludes wear and tear).\nStock is things like food, beers and toiletries you provide for your guests.\nWhen deciding on how much insurance you need, you should use the amount it'd cost to buy new replacements.";
                        Assert.assertTrue("BedRoomHT is displayed", strText.equalsIgnoreCase(strHelpText));
                        break;
                    case "QSWinesSpiritHelpText":
                        strText = (String) getDriver.executeScript("return arguments[0].innerText", obj_quoteSummary.qsWinesSpiritHelpText());
                        strHelpText = "You should only include wines and spirits you provide for your guests.";
                        Assert.assertTrue("BedRoomHT is displayed", strHelpText.replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "").replace(",", "")));
                        break;
                    case "PremiumComparisonCC":
                        Assert.assertThat("Comparing WJ premium and CC Premium", Premium1, equalTo(Premium4));
                        break;
                    case "PremiumCaptureWJ":
                        Premium1 = quoteSummeryPremiumCapture();
                        break;
                    case "PremiumCaptureCC":
                        Premium4 = ccPremiumCapture();
                        break;
                }
            }
        }
    }


    public float ccPremiumCapture() {
        //commented by rao on 24Aug
        //obj_generalInformation.pageLoading();
        String premium = ccSearch.cctotalPremiumText().getText();
        String premiumValue[] = premium.split("£");
        String PremiumNumber = premiumValue[1];
        String premiumNum[] = PremiumNumber.split("[\\r\\n]+");
        float f = Float.parseFloat(premiumNum[0]);
        return f;
    }


    public void fillRetriveSection(String Retrievescreen, int i) throws Throwable {
        HashMap<String, String> retrieveFields = new LinkedHashMap<String, String>();
        String[] retrieveField = Retrievescreen.split("~");
        for (int a = 1; a <= retrieveField.length; a++) {
            String[] retrieveValues = retrieveField[a - 1].split("_");
            retrieveFields.put(retrieveValues[0], retrieveValues[1]);
        }
        List<String> retrieveScreenQuestions = new ArrayList<>(retrieveFields.keySet());
        for (String retrieveScreenQuestion : (retrieveScreenQuestions))
            switch (retrieveScreenQuestion) {
                case "GI":
                    fillGeneralInformationOfficeSectionWithNext(retrieveFields.get(retrieveScreenQuestion));
                    break;
                case "People":
                    fillPeopleScreen(retrieveFields.get(retrieveScreenQuestion));
                    break;
                case "PL":
                    fillLiabilityCoverSectionWithSaveExit(retrieveFields.get(retrieveScreenQuestion));
                    break;
                case "ProfessionalLiability":
                    professionalLiabilityUtil.fillPLCoverDetails(retrieveFields.get(retrieveScreenQuestion), i);
                    break;
                case "Premise":
                    fillPremiseSection(retrieveFields.get(retrieveScreenQuestion), i);
                    break;
                case "PA":
                    fillPropertyAwayScreen(retrieveFields.get(retrieveScreenQuestion));
                    break;
                case "BI":
                    fillBIScreen(retrieveFields.get(retrieveScreenQuestion));
                    break;
                case "TOT":
                    fillTheftOfTakings(retrieveFields.get(retrieveScreenQuestion));
                    break;
                case "ImpState":
                    fillImportantStatementsSectionWithSaveExit(retrieveFields.get(retrieveScreenQuestion));
                    break;
                case "PreviousLoss":
                    fillPreviousLossScreen(retrieveFields.get(retrieveScreenQuestion));
                    break;
                case "QuoteSummary":
                    coversInMoreOptions(retrieveFields.get(retrieveScreenQuestion));
                    break;
                case "Postquote":
                    fillPostQuoteScreens(retrieveFields.get(retrieveScreenQuestion));
                    break;
                case "Interestedparties":
                    fillInterestedPartyScreen(retrieveFields.get(retrieveScreenQuestion));
                    break;
                case "contact":
                    fillcontactScreen(retrieveFields.get(retrieveScreenQuestion));
                    break;
                case "Payment":
                    fillPaymentScreen(retrieveFields.get(retrieveScreenQuestion));
                    break;
                case "RetrivePolicyInCC":
                    // give input as 'null' to search the policy using Policy number and input as 'Y' to search by business name
                    userSearchPolicyinCC(retrieveFields.get(retrieveScreenQuestion));
                    break;
                case "ManageQuote":
                    ccSearch.executeScript("arguments[].click()", ccSearch.ManagequoteButton());
                    ccSearch.ccPageLoad();
                    ccSearch.executeScript("arguments[].click()", ccSearch.editButton());
                    ccSearch.ccPageLoad();
                    break;
                case "ManualDocs":
                    ccSearch.executeScript("arguments[].click()", ccSearch.manageAuthorizedContact());
                    ccSearch.ccPageLoad();
                    ccSearch.executeScript("arguments[].click()", ccSearch.manageAuthorizedContactEmail());
                    ccSearch.ccPageLoad();
                    ccSearch.executeScript("arguments[].click()", ccSearch.manageAuthorizedContactEdit());
                    ccSearch.ccPageLoad();
                    ccSearch.executeScript("arguments[].click()", ccSearch.manageAuthorizedContactEmailEdit());
                    ccSearch.ccPageLoad();
                    ccSearch.manageAuthorizedContactEmailEdit().sendKeys("sathya.kathiresan@directlinegroup.co.uk");
                    ccSearch.ccPageLoad();
                    ccSearch.executeScript("arguments[].click()", ccSearch.manageAuthorizedContactEditSave());
                    ccSearch.ccPageLoad();
                    ccSearch.executeScript("arguments[].click()", ccSearch.manageAuthorizedContactEditClose());
                    ccSearch.ccPageLoad();
                    ccSearch.executeScript("arguments[].click()", ccSearch.documentsLinkclick());
                    ccSearch.ccPageLoad();
                    ccSearch.executeScript("arguments[].click()", ccSearch.createDocumentButton());
                    ccSearch.ccPageLoad();
                    ccSearch.executeScript("arguments[].click()", ccSearch.declineAfterReferral());
                    ccSearch.ccPageLoad();
                    break;
                case "PremiumComparisonCCtoWJ":
                    Assert.assertThat("Comparing WJ premium and CC Premium", Premium1, equalTo(Premium4));
                    break;
                case "PremiumComparisonCCtoNS":
                    Assert.assertThat("Comparing WJ premium and CC Premium", Premium1, equalTo(Premium4));
                    break;
                case "PremiumCaptureWJ":
                    Premium1 = quoteSummeryPremiumCapture();
                    break;
                case "PremiumCaptureCC":
                    Premium4 = ccPremiumCapture();
                    break;

            }

    }


    public void beforeWeStart(String test) throws Throwable {

        HashMap<String, String> beforeWeStartElements = new HashMap<String, String>();
        if (!test.equalsIgnoreCase("null")) {

            beforeWeStartElements.put("Trade", "Actuary");
            beforeWeStartElements.put("Business", "I visit my clients");
            beforeWeStartElements.put("Employees", "Y");
            beforeWeStartElements.put("Covers", "Business Contents");


            String[] fieldAndValuesFromFeatureFile = test.split(",");
            for (String fieldAndValueFromFeatureFile : fieldAndValuesFromFeatureFile) {
                String[] fieldAndValue = fieldAndValueFromFeatureFile.split(":");
                beforeWeStartElements.put(fieldAndValue[0], fieldAndValue[1]);

            }

            System.out.println(beforeWeStartElements.get("Trade"));
            System.out.println(beforeWeStartElements.get("Business"));
            System.out.println(beforeWeStartElements.get("Employees"));
            System.out.println(beforeWeStartElements.get("Covers"));

//            obj_coverwizard.tradeNameTextbox().sendKeys(beforeWeStartElements.get("Trade"));
//            Thread.sleep(5000);
//            obj_coverwizard.wizardTradeList().click();
//            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.businessFromCheckbox(beforeWeStartElements.get("Business")));
//            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.businessNextButton());
//            Thread.sleep(5000);
//            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.haveEmployeesButton(beforeWeStartElements.get("Employees")));
//            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversCheckbox(beforeWeStartElements.get("Covers")));


        }

    }
}