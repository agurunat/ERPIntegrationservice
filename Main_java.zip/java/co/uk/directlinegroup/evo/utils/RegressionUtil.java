package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.*;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

import static com.usmanhussain.habanero.framework.AbstractPage.getDriver;

/*
This util created for HnB regression test case conversion Please don't use any methods from this for sprint bautomation
 Soon, in refactoring we are going to minimise the methods in this class.
 */
public class RegressionUtil {

    public static boolean booleanTrue;
    public static String strBusinessName, strFirstName, strSecondName;
    public String haveEmployee;
    private FunctionalUtil functionalUtil = new FunctionalUtil();
    private Obj_Treatments obj_treatmentprovide = new Obj_Treatments();
    private Obj_Generalinformation obj_generalInformation = new Obj_Generalinformation();
    private Obj_Businesspremises obj_businessPremises = new Obj_Businesspremises();
    private Obj_Coverwizard obj_coverwizard = new Obj_Coverwizard();
    private Obj_Peoplebusiness obj_peoplebusiness = new Obj_Peoplebusiness();
    private CommonUtil obj_commonUtil = new CommonUtil();
    private Obj_Claims obj_claims = new Obj_Claims();
    private Obj_Theftoftaking obj_theftOfTakings = new Obj_Theftoftaking();
    private Obj_Quotesummary obj_quotesummary = new Obj_Quotesummary();
    private Obj_Liabilitycover obj_liabilitycover = new Obj_Liabilitycover();
    private Obj_Propertyaway obj_propertyAway = new Obj_Propertyaway();
    private Obj_PostQuote obj_postquote = new Obj_PostQuote();
    private Obj_BusinessInterruption obj_businessInterruption = new Obj_BusinessInterruption();
    private Obj_Importantstatement obj_impornantstatement = new Obj_Importantstatement();
    private Obj_SaveAndExit obj_saveExit = new Obj_SaveAndExit();
    private Obj_BusinessInteruptionThirdParty obj_businessInteruptionParty = new Obj_BusinessInteruptionThirdParty();
    private Obj_Partners partners = new Obj_Partners();
    private Obj_Paymentselection obj_paymentSelection = new Obj_Paymentselection();
    private Obj_Paymentinformation obj_paymentInformation = new Obj_Paymentinformation();
    private Obj_Carddetails obj_cardDetails = new Obj_Carddetails();
    private Obj_Directdebit obj_directDebit = new Obj_Directdebit();
    private Obj_Createcustomer createcustomer = new Obj_Createcustomer();
    private CommonUtil commonutil = new CommonUtil();
    private CCSearchUtil ccsearchUtil = new CCSearchUtil();
    private Obj_CC_Search ccSearch = new Obj_CC_Search();
    private Obj_Createaccount obj_createAccount = new Obj_Createaccount();
    private Obj_Createcustomer obj_createCustomer = new Obj_Createcustomer();
    private GeneralinformationUtil obj_generalInformationUtil = new GeneralinformationUtil();
    private CreateaccountUtil createAccountUtil = new CreateaccountUtil();
    private Obj_CC_Login obj_cc_login = new Obj_CC_Login();
    private Obj_Treatments obj_treatments = new Obj_Treatments();
    private Obj_Businesspremises businesspremises = new Obj_Businesspremises();


    public void coverWizardGeneralinfoPeopleSecLiabilityTratments() throws Throwable {
        functionalUtil.fillCoverWizardSectionForHnB("beautician", "From my own salon", "No", "null", "Hair and beauty treatments liability#Theft of takings");
        fillGeneralInformationSection("Only at the business premises");
        fillPeopleInYourBusinessSectionLimitedCompany();
        PremisesUsedBySelfEmployedPeopleNO();
        functionalUtil.fillLiabilityCoverSection();
        treatmentsCoverSection("Yes", "biosthetics#trichology", "Yes");
    }


    public void coverWizardGeneralinfoPartnershipTreatments() throws Exception {

        fillGeneralInformationSpecificValueMultiTrade("hb", "Y", "null", "null", "null", "null", "Partnership or limited partnership", "N", "4", "null", "null", "Anywhere in the UK, Channel Islands and the Isle of Man", "Barber");
        fillPeopleInYourBusinessSectionPartnership();
        functionalUtil.fillLiabilityCoverSection();
        treatmentsCoverSection("Yes", "Reiki#reflexology", "Yes");
        /*functionalUtil.fillTOTSection();
        functionalUtil.fillImportantStatementsSection();
        userFillsPreviousLossesDetails("Yes","26/06/2016#26/05/2016","Loss of Money#Accidental Damage","200#250");*/
    }

    public void fillGeneralInformationSection(String BusinessWork) throws Throwable {
        strBusinessName = obj_generalInformationUtil.randomFirstName();
        obj_generalInformation.businessNameTextbox().sendKeys(strBusinessName);
        new Select(obj_generalInformation.titleDropdown()).selectByVisibleText("Mr");
        obj_generalInformation.firstNameTextbox().sendKeys("automation");
        obj_generalInformation.lastNameTextbox().sendKeys("tester");
        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText("Limited company");
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
        obj_generalInformation.pageLoading();
        new Select(obj_generalInformation.tradeDropdownListValue()).selectByVisibleText("2");
        obj_generalInformation.pageLoading();
        obj_generalInformation.postcodeTextbox().sendKeys("AB10 1AH");
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
        Thread.sleep(3000);
        new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByValue("1");
        obj_generalInformation.pageLoading();
        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
        obj_generalInformation.pageLoading();
        new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText(BusinessWork);
//        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.mobileDropdown());
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
    }

    //Rao: This method is generic, need to be removed after refatoring
    public void fillGeneralInformationSpecificValue(String tradeName, String anythingElse, String businessName, String title, String firstName, String lastName, String typeOfBusiness, String subsidiaries, String yearsTrading, String postCode, String businessRunFromChoice, String whereBusinessWork, String addTrade) throws Exception {


        if (!businessName.equalsIgnoreCase("null")) {
            strBusinessName = obj_generalInformationUtil.randomFirstName();
            obj_generalInformation.businessNameTextbox().sendKeys(strBusinessName);
            new Select(obj_generalInformation.titleDropdown()).selectByVisibleText(title);
            obj_generalInformation.firstNameTextbox().sendKeys(firstName);
            obj_generalInformation.lastNameTextbox().sendKeys(lastName);
            obj_generalInformation.postcodeTextbox().sendKeys(postCode);
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
            obj_generalInformation.pageLoading();
            new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByValue("1");
            obj_generalInformation.pageLoading();
        }
        if (!typeOfBusiness.equalsIgnoreCase("null")) {

            new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText(typeOfBusiness);
            obj_generalInformation.pageLoading();
        }
        if (!subsidiaries.equalsIgnoreCase("null")) {

            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesRadiobutton(subsidiaries));
            obj_generalInformation.pageLoading();
        }

        if ((!yearsTrading.equalsIgnoreCase("null"))) {
            new Select(obj_generalInformation.businessTradeDropdown()).selectByVisibleText(yearsTrading);
            obj_generalInformation.pageLoading();
        }
        if (tradeName.equalsIgnoreCase("B&B")) {
            String[] arrbusinessfromchoice = businessRunFromChoice.split("#");
            for (int i = 0; i < businessRunFromChoice.split("#").length; i++) {
                obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.businessFromCheckbox(arrbusinessfromchoice[i]));
                obj_generalInformation.pageLoading();
            }

        }
        //  obj_generalInformation.pageLoading();
        if (tradeName.equalsIgnoreCase("H&B")) {
            if (anythingElse.equalsIgnoreCase("Y")) {
                String tradeList[] = addTrade.split(";");
                for (int trade = 0; trade < tradeList.length; trade++) {
                    //    obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anyThingElseRadioButton(anythingElse));
                    obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseYesRadiobutton());

                    obj_generalInformation.pageLoading();
                    obj_generalInformation.tradeNameTextbox().sendKeys(tradeList[trade]);
                    obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.addMultipleTradeNameSelect(tradeList[trade]));
                    obj_generalInformation.pageLoading();
                }
            }

            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
            obj_generalInformation.pageLoading();
            if (!whereBusinessWork.equalsIgnoreCase("null")) {
                new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText(whereBusinessWork);
            }

        }
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillPeopleInYourBusinessSection(String moreThan50Days, String employeeType, String empLiability, String employees, String employeeAdmin, String directorsBusiness, String directorsAdmin, String empExcludeDirectors, String empExcludeDirectorsAdmin, String selfEmployedPeople, String selfEmployeeValue, String coverInjuries) throws Exception {

        if (!employeeType.equalsIgnoreCase("null")) {
            new Select(obj_peoplebusiness.toldUsBuisnessDropdownbox()).selectByVisibleText(employeeType);
            obj_generalInformation.pageLoading();
        }
        if (!empLiability.equalsIgnoreCase("null")) {
            if (empLiability.equalsIgnoreCase("Yes")) {
                obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.employerLiabilityYesRadiobutton());

            } else {
                obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.employerLiabilityNoRadiobutton());

            }
        }
        obj_generalInformation.pageLoading();
        if (!moreThan50Days.equalsIgnoreCase("null")) {
            if (moreThan50Days.equalsIgnoreCase("Yes")) {
                obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.tempMorethanDaysYesRadiobutton());

            } else {
                obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.tempMorethanDaysNoRadiobutton());

            }
        }
        obj_generalInformation.pageLoading();
        if (!employees.equalsIgnoreCase("null")) {
            obj_peoplebusiness.empWorkBusinessTextbox().sendKeys(employees);
            obj_commonUtil.tabKeypress();
            obj_generalInformation.pageLoading();
        }
        if (!employeeAdmin.equalsIgnoreCase("null")) {
            obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.empAdminWorkTextbox());
            obj_peoplebusiness.empAdminWorkTextbox().sendKeys(employeeAdmin);
            obj_commonUtil.tabKeypress();
            obj_generalInformation.pageLoading();
        }
        if (!directorsBusiness.equalsIgnoreCase("null")) {
            obj_peoplebusiness.directorBusinessTextbox().sendKeys(directorsBusiness);
            obj_generalInformation.pageLoading();
        }
        if (!directorsAdmin.equalsIgnoreCase("null")) {
            obj_peoplebusiness.directorAdminTextbox().sendKeys(directorsAdmin);
            obj_generalInformation.pageLoading();
        }
        if (!empExcludeDirectors.equalsIgnoreCase("null")) {
            obj_peoplebusiness.employeeExcludeDirectorsTextbox().sendKeys(empExcludeDirectors);
            obj_generalInformation.pageLoading();
        }
        if (!empExcludeDirectorsAdmin.equalsIgnoreCase("null")) {
            obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.employeeExcludeDirectorsAdminTextbox());
            obj_generalInformation.pageLoading();
            obj_peoplebusiness.employeeExcludeDirectorsAdminTextbox().sendKeys(empExcludeDirectorsAdmin);
            obj_generalInformation.pageLoading();
        }

        if (!selfEmployedPeople.equalsIgnoreCase("null")) {
            if (selfEmployedPeople.equalsIgnoreCase("Yes")) {
                obj_peoplebusiness.selfEmployeeValueTextbox().sendKeys(selfEmployeeValue);
                obj_generalInformation.pageLoading();
            } else {
                obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.selfEmployeeNoRadiobutton());
                obj_generalInformation.pageLoading();
            }
        }
        if (!coverInjuries.equalsIgnoreCase("null")) {
            if (coverInjuries.equalsIgnoreCase("Yes")) {
                obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.coverInjuriesYesRadiobutton());
                obj_generalInformation.pageLoading();
            } else {
                obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.coverInjuriesNoRadiobutton());
                obj_generalInformation.pageLoading();
            }
        }
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
    }

    public void fillPeopleInYourBusinessSectionHelpText(String moreThan50Days, String employeeType, String empLiability, String employees, String employeeAdmin, String directorsBusiness, String directorsAdmin, String empExcludeDirectors, String empExcludeDirectorsAdmin, String selfEmployedPeople, String selfEmployeeValue, String coverInjuries) throws Exception {

        if (!employeeType.equalsIgnoreCase("null")) {
            new Select(obj_peoplebusiness.toldUsBuisnessDropdownbox()).selectByVisibleText(employeeType);
            obj_generalInformation.pageLoading();
        }
        if (!empLiability.equalsIgnoreCase("null")) {
            if (empLiability.equalsIgnoreCase("Yes")) {
                obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.employerLiabilityYesRadiobutton());

            } else {
                obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.employerLiabilityNoRadiobutton());

            }
        }
        obj_generalInformation.pageLoading();
        if (!moreThan50Days.equalsIgnoreCase("null")) {
            if (moreThan50Days.equalsIgnoreCase("Yes")) {
                obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.tempMorethanDaysYesRadiobutton());

            } else {
                obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.tempMorethanDaysNoRadiobutton());

            }
        }
        obj_generalInformation.pageLoading();
        if (!employees.equalsIgnoreCase("null")) {
            obj_peoplebusiness.empWorkBusinessTextbox().sendKeys(employees);
            obj_commonUtil.tabKeypress();
            obj_generalInformation.pageLoading();
        }
        if (!employeeAdmin.equalsIgnoreCase("null")) {
            obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.empAdminWorkTextbox());
            obj_peoplebusiness.empAdminWorkTextbox().sendKeys(employeeAdmin);
            obj_commonUtil.tabKeypress();
            obj_generalInformation.pageLoading();
        }
        if (!directorsBusiness.equalsIgnoreCase("null")) {
            obj_peoplebusiness.directorBusinessTextbox().sendKeys(directorsBusiness);
            obj_generalInformation.pageLoading();
        }
        if (!directorsAdmin.equalsIgnoreCase("null")) {
            obj_peoplebusiness.directorAdminTextbox().sendKeys(directorsAdmin);
            obj_generalInformation.pageLoading();
        }
        if (!empExcludeDirectors.equalsIgnoreCase("null")) {
            obj_peoplebusiness.employeeExcludeDirectorsTextbox().sendKeys(empExcludeDirectors);
            obj_generalInformation.pageLoading();
        }
        if (!empExcludeDirectorsAdmin.equalsIgnoreCase("null")) {
            obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.employeeExcludeDirectorsAdminTextbox());
            obj_generalInformation.pageLoading();
            obj_peoplebusiness.employeeExcludeDirectorsAdminTextbox().sendKeys(empExcludeDirectorsAdmin);
            obj_generalInformation.pageLoading();
        }

        if (!selfEmployedPeople.equalsIgnoreCase("null")) {
            if (selfEmployedPeople.equalsIgnoreCase("Yes")) {
                obj_peoplebusiness.selfEmployeeValueTextbox().sendKeys(selfEmployeeValue);
                obj_generalInformation.pageLoading();
            } else {
                obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.selfEmployeeNoRadiobutton());
                obj_generalInformation.pageLoading();
            }
        }
        if (!coverInjuries.equalsIgnoreCase("null")) {
            if (coverInjuries.equalsIgnoreCase("Yes")) {
                obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.coverInjuriesYesRadiobutton());
                obj_generalInformation.pageLoading();
            } else {
                obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.coverInjuriesNoRadiobutton());
                obj_generalInformation.pageLoading();
            }
        }

    }

    public void fillLiabilityCoverSection(String PL) throws Exception {
        new Select(obj_liabilitycover.public_LiabilitycoverDropdown()).selectByValue(PL);
        String strtext = obj_liabilitycover.productsOutsideukDropdownList().getText();
        if (strtext.trim().equalsIgnoreCase("No")) {
            new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("No");
        } else if (strtext.trim().equalsIgnoreCase("UK only")) {
            new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("UK only");
        } else if (strtext.trim().equalsIgnoreCase("I don't sell products")) {
            new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("UK only");
        } else {
            new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("No");
        }
        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.liabilityCoverNextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillLiabilityCoverSectionAfterQuote(String PL) throws Exception {
        new Select(obj_liabilitycover.public_LiabilitycoverDropdown()).selectByValue(PL);
        obj_generalInformation.pageLoading();
    }

    public void fillPeopleInYourBusinessSectionLimitedCompany() throws Exception {
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.directorBusinessTextbox().sendKeys("2");
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.directorAdminTextbox().sendKeys("1");
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
    }

    public void fillPeopleInYourBusinessSectionPartnership() throws Exception {
        new Select(obj_peoplebusiness.toldUsBuisnessDropdownbox()).selectByVisibleText("Permanent employee(s)");
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.directorBusinessTextbox().sendKeys("2");
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.directorAdminTextbox().sendKeys("1");
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.empWorkBusinessTextbox().sendKeys("2");
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.empAdminWorkTextbox().sendKeys("1");
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();

    }

    public void premisesOutbuildingsWallTimberRoof() throws Exception {
        premisePostCodePremiseType(1, "AB10 1AH", "home business", "Y", "", "");
        premiseDoAnyfollowingApply(1, "None of the above");
        premiseInsureOutBuildingYes(1, "Y", "Yes", "31000", "Yes", "7500", "Yes", "3000");
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outBuildingStockRemoveButton(1));
        obj_generalInformation.pageLoading();
        premisepublicMainBuildingTypeNPropertyBuilt(1, "House (Terraced)", "1920-1945");
        premiseGrade1ListedNo(1, "N");
        premiseWallsMadeBrickConcreteTimber(1, "No", "Concrete");
        premiseRoofMadeSlatesTiles(1, "No", "Asbestos");
        functionalUtil.openFirePlace("heathree", 1);
        premisetickSecurityFeatures("cctv", 1);
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outbuildingElectricHeater("heathree",1));
        //      below line commented on 23-aug palani priya/rao
        premiseSubsidenceCover(1, "No");
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.nextButton());
    }


    public void premisesOutbuildingsWallTimberRoofCustomIteration(String iteration) throws Exception {
        String[] arriteration = iteration.split(",");
        for (int i = 0; i < arriteration.length; i++) {
            int intiteration = Integer.parseInt(arriteration[i]);
            premisePostCodePremiseType(intiteration, "AB10 1AH", "home business", "Y", "", "");
            premiseDoAnyfollowingApply(intiteration, "None of the above");
            premiseInsureOutBuildingYes(intiteration, "Y", "Yes", "31000", "Yes", "7500", "Yes", "3000");
            premisepublicMainBuildingTypeNPropertyBuilt(intiteration, "House (Terraced)", "1920-1945");
            premiseGrade1ListedNo(intiteration, "N");
            premiseWallsMadeBrickConcreteTimber(intiteration, "No", "Concrete");
            premiseRoofMadeSlatesTiles(intiteration, "No", "Asbestos");
            functionalUtil.openFirePlace("heathree", intiteration);
            premisetickSecurityFeatures("cctv", intiteration);
            functionalUtil.outbuildingElectricHeater("heathree", intiteration);
            premiseSubsidenceCover(intiteration, "No");
            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.nextButton());

        }
    }


    public void premisesOutbuildingsWallTimberRoofCustom() throws Exception {
        premisePostCodePremiseType(1, "AB10 1AH", "home business", "Y", "", "");
        premiseDoAnyfollowingApply(1, "None of the above");
        premiseInsureOutBuildingYes(1, "Y", "Yes", "31000", "Yes", "7500", "Yes", "3000");
        premisepublicMainBuildingTypeNPropertyBuilt(1, "House (Terraced)", "1920-1945");
        premiseGrade1ListedNo(1, "N");
        premiseWallsMadeBrickConcreteTimber(1, "No", "Concrete");
        premiseRoofMadeSlatesTiles(1, "No", "Asbestos");
        functionalUtil.openFirePlace("heathree", 1);
        premisetickSecurityFeatures("cctv", 1);
        functionalUtil.outbuildingElectricHeater("heathree", 1);
        premiseSubsidenceCover(1, "No");
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.nextButton());
    }

    public void propertyAwayInsureTakeAwayInTransit() throws Exception {
        propertyAwayInsureBusinessTolls("N", 0);
        propertyAwayInsureStockTakeAway("Y", "3000");
        propertyAwayInsureStockInTransit("Y", "3000");
        propertyAwayInsureAnyIndividualItem("Y", "Stock", "Stock", "2500", "item");
    }

    public void PremisesUsedBySelfEmployedPeopleNO() throws Exception {
        obj_commonUtil.executeScript("arguments[0].click();", obj_peoplebusiness.selfEmployeeNoRadiobutton());
        obj_generalInformation.pageLoading();
        obj_commonUtil.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
    }

    public void treatmentsCoverSection(String anyOtherTreatment, String treatment, String QualificationYorN) {
        obj_generalInformation.pageLoading();
        obj_treatmentprovide.peopleProvideTreatmentTextBox().sendKeys("1");
        obj_generalInformation.pageLoading();
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.anyOtherTreatmentsYesNoButton(anyOtherTreatment));
        obj_generalInformation.pageLoading();
        if (anyOtherTreatment.equalsIgnoreCase("Yes")) {

            String treatmentList[] = treatment.split("#");
            for (int multitreatment = 0; multitreatment < treatmentList.length; multitreatment++) {
                if (multitreatment == 0) {
                    obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.addTreatmentButton());
                    obj_generalInformation.pageLoading();
                    new Select(obj_treatmentprovide.treatmentDropdown()).selectByVisibleText(treatmentList[multitreatment]);
                    obj_generalInformation.pageLoading();
                    obj_treatmentprovide.peoplePerformTreatmentTextBox().sendKeys("1");
                    obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.addTreatmentPopUpButton());
                    obj_generalInformation.pageLoading();
                } else {
                    obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.addAnotherTreatmentButton());
                    obj_generalInformation.pageLoading();
                    new Select(obj_treatmentprovide.treatmentDropdown()).selectByVisibleText(treatmentList[multitreatment]);
                    obj_generalInformation.pageLoading();
                    obj_treatmentprovide.peoplePerformTreatmentTextBox().sendKeys("1");
                    obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.addTreatmentPopUpButton());
                    obj_generalInformation.pageLoading();
                }
            }
        } else {
            obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.anyOtherTreatmentsYesNoButton(anyOtherTreatment));
            obj_generalInformation.pageLoading();
        }
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.qualificationYesNoButton(QualificationYorN));
        obj_generalInformation.pageLoading();
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void treatmentsCoverSectionWithNoEmployees(String emp, String anyOtherTreatment, String treatment, String QualificationYorN) {
        obj_generalInformation.pageLoading();
        if (!emp.equalsIgnoreCase("null")) {
            obj_treatmentprovide.peopleProvideTreatmentTextBox().sendKeys(emp);
            obj_generalInformation.pageLoading();
        }
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.anyOtherTreatmentsNoEmpYesNoButton(anyOtherTreatment));
        obj_generalInformation.pageLoading();
        if (anyOtherTreatment.equalsIgnoreCase("Yes")) {

            String treatmentList[] = treatment.split("#");
            for (int multitreatment = 0; multitreatment < treatmentList.length; multitreatment++) {
                if (multitreatment == 0) {
                    obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.addTreatmentButton());
                    obj_generalInformation.pageLoading();
                    new Select(obj_treatmentprovide.treatmentDropdown()).selectByVisibleText(treatmentList[multitreatment]);
                    obj_generalInformation.pageLoading();
                    obj_treatmentprovide.peoplePerformTreatmentTextBox().sendKeys("1");
                    obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.addTreatmentPopUpButton());
                    obj_generalInformation.pageLoading();
                } else {
                    obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.addAnotherTreatmentButton());
                    obj_generalInformation.pageLoading();
                    new Select(obj_treatmentprovide.treatmentDropdown()).selectByVisibleText(treatmentList[multitreatment]);
                    obj_generalInformation.pageLoading();
                    obj_treatmentprovide.peoplePerformTreatmentTextBox().sendKeys("1");
                    obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.addTreatmentPopUpButton());
                    obj_generalInformation.pageLoading();
                }
            }
        } else {
            obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.anyOtherTreatmentsNoEmpYesNoButton(anyOtherTreatment));
            obj_generalInformation.pageLoading();
        }
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.qualificationYesNoButton(QualificationYorN));
        obj_generalInformation.pageLoading();
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void premisePostCodePremiseType(int iteration, String postCode, String premiseType, String premisesOnlyOccupiped, String buildingOccupied, String haveATM) {
        obj_generalInformation.pageLoading();
        obj_businessPremises.postCodetextbox(iteration).sendKeys(postCode);
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.findAddressButton(iteration));
        obj_generalInformation.pageLoading();
        new Select(obj_businessPremises.selectAddressDropdown(iteration)).selectByValue("1");
        obj_generalInformation.pageLoading();
        new Select(obj_businessPremises.selectPremisesTypeDropdown(iteration)).selectByVisibleText(premiseType);
        obj_generalInformation.pageLoading();
        switch (premiseType) {
            case "home business":
                obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.premisesOnlyOccupiped(premisesOnlyOccupiped, iteration));
                obj_generalInformation.pageLoading();
                break;
            case "commercial premises":
                obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.buildingOccupied(buildingOccupied, iteration));
                obj_generalInformation.pageLoading();
                new Select(obj_businessPremises.selectATM(iteration)).selectByVisibleText(haveATM);
        }
    }

    public void premiseDoAnyfollowingApply(int iteration, String applyToYourBusiness) {
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.applyToYpurBusiness(applyToYourBusiness, iteration));
    }

    public void premiseInsureOutBuildingYes(int iteration, String insureAnyOutbuilding, String yourBuildingAddCover, String yourBuildingValue, String businessContentAddCover, String businessContenValue, String stockAddCover, String stockValue) throws Exception {
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.insureAnyOutBuilding(insureAnyOutbuilding, iteration));
        obj_generalInformation.pageLoading();
        functionalUtil.yourBuildingAddCover(iteration, yourBuildingAddCover, yourBuildingValue);
        obj_generalInformation.pageLoading();
        functionalUtil.businessContentAddCover(iteration, businessContentAddCover, businessContenValue);
        obj_generalInformation.pageLoading();
        functionalUtil.stockAddCover(iteration, stockAddCover, stockValue);
        obj_generalInformation.pageLoading();


    }

    public void premiseInsureOutBuildingNo(int iteration, String insureAnyOutbuilding, String buildingTypeValue) throws Exception {
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.insureAnyOutBuilding(insureAnyOutbuilding, iteration));
        obj_generalInformation.pageLoading();
        functionalUtil.buildingTypeDropDown(iteration, buildingTypeValue);
        obj_generalInformation.pageLoading();
    }

    public void premiseSubsicedenceCoverNo(int iteration, String subsidenceCover) throws Exception {
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.subsidenceCover(subsidenceCover, iteration));
    }

    void premisepublicMainBuildingTypeNPropertyBuilt(int iteration, String buildingTypeValue, String propertyBuilt) throws Exception {
        new Select(obj_businessPremises.buildingTypedDrodown(iteration)).selectByVisibleText(buildingTypeValue);
        obj_generalInformation.pageLoading();
        functionalUtil.propertyBuilt(iteration, propertyBuilt);
        obj_generalInformation.pageLoading();
    }

    void premiseGrade1ListedNo(int iteration, String premiseGrade1) {
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.premiseGrade1(premiseGrade1, iteration));
        obj_generalInformation.pageLoading();
    }

    void premiseWallsMadeBrickConcreteTimber(int iteration, String wallsMade, String material) {
        if (wallsMade.equalsIgnoreCase("N")) {
            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.wallsMadeSololyBrickNo(iteration));
            obj_generalInformation.pageLoading();
            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.addWallMaterial(iteration));
            new Select(obj_businessPremises.wallmaterialdropdown()).selectByVisibleText(material);
            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.wallMaterialPopupAddMaterial());
        } else {
            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.wallsMadeSololyBrickYes(iteration));
            obj_generalInformation.pageLoading();
        }
    }

    void premiseRoofMadeSlatesTiles(int iteration, String Roof, String material) {
        premiseisRoofMade(Roof, iteration);
        obj_generalInformation.pageLoading();
        if ((Roof.equalsIgnoreCase("No")) || (Roof.equalsIgnoreCase("N"))) {
            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.addARoofMaterial(iteration));
            obj_generalInformation.pageLoading();
            new Select(obj_businessPremises.addRoofMaterialPopupDropdon()).selectByVisibleText(material);
            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.addRoofMaterialPopupAdd());
        }
    }

    public void premiseisRoofMade(String roof, int iteration) {
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.roofs(roof, iteration));
        obj_generalInformation.pageLoading();
    }

    public void premisetickSecurityFeatures(String list, int iteration) {
        String security[] = list.split("#");
        for (String securityList : security) {
            if (securityList == "cctv") {
                obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.saloncctvOptionid(iteration));
                obj_generalInformation.pageLoading();
            }
            if (securityList == "Burglar alarm") {
                obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.homeBurglarOptionid(iteration));
                obj_generalInformation.pageLoading();
            }
            if (securityList == "None") {
                obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.homeNoneOptionid(iteration));
                obj_generalInformation.pageLoading();
            }
        }
    }

    public void premiseSubsidenceCover(int iteration, String subsidence) {
        obj_generalInformation.pageLoading();
        if ((subsidence.equalsIgnoreCase("No")) || ((subsidence.equalsIgnoreCase("N")))) {
            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.subsidenceCover(subsidence, iteration));
            obj_generalInformation.pageLoading();
        } else {
            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.subsidenceCover(subsidence, iteration));
            obj_generalInformation.pageLoading();
        }
    }

    public void propertyAwayInsureBusinessTolls(String YnN, int value) {
        if ((YnN.equalsIgnoreCase("No")) || (YnN.equalsIgnoreCase("N"))) {
            YnN = "N";
            obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.businessToolsEquipment(YnN));
            obj_generalInformation.pageLoading();
        } else {
            obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.businessToolsEquipment(YnN));
            obj_generalInformation.pageLoading();
            obj_propertyAway.businessToolsEquipmentValueTextbox().sendKeys("value");
        }
    }

    public void propertyAwayInsureStockTakeAway(String YnN, String value) {
        if ((YnN.equalsIgnoreCase("No")) || (YnN.equalsIgnoreCase("N"))) {
            YnN = "N";
            obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureYourStock(YnN));
            obj_generalInformation.pageLoading();
        } else {
            obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureYourStock(YnN));
            obj_generalInformation.pageLoading();
            obj_propertyAway.insureYourStockValueTextbox().sendKeys(value);
        }
    }

    public void propertyAwayInsureStockInTransit(String YnN, String value) {
        if ((YnN.equalsIgnoreCase("No")) || (YnN.equalsIgnoreCase("N"))) {
            YnN = "N";
            obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureStocksAtTransit(YnN));
            obj_generalInformation.pageLoading();
        } else {
            obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureStocksAtTransit(YnN));
            obj_generalInformation.pageLoading();
            obj_propertyAway.transitViaThirdPartyValueTextbox().sendKeys(value);
        }
    }

    public void propertyAwayInsureAnyIndividualItem(String YnN, String stock, String itemType, String itemValue, String itemDescribe) {
        if ((YnN.equalsIgnoreCase("No")) || (YnN.equalsIgnoreCase("N"))) {
            YnN = "N";
            obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureAnyIndividualItem(YnN));
            obj_generalInformation.pageLoading();
        } else {
            obj_generalInformation.pageLoading();
            obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureAnyIndividualItem(YnN));
            obj_generalInformation.pageLoading();
            obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.propertyAwayAddItemRadiobutton());
            obj_generalInformation.pageLoading();
            new Select(obj_propertyAway.insureAnyIndividualPopupItemGroup()).selectByVisibleText(stock);
            obj_generalInformation.pageLoading();
            new Select(obj_propertyAway.insureAnyIndividualPopupTypeofItem()).selectByVisibleText(itemType);
            obj_generalInformation.pageLoading();
            obj_propertyAway.insureAnyIndividualPopupItemValue().sendKeys(itemValue);
            obj_generalInformation.pageLoading();
            obj_propertyAway.insureAnyIndividualPopupDescribe().sendKeys(itemDescribe);
            obj_generalInformation.pageLoading();
            obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureAnyIndividualPopupAddItem());
            obj_generalInformation.pageLoading();
            obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.nextButton());
            obj_generalInformation.pageLoading();
        }
    }

    public void previousLossYes(String YnN) throws Exception {
        if ((YnN.equalsIgnoreCase("No")) || (YnN.equalsIgnoreCase("N")))
            functionalUtil.fillPreviousLossesSection();
        else {
            String date = "01/11/2015";
            String lossCause = "Accidental Damage";
            String lossAmount = "1000";
            obj_claims.executeScript("arguments[0].click();", obj_claims.previousLossesYesRadiobutton());
            obj_generalInformation.pageLoading();
            obj_claims.executeScript("arguments[0].click();", obj_claims.addALoss());
            obj_generalInformation.pageLoading();
            obj_claims.dateOfLoss().sendKeys(date);
            obj_generalInformation.pageLoading();
            new Select(obj_claims.causeOfLoss()).selectByVisibleText(lossCause);
            obj_generalInformation.pageLoading();
            obj_claims.amountOfloss().sendKeys(lossAmount);
            obj_generalInformation.pageLoading();
            obj_claims.executeScript("arguments[0].click();", obj_claims.lossStatusSettled());
            obj_generalInformation.pageLoading();
            obj_claims.executeScript("arguments[0].click();", obj_claims.addALoss());
            obj_generalInformation.pageLoading();
            obj_claims.executeScript("arguments[0].click();", obj_claims.getQuoteButton());
            obj_generalInformation.pageLoading();
        }
    }

    public void fillTOTSection() throws Exception {
        String pound = "£";
        String valTOT = pound.concat("2,500");
        obj_generalInformation.pageLoading();
        new Select(obj_theftOfTakings.TOTdropDown()).selectByVisibleText(valTOT);
        obj_generalInformation.pageLoading();
        booleanTrue = TOTTextValidation();
        obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.nextButton());
        obj_generalInformation.pageLoading();
    }

    //this method customised for £2,500
    public boolean TOTTextValidation() throws Exception {
        String textTOT = obj_theftOfTakings.premisesWhilstUnattendedAndsafeText().getText();
        String Text = "In the premises whilst unattended and in a safe";
        Assert.assertTrue(textTOT.equalsIgnoreCase(Text));
        String valueTOT = obj_theftOfTakings.premisesWhilstUnattendedAndsafeValue().getText();
        String value = "£2500";
        Assert.assertTrue(valueTOT.equalsIgnoreCase(value));

        String textTOT1 = obj_theftOfTakings.premisesWhilstUnattendedAndNotInsafeText().getText();
        String Text1 = "In the premises whilst unattended and not in a safe";
        Assert.assertTrue(textTOT1.equalsIgnoreCase(Text1));
        String value1TOT = obj_theftOfTakings.premisesWhilstUnattendedAndNotInsafeValue().getText();
        String value1 = "£500";
        Assert.assertTrue(value1TOT.equalsIgnoreCase(value1));

        String textTOT2 = obj_theftOfTakings.homeAnyAuthorisedPersonWorkingText().getText();
        String Text2 = "In the home of any authorised person working in the business";
        Assert.assertTrue(textTOT2.equalsIgnoreCase(Text2));
        String value2TOT = obj_theftOfTakings.homeAnyAuthorisedPersonWorkingValue().getText();
        String value2 = "£500";
        Assert.assertTrue(value2TOT.equalsIgnoreCase(value2));

        String textTOT3 = obj_theftOfTakings.thirdPartyPremisesWhereYouWorkText().getText();
        String Text3 = "On you or anyone in your business at any third party locations where you work";
        Assert.assertTrue(textTOT3.equalsIgnoreCase(Text3));
        String value3TOT = obj_theftOfTakings.thirdPartyPremisesWhereYouWorkValue().getText();
        String value3 = "£1000";
        Assert.assertTrue(value3TOT.equalsIgnoreCase(value3));

        String textTOT4 = obj_theftOfTakings.increaseCoverLimitText().getText();
        String Text4 = "If you'd like to increase the cover limit, please call us or talk to us by webchat. We might need your safe details.";
        Assert.assertTrue(textTOT4.equalsIgnoreCase(Text4));
        return true;
    }

    public void fillTOTSection(String tot) throws Exception {
        String pound = "£";
        String valTOT = pound.concat(tot);
        obj_generalInformation.pageLoading();
        new Select(obj_theftOfTakings.theftOfTakingDropdown()).selectByVisibleText(valTOT);
        obj_generalInformation.pageLoading();
        obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillTOTSection(String tot, String save) throws Throwable {
        String pound = "£";
        String valTOT = pound.concat(tot);
        obj_generalInformation.pageLoading();
        new Select(obj_theftOfTakings.theftOfTakingDropdown()).selectByVisibleText(valTOT);
        obj_generalInformation.pageLoading();
        if (!save.equalsIgnoreCase("null") && save.equalsIgnoreCase("save")) {
            obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.saveAndExitButton());
            obj_generalInformation.pageLoading();
            obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.saveAndExitPopUp());
            obj_generalInformation.pageLoading();
            functionalUtil.saveandExit();
        } else if (save.equalsIgnoreCase("null")) {
            obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.nextButton());
        }
        obj_generalInformation.pageLoading();
    }


    public float quoteSummeryPremiumCapture() {
        //commented by rao on 24Aug
        //obj_generalInformation.pageLoading();
        String premium = obj_quotesummary.totalPremiumText().getText();
        String premiumValue[] = premium.split("£");
        String PremiumNumber = premiumValue[1];
        String premiumNum[] = PremiumNumber.split("[\\r\\n]+");
        float f = Float.parseFloat(premiumNum[0]);
        return f;
    }

    public void quoteSummeryAddLegalExpences() throws Exception {
        obj_generalInformation.pageLoading();
        new Select(obj_quotesummary.legalExpencesDropdown()).selectByVisibleText("£250,000");
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.legalExpencesaddButton());
        obj_generalInformation.pageLoading();
        Thread.sleep(3000);
    }

    //Rao: need to refactor this method
    public void fillPropertyAwayFromPremiseHB(String insureBusinessTools, String toolsAmt, String insureStocks, String StockAmt, String insureStocksAtTransit, String TransitAmt, String InsureItem, String itemGroup, String itemType, String itemValue, String itemDesc) throws Exception {
        if (!insureBusinessTools.equalsIgnoreCase("null")) {
            if (insureBusinessTools.equalsIgnoreCase("Yes")) {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.businessToolsEquipmentYesRadiobutton());
                obj_generalInformation.pageLoading();
                obj_propertyAway.businessToolsEquipmentValueTextbox().sendKeys(toolsAmt);
                obj_commonUtil.tabKeypress();
                obj_generalInformation.pageLoading();
            } else if (insureBusinessTools.equalsIgnoreCase("No")) {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.businessToolsEquipmentNoRadiobutton());
                obj_generalInformation.pageLoading();
            }
        }
        if (!insureStocks.equalsIgnoreCase("null")) {
            if (insureStocks.equalsIgnoreCase("Yes")) {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureYourStockYesRadiobutton());
                obj_generalInformation.pageLoading();
                obj_propertyAway.insureYourStockValueTextbox().sendKeys(StockAmt);
                obj_commonUtil.tabKeypress();
                obj_generalInformation.pageLoading();
            } else {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureYourStockNoRadiobutton());
                obj_generalInformation.pageLoading();
            }
        }

        if (!insureStocksAtTransit.equalsIgnoreCase("null")) {
            if (insureStocksAtTransit.equalsIgnoreCase("Yes")) {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.TransitViaThirdPartyYesRadiobutton());
                obj_generalInformation.pageLoading();
                obj_propertyAway.transitViaThirdPartyValueTextbox().sendKeys(TransitAmt);
                obj_commonUtil.tabKeypress();
            } else {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.TransitViaThirdPartyNoRadiobutton());
                obj_generalInformation.pageLoading();
            }
        }
        if (!InsureItem.equalsIgnoreCase("null")) {
            if (InsureItem.equalsIgnoreCase("Yes")) {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureItemYesRadiobutton());
                obj_generalInformation.pageLoading();
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.propertyAwayAddItemRadiobutton());
                obj_generalInformation.pageLoading();
                new Select(obj_propertyAway.ItemGroup()).selectByVisibleText(itemGroup);
                obj_generalInformation.pageLoading();
                new Select(obj_propertyAway.ItemType()).selectByVisibleText(itemType);
                obj_generalInformation.pageLoading();
                obj_propertyAway.ItemValue().sendKeys(itemValue);
                obj_generalInformation.pageLoading();
                obj_propertyAway.ItemDesc().sendKeys(itemDesc);
                obj_generalInformation.pageLoading();
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.AddItem());
                obj_generalInformation.pageLoading();
            } else {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureItemNoRadiobutton());
                obj_generalInformation.pageLoading();
            }
        }
        obj_generalInformation.pageLoading();
        obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.nextButton());
        obj_generalInformation.pageLoading();

    }

    public void userVerifiesAutoPopulation(String tradeWord) {
        obj_coverwizard.tradeNameTextbox().sendKeys(tradeWord);
        obj_generalInformation.pageLoading();
        String strList = obj_coverwizard.TradeList().getText();
        if (strList.contains("Hair and beauty therapist\nHairdresser")) {
            Assert.assertTrue("Correct  trade  displayed", true);
        } else if (!strList.contains("Hair and beauty therapist\nHairdresser")) {
            Assert.assertTrue(false);
        }
        obj_coverwizard.tradeNameTextbox().clear();
    }

    public void fillCoverWizardAndVerifyCoverSelection() {
        functionalUtil.fillCoverWizardSectionForHnB("Hair and beauty therapist", "I rent a chair or a space from a salon#Mobile business", "Permanent employee(s)", "Y", "Hair and beauty treatments liability#Business stock#Theft of takings");
        UserchecksCoverList();
    }

    public void UserchecksCoverList() {
        int size = obj_coverwizard.CoverList().size();
        for (int i = 0; i < size; i++) {
            String strList = obj_coverwizard.CoverList().get(i).getText();
            if (strList.contains("Hair and beauty treatments liability") || strList.contains("Business Stock") || strList.contains("Theft of takings") || strList.contains("Business Interruption") || strList.contains("Business tools and equipment") || strList.contains("None")) {
                Assert.assertTrue("Correct  covers  displayed", true);
            } else {
                Assert.assertTrue(false);
            }
        }
        int selectsize = obj_coverwizard.SelectedCoverList().size();
        for (int i = 0; i < selectsize; i++) {
            String strList1 = obj_coverwizard.SelectedCoverList().get(i).getText();
            if (strList1.contains("Hair and beauty treatments liability") || strList1.contains("Business Stock") || strList1.contains("Theft of takings") || strList1.contains("Public and Products liability") || strList1.contains("Employers' Liability")) {
                Assert.assertTrue("Selected  covers  displayed", true);
            } else {
                Assert.assertTrue(false);
            }
        }
    }

    public void proceedTillQuote() throws Exception {
        fillGeneralInformationSpecificValueMultiTrade("hb", "Y", "null", "null", "null", "null", "Limited company", "N", "2", "null", "null", "Anywhere in the UK, Channel Islands and the Isle of Man", "Barber;Beautician");
        fillPeopleInYourBusinessSectionSpecificValue("null", "Permanent employee(s)", "Yes", "null", "null", "2", "1", "2", "1", "null", "null", "null");
        functionalUtil.fillLiabilityCoverSection();
        multiTreatmentCoverSection("2", "Y", "Faradic treatment#Galvanic treatment#biosthetics");
        fillPropertyAwayFromPremiseAddNamedItems("null", "Yes", "3000", "Yes", "2550", "Yes", "Stock", "Furniture", "2550", "table");
        functionalUtil.fillTOTSection();
        functionalUtil.fillImportantStatementsSection();
        userFillsPreviousLossesDetails("Yes", "26/06/2016#26/05/2016", "Loss of Money#Accidental Damage", "200#250");
        obj_claims.executeScript("arguments[0].click();", obj_claims.ReviewAndConfirm());
        obj_generalInformation.pageLoading();
    }

    public void fillGeneralInformationSpecificValueMultiTrade(String tradeName, String anythingElse, String businessName, String title, String firstName, String lastName, String typeOfBusiness, String subsidiaries, String yearsTrading, String postCode, String businessRunFromChoice, String whereBusinessWork, String addTrade) throws Exception {

        if (!businessName.equalsIgnoreCase("null")) {
            strBusinessName = obj_generalInformationUtil.randomFirstName();
            obj_generalInformation.businessNameTextbox().sendKeys(strBusinessName);
            new Select(obj_generalInformation.titleDropdown()).selectByVisibleText(title);
            obj_generalInformation.firstNameTextbox().sendKeys(firstName);
            obj_generalInformation.lastNameTextbox().sendKeys(lastName);
            obj_generalInformation.postcodeTextbox().sendKeys(postCode);
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
            obj_generalInformation.pageLoading();
            new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByValue("1");
            obj_generalInformation.pageLoading();
        }
        if (!typeOfBusiness.equalsIgnoreCase("null")) {

            new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText(typeOfBusiness);
            obj_generalInformation.pageLoading();
        }
        if (!subsidiaries.equalsIgnoreCase("null")) {

            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesRadiobutton(subsidiaries));
            obj_generalInformation.pageLoading();
        }

        if ((!yearsTrading.equalsIgnoreCase("null"))) {
            new Select(obj_generalInformation.businessTradeDropdown()).selectByVisibleText(yearsTrading);
            obj_generalInformation.pageLoading();
        }
        if (tradeName.equalsIgnoreCase("B&B")) {
            String[] arrbusinessfromchoice = businessRunFromChoice.split("#");
            for (int i = 0; i < businessRunFromChoice.split("#").length; i++) {
                obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.businessFromCheckbox(arrbusinessfromchoice[i]));
                obj_generalInformation.pageLoading();
            }

        }
        if (tradeName.equalsIgnoreCase("hb")) {

            if (anythingElse.equalsIgnoreCase("Y")) {
                String tradeList[] = addTrade.split(";");
                for (int trade = 0; trade < tradeList.length; trade++) {
                    //    obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anyThingElseRadioButton(anythingElse));
                    obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseYesRadiobutton());
                    obj_generalInformation.pageLoading();
                    obj_generalInformation.tradeNameTextbox().sendKeys(tradeList[trade]);
                    obj_generalInformation.pageLoading();
                    obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.addMultipleTradeNameSelect(tradeList[trade]));
                    obj_generalInformation.pageLoading();
                }
            }

            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
            obj_generalInformation.pageLoading();
            if (!whereBusinessWork.equalsIgnoreCase("null")) {
                new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText(whereBusinessWork);
            }

        }
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillPeopleInYourBusinessSectionSpecificValue(String moreThan50Days, String employeeType, String empLiability, String employees, String employeeAdmin, String directorsBusiness, String directorsAdmin, String empExcludeDirectors, String empExcludeDirectorsAdmin, String selfEmployedPeople, String selfEmployeeValue, String coverInjuries) throws Exception {

        if (!employeeType.equalsIgnoreCase("null")) {
            new Select(obj_peoplebusiness.toldUsBuisnessDropdownbox()).selectByVisibleText(employeeType);
            obj_generalInformation.pageLoading();
        }
        if (!empLiability.equalsIgnoreCase("null")) {
            if (empLiability.equalsIgnoreCase("Yes")) {
                obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.employerLiabilityYesRadiobutton());
            } else {
                obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.employerLiabilityNoRadiobutton());
            }
        }
        obj_generalInformation.pageLoading();
        if (!moreThan50Days.equalsIgnoreCase("null")) {
            if (moreThan50Days.equalsIgnoreCase("Yes")) {
                obj_peoplebusiness.tempMorethanDaysYesRadiobutton().click();
            } else {
                obj_peoplebusiness.tempMorethanDaysNoRadiobutton().click();
            }
        }
        obj_generalInformation.pageLoading();
        if (!employees.equalsIgnoreCase("null")) {
            obj_peoplebusiness.empWorkBusinessTextbox().sendKeys(employees);
            obj_generalInformation.pageLoading();
        }
        if (!employeeAdmin.equalsIgnoreCase("null")) {
            obj_peoplebusiness.empAdminWorkTextbox().click();
            obj_generalInformation.pageLoading();
            obj_peoplebusiness.empAdminWorkTextbox().sendKeys(employeeAdmin);
            obj_commonUtil.tabKeypress();
            obj_generalInformation.pageLoading();
        }
        if (!directorsBusiness.equalsIgnoreCase("null")) {
            obj_peoplebusiness.directorBusinessTextbox().sendKeys(directorsBusiness);
            obj_generalInformation.pageLoading();
        }
        if (!directorsAdmin.equalsIgnoreCase("null")) {
            obj_peoplebusiness.directorAdminTextbox().click();
            obj_generalInformation.pageLoading();
            obj_peoplebusiness.directorAdminTextbox().sendKeys(directorsAdmin);
            obj_commonUtil.tabKeypress();
            obj_generalInformation.pageLoading();
        }
        if (!empExcludeDirectors.equalsIgnoreCase("null")) {
            obj_peoplebusiness.employeeExcludeDirectorsTextbox().sendKeys(empExcludeDirectors);
            obj_generalInformation.pageLoading();
        }
        if (!empExcludeDirectorsAdmin.equalsIgnoreCase("null")) {
            obj_peoplebusiness.employeeExcludeDirectorsAdminTextbox().click();
            obj_generalInformation.pageLoading();
            obj_peoplebusiness.employeeExcludeDirectorsAdminTextbox().sendKeys(empExcludeDirectorsAdmin);
            obj_commonUtil.tabKeypress();
            obj_generalInformation.pageLoading();
        }

        if (!selfEmployedPeople.equalsIgnoreCase("null")) {
            //obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.selfEmployedPeople(SelfEmployedPeople));
            if (selfEmployedPeople.equalsIgnoreCase("Yes")) {
                obj_peoplebusiness.selfEmployeeYesRadiobutton().click();
                obj_peoplebusiness.selfEmployeeValueTextbox().sendKeys(selfEmployeeValue);
                obj_generalInformation.pageLoading();
            } else {
                obj_peoplebusiness.selfEmployeeNoRadiobutton().click();
                obj_generalInformation.pageLoading();
            }
        }
        if (!coverInjuries.equalsIgnoreCase("null")) {
            if (coverInjuries.equalsIgnoreCase("Yes")) {
                obj_peoplebusiness.coverInjuriesYesRadiobutton().click();
                obj_generalInformation.pageLoading();
            } else {
                obj_peoplebusiness.coverInjuriesNoRadiobutton().click();
                obj_generalInformation.pageLoading();
            }
        }
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
    }

    public void multiTreatmentCoverSection(String people, String anyOtherTreatment, String treatment) {

        if (!people.equalsIgnoreCase("null")) {
            obj_generalInformation.pageLoading();
            obj_treatmentprovide.peopleProvideTreatmentTextBox().sendKeys(people);
            obj_generalInformation.pageLoading();
        }
        obj_generalInformation.pageLoading();
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.anyOtherTreatmentYesButton());
        obj_generalInformation.pageLoading();
        if (anyOtherTreatment.equalsIgnoreCase("Y")) {

            String treatmentList[] = treatment.split("#");
            for (int multitreatment = 0; multitreatment < treatmentList.length; multitreatment++) {
                if (multitreatment == 0) {
                    obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.addATreatmentButton());
                    obj_generalInformation.pageLoading();
                    new Select(obj_treatmentprovide.treatmentDropdown()).selectByVisibleText(treatmentList[multitreatment]);
                    obj_generalInformation.pageLoading();
                    obj_treatmentprovide.peoplePerformTreatmentTextBox().sendKeys("1");
                    obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.addTreatmentPopUpButton());
                    obj_generalInformation.pageLoading();
                } else {
                    obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.addAnotherTreatmentButton());
                    obj_generalInformation.pageLoading();
                    new Select(obj_treatmentprovide.treatmentDropdown()).selectByVisibleText(treatmentList[multitreatment]);
                    obj_generalInformation.pageLoading();
                    obj_treatmentprovide.peoplePerformTreatmentTextBox().sendKeys("1");
                    obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.addTreatmentPopUpButton());
                    obj_generalInformation.pageLoading();
                }
            }
        } else if (anyOtherTreatment.equalsIgnoreCase("N")) {
            obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.anyOtherTreatmentNoButton());
            obj_generalInformation.pageLoading();
        }
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.qualificationYesButton());
        obj_generalInformation.pageLoading();
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillPropertyAwayFromPremiseAddNamedItems(String insureBusinessTools, String insureStocks, String StockAmt, String insureStocksAtTransit, String TransitAmt, String InsureItem, String itemGroup, String itemType, String itemValue, String itemDesc) {
        if (!insureBusinessTools.equalsIgnoreCase("null")) {
            obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.businessToolsEquipmentNoRadiobutton());
            obj_generalInformation.pageLoading();
        }
        if (!insureStocks.equalsIgnoreCase("null")) {
            if (insureStocks.equalsIgnoreCase("Yes")) {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureYourStockYesRadiobutton());
                obj_generalInformation.pageLoading();
                obj_propertyAway.insureYourStockValueTextbox().sendKeys(StockAmt);
                obj_generalInformation.pageLoading();
            } else {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureYourStockNoRadiobutton());
                obj_generalInformation.pageLoading();
            }
        }

        if (!insureStocksAtTransit.equalsIgnoreCase("null")) {
            if (insureStocks.equalsIgnoreCase("Yes")) {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.TransitViaThirdPartyYesRadiobutton());
                obj_generalInformation.pageLoading();
                obj_propertyAway.transitViaThirdPartyValueTextbox().sendKeys(TransitAmt);
            } else {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureYourStockNoRadiobutton());
                obj_generalInformation.pageLoading();
            }
        }
        if (!InsureItem.equalsIgnoreCase("null")) {
            if (InsureItem.equalsIgnoreCase("Yes")) {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureItemYesRadiobutton());
                obj_generalInformation.pageLoading();
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.propertyAwayAddItemRadiobutton());
                obj_generalInformation.pageLoading();
                new Select(obj_propertyAway.ItemGroup()).selectByVisibleText(itemGroup);
                obj_generalInformation.pageLoading();
                new Select(obj_propertyAway.ItemType()).selectByVisibleText(itemType);
                obj_generalInformation.pageLoading();
                obj_propertyAway.ItemValue().sendKeys(itemValue);
                obj_generalInformation.pageLoading();
                obj_propertyAway.ItemDesc().sendKeys(itemDesc);
                obj_generalInformation.pageLoading();
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.AddItem());
                obj_generalInformation.pageLoading();
            } else {
                obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.insureItemNoRadiobutton());
                obj_generalInformation.pageLoading();
            }
        }
        obj_generalInformation.pageLoading();
        obj_propertyAway.executeScript("arguments[0].click();",obj_propertyAway.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void userFillsPreviousLossesDetails(String AddLoss, String LossDate, String LossCause, String LossAmt) throws Exception {
        obj_claims.executeScript("arguments[0].click();", obj_claims.previousLossesYesRadiobutton());
        obj_generalInformation.pageLoading();

        if (AddLoss.equalsIgnoreCase("Yes")) {
            String LossList[] = LossDate.split("#");
            String LossList1[] = LossCause.split("#");
            String LossList2[] = LossAmt.split("#");
            for (int multiloss = 0; multiloss < LossList.length; multiloss++) {
                if (multiloss == 0) {
                    obj_claims.executeScript("arguments[0].click();", obj_claims.Addloss());
                    obj_generalInformation.pageLoading();
                    obj_claims.Lossdate().sendKeys(LossList[multiloss]);
                    obj_generalInformation.pageLoading();
                    new Select(obj_claims.Cause()).selectByVisibleText(LossList1[multiloss]);
                    obj_generalInformation.pageLoading();
                    obj_claims.Lossamt().sendKeys(LossList2[multiloss]);
                    obj_generalInformation.pageLoading();
                    obj_claims.executeScript("arguments[0].click();", obj_claims.SettledYesbutton());
                    obj_generalInformation.pageLoading();
                    obj_claims.executeScript("arguments[0].click();", obj_claims.AddLossInternal());
                    obj_generalInformation.pageLoading();

                } else if (multiloss > 0) {
                    obj_claims.executeScript("arguments[0].click();", obj_claims.addAnotherLoss());
                    obj_generalInformation.pageLoading();
                    obj_claims.Lossdate().sendKeys(LossList[multiloss]);
                    obj_generalInformation.pageLoading();
                    new Select(obj_claims.Cause()).selectByVisibleText(LossList1[multiloss]);
                    obj_generalInformation.pageLoading();
                    obj_claims.Lossamt().sendKeys(LossList2[multiloss]);
                    obj_generalInformation.pageLoading();
                    obj_claims.executeScript("arguments[0].click();", obj_claims.SettledYesbutton());
                    obj_generalInformation.pageLoading();
                    obj_claims.executeScript("arguments[0].click();", obj_claims.AddLossInternal());
                    obj_generalInformation.pageLoading();
                }
            }
        } else if (AddLoss.equalsIgnoreCase("No")) {
            obj_claims.executeScript("arguments[0].click();", obj_claims.previousLossesNoRadiobutton());
        }
        obj_claims.executeScript("arguments[0].click();", obj_claims.getQuoteButton());
        obj_generalInformation.pageLoading();
        Thread.sleep(500);
         obj_claims.executeScript("arguments[0].click();", obj_claims.ReviewAndConfirm());
        // obj_generalInformation.pageLoading();


    }


    public void userFillsPreviousLossesDetailsWithMultiple(String AddLoss, String LossDate, String LossCause, String LossAmt) throws Throwable {
        obj_claims.executeScript("arguments[0].click();", obj_claims.previousLossesYesRadiobutton());
        obj_generalInformation.pageLoading();

        if (AddLoss.equalsIgnoreCase("Yes")) {
            String LossList[] = LossDate.split(";");
            String LossList1[] = LossCause.split(";");
            String LossList2[] = LossAmt.split(";");
            for (int multiloss = 0; multiloss < LossList.length; multiloss++) {
                if (multiloss == 0) {
                    obj_claims.executeScript("arguments[0].click();", obj_claims.Addloss());
                    obj_generalInformation.pageLoading();
                    obj_claims.Lossdate().sendKeys(LossList[multiloss]);
                    obj_commonUtil.tabKeypress();
                    String optionsAct = obj_claims.Cause().getText();
//                    String optionsExp="\n Select...\n \n \n \n Accidental Damage\n \n \n \n Aircraft And Other Aerial Devices\n \n \n \n Assault\n \n \n \n Breakdown\n \n \n \n Business Interruption at Suppliers\n \n \n \n Death\n \n \n \n Denial of access\n \n \n \n Deterioration of Stock\n \n \n \n Discovery of Vermin\n \n \n \n Diseases, Murder, Suicide, Defective Sanitation\n \n \n \n Earthquake (Fire And Shock Risks)\n \n \n \n Employee Injury\n \n \n \n Escape Of Water/Oil/Beverages\n \n \n \n Explosion\n \n \n \n Falling Trees\n \n \n \n Fire - arson\n \n \n \n Fire - electrical fault\n \n \n \n Fire - other\n \n \n \n Flood\n \n \n \n Food And/Or Drink Poisoning\n \n \n \n Fraud or Dishonesty of Staff\n \n \n \n Health And Safety Legislation\n \n \n \n Impact - Own Vehicles\n \n \n \n Impact - Third Party\n \n \n \n Legal Expenses\n \n \n \n Lightning\n \n \n \n Loss of Money\n \n \n \n Loss of income arising from public utilities\n \n \n \n Lost In Transit\n \n \n \n Malicious Damage\n \n \n \n Motor Contingent Liability\n \n \n \n Product Liability\n \n \n \n Replacement Of Locks\n \n \n \n Riot\n \n \n \n Robbery Or Attempted Robbery\n \n \n \n Storm\n \n \n \n Subsidence Ground Heave Landslip\n \n \n \n Terrorism\n \n \n \n Theft Or Attempted Theft\n \n \n \n Third Party Injury\n \n \n \n Third Party Property Damage\n \n \n \n Underground Services";
//                    if(optionsExp.equals(optionsAct)){
//                        Assert.assertTrue(true);
//                    }else Assert.assertTrue(false);
                    new Select(obj_claims.Cause()).selectByVisibleText(LossList1[multiloss]);
                    obj_generalInformation.pageLoading();
                    obj_claims.Lossamt().sendKeys(LossList2[multiloss]);
                    obj_generalInformation.pageLoading();
                    obj_claims.executeScript("arguments[0].click();", obj_claims.SettledYesbutton());
                    obj_generalInformation.pageLoading();
                    obj_claims.executeScript("arguments[0].click();", obj_claims.AddLossInternal());
                    obj_generalInformation.pageLoading();

                } else if (multiloss > 0) {
                    obj_claims.executeScript("arguments[0].click();", obj_claims.addAnotherLoss());
                    obj_generalInformation.pageLoading();
                    obj_claims.Lossdate().sendKeys(LossList[multiloss]);
                    obj_generalInformation.pageLoading();
                    new Select(obj_claims.Cause()).selectByVisibleText(LossList1[multiloss]);
                    obj_generalInformation.pageLoading();
                    obj_claims.Lossamt().sendKeys(LossList2[multiloss]);
                    obj_generalInformation.pageLoading();
                    obj_claims.executeScript("arguments[0].click();", obj_claims.SettledYesbutton());
                    obj_generalInformation.pageLoading();
                    obj_claims.executeScript("arguments[0].click();", obj_claims.AddLossInternal());
                    obj_generalInformation.pageLoading();
                }
            }
            for (int i = 1; i <= LossList.length; i++) {
                Assert.assertTrue(obj_claims.changebutton(i).isDisplayed());
                Assert.assertTrue(obj_claims.binbuttonlosspage(i).isDisplayed());
                obj_claims.executeScript("arguments[0].click();", obj_claims.binbuttonlosspage(LossList.length));
            }
        } else if (AddLoss.equalsIgnoreCase("No")) {
            obj_claims.executeScript("arguments[0].click();", obj_claims.previousLossesNoRadiobutton());
        }
        obj_generalInformation.pageLoading();
        obj_claims.executeScript("arguments[0].click();", obj_claims.getQuoteButton());
        obj_generalInformation.pageLoading();
        obj_claims.executeScript("arguments[0].click();", obj_claims.ReviewAndConfirm());
        obj_generalInformation.pageLoading();

    }

    public void yourDetails() {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.YourDetailsNext());
        obj_generalInformation.pageLoading();
    }

    public void employersLiability() throws Exception {
        obj_generalInformation.postcodeTextbox().sendKeys("AB10 1AH");
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
        Thread.sleep(3000);
        new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByValue("1");
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.ExemptERM());
        obj_generalInformation.pageLoading();
        obj_postquote.ERMnum().sendKeys("123/a234");
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.ELNext());
        obj_generalInformation.pageLoading();
    }

    public void employersLiabilityAddAddresss() throws Exception {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.businessaAddressNoButton());
        obj_generalInformation.pageLoading();
        obj_generalInformation.postcodeTextbox().sendKeys("AB10 1AS");
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
        Thread.sleep(3000);
        new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByValue("1");
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.ExemptERM());
        obj_generalInformation.pageLoading();
        obj_postquote.ERMnum().sendKeys("123/a234");
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.ELNext());
        obj_generalInformation.pageLoading();
    }

    public void employersLiabilityNotAddAddresss() throws Exception {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.businessaAddressYesButton());
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.ExemptERM());
        obj_generalInformation.pageLoading();
        obj_postquote.ERMnum().sendKeys("123/a234");
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.ELNext());
        obj_generalInformation.pageLoading();
    }

    public void intrestedParties() {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.InterestedPartyNoButton());
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.InterestedPartyNext());
        obj_generalInformation.pageLoading();
    }

    public void intrestedPartiesAdd() throws Exception {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.InterestedPartyYesButton());
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.addInterestedParty());
        obj_generalInformation.pageLoading();
        obj_postquote.interestedPartyName().sendKeys("Jon");
        obj_generalInformation.pageLoading();
        obj_postquote.postCodeTextBox().sendKeys("AB10 1AS");
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.findAddressButton());
        Thread.sleep(3000);
        new Select(obj_postquote.correspondenceAddressDropdown()).selectByValue("1");
        obj_generalInformation.pageLoading();
        new Select(obj_postquote.natureOfInterestDropDown()).selectByVisibleText("Trustee");
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.addButtonToSave());
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.InterestedPartyNext());
        obj_generalInformation.pageLoading();
    }

    public void contacts() {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.ContactsNoButton());
        obj_generalInformation.pageLoading();
        // obj_postquote.executeScript("arguments[0].click();", obj_postquote.contactNextButton());
        //  obj_generalInformation.pageLoading();
    }

    public void noContact() {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.ContactsNoButton());
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.contactNextButton());
        obj_generalInformation.pageLoading();

    }

    public void contactsYes() {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.contactsYesButton());
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.addContactButton());
        obj_generalInformation.pageLoading();
        new Select(obj_postquote.contactTitle()).selectByVisibleText("Miss");
        obj_generalInformation.pageLoading();
        obj_postquote.contactFirstName().sendKeys("Arya");
        obj_generalInformation.pageLoading();
        obj_postquote.contactLasttName().sendKeys("Stark");
        obj_generalInformation.pageLoading();
        obj_postquote.contactRelationship().sendKeys("Advisor");
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.addButtonToSaveContact());
        obj_generalInformation.pageLoading();
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.contactNextButton());
        obj_generalInformation.pageLoading();
    }

    public void seasonalStock() {
        new Select(obj_postquote.seasonalStockMonth1()).selectByVisibleText("May");
        obj_generalInformation.pageLoading();
        new Select(obj_postquote.seasonalStockMonth2()).selectByVisibleText("June");
        obj_generalInformation.pageLoading();
    }

    public void checkOut() {
        obj_postquote.executeScript("arguments[0].click();", obj_postquote.checkOutButton());
        obj_generalInformation.pageLoading();

    }

    public void userProceedTillPremise() throws Exception {
        functionalUtil.fillCoverWizardSectionForHnB("Hair and beauty therapist", "I work from home", "Temporary employee(s)", "Y", "Hair and beauty treatments liability#Business interruption#Theft of takings");
        fillGeneralInformationSpecificValueMultiTrade("hb", "N", "TC525456", "Mr", "Tyrion1", "Lan", "Sole business owner", "No", "2", "AB101AH", "null", "Only at the business premises", "null");
        fillPeopleInYourBusinessSectionSpecificValue("Yes", "Temporary employee(s)", "Yes", "2", "1", "null", "null", "null", "null", "null", "null", "null");
        functionalUtil.fillLiabilityCoverSection();
        multiTreatmentCoverSection("2", "Y", "ear piercing by gun and stud method#trichology");

    }

    public void saveAndExit() throws Exception {
        obj_generalInformation.pageLoading();
        String strEmail = createAccountUtil.randomemail();
        obj_claims.Email().click();
        obj_claims.Email().sendKeys(strEmail);
        obj_commonUtil.tabKeypress();
        obj_generalInformation.pageLoading();
        obj_claims.ConfirmEmail().click();
        obj_claims.ConfirmEmail().sendKeys(strEmail);
        obj_commonUtil.tabKeypress();
        obj_generalInformation.pageLoading();
        obj_claims.telephone().click();
        obj_claims.telephone().sendKeys("07448956231");
        obj_commonUtil.tabKeypress();
        obj_generalInformation.pageLoading();
        obj_createAccount.emailRadiobutton().click();
        obj_generalInformation.pageLoading();
        obj_claims.executeScript("arguments[0].click();", obj_claims.Exit());
        obj_generalInformation.pageLoading();

    }

    public void fillPreviousLossesSectionWithoutQuote() {
        obj_claims.executeScript("arguments[0].click();", obj_claims.previousLossesNoRadiobutton());
        obj_generalInformation.pageLoading();
        obj_generalInformation.pageLoading();
        obj_claims.executeScript("arguments[0].click();", obj_claims.SaveAndExit());
        obj_generalInformation.pageLoading();
        obj_claims.executeScript("arguments[0].click();", obj_claims.SaveAndExitpopup());

    }


    public void NavigationTillQuoteSummary() throws Exception {
        obj_generalInformation.pageLoading();
        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.liabilityCoverNextButton());
        obj_generalInformation.pageLoading();
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.nextButton());
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.subsidenceCoverNoRadiobutton(1));
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.nextButton());
        obj_generalInformation.pageLoading();
        functionalUtil.fillPropertyAwayFromPremiseHB("No", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null");
        obj_generalInformation.pageLoading();
        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.businessInterruptionNextButton());
        obj_generalInformation.pageLoading();
        obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.nextButton());
        obj_generalInformation.pageLoading();
        obj_impornantstatement.executeScript("arguments[0].click();", obj_impornantstatement.importantStatNextButton());
        obj_generalInformation.pageLoading();
        functionalUtil.fillPreviousLossesSection();
    }

    public void userVerifiesQSPage() {
        float f = quoteSummeryPremiumCapture();
        Assert.assertTrue(f + "Premium is Not displayed or 0", f > 0);
        verifyQSPolicyLevelCover();
        obj_postquote.executeScript("arguments[0].click();", obj_quotesummary.PremiseShowArrow());
        verifyPremiseCover();
        verifyAnyOtherPoliciesOptions();
        verifyMoreOptionsCover();
        verifyAddCoverLinkinMoreOptions();

    }

    private void verifyAddCoverLinkinMoreOptions() {
        int size = obj_quotesummary.AddCoverLink().size();
        Assert.assertTrue(size > 0);
    }

    public void verifyMoreOptionsCover() {
        int size = obj_quotesummary.MoreOptionsCover().size();
        for (int i = 0; i < size; i++) {
            String strList = obj_quotesummary.MoreOptionsCover().get(i).getText();
            if (strList.contains("Legal Expenses") || strList.contains("Property away from the premises"))
                Assert.assertTrue("Correct  Covers  displayed under More Options", true);
            else if (strList.contains("Legal Expenses") && strList.contains("Theft of takings"))
                Assert.assertTrue("Correct  Covers  displayed under More Options", true);
            else
                Assert.assertTrue(false);

        }
    }

    public void verifyAnyOtherPoliciesOptions() {
        int size = obj_quotesummary.OtherPoliciesLabel().size();
        for (int i = 0; i < size; i++) {
            String strList = obj_quotesummary.OtherPoliciesLabel().get(i).getText();
            if (strList.contains("Car") || strList.contains("Pet") || strList.contains("Home") || strList.contains("Landlord") || strList.contains("Travel") || strList.contains("Life") || strList.contains("Van") || strList.contains("Other")) {
                Assert.assertTrue("Correct  Options  displayed", true);
            } else {
                Assert.assertTrue(false);
            }
        }
    }

    private void verifyPremiseCover() {
        String str1 = obj_quotesummary.PremiseCoverValidation().getText();
        if (str1.contains("Business contents")) {
            Assert.assertTrue("Correct  cover  displayed", true);
        } else {
            Assert.assertTrue(false);
        }
    }

    public void verifyQSPolicyLevelCover() {
        int size = obj_quotesummary.PolicyLevelCoverVerification().size();
        for (int i = 0; i < size; i++) {
            String strList = obj_quotesummary.PolicyLevelCoverVerification().get(i).getText();
            if (strList.contains("Hair and beauty treatments liability") || strList.contains("Public and Products liability") || strList.contains("Theft of takings") || strList.contains("Business Interruption") || strList.contains("Employers' Liability")) {
                Assert.assertTrue("Correct  covers  displayed", true);
            } else {
                Assert.assertTrue(false);
            }
        }
    }

    public void userAddPremiseFromQS(String iteration) throws Exception {
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.addPremise());
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.addAnotherPremise());
        obj_generalInformation.pageLoading();
        premisesOutbuildingsWallTimberRoofCustomIteration(iteration);
        functionalUtil.fillPropertyAwayFromPremiseHB("No", "null", "No", "null", "No", "null", "null", "null", "null", "null", "null", "null", "null");
        obj_generalInformation.pageLoading();
        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.businessInterruptionNextButton());
        obj_generalInformation.pageLoading();
        obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.nextButton());
        obj_generalInformation.pageLoading();
        functionalUtil.fillImportantStatementsSection();
        obj_generalInformation.pageLoading();
        functionalUtil.fillPreviousLossesSection();

    }

    public void UserProcceedTillPremiseScreenForPermanentTempEmp() throws Exception {
        functionalUtil.fillCoverWizardSectionForHnB("Barber", "I work from home", "Permanent & temporary employees", "Y", "Business stock#Your salon (the building)#Theft of takings");
        fillGeneralInformationSpecificValueMultiTrade("hb", "N", "TC55updated1", "Mr", "Jamiee", "Lan", "Sole business owner", "No", "2", "AB101AH", "null", "Only at the business premises", "null");
        fillPeopleInYourBusinessSectionSpecificValue("null", "Permanent and temporary employees", "Yes", "2", "1", "null", "null", "null", "null", "null", "null", "null");
        functionalUtil.fillLiabilityCoverSection();

    }

    public void UserProcceedTillPremiseScreenForPermanentTempEmpOwnSaloon() throws Exception {
        functionalUtil.fillCoverWizardSectionForHnB("Barber", "From my own salon", "Permanent & temporary employees", "Y", "Business stock#Your salon (the building)#Theft of takings");
        fillGeneralInformationSpecificValueMultiTrade("H&B", "N", "Prereq51", "Mr", "Jamie", "Lan", "Sole business owner", "No", "2", "AB101AH", "null", "Only at the business premises", "null");
        fillPeopleInYourBusinessSectionSpecificValue("null", "Permanent and temporary employees", "Yes", "2", "1", "null", "null", "null", "null", "No", "null", "null");
        functionalUtil.fillLiabilityCoverSection();

    }

    public void userFillsPropertyAwayValuesToTImptStmtLossAndClickSaveInQuoteSummary() throws Throwable {
        functionalUtil.fillPropertyAwayFromPremiseHB("Yes", "1000", "Yes", "1000", "Yes", "1000", "null", "null", "null", "null", "null", "null", "null");
        functionalUtil.fillTOTSection();
        functionalUtil.fillImportantStatementsSection();
        functionalUtil.fillPreviousLossesSection();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.SaveAndExit());
        obj_generalInformation.pageLoading();
        functionalUtil.saveandExit();

    }

    public void reviewConfirm() {
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.reviewConfirmButton());
        obj_generalInformation.pageLoading();

    }


    public void quoteSummeryIncreasePublicLiabilityLimit() {
        new Select(obj_quotesummary.publicLiabilityDropDown()).selectByValue("2000000");
        obj_generalInformation.pageLoading();
        quoteSummeryPremiumCapture();


    }

    public void userClickSaveAndExit() {
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.SaveAndExit());
        obj_generalInformation.pageLoading();
    }

    public void fillGIScreenAddTrade(String application, String tradeName, String anythingElse, String tradeList) throws InterruptedException {
        if (!application.equalsIgnoreCase("null")) {
            switch (application) {
                case "WJ":
                    if (tradeName.equalsIgnoreCase("B&B")) {
                        obj_generalInformation.businessNameTextbox().sendKeys("businessName");
                        new Select(obj_generalInformation.titleDropdown()).selectByVisibleText("Miss");
                        obj_generalInformation.firstNameTextbox().sendKeys("TCFourSeven");
                        obj_generalInformation.lastNameTextbox().sendKeys("FourSeven");
                        obj_generalInformation.postcodeTextbox().sendKeys("AB101AH");
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
                        Thread.sleep(1000);
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByValue("1");
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText("Sole business owner");
                        obj_generalInformation.pageLoading();
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTradeDropdown()).selectByVisibleText("2");
                        obj_generalInformation.pageLoading();
                    } else if (tradeName.equalsIgnoreCase("H&B")) {
                        if (anythingElse.equalsIgnoreCase("No")) {
                            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
                            obj_generalInformation.pageLoading();
                        }
                        if (anythingElse.equalsIgnoreCase("Yes")) {
                            String listOfTrades[] = tradeList.split("#");
                            for (int t = 0; t < listOfTrades.length; t++) {
                                obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseYesRadiobutton());
                                obj_generalInformation.pageLoading();
                                obj_generalInformation.otherTradeTextbox().sendKeys(listOfTrades[t]);
                                obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.multiTradeAutocompleteList(listOfTrades[t]));
                                obj_generalInformation.pageLoading();
                            }
                        }
                        obj_generalInformation.businessNameTextbox().sendKeys("businessName");
                        new Select(obj_generalInformation.titleDropdown()).selectByVisibleText("Miss");
                        obj_generalInformation.firstNameTextbox().sendKeys("TC FourSeven");
                        obj_generalInformation.lastNameTextbox().sendKeys("FourSeven");
                        obj_generalInformation.postcodeTextbox().sendKeys("AB101AH");
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
                        Thread.sleep(3000);
                        new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByValue("1");
                        Thread.sleep(3000);
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText("Limited company");
                        obj_generalInformation.pageLoading();
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTradeDropdown()).selectByVisibleText("2");
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText("Anywhere in the UK, Channel Islands and the Isle of Man");
                    }else if(tradeName.equalsIgnoreCase("OPR")){

                        if (anythingElse.equalsIgnoreCase("No")) {
                            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
                            obj_generalInformation.pageLoading();
                        }
                        if (anythingElse.equalsIgnoreCase("Yes")) {
                            String listOfTrades[] = tradeList.split("#");
                            for (int t = 0; t < listOfTrades.length; t++) {
                                obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseYesRadiobutton());
                                obj_generalInformation.pageLoading();
                                obj_generalInformation.otherTradeTextbox().sendKeys(listOfTrades[t]);
                                obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.multiTradeAutocompleteList(listOfTrades[t]));
                                obj_generalInformation.pageLoading();
                            }
                        }

                        obj_generalInformation.businessNameTextbox().sendKeys("OPRBusinessName");
                        new Select(obj_generalInformation.titleDropdown()).selectByVisibleText("Mr");
                        obj_generalInformation.firstNameTextbox().sendKeys(obj_generalInformationUtil.randomFirstName());
                        obj_generalInformation.lastNameTextbox().sendKeys(obj_generalInformationUtil.randomSecondName());
                        obj_generalInformation.postcodeTextbox().sendKeys("AB101AH");
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
                        Thread.sleep(3000);
                        new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByValue("1");
                        Thread.sleep(3000);
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText("Sole business owner");
                        obj_generalInformation.pageLoading();
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTradeDropdown()).selectByVisibleText("0");
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.giTurnOverDropDown()).selectByVisibleText("£25,001 - £50,000");
                        new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText("Anywhere in the UK, Channel Islands and the Isle of Man");


                    }
                    break;
                default:
                    if (tradeName.equalsIgnoreCase("B&B")) {
                        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText("Sole business owner");
                        obj_generalInformation.pageLoading();
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTradeDropdown()).selectByVisibleText("2");
                        obj_generalInformation.pageLoading();
                    } else if (tradeName.equalsIgnoreCase("H&B")) {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText("Sole business owner");
                        obj_generalInformation.pageLoading();
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTradeDropdown()).selectByVisibleText("2");
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText("Anywhere in the UK, Channel Islands and the Isle of Man");
                    }
                    else if (tradeName.equalsIgnoreCase("OPR")) {
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText("Sole business owner");
                        obj_generalInformation.pageLoading();
                        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.businessTradeDropdown()).selectByVisibleText("0");
                        obj_generalInformation.pageLoading();
                        new Select(obj_generalInformation.giTurnOverDropDown()).selectByVisibleText("£25,001 - £50,000");
                        new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText("Anywhere in the UK, Channel Islands and the Isle of Man");
                    }
            }
            obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
            obj_generalInformation.pageLoading();
            Thread.sleep(2000);
        }
    }

    public void saveAndExit(String screen, String application) throws Throwable {
        if (application.equalsIgnoreCase("WJ")) {
            switch (screen) {
                case "People":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonImportantStatements());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopupPeople());
                    obj_generalInformation.pageLoading();
                    functionalUtil.saveandExit();
                    obj_generalInformation.pageLoading();
                    break;
                case "Liability":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonImportantStatements());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopup());
                    obj_generalInformation.pageLoading();
                    functionalUtil.saveandExit();
                    obj_generalInformation.pageLoading();
                    break;
                case "Treatment":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonTreatment());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopup());
                    obj_generalInformation.pageLoading();
                    functionalUtil.saveandExit();
                    obj_generalInformation.pageLoading();
                    break;
                case "Premises":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonPremises());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopup());
                    obj_generalInformation.pageLoading();
                    functionalUtil.saveandExit();
                    obj_generalInformation.pageLoading();
                    break;
                case "PropertyAway":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonPropertyAway());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopup());
                    obj_generalInformation.pageLoading();
                    functionalUtil.saveandExit();
                    obj_generalInformation.pageLoading();
                    break;
                case "ImportantStatement":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonImportantStatements());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopup());
                    obj_generalInformation.pageLoading();
                    functionalUtil.saveandExit();
                    obj_generalInformation.pageLoading();
                    break;
                case "Claims":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonImportantStatements());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonImportantStatements());
                    obj_generalInformation.pageLoading();
                    functionalUtil.saveandExit();
                    obj_generalInformation.pageLoading();
                    break;
            }
        } else if(application.equalsIgnoreCase("CC")){

            switch (screen) {
                case "People":
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonImportantStatements());
                    obj_generalInformation.pageLoading();
                    obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopupPeople());
                    obj_generalInformation.pageLoading();
                     break;
            } }else if(application.equalsIgnoreCase("SS")){

                switch (screen) {
                    case "People":
                        obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonImportantStatements());
                        obj_generalInformation.pageLoading();
                        obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopup());
                        obj_generalInformation.pageLoading();
                        break;
                }

        } else {
            obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonImportantStatements());
            obj_generalInformation.pageLoading();
            obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitPopup());
            obj_generalInformation.pageLoading();
        }
    }

    public void userDeleteAddTreatmentfromQS() {
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.viewTreatmentsLink());
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.deleteTreatment1Button());
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.addAnotherTreatmentButton());
        obj_generalInformation.pageLoading();
        multiTreatmentFromQuoteSummary("1", "Y", "manicure and pedicure#facial including ionisation, electro-mechanical, ultra-sound and infa-red treatment");
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.viewTreatmentsLink());
        obj_generalInformation.pageLoading();

    }


    public void userDeleteAddTreatmentfromQS1() {
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.viewTreatmentsLink());
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.deleteTreatment1Button());
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.addAnotherTreatmentButton());
        obj_generalInformation.pageLoading();
        multiTreatmentFromQuoteSummary("1", "Y", "manicure and pedicure");
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.viewTreatmentsLink());
        obj_generalInformation.pageLoading();

    }

    public void multiTreatmentFromQuoteSummary(String people, String anyOtherTreatment, String treatment) {

        if (anyOtherTreatment.equalsIgnoreCase("Y")) {

            String treatmentList[] = treatment.split("#");
            for (int multitreatment = 0; multitreatment < treatmentList.length; multitreatment++) {
                if (multitreatment == 0) {
                    new Select(obj_quotesummary.treatmentDropDown()).selectByVisibleText(treatmentList[multitreatment]);
                    obj_generalInformation.pageLoading();
                    obj_quotesummary.peoplePerformTreatmentTextBox().sendKeys(people);
                    obj_generalInformation.pageLoading();
                    obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.addTreatmentButtonToSave());
                    obj_generalInformation.pageLoading();
                } else {
                    obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.addAnotherTreatmentButton());
                    obj_generalInformation.pageLoading();
                    new Select(obj_quotesummary.treatmentDropDown()).selectByVisibleText(treatmentList[multitreatment]);
                    obj_generalInformation.pageLoading();
                    obj_quotesummary.peoplePerformTreatmentTextBox().sendKeys(people);
                    obj_generalInformation.pageLoading();
                    obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.addTreatmentButtonToSave());
                    obj_generalInformation.pageLoading();
                }
            }
        }
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.addToQuoteButton());
        obj_generalInformation.pageLoading();
    }

    public void userVerifytheAddedTreatmentAndPremiumIncrease() {
        String strList1 = obj_quotesummary.manicureLabel().getText();
        if (strList1.contains("manicure")) {
            Assert.assertTrue("manicure treatment not displayed", true);
        } else {
            Assert.assertTrue(false);
        }
        String strList2 = obj_quotesummary.facialLabel().getText();
        if (strList2.contains("facial including")) {
            Assert.assertTrue(" facial including ionisation, electro-mechanical, ultra-sound and infa-red  treatment not displayed", true);
        } else {
            Assert.assertTrue(false);
        }
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.treatmentPopUpWindowCloseButton());
        obj_generalInformation.pageLoading();


    }

    public void userIncreaseToT() {
        String pound = "£";
        String valTOT = pound.concat("2,500");
        obj_generalInformation.pageLoading();
        new Select(obj_quotesummary.TOTdropDown()).selectByVisibleText(valTOT);
        obj_generalInformation.pageLoading();

    }

    public void userIncreaseBIlimit() {
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.amendBILimitButton());
        obj_generalInformation.pageLoading();
        new Select(obj_quotesummary.grossTurnOverDropDown()).selectByVisibleText("£75,001 - £100,000");
        obj_generalInformation.pageLoading();
        new Select(obj_quotesummary.monthOfCoverDropDown()).selectByVisibleText("24");
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.BIAddToQuoteButton());
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.BIpopUpWindowCloseButton());
        obj_generalInformation.pageLoading();
    }

    public void userFillsToTImptStmtLossAndClickSaveInQuoteSummary() throws Throwable {
        functionalUtil.fillTOTSection();
        functionalUtil.fillImportantStatementsSection();
        functionalUtil.fillPreviousLossesSection();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.SaveAndExit());
        obj_generalInformation.pageLoading();
        functionalUtil.saveandExit();
    }

    public void userEditPropertyAwayValues() throws Exception {
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.toolsSumInsuredTextBox());
        obj_generalInformation.pageLoading();
        obj_quotesummary.toolsSumInsuredTextBox().clear();
        obj_quotesummary.toolsSumInsuredTextBox().sendKeys("200");
        obj_commonUtil.tabKeypress();
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.viewStockCoverLink());
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.stockInTransitThirdPartyDeleteButton());
        obj_generalInformation.pageLoading();
        obj_quotesummary.stockInTransitOwnTextBox().clear();
        obj_quotesummary.stockInTransitOwnTextBox().sendKeys("200");
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.stockAddToQuoteButton());
        obj_generalInformation.pageLoading();

    }

    public void businessInteruptionThirdParty() {
        obj_generalInformation.pageLoading();
        obj_businessInteruptionParty.executeScript("arguments[0].click();", obj_businessInteruptionParty.rentChair());
        obj_generalInformation.pageLoading();
        obj_businessInteruptionParty.nameOfSaloon().sendKeys("saloon");
        obj_generalInformation.pageLoading();
        obj_businessInteruptionParty.postcode().sendKeys("AB10 1AH");
        obj_generalInformation.pageLoading();
        obj_businessInteruptionParty.executeScript("arguments[0].click();", obj_businessInteruptionParty.addSaloon());
        obj_generalInformation.pageLoading();
        obj_businessInteruptionParty.executeScript("arguments[0].click();", obj_businessInteruptionParty.nextbutton());
        obj_generalInformation.pageLoading();
    }

    public void partners(String title, String firstname, String lastname) {
        String dataList[] = title.split(",");
        String dataList1[] = firstname.split(",");
        String dataList2[] = lastname.split(",");
        for (int data = 0; data < dataList.length; data++) {

            if (data == 0) {
                obj_generalInformation.pageLoading();
                partners.executeScript("arguments[0].click();", partners.addPartner());
                obj_generalInformation.pageLoading();
                new Select(partners.title()).selectByVisibleText(dataList[data]);
                obj_generalInformation.pageLoading();
                partners.firstName().sendKeys(dataList1[data]);
                obj_generalInformation.pageLoading();
                partners.lastName().sendKeys(dataList2[data]);
                obj_generalInformation.pageLoading();
                partners.executeScript("arguments[0].click();", partners.addbutton());
                obj_generalInformation.pageLoading();
            } else {
                partners.executeScript("arguments[0].click();", partners.anotherPartners());
                obj_generalInformation.pageLoading();
                new Select(partners.title()).selectByVisibleText(dataList[data]);
                obj_generalInformation.pageLoading();
                partners.firstName().sendKeys(dataList1[data]);
                obj_generalInformation.pageLoading();
                partners.lastName().sendKeys(dataList2[data]);
                obj_generalInformation.pageLoading();
                partners.executeScript("arguments[0].click();", partners.addbutton());
                obj_generalInformation.pageLoading();
            }
        }
        partners.executeScript("arguments[0].click();", partners.nextbutton());
        obj_generalInformation.pageLoading();
    }

    public void NavigationTillTOTScreen() throws Exception {
        obj_generalInformation.pageLoading();
        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.selfEmployeeNoRadiobutton());
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.liabilityCoverNextButton());
        obj_generalInformation.pageLoading();
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.anyOtherTreatmentsYesNoButton("N"));
        obj_generalInformation.pageLoading();
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.nextButton());
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.householdremovecover(1));
        obj_businessPremises.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.subsidenceCoverNoRadiobutton(1));
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.nextButton());
        obj_generalInformation.pageLoading();
        functionalUtil.fillPropertyAwayFromPremiseHB("null", "null", "No", "null", "No", "null", "null", "null", "null", "null", "null", "null", "null");
    }

    public void hbImpornantStatementText() {
        String expected = "Neither you, or any director or partner of the business or its subsidiary companies either personally or in any business capacity:\nhas ever had a proposal refused or declined or ever had an insurance cancelled, renewal refused or had special terms imposed;\nhas ever been convicted of or charged (but not yet tried) with a breach of any health and safety legislation or any other criminal offence other than parking or speeding offences or offences which are spent under the Rehabilitation of Offenders Act 1974;\nhas been subject of a County Court Judgement and/or ever been cited in any unsatisfied court judgements (or the Scottish equivalent) within the last 10 years;\nhas been subject of an individual voluntary arrangement with creditors, voluntary liquidation, a winding up or administration order, or administrative receivership proceedings within the last 10 years;\nare subject to bankruptcy or insolvency orders which are outstanding or have been discharged for less than 5 years.\nYour business:\ndoes not manufacture any lotion, hair dye or other preparation and only mixes or blends oils, creams and lotions in accordance with manufacturers' instructions.\nYour premises:\ndo not need any repair or refurbishment to make them secure or water tight and will be so maintained.\n  I agree\nI disagree\nSave & exit";
        String contentFromPage = obj_impornantstatement.contentsImpStmtHbfull().getText();
        if (expected.equals(contentFromPage)) {
            Assert.assertTrue(true);
        } else Assert.assertTrue(false);
    }

    public void userClicksOnContinueQuoteAndProceedTillTOTPage() throws Exception {
        obj_generalInformation.pageLoading();
        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.liabilityCoverNextButton());
        obj_generalInformation.pageLoading();
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.nextButton());
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.subsidenceCoverNoRadiobutton(1));
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.nextButton());
        obj_generalInformation.pageLoading();
        functionalUtil.fillPropertyAwayFromPremiseHB("No", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null");
        obj_generalInformation.pageLoading();
        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.businessInterruptionNextButton());
        obj_generalInformation.pageLoading();
        obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.nextButton());
        obj_generalInformation.pageLoading();
        obj_impornantstatement.executeScript("arguments[0].click();", obj_impornantstatement.importantStatNextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillBISection(String turnover, String months) throws Exception {
        new Select(obj_businessInterruption.grossTurnOverDropDown()).selectByVisibleText(turnover);
        obj_generalInformation.pageLoading();
        new Select(obj_businessInterruption.monthOfCoverDropDown()).selectByVisibleText(months);
        obj_generalInformation.pageLoading();
        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.businessInterruptionNextButton());
        obj_generalInformation.pageLoading();
    }

    public void thirdPartyAtBI(String nameSalon, String postcode) {
        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.addSalon());
        obj_generalInformation.pageLoading();
        obj_businessInterruption.thirdPartyNameBI().sendKeys(nameSalon);
        obj_generalInformation.pageLoading();
        obj_businessInterruption.thirdPartyPostCodeBI().sendKeys(postcode);
        obj_generalInformation.pageLoading();
        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.addBIatThirdParty());
        obj_generalInformation.pageLoading();
        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.nextBIThirdParty());
        obj_generalInformation.pageLoading();
    }

    public void fillsPeopleBusinessSection() throws Exception {
//        new Select(obj_peoplebusiness.toldUsBuisnessDropdownbox()).selectByVisibleText("No employees");
//        obj_generalInformation.pageLoading();
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
    }


    public void fillLiabilityCoverSection() throws Exception {
        new Select(obj_liabilitycover.public_LiabilitycoverDropdown()).selectByValue("1000000");
        obj_generalInformation.pageLoading();
//        new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("No");
        String strtext = obj_liabilitycover.productsOutsideukDropdownList().getText();
        if (strtext.trim().equalsIgnoreCase("No")) {
            new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("No");
        } else {
            new Select(obj_liabilitycover.productsOutsideukDropdown()).selectByVisibleText("UK only");
        }
        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.liabilityCoverNextButton());
        obj_generalInformation.pageLoading();
    }

    public void compareDueAmount() throws Throwable {
        String strtext1 = obj_cc_login.paymentAmountDue().getText();
        obj_cc_login.executeScript("arguments[0].click();", obj_cc_login.takePaymentLinkEC());
        obj_generalInformation.pageLoading();
        Thread.sleep(2000);
            String strtext2 = obj_cc_login.paymentAmountPopUpDue().getAttribute("value");
        Thread.sleep(2000);
            Assert.assertTrue(strtext1.equals(strtext2));
           //String strTnxText = obj_cc_login.tnxId().getText();
          //Assert.assertTrue(strTnxText.equalsIgnoreCase(" Transaction ID"));

            obj_cc_login.nameOnCardEC().sendKeys("Engagement");

    }

    public void compareSumDueAmount() throws Throwable {
        String newText1="";
        double  text1 =  morethanTwoCheckBox();
         newText1 = Double.toString(text1);
        obj_cc_login.executeScript("arguments[0].click();", obj_cc_login.takePaymentLinkEC());
        obj_generalInformation.pageLoading();
        Thread.sleep(2000);
        String strtext2 = obj_cc_login.paymentAmountPopUpDue().getAttribute("value");
        Thread.sleep(2000);
        Assert.assertTrue(newText1.equals(strtext2));

       // String strTnxText = obj_cc_login.tnxId().getText();
       // Assert.assertTrue(strTnxText.equalsIgnoreCase(" Transaction ID"));

        obj_cc_login.nameOnCardEC().sendKeys("Engagement");
    }



    // payment session.......

    public void fillYourBusinessWithDefaultValues() throws Throwable {
        fillPaymentSection();
        fillDirectDebitSection();
        fillPaymentInformationDetails();
        functionalUtil.fillCardDetailsSection("Visa");
    }


    public double morethanTwoCheckBox() throws Throwable {

        String data =""; double amnt=0;

        Thread.sleep(4000);

        for(int i=1;i<=4;i++) {

            String element = getDriver.findElement(By.xpath("//*[@id='finance_table']/tbody/tr[" + i + "]/td[6]")).getText();
            if (element.equals("0.00")) {
                WebElement element1 = getDriver.findElement(By.xpath("//*[starts-with(@id,'C2__C6__FS_QUE_EB05634B0D109C89693217_0_R" + i + "')]"));
                ((JavascriptExecutor) getDriver).executeScript("arguments[0].click();", element1);


                ccSearch.ccPageLoad();
                //*[@id="finance_table"]/tbody/tr/td[5]
                data = getDriver.findElement(By.xpath("//*[@id='finance_table']/tbody/tr[" + i + "]/td[5]")).getText();
                double Amount = Double.parseDouble(data);
                amnt = Amount + amnt;
            }
        }
        double roundOff = Math.round(amnt * 100.0) / 100.0;
        return roundOff;


    }



    public void fillYourBusinessWithVISAWorldPay(String hb) throws Throwable {
        fillPaymentSection();
        fillPaymentInformationDetails();
        functionalUtil.fillCardDetailsSection("Visa");
    }

    public void fillYourBusinessWithCardVISAWorldPay() throws Throwable {
        functionalUtil.fillCardDetailsSectionVisa("Visa");
    }

    public void fillYourBusinessWithDDVisa(String hb) throws Throwable {
        fillPaymentSection();
        fillDirectDebitSection();
        fillPaymentInformationDetails();
        fillCardDetailsSectionVISA();
    }

    public void fillYourBusinessWithDDAmex(String CC) throws Throwable {
        fillPaymentSection();
        fillDirectDebitSection();
        fillPaymentInformationDetails();
        fillCardDetailsSectionAmex(CC);
    }

    public void fillYourBusinessWithDDAmexPaymentFailure(String CC) throws Throwable {
        fillPaymentSection();
        fillDirectDebitSection();
        fillPaymentInformationDetails();
        fillCardDetailsSectionAmexPaymentFailure(CC);
    }

    public void fillYourBusinessWithDDMaestro(String CC) throws Throwable {
        fillPaymentSection();
        fillDirectDebitSection();
        fillPaymentInformationDetails();
        fillCardDetailsSectionMaestro(CC);
    }

    private void fillPaymentSection() {
         obj_paymentSelection.monthlyLink().click();
        obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.monthlyLink());
        obj_generalInformation.pageLoading();
        obj_paymentSelection.executeScript("arguments[0].click();", obj_paymentSelection.acceptRadiobutton());
        obj_generalInformation.pageLoading();
        obj_paymentSelection.renewRadiobutton().click();
        obj_generalInformation.pageLoading();
        obj_paymentSelection.understoodRadiobutton().click();
        obj_generalInformation.pageLoading();
        obj_paymentSelection.paymentScreenNextButton().click();
        obj_generalInformation.pageLoading();
    }

    public void fillPaymentInformationDetails() {
        obj_paymentInformation.cardBelongsToYesRadiobutton().click();
        obj_generalInformation.pageLoading();
        obj_paymentInformation.cardPermissionYesRadiobutton().click();
        obj_generalInformation.pageLoading();
        obj_paymentInformation.cardHolderNameTextbox().click();
        obj_paymentInformation.cardHolderNameTextbox().sendKeys("Smokecard");
        obj_generalInformation.pageLoading();
        obj_paymentInformation.billingAddressYesRadiobutton().click();
        obj_generalInformation.pageLoading();
        obj_paymentInformation.PaymentInfoNextButton().click();
        obj_generalInformation.pageLoading();
    }


    public void fillCardDetailsSection() throws Throwable {
        Thread.sleep(3000);
        obj_commonUtil.switchFrame("sagepay");
        Thread.sleep(5000);
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.masterCardLink());
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardNumberTextbox().sendKeys("5555555555554444");
        obj_cardDetails.cardVerificationCodeTextbox().click();
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardholderNameTextbox().click();
        obj_cardDetails.cardholderNameTextbox().sendKeys("Cindrella");
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardVerificationCodeTextbox().sendKeys("123");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryMMDropdown()).selectByVisibleText("05");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryYYYYDropdown()).selectByVisibleText("2025");
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.buyPolicyButton());
        obj_generalInformation.pageLoading();
        obj_cardDetails.avsResponse();
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.sppContinueButton());
        obj_generalInformation.pageLoading();
//        String policyNumber = obj_cardDetails.policyNumberFetch().getText();
    }

    public void fillCardDetailsSectionPaymentCancel(String app) throws Throwable {
        Thread.sleep(3000);
        obj_commonUtil.switchFrame("sagepay");
        Thread.sleep(5000);
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.masterCardLink());
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardNumberTextbox().sendKeys("5555555555554444");
        obj_cardDetails.cardVerificationCodeTextbox().click();
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardholderNameTextbox().click();
        obj_cardDetails.cardholderNameTextbox().sendKeys("Cindrella");
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardVerificationCodeTextbox().sendKeys("123");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryMMDropdown()).selectByVisibleText("05");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryYYYYDropdown()).selectByVisibleText("2025");
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.cancelPaymentButton());
        obj_generalInformation.pageLoading();
    }


    public void fillDirectDebitSection() {
        obj_directDebit.directdebitYesRadiobutton().click();
        obj_generalInformation.pageLoading();
        obj_directDebit.sortCodeTextbox().click();
        obj_directDebit.sortCodeTextbox().sendKeys("090126");
        obj_generalInformation.pageLoading();
        obj_directDebit.accountNumberTextbox().click();
        obj_directDebit.accountNumberTextbox().sendKeys("02948723");
        obj_generalInformation.pageLoading();
        obj_directDebit.installmentdayTextbox().click();
        obj_directDebit.installmentdayTextbox().sendKeys("20");
        obj_generalInformation.pageLoading();
        obj_directDebit.paymentInformationNextButton().click();
        obj_generalInformation.pageLoading();

    }

    public void saveAndExitAfterQuote() {

        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.SaveAndExit());
        obj_generalInformation.pageLoading();

    }

    public void userAccountDetailSection() throws Exception {
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.createAccountButton());
        obj_generalInformation.pageLoading();
        obj_quotesummary.contactEmailTextbox().sendKeys("emp25@mail.com");
        obj_generalInformation.pageLoading();
        obj_quotesummary.confirmEmailTextbox().sendKeys("emp25@mail.com");
        obj_generalInformation.pageLoading();
        obj_quotesummary.telephoneNumberTextbox().sendKeys("7405700740");
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.emailRadiobutton());
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.saveExitButton());
        obj_generalInformation.pageLoading();
        // obj_generalInformation.pageLoading();
        // obj_userDetail.executeScript("arguments[0].click();", obj_userDetail.createAccountNextButton());
        // obj_generalInformation.pageLoading();

    }

    public void saveGeneralInformation() throws Throwable {
        createcustomer.executeScript("arguments[0].click();", createcustomer.saveExitButton());
        obj_generalInformation.pageLoading();
        //  createcustomer.executeScript("arguments[0].click();", createcustomer.saveExitButton1());
        // obj_generalInformation.pageLoading();
        //  commonutil.clickElement(createcustomer.saveExitButton1());
        commonutil.clickbyJS(createcustomer.saveExitButtonPopUp());
        obj_generalInformation.pageLoading();

    }

    public void customerInformation()

    {

        createcustomer.emailTextBox().sendKeys("emp91@mail.com");

        createcustomer.confirmEmailTextBox().click();
        obj_generalInformation.pageLoading();
        createcustomer.confirmEmailTextBox().sendKeys("emp91@mail.com");
        obj_generalInformation.pageLoading();
        createcustomer.contactNoTextBox().sendKeys("7405700740");
        obj_generalInformation.pageLoading();

        createcustomer.executeScript("arguments[0].click();", createcustomer.emailCheckBox());
        obj_generalInformation.pageLoading();
        createcustomer.executeScript("arguments[0].click();", createcustomer.saveExitButton2());
        obj_generalInformation.pageLoading();
    }

    public void premiseDetailEdit() {
        obj_quotesummary.premiseDetailsEditLink().click();
        obj_generalInformation.pageLoading();
    }

    public void removeCovers() {
        createcustomer.removeBusinessTools().click();
        createcustomer.removeBusinessToolsYesButton().click();
        obj_generalInformation.pageLoading();
        createcustomer.removeBusinessContents().click();
        createcustomer.removeBusinessToolsYesButton().click();
        obj_generalInformation.pageLoading();
        obj_claims.executeScript("arguments[0].click();", obj_claims.ReviewAndConfirm());
        obj_generalInformation.pageLoading();
    }

    public void businessPremiseTradeSelection(int i) {
        if (obj_businessPremises.trade(i).isDisplayed()) {
            int rowcount = obj_businessPremises.tradeTableRow().size();
            for (int n = 1; n <= rowcount; n++) {
                if (obj_businessPremises.tradeselect(i, n).isDisplayed()) {
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.tradeselect(i, n));
                    obj_businessPremises.pageLoading();
                } else if (!obj_businessPremises.tradeselect(i, n).isDisplayed()) {
                    obj_businessPremises.pageLoading();
                }
            }
        }
    }

    public void fillCoverWizardAndVerifyCoversDisplayed() {
        fillCoverWizardSectionForHnB("Hair and beauty therapist", "I rent a chair or a space from a salon#Mobile business#I work from home", "Temporary employee(s)", "Y", "Hair and beauty treatments liability");
        UserchecksCoverListbeingDisplayed();
        obj_coverwizard.coversContinueButton().click();
    }

    public void fillCoverWizardSectionForHnB(String tradeName, String workBusiness, String haveEmployees, String employeeLiabilityCover, String covers) {
        obj_coverwizard.tradeNameTextbox().sendKeys(tradeName);
        obj_coverwizard.tradeNameSelect().click();
        String[] businessFromCheckbox = workBusiness.split("#");
        for (int i = 0; i < businessFromCheckbox.length; i++) {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.businessFromCheckbox(businessFromCheckbox[i]));
        }
        obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.businessNextButton());
        obj_generalInformation.pageLoading();
        if (haveEmployees.equalsIgnoreCase("No")) {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.noEmployeesRadiobutton());

        } else {
            if (haveEmployees.equalsIgnoreCase("Permanent employee(s)")) {
                haveEmployee = "P";
            } else if (haveEmployees.equalsIgnoreCase("Temporary employee(s)")) {
                haveEmployee = "T";
            } else if (haveEmployees.equalsIgnoreCase("Permanent & temporary employees")) {
                haveEmployee = "B";
            } else if (haveEmployees.equalsIgnoreCase("No")) {
                haveEmployee = "N";
            }
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.haveEmployeesButton(haveEmployee));
            //obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.haveEmployeesButton(haveEmployees));
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.ClkemployersLiabilityCoverRadiobutton(employeeLiabilityCover));
        }
        String[] cover = covers.split("#");
        for (int i = 0; i < cover.length; i++) {
            obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversCheckboxHB(cover[i]));
        }
    }

    private void UserchecksCoverListbeingDisplayed() {
        int size = obj_coverwizard.CoverList().size();
        for (int i = 0; i < size; i++) {
            String strList = obj_coverwizard.CoverList().get(i).getText();
            if (strList.contains("Hair and beauty treatments liability") || strList.contains("Business Stock") || strList.contains("Theft of takings") || strList.contains("Business Interruption") || strList.contains("Business contents") || strList.contains("Your home (the building)") || strList.contains("Your household contents") || strList.contains("None")) {
                Assert.assertTrue("Correct  covers  displayed", true);
            } else {
                Assert.assertTrue(false);
            }
        }
    }

    public void userProceedTillTreatmentSection() throws Exception {
        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseYesRadiobutton());
        obj_generalInformation.pageLoading();
        obj_generalInformation.tradeNameTextbox().sendKeys("Tanning salon");
        obj_generalInformation.pageLoading();
        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.addMultipleTradeNameSelect("Tanning salon"));
        obj_generalInformation.pageLoading();
        String strList = obj_generalInformation.tanningSalonErrorMsg().getText();
        if (strList.contains("We're sorry")) {
            Assert.assertTrue("Error message displayed", true);
        } else {
            Assert.assertTrue(false);
        }
        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
        obj_generalInformation.pageLoading();
        fillGeneralInformationSpecificValueMultiTrade("hb", "Y", "TC32", "Mr", "TC32", "Reg", "Sole business owner", "N", "2", "AB101AH", "null", "Anywhere in the UK, Channel Islands and the Isle of Man", "Beautician;Beauty therapist;Make-up artist;Nail technician");
        fillPeopleInYourBusinessSectionSpecificValue("Yes", "Temporary employee(s)", "Yes", "2", "1", "null", "null", "null", "null", "null", "null", "null");
        functionalUtil.fillLiabilityCoverSection();
        multiTreatmentCoverSection("2", "Y", "cranio-sacral therapy#biosthetics");

    }

    public void userProceedTillQuoteSummary() throws Throwable {
        functionalUtil.fillPropertyAwayFromPremise("H&B", "N", "N", "No", "No", "null", "null", "No");
        functionalUtil.fillImportantStatementsSection();
        functionalUtil.fillPreviousLossesSection();
        obj_generalInformation.pageLoading();
    }

    public void userAddTreatmentFromQS() {
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.viewTreatmentsLink());
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.addAnotherTreatmentButton());
        obj_generalInformation.pageLoading();
        multiTreatmentFromQuoteSummary("1", "Y", "Faradic treatment#Reiki#trichology");
        obj_generalInformation.pageLoading();
    }

    public void userAddPremiseFromQSPage(String iteration) throws Exception {
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.addPremise());
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.addAnotherPremise());
        obj_generalInformation.pageLoading();
        premisesOutbuildingsWallTimberRoofCustomIteration(iteration);

    }

    public void userEditQuote() throws Throwable {
        commonutil.clickbyJS(obj_coverwizard.ManagequoteButton());
        commonutil.clickbyJS(obj_coverwizard.editButton());
        ccSearch.ccPageLoad();
        //obj_commonUtil.switchFrame("sagepay");
    }

    public void userSearchPolicyinCC(String searchbusiness) throws Throwable {
        if (!searchbusiness.equalsIgnoreCase("null")) {
            obj_coverwizard.searchbusinessTextbox().sendKeys(strBusinessName);
        } else {
            ccsearchUtil.setSearchvalue(CarddetailsUtil.policyno, ccSearch.policyNumberTextbox());
        }
        ccSearch.searchButton().click();
        ccSearch.ccPageLoad();
        ccSearch.policySelectionLink().click();
        ccSearch.ccPageLoad();
        ccSearch.authorizContanctselectionLink().click();
        ccSearch.ccPageLoad();
        ccSearch.passedVerificaitionButton().click();
        ccSearch.ccPageLoad();
    }

    public void userSearchPolicyNOinCC(String searchbusiness) throws Throwable {
        if (!searchbusiness.equalsIgnoreCase("null")) {
            ccsearchUtil.setSearchvalue(searchbusiness, ccSearch.policyNumberTextbox());
        }

        ccSearch.searchButton().click();
        ccSearch.ccPageLoad();
        ccSearch.policySelectionLink().click();
        ccSearch.ccPageLoad();
        ccSearch.authorizContanctselectionLink().click();
        ccSearch.ccPageLoad();
        Thread.sleep(2000);
        ccSearch.passedVerificaitionButton().click();
        ccSearch.ccPageLoad();
    }

    public void fillGeneralInformationSectionRandom(String hb) throws Exception {
        if (hb.equalsIgnoreCase("hb")) {
            obj_generalInformation.anythingElseNoRadiobutton().click();
            obj_generalInformation.pageLoading();
            new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText("Anywhere in the UK, Channel Islands and the Isle of Man");
        }
        strBusinessName = obj_generalInformationUtil.randomFirstName();
        obj_generalInformation.businessNameTextbox().sendKeys(strBusinessName);
        new Select(obj_generalInformation.titleDropdown()).selectByVisibleText("Mr");
        strFirstName = obj_generalInformationUtil.randomFirstName();
        obj_generalInformation.firstNameTextbox().sendKeys(strFirstName);
        obj_commonUtil.tabKeypress();
        GeneralinformationUtil.firstName(obj_generalInformation.firstNameTextbox());
        strSecondName = obj_generalInformationUtil.randomSecondName();
        obj_generalInformation.lastNameTextbox().sendKeys(strSecondName);
        GeneralinformationUtil.lastName(obj_generalInformation.lastNameTextbox());
        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText("Sole business owner");
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
        obj_generalInformation.pageLoading();
        new Select(obj_generalInformation.tradeDropdownListValue()).selectByVisibleText("2");
        obj_generalInformation.pageLoading();
        obj_generalInformation.postcodeTextbox().sendKeys("AB10 1AH");
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
        Thread.sleep(3000);
        new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByValue("1");
        obj_generalInformation.pageLoading();
//        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.mobileDropdown());
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillCCCreateContact() throws Throwable {
        obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.createNewCustomerButton());
        obj_generalInformation.pageLoading();
        strBusinessName = obj_generalInformationUtil.randomBusinessName();
        obj_createCustomer.corporateContact().click();
        obj_createCustomer.tradeNametextbox().sendKeys(strBusinessName);
        obj_generalInformationUtil.businessName(obj_createCustomer.tradeNametextbox());
        new Select(obj_createCustomer.addressTypeButton()).selectByVisibleText("Business");
        new Select(obj_createCustomer.countryTextbox()).selectByVisibleText("Scotland");
        obj_generalInformation.pageLoading();
        obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.postCodeTextbox());
        Thread.sleep(1000);
        obj_createCustomer.postCodeTextbox().sendKeys("AB101AH");
        obj_generalInformation.pageLoading();
        obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.findAddressButton());
        obj_generalInformation.pageLoading();
//        obj_createCustomer.selectAddressDropdown().click();
//        obj_generalInformation.pageLoading();
        new Select(obj_createCustomer.titleContactDetailsDropdown()).selectByVisibleText("Mr");
        obj_generalInformation.pageLoading();
        obj_createCustomer.firstnameContactDetailsTextbox().sendKeys("frozes");
        obj_generalInformation.pageLoading();
        obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.lastnameContactDetailstextbox());
        obj_generalInformation.pageLoading();
        obj_createCustomer.lastnameContactDetailstextbox().sendKeys("roses");
        obj_generalInformation.pageLoading();
        obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.mobileBusinessTextbox());
        obj_generalInformation.pageLoading();
        obj_createCustomer.mobileBusinessTextbox().sendKeys("07584768389");
        obj_generalInformation.pageLoading();
        obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.emailBusinessTextbox());
        Thread.sleep(1000);
        obj_createCustomer.emailBusinessTextbox().sendKeys("abcd@gmail.com");
        obj_createCustomer.waitForPageLoad();
        obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.marketingPreferenceNoRadiobutton());
        obj_generalInformation.pageLoading();
        obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.correspondenceByMailRadiobutton());
        obj_generalInformation.pageLoading();
        obj_createCustomer.smsNotificationCheckbox().click();
        obj_generalInformation.pageLoading();
        obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.saveButtonButton());
        Thread.sleep(2000);
        obj_createCustomer.executeScript("arguments[0].click();", obj_createCustomer.newQuoteButton());
        obj_generalInformation.pageLoading();
        Thread.sleep(2000);
        obj_commonUtil.switchFrame("sagepay");


    }

    public void ccUserFillTillClaimsPageForHomeBusinessTempEmpToTBIPropAway() throws Exception {
        functionalUtil.fillCoverWizardSectionForHnB("Hair and beauty therapist", "I work from home", "Temporary employee(s)", "Y", "Hair and beauty treatments liability#Business interruption#Theft of takings#Business stock");
        fillGeneralInformationSpecificValueMultiTrade("hb", "N", "null", "null", "null", "null", "Partnership or limited partnership", "N", "2", "null", "null", "Anywhere in the UK, Channel Islands and the Isle of Man", "null");
        fillPeopleInYourBusinessSectionSpecificValue("Yes", "Temporary employee(s)", "Yes", "2", "1", "2", "1", "null", "null", "null", "null", "null");
        functionalUtil.fillLiabilityCoverSection();
        functionalUtil.fillTreatmentsBusiness();
        premisesOutbuildingsWallTimberRoof();
        functionalUtil.fillPropertyAwayFromPremiseHB("No", "null", "Yes", "200", "Yes", "100", "null", "null", "null", "null", "null", "null", "null");
        functionalUtil.fillBusinessInterruption();
        functionalUtil.fillTheftOfTakings();
        functionalUtil.fillImportantStatementsSection();
        fillPreviousLossesSectionWithoutQuote();

    }

    public void userSearchPolicyinCC() throws Throwable {
        obj_coverwizard.searchbusinessTextbox().sendKeys(functionalUtil.strBusinessName);
        ccSearch.ccPageLoad();
        ccSearch.searchButton().click();
        ccSearch.ccPageLoad();
        ccSearch.policySelectionLink().click();
        ccSearch.ccPageLoad();
        ccSearch.authorizContanctselectionLink().click();
        ccSearch.ccPageLoad();
        ccSearch.passedVerificaitionButton().click();
        ccSearch.ccPageLoad();
        ccSearch.ManagequoteButton().click();
        ccSearch.editButton().click();
        ccSearch.ccPageLoad();
        commonutil.switchFrame("sagepay");
        Thread.sleep(1000);
    }

    public void userVerifiesQSPageCustom() {
        float f = quoteSummeryPremiumCapture();
        Assert.assertTrue(f + "Premium is Not displayed or 0", f > 0);
        verifyQSPolicyLevelCover();
        obj_postquote.executeScript("arguments[0].click();", obj_quotesummary.PremiseShowArrow());
        verifyPremiseCoverValidation();
        verifyAnyOtherPoliciesOptions();
        verifyMoreOptionsCover();
        verifyAddCoverLinkinMoreOptions();
    }

    private void verifyPremiseCoverValidation() {

        String premiseTab = obj_quotesummary.premiseTabCC().get(0).getText();
        if (premiseTab.contains("Premises 1")) {
            Assert.assertTrue(premiseTab + "is displayed", true);
        } else if (premiseTab.contains("Premises 2")) {
            Assert.assertTrue(premiseTab + "is displayed", true);
        } else {
            Assert.assertFalse(false);
        }


    }

    public void userNavigateTillQuoteSummaryPageinCC() throws Throwable {
        obj_generalInformation.pageLoading();
        obj_commonUtil.switchFrame("sagepay");
        obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.liabilityCoverNextButton());
        obj_generalInformation.pageLoading();
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.anyOtherTreatmentNoButton());
        obj_generalInformation.pageLoading();
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.nextButton());
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outBuildingStockRemoveButton(1));
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.subsidenceCoverNoRadiobutton(1));
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.nextButton());
        obj_generalInformation.pageLoading();
        functionalUtil.fillPropertyAwayFromPremiseHB("No", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null", "null");
        obj_generalInformation.pageLoading();
        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.businessInterruptionNextButton());
        obj_generalInformation.pageLoading();
        obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.nextButton());
        obj_generalInformation.pageLoading();
        obj_impornantstatement.executeScript("arguments[0].click();", obj_impornantstatement.importantStatNextButton());
        obj_generalInformation.pageLoading();
        functionalUtil.fillPreviousLossesSection();
    }

    public void saveAndExitCC() throws Throwable {
        obj_saveExit.executeScript("arguments[0].click();", obj_saveExit.saveAndExitButtonQSCC());
        obj_generalInformation.pageLoading();
    }



    public void userupdatesPreviousLossesDetails() throws Exception {
        obj_claims.executeScript("arguments[0].click();", obj_claims.changebutton());
        obj_generalInformation.pageLoading();
        obj_claims.Lossamt().clear();
        obj_claims.Lossamt().sendKeys("1000");
        obj_claims.executeScript("arguments[0].click();", obj_claims.updateLossButton());
        obj_generalInformation.pageLoading();
        obj_claims.executeScript("arguments[0].click();", obj_claims.getQuoteButton());
        obj_generalInformation.pageLoading();
    }


    public void navigationTillTreatmentscreen(String cc) throws Throwable {
        obj_generalInformation.pageLoading();
        if (cc.equalsIgnoreCase("CC")) {
            obj_commonUtil.switchFrame("sagepay");
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
        } else {
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
        }
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.liabilityCoverNextButton());
        obj_generalInformation.pageLoading();
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.anyOtherTreatmentsYesNoButton("N"));
        obj_generalInformation.pageLoading();
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.qualificationYesButton());
        obj_generalInformation.pageLoading();
        obj_treatmentprovide.executeScript("arguments[0].click();", obj_treatmentprovide.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void navigationTillLiabilityscreen(String cc) throws Throwable {
        obj_generalInformation.pageLoading();
        if (cc.equalsIgnoreCase("CC")) {
            obj_commonUtil.switchFrame("sagepay");
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
        } else {
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
        }
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();

    }


    public void fillPreviousLossesSectionSavenExit() throws Exception {
        obj_claims.executeScript("arguments[0].click();", obj_claims.previousLossesNoRadiobutton());
        obj_generalInformation.pageLoading();
        obj_claims.executeScript("arguments[0].click();", obj_claims.getQuoteButton());
        obj_generalInformation.pageLoading();
        obj_claims.executeScript("arguments[0].click();", obj_claims.saveAndExitButtonQuoteSummary());
        obj_generalInformation.pageLoading();
    }

    public void fillGeneralInformationSectionForHnB(String hb) throws Exception {
        if (hb.equalsIgnoreCase("hb")) {
            obj_generalInformation.anythingElseNoRadiobutton().click();
            obj_generalInformation.pageLoading();
            new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText("Anywhere in the UK, Channel Islands and the Isle of Man");
        }
        obj_generalInformation.pageLoading();
        strBusinessName = obj_generalInformationUtil.randomFirstName();
        obj_generalInformation.businessNameTextbox().sendKeys(strBusinessName);
        obj_generalInformation.pageLoading();
        new Select(obj_generalInformation.titleDropdown()).selectByVisibleText("Mr");
        String strFirstName = obj_generalInformationUtil.randomFirstName();
        obj_generalInformation.firstNameTextbox().sendKeys(strFirstName);
        obj_commonUtil.tabKeypress();
        GeneralinformationUtil.firstName(obj_generalInformation.firstNameTextbox());
//        String strValue=obj_generalInformation.firstNameTextbox().getAttribute("value");
        String strSecondName = obj_generalInformationUtil.randomSecondName();
        obj_generalInformation.lastNameTextbox().sendKeys(strSecondName);
        GeneralinformationUtil.lastName(obj_generalInformation.lastNameTextbox());
        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText("Limited company");
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
        obj_generalInformation.pageLoading();
        new Select(obj_generalInformation.tradeDropdownListValue()).selectByVisibleText("2");
        obj_generalInformation.pageLoading();
        obj_generalInformation.postcodeTextbox().sendKeys("AB10 1AH");
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
        Thread.sleep(3000);
        new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByValue("1");
        obj_generalInformation.pageLoading();
//        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.mobileDropdown());
        //  new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText("Anywhere in the UK, Channel Islands and the Isle of Man");
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
    }

    public void fillCCSearch() throws Throwable {
        obj_cc_login.executeScript("arguments[0].click();", obj_cc_login.passedVerificationButton());
        obj_generalInformation.pageLoading();
        obj_cc_login.executeScript("arguments[0].click();", obj_cc_login.manageQuoteLink());
        obj_generalInformation.pageLoading();
        obj_cc_login.executeScript("arguments[0].click();", obj_cc_login.manageQuoteEditLink());
//        obj_commonUtil.executeScript("return document.readyState").equals("complete");
        obj_commonUtil.switchFrame("sagepay");
    }

    public void userDeleteAddTreatmentfromQSQnB() throws Throwable {

//        Thread.sleep(5000);
//        obj_quotesummary.policyLevelCover();
//        obj_quotesummary.viewTreatmentsLink();
//        obj_quotesummary.viewTreatmentsLink().click();
        //Float prem1 = quoteSummeryPremiumCapture();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.viewTreatmentsLink());
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.deleteTreatment1Button());
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.addTreatmentButtonInQS());
        obj_generalInformation.pageLoading();
        treatmentFromQuoteSummaryQnB("1", "Y", "manicure and pedicure");
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.addAnotherTreatmentButtonInQS());
        obj_generalInformation.pageLoading();
        treatmentFromQuoteSummaryQnB("1", "Y", "facial including ionisation, electro-mechanical, ultra-sound and infa-red treatment");
        obj_generalInformation.pageLoading();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.addToQuoteButton());
        obj_generalInformation.pageLoading();
        Float prem2 = quoteSummeryPremiumCapture();
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.viewTreatmentsLink());
        obj_generalInformation.pageLoading();
        String treat1 = obj_treatmentprovide.manicureText().getText();
        String text1 = "manicure and pedicure";
        String treat2 = obj_treatmentprovide.facialText().getText();
        String text2 = "facial including ionisation, electro-mechanical, ultra-sound and infa-red treatment";
        Assert.assertTrue("Treatment1 is displayed", treat1.equalsIgnoreCase(text1));
        Assert.assertTrue("Treatment2 is displayed", treat2.equalsIgnoreCase(text2));
        // Assert.assertTrue("Premium has changed",!prem2.equals(prem1));

    }

    public void treatmentFromQuoteSummaryQnB(String people, String anyOtherTreatment, String treatment) {

        if (anyOtherTreatment.equalsIgnoreCase("Y")) {
            new Select(obj_quotesummary.treatmentDropDown()).selectByVisibleText(treatment);
            obj_generalInformation.pageLoading();
            obj_quotesummary.peoplePerformTreatmentTextBox().sendKeys(people);
            obj_generalInformation.pageLoading();
            obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.addTreatmentButtonToSave());
            obj_generalInformation.pageLoading();
        }
    }

    public void navigationTillTOT(String cc) throws Throwable {
        obj_generalInformation.pageLoading();
        if (cc.equalsIgnoreCase("CC")) {
            obj_commonUtil.switchFrame("sagepay");
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
        } else {
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
        }
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.liabilityCoverNextButton());
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.householdremovecover(1));
        obj_businessPremises.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.subsidenceCoverNoRadiobutton(1));
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.nextButton());
        obj_generalInformation.pageLoading();
        functionalUtil.fillPropertyAwayFromPremiseHB("No", "null", "No", "null", "No", "null", "null", "null", "null", "null", "null", "null", "null");
        obj_businessInterruption.executeScript("arguments[0].click();", obj_businessInterruption.businessInterruptionNextButton());
        obj_generalInformation.pageLoading();
    }

    public void navigationTillPropertyAway(String cc) throws Throwable {
        obj_generalInformation.pageLoading();
        if (cc.equalsIgnoreCase("CC")) {
            obj_commonUtil.switchFrame("sagepay");
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
        } else {
            obj_generalInformation.executeScript("arguments[0].click();", obj_generalInformation.anythingElseNoRadiobutton());
        }
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.executeScript("arguments[0].click();", obj_peoplebusiness.peopleBusinessNextbutton());
        obj_generalInformation.pageLoading();
        obj_liabilitycover.executeScript("arguments[0].click();", obj_liabilitycover.liabilityCoverNextButton());
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.householdremovecover(1));
        obj_businessPremises.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.subsidenceCoverNoRadiobutton(1));
        obj_generalInformation.pageLoading();
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.nextButton());
        obj_generalInformation.pageLoading();
        functionalUtil.fillPropertyAwayFromPremiseHB("No", "null", "No", "null", "No", "null", "null", "null", "null", "null", "null", "null", "null");
    }

    public void editStockInQuoteSummaryWithTheftOfTakings(int iteration, String stockAddCover, String stockAmount) throws Throwable {
        //String stock = "3500";
        obj_quotesummary.premiseDetailsEditLink().click();
        obj_generalInformation.pageLoading();
        obj_businessPremises.stockValueTextboxVal(iteration).clear();
        functionalUtil.stockAddCover(iteration, stockAddCover, stockAmount);
        obj_commonUtil.tabKeypress();
        obj_generalInformation.pageLoading();
        premiseSubsidenceCover(iteration, "No");
        obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.nextButton());
        obj_generalInformation.pageLoading();
        propertyAwayInsureBusinessTolls("N", 0);
        obj_commonUtil.tabKeypress();
        obj_generalInformation.pageLoading();
        obj_propertyAway.executeScript("arguments[0].click();", obj_propertyAway.nextButton());
        obj_generalInformation.pageLoading();
        obj_theftOfTakings.executeScript("arguments[0].click();", obj_theftOfTakings.nextButton());
        obj_generalInformation.pageLoading();
        obj_impornantstatement.executeScript("arguments[0].click();", obj_impornantstatement.importantStatNextButton());
        obj_generalInformation.pageLoading();
        obj_claims.executeScript("arguments[0].click();", obj_claims.getQuoteButton());
        obj_generalInformation.pageLoading();
        obj_quotesummary.premiseTabOne().click();
        String text = obj_quotesummary.stockTextQuoteSummary(iteration).getText();
        Assert.assertTrue(text.equalsIgnoreCase("Your sum insured is £" + stockAmount));
        obj_quotesummary.executeScript("arguments[0].click();", obj_quotesummary.reviewConfirmButton());
        obj_generalInformation.pageLoading();
        functionalUtil.saveandExit("PostQuote", "CC");
    }

    public void saveAndExitInGeneralInformationPage(String tradeName) throws Throwable {
        //Need to add priya function
        functionalUtil.fillCoverWizardSectionForHnB("Hair and beauty therapist", "From my own salon#I work from home", "Permanent & temporary employees", "Yes", "Hair and beauty treatments liability#Business contents#Your home (the building)#Business stock#Your household contents#Your salon (the building)#Theft of takings#Business interruption");
        fillGeneralInformationSectionWorkOutsideUK("Anywhere in the EU", "N", tradeName);
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.nextButton());
        functionalUtil.saveandExit("People", "WJ");
    }

    public void fillGeneralInformationSectionWorkOutsideUK(String BusinessWork, String workOutsideYnN, String businessTradeName) throws Exception {
        strBusinessName = obj_generalInformationUtil.randomFirstName();
        obj_generalInformation.businessNameTextbox().sendKeys(strBusinessName);
        new Select(obj_generalInformation.titleDropdown()).selectByVisibleText("Mr");
        obj_generalInformation.firstNameTextbox().sendKeys("automation");
        obj_generalInformation.lastNameTextbox().sendKeys("tester");
        new Select(obj_generalInformation.businessTypeDropdown()).selectByVisibleText("Limited company");
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.subsidiariesNoRadiobutton());
        obj_generalInformation.pageLoading();
        new Select(obj_generalInformation.tradeDropdownListValue()).selectByVisibleText("2");
        obj_generalInformation.pageLoading();
        obj_generalInformation.postcodeTextbox().sendKeys("AB10 1AH");
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.findAddressButton());
        Thread.sleep(3000);
        new Select(obj_generalInformation.correspondenceAddressDropdown()).selectByValue("1");
        obj_generalInformation.pageLoading();
        obj_generalInformation.anythingElseNoRadiobutton().click();
        obj_generalInformation.pageLoading();
        new Select(obj_generalInformation.businessWorkLocDropdown()).selectByVisibleText(BusinessWork);
        obj_generalInformation.pageLoading();
        obj_coverwizard.executeScript("arguments[0].click();", obj_generalInformation.workOutsideUKYnN(workOutsideYnN));
    }

    public void fillTreatmentsBusiness() {
        // obj_treatments.peopleProvideTreatmentTextBox().sendKeys("3");
        // obj_generalInformation.pageLoading();
        obj_treatments.anyTreatmentNoButton().click();
        obj_generalInformation.pageLoading();
        obj_treatments.qualificationYesButton().click();
        obj_generalInformation.pageLoading();
        obj_treatments.nextButton().click();
        obj_generalInformation.pageLoading();
    }

    public void fillPeopleInYourBusinessSectionPermanentTemporaryEmployees() throws Exception {
        new Select(obj_peoplebusiness.toldUsBuisnessDropdownbox()).selectByVisibleText("Permanent and temporary employees");
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.directorBusinessTextbox().sendKeys("3");
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.directorAdminTextbox().sendKeys("1");
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.employeeExcludeDirectorsTextbox().sendKeys("10");
        obj_generalInformation.pageLoading();
        obj_peoplebusiness.employeeExcludeDirectorsAdminTextbox().sendKeys("5");
        obj_generalInformation.pageLoading();
        PremisesUsedBySelfEmployedPeopleNO();
    }

    public void commWallMaterial(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                commonutil.clickbyJS(businesspremises.commWallMaterialYesRadiobutton(i));
            } else if (strVal.equalsIgnoreCase("No"))
                commonutil.clickbyJS(businesspremises.commWallMaterialNoRadiobutton(i));
        }
    }

    public void fillYourBusinessWithDefaultValuesVISA() throws Throwable {
        fillPaymentSection();
        fillDirectDebitSection();
        fillPaymentInformationDetails();
        fillCardDetailsSectionVISA();
    }

    public void fillCardDetailsSectionAmex(String app) throws Throwable {
        Thread.sleep(3000);
        obj_commonUtil.switchFrame("sagepay");
        Thread.sleep(5000);
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.AmexCardLink());
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardNumberTextbox().sendKeys("370000000000002");
        obj_cardDetails.cardVerificationCodeTextbox().click();
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardholderNameTextbox().click();
        obj_cardDetails.cardholderNameTextbox().sendKeys("Cindrella");
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardVerificationCodeTextbox().sendKeys("9000");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryMMDropdown()).selectByVisibleText("02");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryYYYYDropdown()).selectByVisibleText("2018");
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.buyPolicyButton());
        obj_generalInformation.pageLoading();
        //Dynamically wait for page to fill
        obj_cardDetails.avsResponse();
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.sppContinueButton());
        obj_generalInformation.pageLoading();
        Thread.sleep(5000);
        if (app.equalsIgnoreCase("CC")) {
            obj_commonUtil.switchFrame("sagepay");
        }
        if ((obj_cardDetails.coversStartDate().isDisplayed()) && (obj_cardDetails.coversEndDate().isDisplayed()) && (obj_cardDetails.policyNumberFetch().isDisplayed()) && (obj_cardDetails.confirmationPaymentpage().isDisplayed())) {
            Assert.assertTrue(true);
        } else {
            Assert.assertTrue(false);
        }
    }

    public void fillCardDetailsSectionAmexPaymentFailure(String app) throws Throwable {
        Thread.sleep(3000);
        obj_commonUtil.switchFrame("sagepay");
        Thread.sleep(5000);
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.AmexCardLink());
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardNumberTextbox().sendKeys("370000000000002");
        obj_cardDetails.cardVerificationCodeTextbox().click();
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardholderNameTextbox().click();
        obj_cardDetails.cardholderNameTextbox().sendKeys("Cindrella");
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardVerificationCodeTextbox().sendKeys("9000");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryMMDropdown()).selectByVisibleText("02");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryYYYYDropdown()).selectByVisibleText("2018");
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.buyPolicyButton());
        obj_generalInformation.pageLoading();
        //Dynamically wait for page to fill
        new Select(obj_cardDetails.acquireResponse()).selectByVisibleText("Refused");
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.sppContinueButton());
        obj_generalInformation.pageLoading();
        Thread.sleep(5000);
        if (app.equalsIgnoreCase("CC")) {
            obj_commonUtil.switchFrame("sagepay");
        }
        if (obj_cardDetails.paymentFailureMessege().isDisplayed()) {
            Assert.assertTrue(true);
        } else {
            Assert.assertTrue(false);
        }
    }

    public void fillCardDetailsSectionMaestro(String app) throws Throwable {
        Thread.sleep(3000);
        obj_commonUtil.switchFrame("sagepay");
        Thread.sleep(5000);
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.MasteroCardLink());
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardNumberTextbox().sendKeys("6759649826438453");
        obj_cardDetails.cardVerificationCodeTextbox().click();
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardholderNameTextbox().click();
        obj_cardDetails.cardholderNameTextbox().sendKeys("Cindrella");
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardVerificationCodeTextbox().sendKeys("123");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryMMDropdown()).selectByVisibleText("02");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryYYYYDropdown()).selectByVisibleText("2018");
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.buyPolicyButton());
        obj_generalInformation.pageLoading();
        //Dynamically wait for page to fill
        obj_cardDetails.avsResponse();
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.sppContinueButton());
        obj_generalInformation.pageLoading();
        Thread.sleep(5000);
        if (app.equalsIgnoreCase("CC")) {
            obj_commonUtil.switchFrame("sagepay");
        }
        if ((obj_cardDetails.coversStartDate().isDisplayed()) && (obj_cardDetails.coversEndDate().isDisplayed()) && (obj_cardDetails.policyNumberFetch().isDisplayed()) && (obj_cardDetails.confirmationPaymentpage().isDisplayed())) {
            Assert.assertTrue(true);
        } else {
            Assert.assertTrue(false);
        }
    }

    public void fillCardDetailsSectionMaestroPaymentCancel(String app) throws Throwable {
        Thread.sleep(3000);
        obj_commonUtil.switchFrame("sagepay");
        Thread.sleep(5000);
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.MasteroCardLink());
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardNumberTextbox().sendKeys("6759649826438453");
        obj_cardDetails.cardVerificationCodeTextbox().click();
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardholderNameTextbox().click();
        obj_cardDetails.cardholderNameTextbox().sendKeys("Cindrella");
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardVerificationCodeTextbox().sendKeys("123");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryMMDropdown()).selectByVisibleText("02");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryYYYYDropdown()).selectByVisibleText("2018");
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.cancelPaymentButton());
        obj_generalInformation.pageLoading();
    }

    public void fillCardDetailsSectionVISA() throws Throwable {
        Thread.sleep(3000);
        obj_commonUtil.switchFrame("sagepay");
        Thread.sleep(5000);
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.VisaCardLink());
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardNumberTextbox().sendKeys("4921828154415519");
        obj_cardDetails.cardVerificationCodeTextbox().click();
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardholderNameTextbox().click();
        obj_cardDetails.cardholderNameTextbox().sendKeys("Cindrella");
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardVerificationCodeTextbox().sendKeys("123");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryMMDropdown()).selectByVisibleText("05");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryYYYYDropdown()).selectByVisibleText("2025");
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.buyPolicyButton());
        obj_generalInformation.pageLoading();
        //Dynamically wait for page to fill
        obj_cardDetails.avsResponse();
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.sppContinueButton());
        obj_generalInformation.pageLoading();
        Thread.sleep(5000);
//        String policyNumber = obj_cardDetails.policyNumberFetch().getText();

    }

    public void fillCardDetailsSectionVISACloseBrowser() throws Throwable {
        Thread.sleep(3000);
        obj_commonUtil.switchFrame("sagepay");
        Thread.sleep(5000);
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.VisaCardLink());
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardNumberTextbox().sendKeys("4921828154415519");
        obj_cardDetails.cardVerificationCodeTextbox().click();
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardholderNameTextbox().click();
        obj_cardDetails.cardholderNameTextbox().sendKeys("Cindrella");
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardVerificationCodeTextbox().sendKeys("123");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryMMDropdown()).selectByVisibleText("05");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryYYYYDropdown()).selectByVisibleText("2025");
        getDriver.close();

    }

    public void fillCardDetailsSectionVISACancelPayment() throws Throwable {
        Thread.sleep(3000);
        obj_commonUtil.switchFrame("sagepay");
        Thread.sleep(5000);
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.VisaCardLink());
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardNumberTextbox().sendKeys("4921828154415519");
        obj_cardDetails.cardVerificationCodeTextbox().click();
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardholderNameTextbox().click();
        obj_cardDetails.cardholderNameTextbox().sendKeys("Cindrella");
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardVerificationCodeTextbox().sendKeys("123");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryMMDropdown()).selectByVisibleText("05");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryYYYYDropdown()).selectByVisibleText("2025");
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.cancelPaymentButton());
        obj_generalInformation.pageLoading();


    }

    public void fillCardDetailsSectionVISAPaymentFailure(String app) throws Throwable {
        Thread.sleep(3000);
        obj_commonUtil.switchFrame("sagepay");
        Thread.sleep(5000);
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.VisaCardLink());
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardNumberTextbox().sendKeys("4921828154415519");
        obj_cardDetails.cardVerificationCodeTextbox().click();
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardholderNameTextbox().click();
        obj_cardDetails.cardholderNameTextbox().sendKeys("Cindrella");
        obj_generalInformation.pageLoading();
        obj_cardDetails.cardVerificationCodeTextbox().sendKeys("123");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryMMDropdown()).selectByVisibleText("05");
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.cardExpiryYYYYDropdown()).selectByVisibleText("2025");
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.buyPolicyButton());
        obj_generalInformation.pageLoading();
        new Select(obj_cardDetails.acquireResponse()).selectByVisibleText("Refused");
        obj_cardDetails.executeScript("arguments[0].click();", obj_cardDetails.sppContinueButton());
        obj_generalInformation.pageLoading();
        Thread.sleep(5000);
        if (app.equalsIgnoreCase("CC")) {
            obj_commonUtil.switchFrame("sagepay");
        }
        if (obj_cardDetails.paymentFailureMessege().isDisplayed()) {
            Assert.assertTrue(true);
        } else {
            Assert.assertTrue(false);
        }
    }

    public void fillYourBusinessWithVISA(String hb) throws Throwable {
        fillPaymentSectionLumpsum();
        fillPaymentInformationDetails();
        fillCardDetailsSectionVISA();
    }

    public void fillYourBusinessWithVISACloseBrowser() throws Throwable {
        fillPaymentSectionLumpsum();
        fillPaymentInformationDetails();
        fillCardDetailsSectionVISACloseBrowser();
    }

    public void fillYourBusinessWithVISAPaymentFailure(String CC) throws Throwable {
        fillPaymentSectionLumpsum();
        fillPaymentInformationDetails();
        fillCardDetailsSectionVISAPaymentFailure(CC);
    }

    public void verifyTotCover() {
        String textTOT3 = obj_theftOfTakings.thirdPartyPremisesWhereYouWorkText().getText();
        String Text3 = "On you or anyone in your business at any third party premises where you work";
        Assert.assertTrue(textTOT3.equalsIgnoreCase(Text3));
        String value3TOT = obj_theftOfTakings.thirdPartyPremisesWhereYouWorkValue().getText();
        String value3 = "£1000";
        Assert.assertTrue(value3TOT.equalsIgnoreCase(value3));
    }

    public void totValidation(String str) throws Exception {
        String str1 = "This will cover your money:\n- In transit\n- In the home of any authorised person working in the business\n- On you at any locations where you carry out your business\n- In a bank night safe";
        String quesAns[] = str.split("#");
        Assert.assertTrue("TOT question is present", quesAns[0].equalsIgnoreCase(obj_theftOfTakings.howMuchTotCoverText().getText()));
        String text1 = obj_theftOfTakings.coverMoneyTransitText().getText();
        Assert.assertTrue(text1.equalsIgnoreCase(str1));
    }

    private void fillPaymentSectionLumpsum() {
        obj_paymentSelection.annualLink().click();
        obj_generalInformation.pageLoading();
        obj_paymentSelection.renewRadiobutton().click();
        obj_generalInformation.pageLoading();
        obj_paymentSelection.understoodRadiobutton().click();
        obj_generalInformation.pageLoading();
        obj_paymentSelection.paymentScreenNextButton().click();
        obj_generalInformation.pageLoading();
    }

    public void fillYourBusinessWithMasterCardForAnnual() throws Throwable {
        fillPaymentSectionLumpsum();
        fillPaymentInformationDetails();
        fillCardDetailsSection();

    }

    public void fillYourBusinessWithMasterCardForAnnualPaymentCancel(String CC) throws Throwable {
        fillPaymentSectionLumpsum();
        fillPaymentInformationDetails();
        fillCardDetailsSectionPaymentCancel(CC);
    }

    public void fillYourBusinessWithAmexCardForAnnual(String CC) throws Throwable {
        fillPaymentSectionLumpsum();
        fillPaymentInformationDetails();
        fillCardDetailsSectionAmex(CC);

    }

    public void fillYourBusinessWithMaestroCardForAnnual(String CC) throws Throwable {
        fillPaymentSectionLumpsum();
        fillPaymentInformationDetails();
        fillCardDetailsSectionMaestro(CC);

    }

    public void fillYourBusinessWithMaestroCardForAnnualPaymentCancel(String CC) throws Throwable {
        fillPaymentSectionLumpsum();
        fillPaymentInformationDetails();
        fillCardDetailsSectionMaestroPaymentCancel(CC);

    }


    public void userEditQuoteviabuy() throws Throwable {
        commonutil.clickbyJS(obj_coverwizard.buyButton());
        ccSearch.ccPageLoad();

    }

    public void financeReceipt() throws Throwable {
        int rowcount = ccSearch.tableRow().size();
        for (int l = 1; l <= rowcount; l++) {
            int colcount = ccSearch.tableColumn().size();
            for (int k = 1; k <= colcount; k++) {
                String data = getDriver.findElement(By.xpath("//table[@id='TBL_A3010BF19BB251F9319727']/tbody/tr[" + l + "]/td[" + k + "]")).getText();
                if (data.equalsIgnoreCase("RT")) {
                    //getDriver.findElement(By.xpath("//table[@id='TBL_A3010BF19BB251F9319727']/tbody/tr[" + l + "]/td[" + (k + 2) + "]/div/div/div/a")).click();
                    Assert.assertTrue("RT is present", true);
                    // ccSearch.ccPageLoad();
                }
            }
        }
    }


    public void fillYourBusinessWithDDVisaWorldPay() throws Throwable {
        fillPaymentSection();
        fillDirectDebitSection();
        fillPaymentInformationDetails();
        // fillCardDetailsSectionVISAWorldPay();
        functionalUtil.fillCardDetailsSection("Visa");
    }

    public void fillYourBusinessWithCardVisaWorldPayCard() throws Throwable {
        fillPaymentSection();
       // fillDirectDebitSection();
        fillPaymentInformationDetails();
        // fillCardDetailsSectionVISAWorldPay();
        functionalUtil.fillCardDetailsSection("Visa");
    }

    public void fillPreviousLossesSectionWithoutQuoteSS() {
        obj_claims.executeScript("arguments[0].click();", obj_claims.previousLossesNoRadiobutton());
        obj_generalInformation.pageLoading();
        obj_generalInformation.pageLoading();
        obj_claims.executeScript("arguments[0].click();", obj_claims.SaveAndExit());
        obj_generalInformation.pageLoading();
        obj_claims.executeScript("arguments[0].click();", obj_claims.SaveAndExitpopupSS());

    }
//    public void UserchecksSelectedCoverList(String covers) {
//        String[] cover = covers.split("#");
//        for (String coverCheck:cover) {
//            if (obj_coverwizard.SelectedListForCover(coverCheck).isDisplayed()) {
//                Assert.assertTrue("Selected  covers  displayed", true);
//            } else {
//                Assert.assertTrue(false);
//            }
//        }
//
//    }
//    public void UserchecksDeselectedCoverList(String covers) {
//        String[] cover = covers.split("#");
//        for (String coverCheck:cover) {
//            if (obj_coverwizard.coversCheckboxHB(coverCheck).isDisplayed()) {
//                obj_coverwizard.executeScript("arguments[0].click();", obj_coverwizard.coversCheckboxHB(coverCheck));
//                if (!obj_coverwizard.SelectedListForCover(coverCheck).isDisplayed()) {
//                    Assert.assertTrue("covers deselected", true);
//                } else {
//                    Assert.assertTrue(false);
//                }
//            } else {
//                Assert.assertTrue(false);
//            }
//        }
//
//    }


}
