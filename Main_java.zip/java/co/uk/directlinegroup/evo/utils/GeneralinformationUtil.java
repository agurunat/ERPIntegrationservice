package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_Generalinformation;
import com.usmanhussain.habanero.framework.AbstractPage;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Random;

public class GeneralinformationUtil extends AbstractPage {

    public static String firstNameValue;
    public static String lastNameValue;
    public static String businessNameValue;
    private static Obj_Generalinformation generalinformation = new Obj_Generalinformation();
    private CommonUtil commonutil = new CommonUtil();

    public static void firstName(WebElement property) throws Exception {
        firstNameValue = property.getAttribute("value");
    }

    public static void lastName(WebElement property) throws Exception {
        lastNameValue = property.getAttribute("value");
    }

    public static void businessName(WebElement property) throws Exception {
        businessNameValue = property.getAttribute("value");
    }

    public void anythingElse(List<List<String>> data, String fieldName) throws Throwable {
        String anythingval = commonutil.datapicker(data, fieldName);
        if (!anythingval.equalsIgnoreCase("")) {
            if (anythingval.equalsIgnoreCase("No")) {
                generalinformation.executeScript("arguments[0].click();", generalinformation.anythingElseNoRadiobutton());

            } else if (anythingval.equalsIgnoreCase("Yes")) {
                generalinformation.executeScript("arguments[0].click();", generalinformation.anythingElseYesRadiobutton());
            }
        }
    }

    public void subsidiaries(List<List<String>> data, String fieldName) throws Throwable {
        String subsidiariesval = commonutil.datapicker(data, fieldName);
        if (subsidiariesval.equalsIgnoreCase("Yes")) {
            generalinformation.executeScript("arguments[0].click();", generalinformation.subsidiariesYesRadiobutton());
        } else if (subsidiariesval.equalsIgnoreCase("No")) {
            generalinformation.executeScript("arguments[0].click();", generalinformation.subsidiariesNoRadiobutton());
        }
    }

    public void businessWorkLocation(List<List<String>> data, String fieldName, WebElement property) throws Throwable {
        boolean flag = false;
        if (property.isDisplayed()) {
            commonutil.selectElement(data, fieldName, property);
        } else {
            Assert.assertTrue(!flag);
        }
    }

    public void runBusiness(List<List<String>> data, String fieldName) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        String[] businesvalue = StrVal.split(";");
        for (int i = 0; i < businesvalue.length; i++) {
            if (!StrVal.equalsIgnoreCase("")) {
                if (StrVal.equalsIgnoreCase("Rent")) {
                    commonutil.clickbyJS(generalinformation.rentDropdown());
                } else if (StrVal.equalsIgnoreCase("salon")) {
                    commonutil.clickbyJS(generalinformation.salonDropdown());
                } else if (StrVal.equalsIgnoreCase("Mobile")) {
                    commonutil.clickbyJS(generalinformation.mobileDropdown());
                } else if (StrVal.equalsIgnoreCase("WFH")) {
                    commonutil.clickbyJS(generalinformation.WFHDropdown());
                }
            }
        }
    }

    public void changeTrade() throws Throwable {
        generalinformation.executeScript("arguments[0].click();", generalinformation.changeTrade());
    }

    public void changeTradeQuestionValidation(List<List<String>> validationContents) throws Throwable {
        String contentFromPage = generalinformation.changeTradeQuestion().getText();
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(contentFromPage + "is displayed", validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            } else if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(contentFromPage + "is not displayed", !validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            }
        }
    }

    public void anythingElseTradeQuestionValidation(List<List<String>> validationContents) throws Throwable {
        String contentFromPage = generalinformation.anythingElseTradeQuestion().getText();
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(contentFromPage + "is displayed", validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            } else if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(contentFromPage + "is not displayed", !validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            }
        }
    }

    public void validateAnythingElseNotPresent(List<List<String>> data) throws Throwable {
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(AnythingElseQuestionNotDisplayed());
            }
        }
    }

    public boolean AnythingElseQuestionNotDisplayed() {
        try {
            generalinformation.tradeQuestionValidation();
            return false;
        } catch (WebDriverException e) {
            return true;
        }
    }

    public void additionalTradeSelection(List<List<String>> data, String fieldName) throws Throwable {
        String tradeVal = commonutil.datapicker(data, fieldName);
        waitForPageLoad();
        String[] tradeSelection = tradeVal.split(";");
        for (int i = 1; i <= tradeSelection.length; i++) {
            String anythingval = commonutil.datapicker(data, fieldName = "AnythingElse");
            if (!anythingval.equalsIgnoreCase("")) {
                for (String trades : tradeSelection) {
                    generalinformation.pageLoading();
                    if (anythingval.equalsIgnoreCase("Yes")) {
                        generalinformation.anythingElseYesRadiobutton().click();
                        generalinformation.pageLoading();
                        commonutil.setValue(trades, generalinformation.tradeNameTextbox());
                        generalinformation.addTradeNameSelect().click();
                    }
                }
            }
        }
    }

    public void tradeDropdownList(List<List<String>> tradeName) throws Throwable {
        String contentFromPage = generalinformation.tradeDropdownListValidation().getText();
        for (int i = 1; i < tradeName.size(); i++) {
            Assert.assertTrue("List Present in dropdown", (!contentFromPage.equalsIgnoreCase("")));
        }
        generalinformation.tradeDropdownListValidation().click();
    }

    public String randomFirstName() {
        Random rand = new Random();
        String strcharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        int randomNum1 = rand.nextInt(25) + 0;
        String strcharacter1 = strcharacters.substring(randomNum1, randomNum1 + 1);
        int randomNum2 = rand.nextInt(25) + 0;
        String strcharacter2 = strcharacters.substring(randomNum2, randomNum2 + 1);
        int randomNum3 = rand.nextInt(25) + 0;
        String strcharacter3 = strcharacters.substring(randomNum3, randomNum3 + 1);
        int randomNum4 = rand.nextInt(25) + 0;
        String strcharacter4 = strcharacters.substring(randomNum4, randomNum4 + 1);
        int randomNum5 = rand.nextInt(25) + 0;
        String strcharacter5 = strcharacters.substring(randomNum5, randomNum5 + 1);
        int randomNum6 = rand.nextInt(25) + 0;
        String strcharacter6 = strcharacters.substring(randomNum6, randomNum6 + 1);
        int randomNum7 = rand.nextInt(25) + 0;
        String strcharacter7 = strcharacters.substring(randomNum7, randomNum7 + 1);
        int randomNum8 = rand.nextInt(25) + 0;
        String strcharacter8 = strcharacters.substring(randomNum8, randomNum8 + 1);
        String FirstName = strcharacter1 + strcharacter2 + strcharacter3 + strcharacter4 + strcharacter5 + strcharacter6 + strcharacter7 + strcharacter8;
        return FirstName;
    }

    public String randomSecondName() {
        Random rand = new Random();
        String strcharacters1 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        int randomNum11 = rand.nextInt(25) + 0;
        String strcharacter11 = strcharacters1.substring(randomNum11, randomNum11 + 1);
        int randomNum21 = rand.nextInt(25) + 0;
        String strcharacter21 = strcharacters1.substring(randomNum21, randomNum21 + 1);
        int randomNum31 = rand.nextInt(25) + 0;
        String strcharacter31 = strcharacters1.substring(randomNum31, randomNum31 + 1);
        int randomNum41 = rand.nextInt(25) + 0;
        String strcharacter41 = strcharacters1.substring(randomNum41, randomNum41 + 1);
        int randomNum51 = rand.nextInt(25) + 0;
        String strcharacter51 = strcharacters1.substring(randomNum51, randomNum51 + 1);
        int randomNum61 = rand.nextInt(25) + 0;
        String strcharacter61 = strcharacters1.substring(randomNum61, randomNum61 + 1);
        int randomNum71 = rand.nextInt(25) + 0;
        String strcharacter71 = strcharacters1.substring(randomNum71, randomNum71 + 1);
        int randomNum81 = rand.nextInt(25) + 0;
        String strcharacter81 = strcharacters1.substring(randomNum81, randomNum81 + 1);
        String LastName = strcharacter11 + strcharacter21 + strcharacter31 + strcharacter41 + strcharacter51 + strcharacter61 + strcharacter71 + strcharacter81;
        return LastName;
    }

    public String randomBusinessName() {
        Random rand = new Random();
        String strcharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        int randomNum1 = rand.nextInt(25) + 0;
        String strcharacter1 = strcharacters.substring(randomNum1, randomNum1 + 1);
        int randomNum2 = rand.nextInt(25) + 0;
        String strcharacter2 = strcharacters.substring(randomNum2, randomNum2 + 1);
        int randomNum3 = rand.nextInt(25) + 0;
        String strcharacter3 = strcharacters.substring(randomNum3, randomNum3 + 1);
        int randomNum4 = rand.nextInt(25) + 0;
        String strcharacter4 = strcharacters.substring(randomNum4, randomNum4 + 1);
        int randomNum5 = rand.nextInt(25) + 0;
        String strcharacter5 = strcharacters.substring(randomNum5, randomNum5 + 1);
        int randomNum6 = rand.nextInt(25) + 0;
        String strcharacter6 = strcharacters.substring(randomNum6, randomNum6 + 1);
        int randomNum7 = rand.nextInt(25) + 0;
        String strcharacter7 = strcharacters.substring(randomNum7, randomNum7 + 1);
        int randomNum8 = rand.nextInt(25) + 0;
        String strcharacter8 = strcharacters.substring(randomNum8, randomNum8 + 1);
        String BusinessName = strcharacter1 + strcharacter2 + strcharacter3 + strcharacter4 + strcharacter5 + strcharacter6 + strcharacter7 + strcharacter8;
        return BusinessName;
    }

    public void declineMessageGI(String GIDeclineMessages) {
        String text = generalinformation.gideclineMessage().getText();
        if (text.equalsIgnoreCase(GIDeclineMessages)) {
            Assert.assertTrue("Error Message is displayed", true);
        } else {
            Assert.assertTrue("Error Message is displayed", false);
        }
    }

    public void validateQuestionsAndHelpText(List<List<String>> data) throws Throwable {
        String strText;
        for (int i = 0; i < data.size(); i++) {
            switch (data.get(i).get(1)) {
                case "ManualWorkQues":
                    strText = generalinformation.manualWorkQuestion().get(0).getText();
                    Assert.assertTrue("ManualWorkQuestion is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "ManualWorkHelpText":
                    strText = (String) getDriver.executeScript("return arguments[0].innerText", generalinformation.manualWorkQuestionHT().get(0));
                    Assert.assertTrue("ManualWorkHelpText is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "ITConsultant":
                    strText = generalinformation.staticTextForITConsult().get(0).getText();
                    Assert.assertTrue("ITConsultant static text is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;
                case "EstateProperty":
                    strText = generalinformation.staticTextForEstateProperty().get(0).getText();
                    Assert.assertTrue("Estate agency,Property letting,Property management trades related static text is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;

                case "WindowDresserQues":
                    strText = generalinformation.staticTextForWindowDresser().get(0).getText();
                    Assert.assertTrue("WindowDresser static text is displayed", data.get(i).get(0).replace(" ", "").replace(",", "").equalsIgnoreCase(strText.replace(" ", "").replace(",", "")));
                    break;

                case "StaticQuestionNotPresent":
                    String[] staticQues = data.get(i).get(0).split("#");
                    for (int j = 0; j < staticQues.length; j++) {
                        if (staticQues[j].contains("IT hardware")) {

                            if (!generalinformation.staticTextForITConsult().get(0).isDisplayed()) {
                                Assert.assertTrue("Static text IT Consultant is not displayed ", true);
                            } else {
                                Assert.assertTrue("Static text IT Consultant is displayed ", false);
                            }
                        } else if (staticQues[j].contains("For sale")) {
                            if (!generalinformation.staticTextForEstateProperty().get(0).isDisplayed()) {
                                Assert.assertTrue("Static text EstateAgent is not displayed ", true);
                            } else {
                                Assert.assertTrue("Static text EstateAgent is displayed ", false);
                            }
                        } else if (staticQues[j].contains("window dressing")) {

                            if (!generalinformation.staticTextForWindowDresser().get(0).isDisplayed()) {
                                Assert.assertTrue("Static text WindowDresser is not displayed ", true);
                            } else {
                                Assert.assertTrue("Static text WindowDresser is displayed ", false);
                            }

                        }


                    }
                    break;
                case "ManualWorkNotPresent":

                    if (!generalinformation.manualWorkQuestion().get(0).isDisplayed()) {
                        Assert.assertTrue("ManualWorkQuestion is not displayed", true);
                    } else {
                        Assert.assertTrue("ManualWorkHT is displayed", false);
                    }

                    break;

                case "ManualWorkHTNotPresent":

                    if (!generalinformation.manualWorkQuestionHT().get(0).isDisplayed()) {
                        Assert.assertTrue("ManualWorkHT is not displayed", true);
                    } else {
                        Assert.assertTrue("ManualWorkHT is displayed", false);
                    }


                    break;
            }

        }
    }


}


