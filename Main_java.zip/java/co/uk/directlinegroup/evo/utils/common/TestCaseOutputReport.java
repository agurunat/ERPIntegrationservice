package co.uk.directlinegroup.evo.utils.common;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by 323996 on 12/21/2017.
 */
public class TestCaseOutputReport {

    List<OutputLogClass> logBook = new ArrayList<>();

}
