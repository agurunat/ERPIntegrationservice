package co.uk.directlinegroup.evo.utils.common;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jruby.RubyProcess;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Iterator;

public class excelReader {

    public static void main(String[] args) throws Exception {

        String filePath = "D:\\";
        String fileName = "Test.xlsx";
        File file =    new File(filePath+"\\"+fileName);
        InputStream ExcelFileToRead = new FileInputStream(file);

        XSSFWorkbook wb = new XSSFWorkbook(ExcelFileToRead);
        XSSFSheet sheet = wb.getSheet("AR");
        DataFormatter dataFormatter = new DataFormatter();

        Iterator<Row> iterator = sheet.iterator();

        while(iterator.hasNext()){
            Row nextRow = iterator.next();
            String Type = dataFormatter.formatCellValue(nextRow.getCell(0));
            if(Type.equals("DLG_PULSE_CONVERSION_TYPE")){
                String Ref = dataFormatter.formatCellValue(nextRow.getCell(1));
                System.out.println("CONVERSION_TYPE----------"+ Ref);
                break;
            }
            else if(Type.equals("'DLG_PULSE_CONVERSION_RATE'")){
                String Ref = dataFormatter.formatCellValue(nextRow.getCell(1));
                System.out.println("CONVERSION_RATE----------"+ Ref);
                break;
            }

        }

    }

}
