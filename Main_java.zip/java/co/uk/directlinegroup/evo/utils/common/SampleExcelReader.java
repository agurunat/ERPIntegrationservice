package co.uk.directlinegroup.evo.utils.common;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.jruby.RubyProcess;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Iterator;

public class SampleExcelReader {

    public static String conversionRef = null;

    public static void main(String[] args) throws Exception {

        String filePath = "D:\\AP LookUp Files";
        String fileName = "AP_VENDOR.xlsx";
        String payType = "TPS";
        File file = new File(filePath + "\\" + fileName);
        InputStream ExcelFileToRead = new FileInputStream(file);

        XSSFWorkbook wb = new XSSFWorkbook(ExcelFileToRead);
        XSSFSheet sheet = wb.getSheet("Export Worksheet");
        DataFormatter dataFormatter = new DataFormatter();
        XSSFRow xssfRow = sheet.getRow(0);
        Iterator<Row> iterator = sheet.iterator();
        //int i_row = 0;
        int col_num = 0;
        for (int i = 0; i < xssfRow.getLastCellNum(); i++) {
            //if(xssfRow.getCell(i).getStringCellValue().trim().equals("RANGE_START"))
            col_num = i;

            String col_name = xssfRow.getCell(i).getStringCellValue();
            System.out.println("i value"+ i);
            System.out.println("Cell value--------->" + xssfRow.getCell(i).getStringCellValue());
            if (col_name.equals("RANGE_START")) {
                while (iterator.hasNext()) {
                    int i_row = i;

                    System.out.println("i_row value --" + i_row);

                    Row nextRow = iterator.next();

                    String Type = dataFormatter.formatCellValue(nextRow.getCell(i_row));
                    System.out.println("While Loop value -------" + Type);
                    if (Type.equals(payType)) {
                        System.out.println("column name is match");
                        col_num++;
                        break;
                    } else {

                        System.out.println(i_row);
                    }
                }
                //xssfRow = sheet.getRow(1);
                //XSSFCell cell = xssfRow.getCell(col_num);

                // String value = cell.getStringCellValue();
                //System.out.println("Value of the Excel Cell is - "+ value);

            }

    /*
        while (iterator.hasNext()) {
            int i_row = 0;
            Row nextRow = iterator.next();

            String Type = dataFormatter.formatCellValue(nextRow.getCell(i_row));
            if(Type.equals("RANGE_START")){
               System.out.println("column name is match");
               break;
            }else{


                System.out.println(i_row);
            }

            System.out.println(Type);
            /*if (Type.equals("TPS")) {
                conversionRef = dataFormatter.formatCellValue(nextRow.getCell(1));
                System.out.println("CONVERSION_TYPE----------" + conversionRef);
                break;
            } else if (Type.equals("'DLG_PULSE_CONVERSION_RATE'")) {
                conversionRef = dataFormatter.formatCellValue(nextRow.getCell(1));
                System.out.println("CONVERSION_RATE----------" + conversionRef);
                break;
            }*/

        }
        //return conversionRef;

    }
}
