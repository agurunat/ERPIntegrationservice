package co.uk.directlinegroup.evo.utils.common;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DisjointedRunBaseCode {
    public static void main(String args[]) {
        DisjointedRunBaseCode run = new DisjointedRunBaseCode();
        Map<Object, List<Object>> map = new HashMap<Object, List<Object>>();
        run.resetIntitialFilevalueWithExpValues(map);
//        map = run.readJsonOutput();
        run.mapPut("a", "b", map);
        run.mapPut("a1", "b", map);
        run.mapPut("a", "b1", map);
        run.mapPut("a", "b", map);
        run.mapPut("a2", "b2", map);
        run.mapPut("a", "b", map);
        run.mapPut("a", "b3", map);
        System.out.println(map);
        run.writeJsonOutput(map);
        System.out.println(run.readJsonOutput());

    }

    public void resetIntitialFilevalueWithExpValues(Map map)
    {
        mapPut("a", "b", map);
        mapPut("a1", "b", map);
        mapPut("a", "b1", map);
        mapPut("a", "b", map);
        mapPut("a2", "b2", map);
        mapPut("a", "b", map);
        mapPut("a", "b3", map);
    }

    public void writeJsonOutput(Map<Object, List<Object>> map) {
        JSONObject obj = new JSONObject();
        obj.putAll(map);

        try (FileWriter file = new FileWriter("target/test.txt")) {

            file.write(obj.toJSONString());
            file.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Map readJsonOutput() {
        JSONParser parser = new JSONParser();
        Object obj = null;
        try {
            obj = parser.parse(new FileReader("target/test.txt"));

            JSONObject jsonObject = (JSONObject) obj;
            return (Map) jsonObject;
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;

    }

    public Map mapPut(Object key, Object val, Map<Object, List<Object>> map) {
        List<Object> temp = new ArrayList<Object>();
        List<Object> temp2 = new ArrayList<Object>();

        temp2.add(val);

        if (map.containsKey(key)) {
            temp = map.get(key);
            temp.add(val);
        } else {
            temp = temp2;
        }
        map.put(key, temp);

        return map;


    }


}