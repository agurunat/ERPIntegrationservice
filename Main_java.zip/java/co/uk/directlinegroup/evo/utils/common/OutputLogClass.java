package co.uk.directlinegroup.evo.utils.common;

/**
 * Created by 323996 on 12/21/2017.
 */
public class OutputLogClass {

    String Type;
    String Expected;
    String Actual;
    boolean Status;
    String Reference;


}
