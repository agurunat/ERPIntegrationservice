package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_Peoplebusiness;
import com.usmanhussain.habanero.framework.AbstractPage;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

public class PeoplebusinessUtil extends AbstractPage {

    private CommonUtil commonutil = new CommonUtil();
    private Obj_Peoplebusiness peoplebusiness = new Obj_Peoplebusiness();

    public void tempEmployees(List<String> columnvalue, List<String> columnname, String fieldName) throws Throwable {
        String options = commonutil.datapicker(columnvalue, columnname, fieldName);
        waitForPageLoad();
        if (!options.equalsIgnoreCase("")) {
            if (options.equalsIgnoreCase("No")) {
                peoplebusiness.executeScript("arguments[0].click();", peoplebusiness.tempMorethanDaysNoRadiobutton());
            } else if (options.equalsIgnoreCase("Yes")) {
                peoplebusiness.executeScript("arguments[0].click();", peoplebusiness.tempMorethanDaysYesRadiobutton());
            }
        }
    }

    public void peopleBusiness(List<List<String>> data, String fieldName, WebElement property) throws Throwable {
        String options = commonutil.datapicker(data, fieldName);
        if (options.equalsIgnoreCase("$Element should be present$")) {
            Assert.assertTrue("Element present in the page", property.isDisplayed());
        } else if (options.equalsIgnoreCase("$Element should not be present$")) {
            Assert.assertTrue("Element not present in the page", !property.isDisplayed());
        } else if (!options.isEmpty()) {
            commonutil.setValue(data, fieldName, property);
        }
    }

    public void peopleBusiness(List<String> columnvalue, List<String> columnname, String fieldName, WebElement property) throws Throwable {
        String options = commonutil.datapicker(columnvalue, columnname, fieldName);
        if (options.equalsIgnoreCase("$Element should be present$")) {
            Assert.assertTrue("Element present in the page", property.isDisplayed());
        } else if (options.equalsIgnoreCase("$Element should not be present$")) {
            Assert.assertTrue("Element not present in the page", !property.isDisplayed());
        } else if (!options.isEmpty()) {
            commonutil.setValue(columnvalue, columnname, fieldName, property);
        }
    }

    public void selfEmployeeCount(List<String> columnvalue, List<String> columnname, String fieldName) throws Throwable {
        String options = commonutil.datapicker(columnvalue, columnname, fieldName);
        if (!options.equalsIgnoreCase("")) {
            commonutil.setValue(columnvalue, columnname, "SelfEmployeeValue", peoplebusiness.selfEmployeeValueTextbox());
        }
    }

    public void selfEmployee(List<String> columnvalue, List<String> columnname, String fieldName) throws Throwable {
        boolean flag = false;
        if (peoplebusiness.selfEmployeeYesRadiobutton().isDisplayed()) {
            String options = commonutil.datapicker(columnvalue, columnname, fieldName);
            waitForPageLoad();
            if (!options.equalsIgnoreCase("")) {
                if (options.equalsIgnoreCase("No")) {
                    commonutil.clickbyJS(peoplebusiness.selfEmployeeNoRadiobutton());
                } else if (options.equalsIgnoreCase("Yes")) {
                    commonutil.clickbyJS(peoplebusiness.selfEmployeeYesRadiobutton());
                    selfEmployeeCount(columnvalue, columnname, "SelfEmployeeValue");
                }
            }
        } else {
            Assert.assertTrue(!flag);
        }
    }

    public void coverInjuries(List<String> columnvalue, List<String> columnname, String fieldName) throws Throwable {
        String options = commonutil.datapicker(columnvalue, columnname, fieldName);
        if (!options.equalsIgnoreCase("")) {
            if (options.equalsIgnoreCase("No")) {
                commonutil.clickbyJS(peoplebusiness.coverInjuriesNoRadiobutton());
            } else {
                commonutil.clickbyJS(peoplebusiness.coverInjuriesYesRadiobutton());
            }
        }
    }

    public void EmployersLiability(List<String> columnvalue, List<String> columnname, String fieldName) throws Throwable {
        String options = commonutil.datapicker(columnvalue, columnname, fieldName);
        if (!options.equalsIgnoreCase("")) {
            if (options.equalsIgnoreCase("No")) {
                commonutil.clickbyJS(peoplebusiness.employerLiabilityNoRadiobutton());
            } else {
                commonutil.clickbyJS(peoplebusiness.employerLiabilityYesRadiobutton());
            }
        }
    }

    public void employeesToldList() throws Throwable {
        Select dropDown = new Select(peoplebusiness.toldUsBuisnessDropdownbox());
        List<WebElement> options = dropDown.getOptions();
        for (WebElement we : options) {
            Boolean flag = true;
            if (CoverwizardUtil.tradename.equalsIgnoreCase("Hotel") || CoverwizardUtil.tradename.equalsIgnoreCase("Guest house") || CoverwizardUtil.tradename.equalsIgnoreCase("Bed Breakfast")) {
                if (we.getText().equalsIgnoreCase("Permanent and temporary employees") || (we.getText().equalsIgnoreCase("Permanent employee(s)")) || (we.getText().equalsIgnoreCase("Temporary employee(s)"))) {
                    flag = false;
                    Assert.assertTrue("System displays the unexpected value - " + we.getText(), flag);
                } else if (we.getText().equalsIgnoreCase("Have employees") || (we.getText().equalsIgnoreCase("No employees") || (we.getText().equalsIgnoreCase("Select...")))) {
                    flag = false;
                    Assert.assertTrue("System displays the expected value - " + we.getText(), flag);
                } else {
                    flag = false;
                    Assert.assertTrue("System displays the unexpected NEW value - " + we.getText(), flag);
                }
            } else {
                if (we.getText().equalsIgnoreCase("Have employees")) {
                    Assert.assertTrue("System displays the unexpected  value - " + we.getText(), flag);
                } else if (we.getText().equalsIgnoreCase("Permanent and temporary employees") || (we.getText().equalsIgnoreCase("Permanent employee(s)")) || (we.getText().equalsIgnoreCase("Temporary employee(s)") || (we.getText().equalsIgnoreCase("Select...")))) {
                    flag = false;
                    Assert.assertTrue("System displays the expected value - " + we.getText(), flag);
                } else {
                    flag = false;
                    Assert.assertTrue("System displays the unexpected NEW value - " + we.getText(), flag);
                }
            }
        }
    }

    public void hbTempEmpQuestionValidation(List<List<String>> data) {
        String strTextValue = peoplebusiness.tempEmployeeText().getText();
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(strTextValue + "is displayed", data.get(i).get(0).equalsIgnoreCase(strTextValue));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(strTextValue + "is displayed", !data.get(i).get(0).equalsIgnoreCase(strTextValue));
            }
        }
    }

    public void hbLiabilityExpansionEmpQuestionValidation(List<List<String>> data) throws Throwable {
        String strTextValue = peoplebusiness.expandLiabilityText().getText();
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(strTextValue + "is displayed", data.get(i).get(0).equalsIgnoreCase(strTextValue));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(strTextValue + "is displayed", !data.get(i).get(0).equalsIgnoreCase(strTextValue));
            }
        }
    }

    public void hbSelfEmployedPeople(List<List<String>> data) throws Throwable {
        String strTextValue = peoplebusiness.selfEmployeeText().getText();
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(strTextValue + "is displayed", data.get(i).get(0).equalsIgnoreCase(strTextValue));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(strTextValue + "is displayed", !data.get(i).get(0).equalsIgnoreCase(strTextValue));
            }
        }
    }

    public boolean textBoxDisplayed() {
        try {
            return peoplebusiness.questionsTextbox().isDisplayed();
        } catch (WebDriverException e) {
            return false;
        }
    }

    public String questionsDisplayed() {
        try {
            return peoplebusiness.questionsDisplayedText().getText();
        } catch (WebDriverException e) {
            return "not Present";
        }
    }

    public boolean buttonDisplayed() {
        try {
            return peoplebusiness.liabilityButton().isDisplayed();
        } catch (WebDriverException e) {
            return false;
        }
    }

    public String liabilityQuestionsDisplayed() {
        try {
            return peoplebusiness.LiabilityQuestionText().getText();
        } catch (WebDriverException e) {
            return "not Present";
        }
    }

    public boolean businessTextBoxDisplayed() {
        try {
            return peoplebusiness.peopleBusinessTextbox().isDisplayed();
        } catch (WebDriverException e) {
            return false;
        }
    }

    public boolean buttonNotDisplayed() {
        try {
            String strdisabled = peoplebusiness.liabilityButton().getAttribute("disabled");
            return strdisabled == null;
        } catch (WebDriverException e) {
            return false;
        }
    }

    public boolean EmpQuestionNotDisplayed() {
        try {
            String strdisabled = peoplebusiness.EmpWorkBusinessQuestion().getAttribute("disabled");
            return strdisabled == null;
        } catch (WebDriverException e) {
            return false;
        }
    }

    public void validateMyScenario(String s, String s1, String s2) {
        if (s1.equalsIgnoreCase("not present")) {
            if (s2.equalsIgnoreCase("text box")) {
                Assert.assertTrue(!textBoxDisplayed());
            } else if (s2.equalsIgnoreCase("question")) {
                String questionFromPage = peoplebusiness.businessQuestions().getText();
                Assert.assertTrue(questionFromPage + "is not displayed", !questionsDisplayed().equalsIgnoreCase(s1));
            }
        }
        if (s1.equalsIgnoreCase("present")) {
            if (s2.equalsIgnoreCase("text box")) {
                Assert.assertTrue(textBoxDisplayed());
            } else if (s2.equalsIgnoreCase("question")) {
                String questionFromPage = peoplebusiness.businessQuestions().getText();
                Assert.assertTrue(questionFromPage + "is displayed", questionsDisplayed().equalsIgnoreCase("not present"));
            }
        }
    }

    public void LiabilityExpansionEmpTextValidation(List<List<String>> data, String fieldName) throws Throwable {
        String text1 = peoplebusiness.expandLiabilityText().getText();
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(text1 + "is displayed", data.get(i).get(0).equalsIgnoreCase(text1));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(text1 + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(text1));
            }
        }
    }

    public void validateButtonScenario(String s, String s1, String s2) {
        if (s1.equalsIgnoreCase("not present")) {
            if (s2.equalsIgnoreCase("button")) {
                Assert.assertTrue(buttonNotDisplayed());
            } else if (s2.equalsIgnoreCase("$ button Not Checked $")) {
                String strELCoverButton = peoplebusiness.employerLiabilityYesRadiobutton().getAttribute("checked");
                Assert.assertTrue(!strELCoverButton.equalsIgnoreCase("checked"));
            } else if (s2.equalsIgnoreCase("question")) {
                String questionFromPage = peoplebusiness.LiabilityQuestionText().getText();
                Assert.assertTrue(questionFromPage + "is not displayed", !questionsDisplayed().equalsIgnoreCase(s1));
            }
        }
        if (s1.equalsIgnoreCase("present")) {
            if (s2.equalsIgnoreCase("button")) {
                Assert.assertTrue(buttonDisplayed());
            } else if (s2.equalsIgnoreCase("question")) {
                String questionFromPage = peoplebusiness.LiabilityQuestionText().getText();
                Assert.assertTrue(questionFromPage + "is displayed", questionsDisplayed().equalsIgnoreCase("not present"));
            }
        }
    }

    public void validateBusinessQuestion(String s, String s1, String s2) {
        if (s1.equalsIgnoreCase("$not present$")) {
            if (s2.equalsIgnoreCase("text box")) {
                Assert.assertTrue(!businessTextBoxDisplayed());
            } else if (s2.equalsIgnoreCase("question")) {
                String questionFromPage = peoplebusiness.businessQuestions().getText();
                Assert.assertTrue(questionFromPage + "is not displayed", !questionsDisplayed().equalsIgnoreCase(s1));
            }
        }
        if (s1.equalsIgnoreCase("$present$")) {
            if (s2.equalsIgnoreCase("text box")) {
                Assert.assertTrue(businessTextBoxDisplayed());
            } else if (s2.equalsIgnoreCase("question")) {
                String questionFromPage = peoplebusiness.businessQuestions().getText();
                Assert.assertTrue(questionFromPage + "is displayed", questionsDisplayed().equalsIgnoreCase("not present"));
            }
        }
    }

    public void coverELValidationMessage(List<List<String>> data) throws Throwable {
        String contentFromPage = peoplebusiness.empELCoverErrorValidation().getText();
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(contentFromPage + "is displayed", data.get(i).get(0).equalsIgnoreCase(contentFromPage));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(contentFromPage + "is displayed", !data.get(i).get(0).equalsIgnoreCase(contentFromPage));
            }
        }
    }

    public void validateHelpText(List<List<String>> data, String fieldName) throws Throwable {
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                peoplebusiness.employeeHelpTextSymbol().click();
                String strText = peoplebusiness.employeeHelpText().getText();
                Assert.assertTrue(strText + "is displayed", data.get(i).get(0).equalsIgnoreCase(strText));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                String strText = peoplebusiness.employeeHelpText().getText();
                Assert.assertTrue(strText + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(strText));
            }
        }
    }

    public void validateHelpTextCommon(List<List<String>> data, WebElement property, WebElement strProperty) throws Throwable {
        for (int i = 1; i < data.size(); i++) {
            String strText = strProperty.getText();
            String script = "return arguments[0].innerText";
            strText = (String) getDriver.executeScript(script, strProperty);
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(strText.replace(" ", "").replace("\n", "") + "is displayed", data.get(i).get(0).replace(" ", "").replace("\n", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "")));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(strText.replace(" ", "").replace("\n", "") + "is not displayed", data.get(i).get(0).replace(" ", "").replace("\n", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "")));
            }
        }
    }



    public void validateHelpTextsPresent(List<List<String>> data, List<WebElement> strProperty) throws Throwable {
        for (int i = 0; i < data.size(); i++) {
            String strText;
            strText = (String) getDriver.executeScript("return arguments[0].innerText", strProperty.get(i));
            Assert.assertTrue(strText + "is displayed", data.get(i).get(0).equalsIgnoreCase(strText));
        }
    }

    public void validateHelpTextPresent(String validateText, WebElement strProperty) throws Throwable {
        String strText;
        strText = (String) getDriver.executeScript("return arguments[0].innerText", strProperty);
        Assert.assertTrue(strText + "is displayed", validateText.replace("\n", "").replace(" ", "").equalsIgnoreCase(strText.replace("\n", "").replace(" ", "")));
    }

    public void validateHelpTextNotPresent(List<List<String>> data) throws Throwable {
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(EmpQuestionNotDisplayed());
            }
        }
    }

    public void tradeBasedEmployee(List<List<String>> data, WebElement property) throws Throwable {
        List<WebElement> dropDownList = new Select(property).getOptions();
        for (WebElement suggestion : dropDownList) {
            String dropDownValues = suggestion.getText();
            for (int i = 1; i < data.size(); i++) {
                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    if (data.get(i).get(0).equalsIgnoreCase((dropDownValues).trim())) {
                        Assert.assertTrue(dropDownValues + "is displayed", data.get(i).get(0).equalsIgnoreCase((dropDownValues).trim()));
                    } else {
                    }
                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue(dropDownValues + "is not displayed", !data.get(i).get(0).equalsIgnoreCase((dropDownValues).trim()));
                }
            }
        }
    }

    public void validateExcludeDirectorHelpText(List<List<String>> data) throws Throwable {
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                peoplebusiness.employeeExcludingQuestionMark().click();
                String strText = peoplebusiness.employeeExcludingHelpText().getText();
                Assert.assertTrue(strText + "is displayed", data.get(i).get(0).equalsIgnoreCase(strText));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                String strText = peoplebusiness.employeeHelpText().getText();
                Assert.assertTrue(strText + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(strText));
            }
        }
    }

}