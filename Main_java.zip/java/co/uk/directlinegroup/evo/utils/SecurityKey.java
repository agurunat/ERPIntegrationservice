package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_Coverwizard;
import co.uk.directlinegroup.evo.pages.Obj_Generalinformation;

import java.util.List;

public class SecurityKey {

    private Obj_Coverwizard coverwizard = new Obj_Coverwizard();
    private CommonUtil commomutil = new CommonUtil();
    private Obj_Generalinformation generalinformation = new Obj_Generalinformation();

    public void enterInSecurityKey(List<List<String>> data, String fieldName) throws Throwable {
        commomutil.setValue(data, fieldName, coverwizard.securityTextbox());
        // commonutil.executeScript("arguments[0].click();", businesspremises.storageHeatingYesRadiobutton(k));
        coverwizard.executeScript("arguments[0].click();", coverwizard.proceedButton());
        generalinformation.pageLoading();
        coverwizard.executeScript("arguments[0].click();", coverwizard.proceedButton());
    }
}