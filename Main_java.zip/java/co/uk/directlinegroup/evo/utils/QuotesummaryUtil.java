package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_Quotesummary;
import com.usmanhussain.habanero.framework.AbstractPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * Created by 257783 on 6/9/2017.
 */
public class QuotesummaryUtil extends AbstractPage {

    private CommonUtil commonutil = new CommonUtil();
    private Obj_Quotesummary quotesummary = new Obj_Quotesummary();


    public void referralMessage(List<List<String>> data) throws Throwable {
        String strReferralText = quotesummary.referalTextMessage().getText();
        for (int i = 1; i < data.size(); i++) {
            if (strReferralText.contains("Beauty therapist")) {

                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(strReferralText + " is displayed", data.get(i).get(0).equalsIgnoreCase(strReferralText));

                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue("Element is not displayed", !data.get(i).get(0).equalsIgnoreCase(strReferralText));
                }
            } else if (strReferralText.contains("Bed and Breakfast")) {
                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(strReferralText + " is displayed", data.get(i).get(0).equalsIgnoreCase(strReferralText));

                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue("Element is not displayed", !data.get(i).get(0).equalsIgnoreCase(strReferralText));

                }
            } else if (strReferralText.contains("Barber")) {

                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(strReferralText + " is displayed", data.get(i).get(0).equalsIgnoreCase(strReferralText));

                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue("Element is not displayed", !data.get(i).get(0).equalsIgnoreCase(strReferralText));
                }
            } else if (strReferralText.contains("Hairdresser")) {

                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(strReferralText + " is displayed", data.get(i).get(0).equalsIgnoreCase(strReferralText));

                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue("Element is not displayed", !data.get(i).get(0).equalsIgnoreCase(strReferralText));
                }
            }
        }
    }

    public void declineMessage(List<List<String>> data) throws Throwable {
        String strDeclineText = quotesummary.declineMsg().getText();
        for (int i = 1; i < data.size(); i++) {
            if (strDeclineText.contains("Nail technician")) {

                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(strDeclineText + "is displayed", data.get(i).get(0).equalsIgnoreCase(strDeclineText));

                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue("Element is not displayed", !data.get(i).get(0).equalsIgnoreCase(strDeclineText));
                }
            } else if (strDeclineText.contains("Hair and beauty therapist")) {
                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(strDeclineText + "is displayed", data.get(i).get(0).equalsIgnoreCase(strDeclineText));

                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue("Element is not displayed", !data.get(i).get(0).equalsIgnoreCase(strDeclineText));
                }
            } else if (strDeclineText.contains("Bed and Breakfast")) {
                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(strDeclineText + "is displayed", data.get(i).get(0).equalsIgnoreCase(strDeclineText));

                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue("Element is not displayed", !data.get(i).get(0).equalsIgnoreCase(strDeclineText));
                }
            } else if (strDeclineText.contains("Guest House")) {
                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(strDeclineText + "is displayed", data.get(i).get(0).equalsIgnoreCase(strDeclineText));

                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue("Element is not displayed", !data.get(i).get(0).equalsIgnoreCase(strDeclineText));
                }
            }
        }
    }

    public void reasonfordecline(List<List<String>> data) {
        for (int i = 1; i < data.size(); i++) {

            List<WebElement> ele = getDriver.findElements(By.xpath(quotesummary.reasonDropdownLable()));
            String[] linkText = new String[ele.size()];
            int xsi = ele.size();

            if (xsi == 1) {
                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    linkText[0] = getDriver.findElement(By.xpath(quotesummary.reasonDropdownLable())).getText();
                    Assert.assertTrue(linkText[0] + "is displayed", data.get(i).get(0).equalsIgnoreCase(linkText[0]));
                }
            } else if (xsi == 0) {
                if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                }
            }
        }
    }


    public void referralMessageText(List<List<String>> data) throws Throwable {
        String strReferralMsg = quotesummary.referralMsgText().getText();
        for (int i = 1; i < data.size(); i++) {
            if (strReferralMsg.contains("Beauty therapist")) {

                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(strReferralMsg + " is displayed", data.get(i).get(0).equalsIgnoreCase(strReferralMsg));

                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue("Element is not displayed", !data.get(i).get(0).equalsIgnoreCase(strReferralMsg));
                }
            } else if (strReferralMsg.contains("Bed and Breakfast")) {
                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(strReferralMsg + " is displayed", data.get(i).get(0).equalsIgnoreCase(strReferralMsg));

                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue("Element is not displayed", !data.get(i).get(0).equalsIgnoreCase(strReferralMsg));

                }
            } else if (strReferralMsg.contains("Barber")) {

                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(strReferralMsg + " is displayed", data.get(i).get(0).equalsIgnoreCase(strReferralMsg));

                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue("Element is not displayed", !data.get(i).get(0).equalsIgnoreCase(strReferralMsg));
                }
            } else if (strReferralMsg.contains("Hairdresser")) {

                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(strReferralMsg + " is displayed", data.get(i).get(0).equalsIgnoreCase(strReferralMsg));

                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue("Element is not displayed", !data.get(i).get(0).equalsIgnoreCase(strReferralMsg));
                }
            }
        }
    }

    public void declineMessageText(List<List<String>> data) throws Throwable {
        String strDeclineMsg = quotesummary.declineMsgText().getText();
        String StrDeclineMessage[] = strDeclineMsg.split("\n");
        for (int i = 1; i < data.size(); i++) {
            if (strDeclineMsg.contains("Hair and beauty")) {

                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(StrDeclineMessage[i - 2] + "is displayed", data.get(i).get(0).equalsIgnoreCase(StrDeclineMessage[i - 2]));

                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue("Element is not displayed", !data.get(i).get(0).equalsIgnoreCase(strDeclineMsg));
                }
            } else if (strDeclineMsg.contains("Bed and Breakfast")) {
                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(strDeclineMsg + "is displayed", data.get(i).get(0).equalsIgnoreCase(strDeclineMsg));

                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue("Element is not displayed", !data.get(i).get(0).equalsIgnoreCase(strDeclineMsg));
                }
            } else if (strDeclineMsg.contains("Nail technician")) {
                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(StrDeclineMessage[i - 2] + "is displayed", data.get(i).get(0).equalsIgnoreCase(StrDeclineMessage[i - 2]));

                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue("Element is not displayed", !data.get(i).get(0).equalsIgnoreCase(strDeclineMsg));
                }
            } else if (strDeclineMsg.contains("Guest House")) {
                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(StrDeclineMessage[i - 1] + "is displayed", data.get(i).get(0).equalsIgnoreCase(StrDeclineMessage[i - 1]));

                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue("Element is not displayed", !data.get(i).get(0).equalsIgnoreCase(strDeclineMsg));
                }
            }
        }
    }

    public boolean DeclineQuestionNotDisplyed() {
        try {

//           generalinformation.notanythingElseTradeQuestion();
            quotesummary.reasonDropdownLable();
//           return true;
            return false;
        } catch (WebDriverException e) {
//            return false ;
            return true;
        }
    }
}