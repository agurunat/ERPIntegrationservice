package BMS;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class BMSXAPInvoice {

    static Statement SQLstmt_isci = null;
    static ResultSet SQLResultset_icsi = null;
    static Statement SQLstmt = null;
    static ResultSet SQLResultset = null;

    public static HTML_Report_Generation_DB_BMS report_generation;

    public static void main(String[] args) throws IOException, SQLException {
        report_generation = new HTML_Report_Generation_DB_BMS();

        //--------------- SIT  database details -------------------
        String URL_SIT1 = "jdbc:oracle:thin:@dbs119dev.gwd.grpinf.net:1521/FSHDTST3";
        String Username_SIT1 = "FSH_ORA_DATA";
        String password_SIT1 = "Development_Test3";

        //--------------- EBS  database details -------------------
        String URL_ICSI = "jdbc:oracle:thin:@dcn2ddbx340.gwd.grpinf.net:1618:ICSI";
        String Username_ICSI = "apps";
        String password_ICSI = "apps4icsi";

        List<String> file_list = new ArrayList<String>();
        List<String> list = new ArrayList<String>();
        List<String> section1_results = new ArrayList<String>();

        int cons_stg_map_row = 1;
        int stg_line_map_row = 1;

        String[] file_lists = null;
        String file_name = "null";
        String db_CONS_SOURCE = "null";
        String db_CONS_TRANSACTION_DATE = "null";
        String db_CONS_POLICY_NUMBER = "null";
        String db_CONS_CLAIM_NUMBER = "null";
        String db_CONS_BRAND = "null";
        String db_CONS_PRODUCT_TYPE = "null";
        String db_CONS_CHANNEL = "null";
        String db_CONS_BASE_CURRENCY_NET_AMOUNT = "null";
        String db_CONS_THIRD_CLAIM_REF = "null";
        String db_CONS_PAYEE_TYPE = "null";
        String db_CONS_PAYMENT_METHOD = "null";
        String db_CONS_PAYMENT_TERMS = "null";
        String db_CONS_CLAIM_HANDLER_REF = "null";
        String db_CONS_APPROVER = "null";
        String db_CONS_BANK_ACCOUNT_NUMBER = "null";
        String db_CONS_BANK_SORT_CODE = "null";
        String db_CONS_INVOICE_NUM = "null";
        String db_CONS_INVOICE_DATE = "null";
        String db_CONS_INVOICE_RECEIVED_DATE = "null";
        String db_CONS_VENDOR_SITE_ID = "null";
        String db_CONS_EXCHANGE_RATE = "null";
        String db_CONS_EXCHANGE_RATE_TYPE = "null";
        String db_CONS_EXCHANGE_EFFECTIVE_DATE = "null";
        String db_CONS_PAYEE_DESCRIPTION = "null";
        String db_CONS_PAYEE_ADDRESS_LINE1 = "null";
        String db_CONS_PAYEE_ADDRESS_LINE2 = "null";
        String db_CONS_PAYEE_ADDRESS_LINE3 = "null";
        String db_CONS_PAYEE_CITY = "null";
        String db_CONS_PAYEE_COUNTY = "null";
        String db_CONS_PAYEE_COUNTRY = "null";
        String db_CONS_PAYEE_POSTCODE = "null";
        String db_CONS_SYSTEM = "null";
        String db_CONS_FILE_NAME = "null";
        String db_CONS_TRANSACTION_TYPE = "null";
        String db_CONS_TXN_REFERENCE1 = "null";
        String db_CONS_UNDERWRITER = "null";
        String db_CONS_LINE_OF_BUSINESS = "null";

        String db_CONS_line_id = "null";
        String db_CONS_LINE_NUMBER = "null";
        String db_CONS_LINE_CATEGORY = "null";
        String db_CONS_LINE_ITEM_AMOUNT = "null";
        String db_CONS_BASE_LINE_ITEM_AMOUNT = "null";
        String db_CONS_LINE_TRANSACTION_DATE = "null";
        String db_CONS_TAX_CODE = "null";
        String db_CONS_LINE_HEADER_ID = "null";


        String db_STG_HEADER_ID = "null";
        String db_STG_SOURCE = "null";
        String db_STG_TRANSACTION_DATE = "null";
        String db_STG_POLICY_NUMBER = "null";
        String db_STG_CLAIM_NUMBER = "null";
        String db_STG_GLOBAL_ATTRIBUTE2 = "null";
        String db_STG_BRAND = "null";
        String db_STG_PRODUCT_TYPE = "null";
        String db_STG_CHANNEL = "null";
        String db_STG_GLOBAL_ATTRIBUTE3 = "null";
        String db_STG_INVOICE_AMOUNT = "null";
        String db_STG_THIRD_CLAIM_REF = "null";
        String db_STG_PAYEE_TYPE = "null";
        String db_STG_PAYMENT_METHOD = "null";
        String db_STG_PAYMENT_TERMS = "null";
        String db_STG_CLAIM_HANDLER_REF = "null";
        String db_STG_APPROVER = "null";
        String db_STG_ACCOUNT_NUMBER = "null";
        String db_STG_SORT_CODE = "null";
        String db_STG_PAYMENT_COUNTRY = "null";
        String db_STG_INVOICE_NUM = "null";
        String db_STG_DESCRIPTION = "null";
        String db_STG_INVOICE_DATE = "null";
        String db_STG_INVOICE_RECEIVED_DATE = "null";
        String db_STG_VENDOR_ID = "null";
        String db_STG_VENDOR_NAME = "null";
        String db_STG_VENDOR_SITE_ID = "null";
        String db_STG_VENDOR_SITE_CD = "null";
        String db_STG_VENDOR_SITE_CODE = "null";
        String db_STG_EXCHANGE_EFFECTIVE_DATE = "null";
        String db_STG_ATTRIBUTE_CATEGORY = "null";
        String db_STG_ATTRIBUTE1 = "null";
        String db_STG_ATTRIBUTE2 = "null";
        String db_STG_ATTRIBUTE3 = "null";
        String db_STG_ATTRIBUTE4 = "null";
        String db_STG_ATTRIBUTE5 = "null";
        String db_STG_ATTRIBUTE6 = "null";
        String db_STG_ATTRIBUTE7 = "null";
        String db_STG_ATTRIBUTE8 = "null";
        String db_STG_SUMMARY_ID = "null";
        String db_STG_FILE_NAME = "null";
        String db_STG_FSH_ATTRIBUTE1 = "null";
        String db_STG_FSH_ATTRIBUTE2 = "null";
        String db_STG_UNDERWRITER = "null";
        String db_STG_LINE_OF_BUSINESS = "null";
        String db_STG_PRODUCT = "null";
        String db_STG_INVOICE_CURRENCY_CODE = "null";
        String db_STG_INVOICE_ID = "null";
        String db_STG_EXCHANGE_RATE = "null";
        String db_STG_EXCHANGE_RATE_TYPE = "null";
        String db_STG_PAY_GROUP_LOOKUP_CODE = "null";
        String db_STG_ORG_ID = "null";

        String db_STG_line_id = "null";
        String db_stg_LINE_INVOICE_ID = "null";
        String db_STG_LINE_NUMBER = "null";
        String db_STG_LINE_DESCRIPTION = "null";
        String db_STG_LINE_ITEM_AMOUNT = "null";
        String db_STG_BASE_LINE_ITEM_AMOUNT = "null";
        String db_STG_LINE_TRANSACTION_DATE = "null";
        String db_STG_TAX_CODE = "null";
        String db_STG_LINE_HEADER_ID = "null";

        //---------------- Line item -------
        String db_stg_line_id = "null";
        String db_stg_INVOICE_ID = "null";


        //--------------- Consolidation variables decleration ---------
        String db_cons_header_id = "null";


        //-------- Connect to Database --------------
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        Connection connection = null;
        try {
            connection = DriverManager.getConnection(
                    URL_SIT1, Username_SIT1, password_SIT1); // --- database details
        } catch (SQLException e) {
            e.printStackTrace();
        }
        Connection connection_icsi = null;

        try {
            connection_icsi = DriverManager.getConnection(
                    URL_ICSI, Username_ICSI, password_ICSI); // --- database details
        } catch (SQLException e) {
            e.printStackTrace();
        }

        // -------------------- Create a statement for sending SQL Query to DB. -----------------
        try {
            SQLstmt = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        try {
            SQLstmt_isci = connection_icsi.createStatement();
            System.out.println("icsi database connected");
        } catch (SQLException e) {
            e.printStackTrace();
        }

        //------ get the new file from batch control table --------------
        boolean newRecord = true;
        SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where Trunc(LOAD_DATE) = TRUNC(SYSDATE) and system = 'ECLI' and pattern = 'APInvoice'");
        while (SQLResultset.next()) {
            file_list.add(SQLResultset.getString("FILE_NAME"));
            System.out.println("File name---" + SQLResultset.getString("FILE_NAME"));
            list.addAll(section1_results);
        }

        //------------------ validate no new files -----------------------
        String xmlfile_name = "null";
        SQLResultset = SQLstmt.executeQuery("Select distinct file_name from DLG_FSH_CTL_BATCH where Trunc(LOAD_DATE) = TRUNC(SYSDATE) and system = 'ECLI' and pattern = 'APInvoice' ");
        if (!SQLResultset.next()) {
            System.out.println("No new B4C PC files have been received to FSH ");
            newRecord = false;
            String nonewfile = ",FILE_NAME," + "No new B4C PC files have been received to FSH" + "," + "," + ",Pass";
        }

        List<String> list_header = new ArrayList<String>(); // -- Add all the header id
        if (newRecord){
            //------------ Split the file names form the list --------------
            for (String xml_file_name : file_list){

                //-------------- Validation Cons to Stag table ----------------
                SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_BMSX_API_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                while (SQLResultset.next()) {
                    db_cons_header_id = SQLResultset.getString("HEADER_ID");
                    list_header.add(db_cons_header_id);
                }

                for(int i = 0; i < list_header.size(); i++){
                    SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_CONS_BMSX_API_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                    while (SQLResultset.next()){
                        db_cons_header_id = SQLResultset.getString("HEADER_ID");
                        db_CONS_SOURCE = SQLResultset.getString("SOURCE");
                        db_CONS_TRANSACTION_DATE = SQLResultset.getString("TRANSACTION_DATE");
                        db_CONS_CLAIM_NUMBER = SQLResultset.getString("CLAIM_NUMBER");
                        db_CONS_CHANNEL = SQLResultset.getString("CHANNEL");
                        db_CONS_THIRD_CLAIM_REF = SQLResultset.getString("THIRD_CLAIM_REF");
                        db_CONS_INVOICE_NUM = SQLResultset.getString("INVOICE_NUM");
                        db_CONS_INVOICE_DATE = SQLResultset.getString("INVOICE_DATE");
                        db_CONS_INVOICE_RECEIVED_DATE = SQLResultset.getString("INVOICE_RECEIVED_DATE");
                        db_CONS_VENDOR_SITE_ID = SQLResultset.getString("VENDOR_SITE_ID");
                        db_CONS_SYSTEM = SQLResultset.getString("SYSTEM");
                        db_CONS_FILE_NAME = SQLResultset.getString("FILE_NAME");
                        db_CONS_TRANSACTION_TYPE = SQLResultset.getString("TRANSACTION_TYPE");
                        db_CONS_TXN_REFERENCE1 = SQLResultset.getString("TXN_REFERENCE1");


                        SQLResultset = SQLstmt.executeQuery("SELECT * from DLG_FSH_STG_COMM_API_HDR WHERE FILE_NAME = '" + xml_file_name + "'");
                        while (SQLResultset.next()){
                            db_STG_HEADER_ID = SQLResultset.getString("HEADER_ID");
                            db_STG_SOURCE = SQLResultset.getString("SOURCE");
                            db_STG_TRANSACTION_DATE = SQLResultset.getString("TRANSACTION_DATE");
                            db_STG_GLOBAL_ATTRIBUTE2 = SQLResultset.getString("GLOBAL_ATTRIBUTE2");
                            db_STG_CHANNEL = SQLResultset.getString("CHANNEL");
                            db_STG_GLOBAL_ATTRIBUTE3 = SQLResultset.getString("GLOBAL_ATTRIBUTE3");
                            db_STG_GLOBAL_ATTRIBUTE2 = SQLResultset.getString("GLOBAL_ATTRIBUTE2");
                            db_STG_INVOICE_AMOUNT = SQLResultset.getString("INVOICE_AMOUNT");
                            db_STG_INVOICE_NUM = SQLResultset.getString("INVOICE_NUM");
                            db_STG_DESCRIPTION = SQLResultset.getString("DESCRIPTION");
                            db_STG_INVOICE_DATE = SQLResultset.getString("INVOICE_DATE");
                            db_STG_INVOICE_RECEIVED_DATE = SQLResultset.getString("INVOICE_RECEIVED_DATE");
                            db_STG_VENDOR_ID = SQLResultset.getString("VENDOR_ID");
                            db_STG_VENDOR_NAME = SQLResultset.getString("VENDOR_NAME");
                            db_STG_VENDOR_SITE_ID = SQLResultset.getString("VENDOR_SITE_ID");
                            db_STG_VENDOR_SITE_CD = SQLResultset.getString("VENDOR_SITE_CD");
                            db_STG_VENDOR_SITE_CODE = SQLResultset.getString("VENDOR_SITE_CODE");
                            db_STG_EXCHANGE_EFFECTIVE_DATE = SQLResultset.getString("EXCHANGE_EFFECTIVE_DATE");
                            db_STG_ATTRIBUTE_CATEGORY = SQLResultset.getString("ATTRIBUTE_CATEGORY");
                            db_STG_ATTRIBUTE1 = SQLResultset.getString("ATTRIBUTE1");
                            db_STG_ATTRIBUTE2 = SQLResultset.getString("ATTRIBUTE2");
                            db_STG_ATTRIBUTE3 = SQLResultset.getString("ATTRIBUTE3");
                            db_STG_ATTRIBUTE4 = SQLResultset.getString("ATTRIBUTE4");
                            db_STG_ATTRIBUTE5 = SQLResultset.getString("ATTRIBUTE5");
                            db_STG_ATTRIBUTE6 = SQLResultset.getString("ATTRIBUTE6");
                            db_STG_ATTRIBUTE7 = SQLResultset.getString("ATTRIBUTE7");
                            db_STG_ATTRIBUTE8 = SQLResultset.getString("ATTRIBUTE8");
                            db_STG_FILE_NAME = SQLResultset.getString("FILE_NAME");
                            db_STG_INVOICE_ID = SQLResultset.getString("INVOICE_ID");
                            db_STG_PAY_GROUP_LOOKUP_CODE = SQLResultset.getString("PAY_GROUP_LOOKUP_CODE");
                            db_STG_ORG_ID = SQLResultset.getString("ORG_ID");

                            if(db_cons_header_id.equals(db_STG_HEADER_ID)){
                                String cons_header_id = cons_stg_map_row + ",HEADER_ID," + db_STG_HEADER_ID + "," + db_cons_header_id + ",Pass";
                                section1_results.add(cons_header_id);
                                cons_stg_map_row++;
                            }else {
                                String cons_header_id = cons_stg_map_row + ",HEADER_ID," + db_STG_HEADER_ID + "," + db_cons_header_id + ",Fail";
                                section1_results.add(cons_header_id);
                                cons_stg_map_row++;
                            }

                            //--------------------  Validation SOURCE ---------------
                            if(db_CONS_SOURCE.equals(db_STG_SOURCE)){
                                String cons_source = ",SOURCE," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Pass";
                                section1_results.add(cons_source);
                            }else {
                                String cons_source = ",SOURCE," + db_STG_SOURCE + "," + db_CONS_SOURCE + ",Fail";
                                section1_results.add(cons_source);
                            }

                            //--------------------  Validation TRANSACTION_DATE ---------------
                            if(db_CONS_TRANSACTION_DATE.equals(db_STG_TRANSACTION_DATE)){
                                String cons_trans_date = ",TRANSACTION_DATE," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Pass";
                                section1_results.add(cons_trans_date);
                            }else {
                                String cons_trans_date = ",TRANSACTION_DATE," + db_STG_TRANSACTION_DATE + "," + db_CONS_TRANSACTION_DATE + ",Fail";
                                section1_results.add(cons_trans_date);
                            }

                            //--------------------  Validation POLICY_NUMBER ---------------
                            if(db_CONS_POLICY_NUMBER.equals(db_STG_POLICY_NUMBER)){
                                String cons_policy_number = ",POLICY_NUMBER," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Pass";
                                section1_results.add(cons_policy_number);
                            }else {
                                String cons_policy_number = ",POLICY_NUMBER," + db_STG_POLICY_NUMBER + "," + db_CONS_POLICY_NUMBER + ",Fail";
                                section1_results.add(cons_policy_number);
                            }

                            //--------------------  Validation CLAIM_NUMBER ---------------
                            if(db_CONS_CLAIM_NUMBER.equals(db_STG_CLAIM_NUMBER)){
                                String cons_claim_number = ",CLAIM_NUMBER," + db_STG_CLAIM_NUMBER + "," + db_CONS_CLAIM_NUMBER + ",Pass";
                                section1_results.add(cons_claim_number);
                            }else {
                                String cons_claim_number = ",CLAIM_NUMBER," + db_STG_CLAIM_NUMBER + "," + db_CONS_CLAIM_NUMBER + ",Fail";
                                section1_results.add(cons_claim_number);
                            }

                            //--------------------  Validation BRAND ---------------
                            if(db_CONS_BRAND.equals(db_STG_BRAND)){
                                String cons_brand = ",BRAND," + db_STG_BRAND + "," + db_CONS_BRAND + ",Pass";
                                section1_results.add(cons_brand);
                            }else {
                                String cons_brand = ",BRAND," + db_STG_BRAND + "," + db_CONS_BRAND + ",Fail";
                                section1_results.add(cons_brand);
                            }

                            //--------------------  Validation PRODUCT_TYPE ---------------
                            if(db_CONS_PRODUCT_TYPE.equals(db_STG_PRODUCT_TYPE)){
                                String cons_product_type = ",PRODUCT_TYPE," + db_STG_PRODUCT_TYPE + "," + db_CONS_PRODUCT_TYPE + ",Pass";
                                section1_results.add(cons_product_type);
                            }else {
                                String cons_product_type = ",PRODUCT_TYPE," + db_STG_PRODUCT_TYPE + "," + db_CONS_PRODUCT_TYPE + ",Fail";
                                section1_results.add(cons_product_type);
                            }

                            //--------------------  Validation CHANNEL ---------------
                            if(db_CONS_CHANNEL.equals(db_STG_CHANNEL)){
                                String cons_channel = ",CHANNEL," + db_STG_CHANNEL + "," + db_CONS_CHANNEL + ",Pass";
                                section1_results.add(cons_channel);
                            }else {
                                String cons_channel = ",CHANNEL," + db_STG_CHANNEL + "," + db_CONS_CHANNEL + ",Fail";
                                section1_results.add(cons_channel);
                            }

                            //--------------------  Validation THIRD_CLAIM_REF ---------------
                            if(db_CONS_THIRD_CLAIM_REF.equals(db_STG_THIRD_CLAIM_REF)){
                                String cons_third_claim_ref = ",THIRD_CLAIM_REF," + db_STG_THIRD_CLAIM_REF + "," + db_CONS_THIRD_CLAIM_REF + ",Pass";
                                section1_results.add(cons_third_claim_ref);
                            }else {
                                String cons_third_claim_ref = ",THIRD_CLAIM_REF," + db_STG_THIRD_CLAIM_REF + "," + db_CONS_THIRD_CLAIM_REF + ",Fail";
                                section1_results.add(cons_third_claim_ref);
                            }

                            //--------------------  Validation PAYEE_TYPE ---------------
                            if(db_CONS_PAYEE_TYPE.equals(db_STG_PAYEE_TYPE)){
                                String cons_Payee_type = ",PAYEE_TYPE," + db_STG_PAYEE_TYPE + "," + db_CONS_PAYEE_TYPE + ",Pass";
                                section1_results.add(cons_Payee_type);
                            }else {
                                String cons_Payee_type = ",PAYEE_TYPE," + db_STG_PAYEE_TYPE + "," + db_CONS_PAYEE_TYPE + ",Fail";
                                section1_results.add(cons_Payee_type);
                            }

                            //--------------------  Validation PAYMENT_METHOD ---------------
                            if(db_CONS_PAYMENT_METHOD.equals(db_STG_PAYMENT_METHOD)){
                                String cons_payment_method = ",PAYMENT_METHOD," + db_STG_PAYMENT_METHOD + "," + db_CONS_PAYMENT_METHOD + ",Pass";
                                section1_results.add(cons_payment_method);
                            }else {
                                String cons_payment_method = ",PAYMENT_METHOD," + db_STG_PAYMENT_METHOD + "," + db_CONS_PAYMENT_METHOD + ",Fail";
                                section1_results.add(cons_payment_method);
                            }

                            //--------------------  Validation PAYMENT_TERMS ---------------
                            if(db_CONS_PAYMENT_TERMS.equals(db_STG_PAYMENT_TERMS)){
                                String cons_payment_terms = ",PAYMENT_TERMS," + db_STG_PAYMENT_TERMS + "," + db_CONS_PAYMENT_TERMS + ",Pass";
                                section1_results.add(cons_payment_terms);
                            }else {
                                String cons_payment_terms = ",PAYMENT_TERMS," + db_STG_PAYMENT_TERMS + "," + db_CONS_PAYMENT_TERMS + ",Fail";
                                section1_results.add(cons_payment_terms);
                            }

                            //--------------------  Validation CLAIM_HANDLER_REF ---------------
                            if(db_CONS_CLAIM_HANDLER_REF.equals(db_STG_CLAIM_HANDLER_REF)){
                                String cons_claim_handler_ref = ",CLAIM_HANDLER_REF," + db_STG_CLAIM_HANDLER_REF + "," + db_CONS_CLAIM_HANDLER_REF + ",Pass";
                                section1_results.add(cons_claim_handler_ref);
                            }else {
                                String cons_claim_handler_ref = ",CLAIM_HANDLER_REF," + db_STG_CLAIM_HANDLER_REF + "," + db_CONS_CLAIM_HANDLER_REF + ",Fail";
                                section1_results.add(cons_claim_handler_ref);
                            }

                            //--------------------  Validation APPROVER ---------------
                            if(db_CONS_APPROVER.equals(db_STG_APPROVER)){
                                String cons_approver = ",APPROVER," + db_STG_APPROVER + "," + db_CONS_APPROVER + ",Pass";
                                section1_results.add(cons_approver);
                            }else {
                                String cons_approver = ",APPROVER," + db_STG_APPROVER + "," + db_CONS_APPROVER + ",Fail";
                                section1_results.add(cons_approver);
                            }

                            //--------------------  Validation ACCOUNT_NUMBER ---------------
                            if(db_CONS_BANK_ACCOUNT_NUMBER.equals(db_STG_ACCOUNT_NUMBER)){
                                String cons_account_number = ",ACCOUNT_NUMBER," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_BANK_ACCOUNT_NUMBER + ",Pass";
                                section1_results.add(cons_account_number);
                            }else {
                                String cons_account_number = ",ACCOUNT_NUMBER," + db_STG_ACCOUNT_NUMBER + "," + db_CONS_BANK_ACCOUNT_NUMBER + ",Fail";
                                section1_results.add(cons_account_number);
                            }

                            //--------------------  Validation SORT_CODE ---------------
                            if(db_CONS_BANK_SORT_CODE.equals(db_STG_SORT_CODE)){
                                String cons_sort_code = ",SORT_CODE," + db_STG_SORT_CODE + "," + db_CONS_BANK_SORT_CODE + ",Pass";
                                section1_results.add(cons_sort_code);
                            }else {
                                String cons_sort_code = ",SORT_CODE," + db_STG_SORT_CODE + "," + db_CONS_BANK_SORT_CODE + ",Fail";
                                section1_results.add(cons_sort_code);
                            }

                            //--------------------  Validation INVOICE_NUM ---------------
                            if(db_CONS_INVOICE_NUM.equals(db_STG_INVOICE_NUM)){
                                String cons_invoice_number = ",INVOICE_NUM," + db_STG_INVOICE_NUM + "," + db_CONS_INVOICE_NUM + ",Pass";
                                section1_results.add(cons_invoice_number);
                            }else {
                                String cons_invoice_number = ",INVOICE_NUM," + db_STG_INVOICE_NUM + "," + db_CONS_INVOICE_NUM + ",Fail";
                                section1_results.add(cons_invoice_number);
                            }

                            //--------------------  Validation DESCRIPTION ---------------
                            if(db_CONS_INVOICE_NUM.equals(db_STG_DESCRIPTION)){
                                String cons_description = ",DESCRIPTION," + db_STG_DESCRIPTION + "," + db_CONS_INVOICE_NUM + ",Pass";
                                section1_results.add(cons_description);
                            }else {
                                String cons_description = ",DESCRIPTION," + db_STG_DESCRIPTION + "," + db_CONS_INVOICE_NUM + ",Fail";
                                section1_results.add(cons_description);
                            }

                            //--------------------  Validation INVOICE_DATE ---------------
                            if(db_CONS_INVOICE_DATE.equals(db_STG_INVOICE_DATE)){
                                String cons_invoice_date = ",INVOICE_DATE," + db_STG_INVOICE_DATE + "," + db_CONS_INVOICE_DATE + ",Pass";
                                section1_results.add(cons_invoice_date);
                            }else {
                                String cons_invoice_date = ",INVOICE_DATE," + db_STG_INVOICE_DATE + "," + db_CONS_INVOICE_DATE + ",Fail";
                                section1_results.add(cons_invoice_date);
                            }

                            //--------------------  Validation INVOICE_RECEIVED_DATE ---------------
                            if(db_CONS_INVOICE_RECEIVED_DATE.equals(db_STG_INVOICE_RECEIVED_DATE)){
                                String cons_invoice_recived_date = ",INVOICE_RECEIVED_DATE," + db_STG_INVOICE_RECEIVED_DATE + "," + db_CONS_INVOICE_RECEIVED_DATE + ",Pass";
                                section1_results.add(cons_invoice_recived_date);
                            }else {
                                String cons_invoice_recived_date = ",INVOICE_RECEIVED_DATE," + db_STG_INVOICE_RECEIVED_DATE + "," + db_CONS_INVOICE_RECEIVED_DATE + ",Fail";
                                section1_results.add(cons_invoice_recived_date);
                            }

                            //--------------------  Validation VENDOR_SITE_ID ---------------
                            if(db_CONS_VENDOR_SITE_ID.equals(db_STG_VENDOR_SITE_ID)){
                                String cons_invoice_site_id = ",VENDOR_SITE_ID," + db_STG_VENDOR_SITE_ID + "," + db_CONS_VENDOR_SITE_ID + ",Pass";
                                section1_results.add(cons_invoice_site_id);
                            }else {
                                String cons_invoice_site_id = ",VENDOR_SITE_ID," + db_STG_VENDOR_SITE_ID + "," + db_CONS_VENDOR_SITE_ID + ",Fail";
                                section1_results.add(cons_invoice_site_id);
                            }

                            //--------------------  Validation EXCHANGE_EFFECTIVE_DATE ---------------
                            if(db_CONS_EXCHANGE_EFFECTIVE_DATE.equals(db_STG_EXCHANGE_EFFECTIVE_DATE)){
                                String cons_exc_effe_date = ",EXCHANGE_EFFECTIVE_DATE," + db_STG_EXCHANGE_EFFECTIVE_DATE + "," + db_CONS_EXCHANGE_EFFECTIVE_DATE + ",Pass";
                                section1_results.add(cons_exc_effe_date);
                            }else {
                                String cons_exc_effe_date = ",EXCHANGE_EFFECTIVE_DATE," + db_STG_EXCHANGE_EFFECTIVE_DATE + "," + db_CONS_EXCHANGE_EFFECTIVE_DATE + ",Fail";
                                section1_results.add(cons_exc_effe_date);
                            }

                            //--------------------  Validation ATTRIBUTE1 ---------------
                            if(db_STG_PAYMENT_METHOD.equalsIgnoreCase("CHECK") && ((!db_STG_PAYEE_TYPE.equalsIgnoreCase("PI")) || (!db_STG_PAYEE_TYPE.equalsIgnoreCase("PS")))){
                                if(db_STG_ATTRIBUTE1.equals(db_CONS_PAYEE_DESCRIPTION)){
                                    String stg_attribute1 = ",ATTRIBUTE1," + db_STG_ATTRIBUTE1 + "," + db_CONS_PAYEE_DESCRIPTION + ",Pass";
                                    section1_results.add(stg_attribute1);
                                }else {
                                    String stg_attribute1 = ",ATTRIBUTE1," + db_STG_ATTRIBUTE1 + "," + db_CONS_PAYEE_DESCRIPTION + ",Fail";
                                    section1_results.add(stg_attribute1);
                                }
                            }

                            //--------------------  Validation ATTRIBUTE2 ---------------
                            if(db_STG_PAYMENT_METHOD.equalsIgnoreCase("CHECK") && ((!db_STG_PAYEE_TYPE.equalsIgnoreCase("PI")) || (!db_STG_PAYEE_TYPE.equalsIgnoreCase("PS")))){
                                if(db_STG_ATTRIBUTE2.equals(db_CONS_PAYEE_ADDRESS_LINE1)){
                                    String stg_attribute2 = ",ATTRIBUTE2," + db_STG_ATTRIBUTE2 + "," + db_CONS_PAYEE_ADDRESS_LINE1 + ",Pass";
                                    section1_results.add(stg_attribute2);
                                }else {
                                    String stg_attribute2 = ",ATTRIBUTE2," + db_STG_ATTRIBUTE2 + "," + db_CONS_PAYEE_ADDRESS_LINE1 + ",Fail";
                                    section1_results.add(stg_attribute2);
                                }
                            }

                            //--------------------  Validation ATTRIBUTE7 ---------------
                            if(db_STG_PAYMENT_METHOD.equalsIgnoreCase("CHECK") && ((!db_STG_PAYEE_TYPE.equalsIgnoreCase("PI")) || (!db_STG_PAYEE_TYPE.equalsIgnoreCase("PS")))){
                                if(db_STG_ATTRIBUTE7.equals(db_CONS_PAYEE_POSTCODE)){
                                    String stg_attribute7 = ",ATTRIBUTE7," + db_STG_ATTRIBUTE7 + "," + db_CONS_PAYEE_POSTCODE + ",Pass";
                                    section1_results.add(stg_attribute7);
                                }else {
                                    String stg_attribute7 = ",ATTRIBUTE7," + db_STG_ATTRIBUTE7 + "," + db_CONS_PAYEE_POSTCODE + ",Fail";
                                    section1_results.add(stg_attribute7);
                                }
                            }

                            //--------------------  Validation SOURCE --------------
                            if(db_CONS_SYSTEM.equals(db_STG_SOURCE)){
                                String cons_source = ",SOURCE," + db_STG_SOURCE + "," + db_CONS_SYSTEM + ",Pass";
                                section1_results.add(cons_source);
                            }else {
                                String cons_source = ",SOURCE," + db_STG_SOURCE + "," + db_CONS_SYSTEM + ",Fail";
                                section1_results.add(cons_source);
                            }

                            //--------------------  Validation FILE_NAME --------------
                            if(db_CONS_FILE_NAME.equals(db_STG_FILE_NAME)){
                                String cons_file_name = ",FILE_NAME," + db_STG_FILE_NAME + "," + db_CONS_FILE_NAME + ",Pass";
                                section1_results.add(cons_file_name);
                            }else {
                                String cons_file_name = ",FILE_NAME," + db_STG_FILE_NAME + "," + db_CONS_FILE_NAME + ",Fail";
                                section1_results.add(cons_file_name);
                            }

                            //--------------------  Validation FSH_ATTRIBUTE1 --------------
                            if(db_CONS_TRANSACTION_TYPE.equals(db_STG_FSH_ATTRIBUTE1)){
                                String cons_fsh_attribute1 = ",FSH_ATTRIBUTE1," + db_STG_FSH_ATTRIBUTE1 + "," + db_CONS_TRANSACTION_TYPE + ",Pass";
                                section1_results.add(cons_fsh_attribute1);
                            }else {
                                String cons_fsh_attribute1 = ",FSH_ATTRIBUTE1," + db_STG_FSH_ATTRIBUTE1 + "," + db_CONS_TRANSACTION_TYPE + ",Fail";
                                section1_results.add(cons_fsh_attribute1);
                            }

                            //--------------------  Validation FSH_ATTRIBUTE2 --------------
                            if(db_CONS_TXN_REFERENCE1.equals(db_STG_FSH_ATTRIBUTE2)){
                                String cons_fsh_attribute2 = ",FSH_ATTRIBUTE2," + db_STG_FSH_ATTRIBUTE2 + "," + db_CONS_TXN_REFERENCE1 + ",Pass";
                                section1_results.add(cons_fsh_attribute2);
                            }else {
                                String cons_fsh_attribute2 = ",FSH_ATTRIBUTE2," + db_STG_FSH_ATTRIBUTE2 + "," + db_CONS_TXN_REFERENCE1 + ",Fail";
                                section1_results.add(cons_fsh_attribute2);
                            }

                            //----------------------- STANDARDISATION start here -----------------------------
                            String db_lookup_underWriter_meaning = "null";
                            String db_lookup_line_of_business_meaning = "null";
                            String db_lookup_line_product_meaning = "null";
                            String db_lookup_line_currency_code_meaning = "null";
                            String db_lookup_exchange_rate_meaning = "null";
                            String db_lookup_exchange_rate_type_meaning = "null";
                            String db_lookup_group_lookup_code_meaning = "null";
                            String db_lookup_org_id_meaning = "null";

                            //---------------- Validate UNDERWRITER -----------------------
                            SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE UPPER(LOOKUP_CODE) = UPPER('" + db_CONS_UNDERWRITER + "') and LOOKUP_TYPE = 'UNDERWRITER' and system = 'ECLI' ");
                            while (SQLResultset.next()) {
                                db_lookup_underWriter_meaning = SQLResultset.getString("MEANING");
                            }
                            if (db_lookup_underWriter_meaning.equals("null")) {
                                String lookup_underWriter_meaning = ",Underwriter lookup," + "LookUp value not found" + "," + db_STG_UNDERWRITER + ",Fail";
                                section1_results.add(lookup_underWriter_meaning);
                            } else if (db_lookup_underWriter_meaning != null) {
                                if (db_lookup_underWriter_meaning.equals(db_STG_UNDERWRITER)) {
                                    String lookup_underWriter_meaning = ",Underwriter lookup," + db_lookup_underWriter_meaning + "," + db_STG_UNDERWRITER + ",Pass";
                                    section1_results.add(lookup_underWriter_meaning);
                                } else {
                                    String lookup_underWriter_meaning = ",Underwriter lookup," + db_lookup_underWriter_meaning + "," + db_STG_UNDERWRITER + ",Fail";
                                    section1_results.add(lookup_underWriter_meaning);
                                }
                            }

                            //------------------------ LINE_OF_BUSINESS Validation -----------------
                            SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_LINE_OF_BUSINESS + "' and LOOKUP_TYPE = 'LINE_OF_BUSINESS' and system = 'ECLI' and pattern = 'APInvoice'");
                            while (SQLResultset.next()) {
                                db_lookup_line_of_business_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_line_of_business_meaning.equals("null")) {
                                String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS lookup," + "LookUp value not found" + "," + db_STG_LINE_OF_BUSINESS + ",Fail";
                                section1_results.add(lookup_line_of_business_meaning);
                            } else if (db_lookup_line_of_business_meaning != null) {
                                if (db_lookup_line_of_business_meaning.equals(db_STG_LINE_OF_BUSINESS)) {
                                    String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS lookup," + db_lookup_line_of_business_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Pass";
                                    section1_results.add(lookup_line_of_business_meaning);
                                } else {
                                    String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS lookup," + db_lookup_line_of_business_meaning + "," + db_STG_LINE_OF_BUSINESS + ",Fail";
                                    section1_results.add(lookup_line_of_business_meaning);
                                }
                            }

                            //------------------------ PRODUCT Validation -----------------
                            SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_STG_PRODUCT + "' and LOOKUP_TYPE = 'PRODUCT' ");
                            while (SQLResultset.next()) {
                                db_lookup_line_product_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_line_product_meaning.equals("null")) {
                                String lookup_line_product_meaning = ",PRODUCT lookup," + "LookUp value not found" + "," + db_STG_PRODUCT + ",Fail";
                                section1_results.add(lookup_line_product_meaning);
                            } else if (db_lookup_line_product_meaning != null) {
                                if (db_lookup_line_product_meaning.equals(db_STG_PRODUCT)) {
                                    String lookup_line_product_meaning = ",PRODUCT lookup," + db_lookup_line_product_meaning + "," + db_STG_PRODUCT + ",Pass";
                                    section1_results.add(lookup_line_product_meaning);
                                } else {
                                    String lookup_line_product_meaning = ",PRODUCT lookup," + db_lookup_line_product_meaning + "," + db_STG_PRODUCT + ",Fail";
                                    section1_results.add(lookup_line_product_meaning);
                                }
                            }

                            //------------------------ INVOICE_CURRENCY_CODE Validation -----------------
                            SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_STG_INVOICE_CURRENCY_CODE + "' and LOOKUP_TYPE = 'INVOICE_CURRENCY_CODE' ");
                            while (SQLResultset.next()) {
                                db_lookup_line_currency_code_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_line_currency_code_meaning.equals("null")) {
                                String lookup_line_currency_code_meaning = ",INVOICE_CURRENCY_CODE lookup," + "LookUp value not found" + "," + db_STG_INVOICE_CURRENCY_CODE + ",Fail";
                                section1_results.add(lookup_line_currency_code_meaning);
                            } else if (db_lookup_line_currency_code_meaning != null) {
                                if (db_lookup_line_currency_code_meaning.equals(db_STG_INVOICE_CURRENCY_CODE)) {
                                    String lookup_line_currency_code_meaning = ",INVOICE_CURRENCY_CODE lookup," + db_lookup_line_currency_code_meaning + "," + db_STG_INVOICE_CURRENCY_CODE + ",Pass";
                                    section1_results.add(lookup_line_currency_code_meaning);
                                } else {
                                    String lookup_line_currency_code_meaning = ",INVOICE_CURRENCY_CODE lookup," + db_lookup_line_currency_code_meaning + "," + db_STG_INVOICE_CURRENCY_CODE + ",Fail";
                                    section1_results.add(lookup_line_currency_code_meaning);
                                }
                            }

                            //--------------- INVOICE_ID validation -------------------------
                            String db_invoice_id = db_STG_INVOICE_NUM + "~" + db_STG_VENDOR_SITE_ID;
                            if(db_STG_INVOICE_ID.equals(db_invoice_id)){
                                String stg_invoice_id = ",INVOICE_ID," + db_STG_INVOICE_ID + "," + db_invoice_id + ",Pass";
                                section1_results.add(stg_invoice_id);
                            }else {
                                String stg_invoice_id = ",INVOICE_ID," + db_STG_INVOICE_ID + "," + db_invoice_id + ",Fail";
                                section1_results.add(stg_invoice_id);
                            }

                            //------------------------ EXCHANGE_RATE Validation -----------------
                            SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_EXCHANGE_RATE + "' and LOOKUP_TYPE = 'EXCHANGE_RATE' ");
                            while (SQLResultset.next()) {
                                db_lookup_exchange_rate_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_exchange_rate_meaning.equals("null")) {
                                String lookup_excahnge_rate_meaning = ",EXCHANGE_RATE lookup," + "LookUp value not found" + "," + db_STG_EXCHANGE_RATE + ",Fail";
                                section1_results.add(lookup_excahnge_rate_meaning);
                            } else if (db_lookup_exchange_rate_meaning != null) {
                                if (db_lookup_exchange_rate_meaning.equals(db_STG_EXCHANGE_RATE)) {
                                    String lookup_excahnge_rate_meaning = ",EXCHANGE_RATE lookup," + db_lookup_exchange_rate_meaning + "," + db_STG_EXCHANGE_RATE + ",Pass";
                                    section1_results.add(lookup_excahnge_rate_meaning);
                                } else {
                                    String lookup_excahnge_rate_meaning = ",EXCHANGE_RATE lookup," + db_lookup_exchange_rate_meaning + "," + db_STG_EXCHANGE_RATE + ",Fail";
                                    section1_results.add(lookup_excahnge_rate_meaning);
                                }
                            }

                            //------------------------ EXCHANGE_RATE_TYPE Validation -----------------
                            SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_CONS_EXCHANGE_RATE_TYPE + "' and LOOKUP_TYPE = 'EXCHANGE_RATE_TYPE' ");
                            while (SQLResultset.next()) {
                                db_lookup_exchange_rate_type_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_exchange_rate_type_meaning.equals("null")) {
                                String lookup_excahnge_rate_type_meaning = ",EXCHANGE_RATE_TYPE lookup," + "LookUp value not found" + "," + db_STG_EXCHANGE_RATE_TYPE + ",Fail";
                                section1_results.add(lookup_excahnge_rate_type_meaning);
                            } else if (db_lookup_exchange_rate_type_meaning != null) {
                                if (db_lookup_exchange_rate_type_meaning.equals(db_STG_EXCHANGE_RATE_TYPE)) {
                                    String lookup_excahnge_rate_type_meaning = ",EXCHANGE_RATE_TYPE lookup," + db_lookup_exchange_rate_type_meaning + "," + db_STG_EXCHANGE_RATE_TYPE + ",Pass";
                                    section1_results.add(lookup_excahnge_rate_type_meaning);
                                } else {
                                    String lookup_excahnge_rate_type_meaning = ",EXCHANGE_RATE_TYPE lookup," + db_lookup_exchange_rate_type_meaning + "," + db_STG_EXCHANGE_RATE_TYPE + ",Fail";
                                    section1_results.add(lookup_excahnge_rate_type_meaning);
                                }
                            }

                            //------------------------ PAY_GROUP_LOOKUP_CODE Validation -----------------
                            SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_STG_PAY_GROUP_LOOKUP_CODE + "' and LOOKUP_TYPE = 'PAY_GROUP_LOOKUP_CODE' ");
                            while (SQLResultset.next()) {
                                db_lookup_group_lookup_code_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_group_lookup_code_meaning.equals("null")) {
                                String lookup_group_lookup_code_meaning = ",PAY_GROUP_LOOKUP_CODE lookup," + "LookUp value not found" + "," + db_STG_PAY_GROUP_LOOKUP_CODE + ",Fail";
                                section1_results.add(lookup_group_lookup_code_meaning);
                            } else if (db_lookup_group_lookup_code_meaning != null) {
                                if (db_lookup_group_lookup_code_meaning.equals(db_STG_PAY_GROUP_LOOKUP_CODE)) {
                                    String lookup_group_lookup_code_meaning = ",PAY_GROUP_LOOKUP_CODE lookup," + db_lookup_group_lookup_code_meaning + "," + db_STG_PAY_GROUP_LOOKUP_CODE + ",Pass";
                                    section1_results.add(lookup_group_lookup_code_meaning);
                                } else {
                                    String lookup_group_lookup_code_meaning = ",PAY_GROUP_LOOKUP_CODE lookup," + db_lookup_group_lookup_code_meaning + "," + db_STG_PAY_GROUP_LOOKUP_CODE + ",Fail";
                                    section1_results.add(lookup_group_lookup_code_meaning);
                                }
                            }

                            //------------------------ ORG_ID Validation -----------------
                            SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_STG_ORG_ID + "' and LOOKUP_TYPE = 'ORG_ID' ");
                            while (SQLResultset.next()) {
                                db_lookup_org_id_meaning = SQLResultset.getString("MEANING");
                            }

                            if (db_lookup_org_id_meaning.equals("null")) {
                                String lookup_org_id_meaning = ",ORG_ID lookup," + "LookUp value not found" + "," + db_STG_ORG_ID + ",Fail";
                                section1_results.add(lookup_org_id_meaning);
                            } else if (db_lookup_org_id_meaning != null) {
                                if (db_lookup_org_id_meaning.equals(db_STG_ORG_ID)) {
                                    String lookup_org_id_meaning = ",ORG_ID lookup," + db_lookup_org_id_meaning + "," + db_STG_ORG_ID + ",Pass";
                                    section1_results.add(lookup_org_id_meaning);
                                } else {
                                    String lookup_org_id_meaning = ",ORG_ID lookup," + db_lookup_org_id_meaning + "," + db_STG_ORG_ID + ",Fail";
                                    section1_results.add(lookup_org_id_meaning);
                                }
                            }

                            //--------------- BUSINESS VALIDATION START HERE -----------------------

                            //-------------- GLOBAL_ATTRIBUTE2 Field is mandatory ----------------
                            if(db_STG_GLOBAL_ATTRIBUTE2 != null){
                                String stg_global_attribute2 = ",GLOBAL_ATTRIBUTE2," + db_STG_LINE_HEADER_ID + "," + "Mandatory field is displayed" + ",Pass";
                                section1_results.add(stg_global_attribute2);
                                if(db_STG_GLOBAL_ATTRIBUTE2.equals(db_STG_UNDERWRITER)){
                                    String global_attribute2 = ",GLOBAL_ATTRIBUTE2," + db_STG_GLOBAL_ATTRIBUTE2 + "," + db_STG_UNDERWRITER + ",Pass";
                                    section1_results.add(global_attribute2);
                                }else {
                                    String global_attribute2 = ",GLOBAL_ATTRIBUTE2," + db_STG_GLOBAL_ATTRIBUTE2 + "," + db_STG_UNDERWRITER + ",Fail";
                                    section1_results.add(global_attribute2);
                                }
                            }else {
                                String stg_global_attribute2 = ",GLOBAL_ATTRIBUTE2," + db_STG_GLOBAL_ATTRIBUTE2 + "," + "Mandatory field is not displayed" + ",Fail";
                                section1_results.add(stg_global_attribute2);
                            }

                            //-------------- GLOBAL_ATTRIBUTE3 Field is mandatory ----------------
                            if(db_STG_GLOBAL_ATTRIBUTE3 != null){
                                String stg_global_attribute3 = ",GLOBAL_ATTRIBUTE3," + db_STG_LINE_HEADER_ID + "," + "Mandatory field is displayed" + ",Pass";
                                section1_results.add(stg_global_attribute3);
                                if(db_STG_GLOBAL_ATTRIBUTE3.equals(db_STG_PRODUCT)){
                                    String global_attribute3 = ",GLOBAL_ATTRIBUTE3," + db_STG_GLOBAL_ATTRIBUTE2 + "," + db_STG_PRODUCT + ",Pass";
                                    section1_results.add(global_attribute3);
                                }else {
                                    String global_attribute3 = ",GLOBAL_ATTRIBUTE3," + db_STG_GLOBAL_ATTRIBUTE2 + "," + db_STG_PRODUCT + ",Fail";
                                    section1_results.add(global_attribute3);
                                }
                            }else {
                                String stg_global_attribute3 = ",GLOBAL_ATTRIBUTE3," + db_STG_GLOBAL_ATTRIBUTE3 + "," + "Mandatory field is not displayed" + ",Fail";
                                section1_results.add(stg_global_attribute3);
                            }

                            //-------------- INVOICE_ID Field is mandatory ----------------
                            if(db_stg_INVOICE_ID != null){
                                String stg_invoice_id = ",INVOICE_ID," + db_stg_INVOICE_ID + "," + "Mandatory field is displayed" + ",Pass";
                                section1_results.add(stg_invoice_id);
                            }else {
                                String stg_invoice_id = ",INVOICE_ID," + db_stg_INVOICE_ID + "," + "Mandatory field is not displayed" + ",Fail";
                                section1_results.add(stg_invoice_id);
                            }

                            //-------------- INVOICE_NUM Field is mandatory ----------------
                            if(db_STG_INVOICE_NUM != null){
                                String stg_invoice_number = ",INVOICE_NUM," + db_STG_INVOICE_NUM + "," + "Mandatory field is displayed" + ",Pass";
                                section1_results.add(stg_invoice_number);
                            }else {
                                String stg_invoice_number = ",INVOICE_NUM," + db_STG_INVOICE_NUM + "," + "Mandatory field is not displayed" + ",Fail";
                                section1_results.add(stg_invoice_number);
                            }

                            //-------------- INVOICE_DATE Field is mandatory ----------------
                            if(db_STG_INVOICE_DATE != null){
                                String stg_invoice_date = ",INVOICE_DATE," + db_STG_INVOICE_DATE + "," + "Mandatory field is displayed" + ",Pass";
                                section1_results.add(stg_invoice_date);
                            }else {
                                String stg_invoice_date = ",INVOICE_DATE," + db_STG_INVOICE_DATE + "," + "Mandatory field is not displayed" + ",Fail";
                                section1_results.add(stg_invoice_date);
                            }

                            //-------------- INVOICE_RECEIVED_DATE Field is mandatory ----------------
                            if(db_STG_INVOICE_RECEIVED_DATE != null){
                                String stg_invoice_received_date = ",INVOICE_RECEIVED_DATE," + db_STG_INVOICE_RECEIVED_DATE + "," + "Mandatory field is displayed" + ",Pass";
                                section1_results.add(stg_invoice_received_date);
                            }else {
                                String stg_invoice_received_date = ",INVOICE_RECEIVED_DATE," + db_STG_INVOICE_RECEIVED_DATE + "," + "Mandatory field is not displayed" + ",Fail";
                                section1_results.add(stg_invoice_received_date);
                            }







                            //------------------------  Line Item validation -----------------------------
                            int line_count = 0;
                            ArrayList<String> list_line_id = new ArrayList<String>();
                            SQLResultset = SQLstmt.executeQuery("SELECT * FROM  DLG_FSH_STG_COMM_API_LIN WHERE  HEADER_ID = '" + db_STG_HEADER_ID + "'");
                            while (SQLResultset.next()){
                                list_line_id.add(SQLResultset.getString("LINE_ID"));
                            }

                            for (int i_count = 0; i_count <= list_line_id.size()-1; i_count++ ){
                                int stg_sub_indent = i_count;
                                int sub_tag_line = 0;
                                System.out.println("Line id ---> " + list_line_id.get(i_count));
                                SQLResultset = SQLstmt.executeQuery("SELECT * FROM  DLG_FSH_STG_COMM_API_LIN WHERE  HEADER_ID = '" + db_STG_HEADER_ID + "' and LINE_ID = '"+list_line_id.get(i_count)+"'");
                                while (SQLResultset.next()){
                                    db_STG_line_id = SQLResultset.getString("LINE_ID");
                                    db_stg_LINE_INVOICE_ID = SQLResultset.getString("INVOICE_ID");
                                    db_STG_LINE_NUMBER = SQLResultset.getString("LINE_NUMBER");
                                    db_STG_LINE_DESCRIPTION = SQLResultset.getString("DESCRIPTION");
                                    db_STG_LINE_ITEM_AMOUNT = SQLResultset.getString("LINE_ITEM_AMOUNT");
                                    db_STG_BASE_LINE_ITEM_AMOUNT = SQLResultset.getString("BASE_LINE_ITEM_AMOUNT");
                                    db_STG_TAX_CODE = SQLResultset.getString("TAX_CODE");
                                    db_STG_LINE_HEADER_ID = SQLResultset.getString("HEADER_ID");

                                    SQLResultset = SQLstmt.executeQuery("SELECT * FROM DLG_FSH_CONS_BMSX_API_LIN WHERE HEADER_ID = '" + db_STG_LINE_HEADER_ID + "' and LINE_ID = '" + db_STG_line_id + "'  ");
                                    while (SQLResultset.next()){
                                        db_CONS_line_id = SQLResultset.getString("LINE_ID");
                                        db_CONS_LINE_NUMBER = SQLResultset.getString("LINE_NUMBER");
                                        db_CONS_LINE_CATEGORY = SQLResultset.getString("CATEGORY");
                                        db_CONS_LINE_ITEM_AMOUNT = SQLResultset.getString("LINE_ITEM_AMOUNT");
                                        //db_CONS_BASE_LINE_ITEM_AMOUNT = SQLResultset.getString("BASE_LINE_ITEM_AMOUNT");
                                        //db_CONS_LINE_TRANSACTION_DATE = SQLResultset.getString("TRANSACTION_DATE");
                                        db_CONS_TAX_CODE = SQLResultset.getString("TAX_CODE");
                                        db_CONS_LINE_HEADER_ID = SQLResultset.getString("HEADER_ID");

                                        if(db_STG_line_id.equals(db_CONS_line_id)){
                                            String stg_line_pc_line_id = stg_line_map_row + "." + stg_sub_indent + ",LINE LINE_ID," + db_STG_line_id + "," + db_CONS_line_id + ",Pass";
                                            section1_results.add(stg_line_pc_line_id);
                                            stg_sub_indent++;
                                        }else {
                                            String stg_line_pc_line_id = stg_line_map_row + "." + stg_sub_indent + ",LINE LINE_ID," + db_STG_line_id + "," + db_CONS_line_id + ",Fail";
                                            section1_results.add(stg_line_pc_line_id);
                                            stg_sub_indent++;
                                        }

                                        //------------- Validate Line HEADER_ID ----------------
                                        if (db_STG_LINE_HEADER_ID.equals(db_CONS_LINE_HEADER_ID)) {
                                            String stg_line_pc_header_id = ",LINE HEADER_ID," + db_STG_LINE_HEADER_ID + "," + db_CONS_LINE_HEADER_ID + ",Pass";
                                            section1_results.add(stg_line_pc_header_id);
                                        } else {
                                            String stg_line_pc_header_id = ",LINE HEADER_ID," + db_STG_LINE_HEADER_ID + "," + db_CONS_LINE_HEADER_ID + ",Fail";
                                            section1_results.add(stg_line_pc_header_id);
                                        }

                                        //------------- Validate Line LINE_NUMBER ----------------
                                        if (db_STG_LINE_NUMBER.equals(db_CONS_LINE_NUMBER)) {
                                            String stg_line_number = ",LINE LINE_NUMBER," + db_STG_LINE_NUMBER + "," + db_CONS_LINE_NUMBER + ",Pass";
                                            section1_results.add(stg_line_number);
                                        } else {
                                            String stg_line_number = ",LINE LINE_NUMBER," + db_STG_LINE_NUMBER + "," + db_CONS_LINE_NUMBER + ",Fail";
                                            section1_results.add(stg_line_number);
                                        }

                                        //------------- Validate Line DESCRIPTION ----------------
                                        if (db_STG_LINE_DESCRIPTION.equals(db_CONS_LINE_CATEGORY)) {
                                            String stg_line_description = ",LINE DESCRIPTION," + db_STG_LINE_DESCRIPTION + "," + db_CONS_LINE_CATEGORY + ",Pass";
                                            section1_results.add(stg_line_description);
                                        } else {
                                            String stg_line_description = ",LINE DESCRIPTION," + db_STG_LINE_DESCRIPTION + "," + db_CONS_LINE_CATEGORY + ",Fail";
                                            section1_results.add(stg_line_description);
                                        }

                                        //------------- Validate LINE_ITEM_AMOUNT ----------------
                                        if (db_STG_LINE_ITEM_AMOUNT.equals(db_CONS_LINE_ITEM_AMOUNT)) {
                                            String stg_line_amount = ",LINE_ITEM_AMOUNT," + db_STG_LINE_ITEM_AMOUNT + "," + db_CONS_LINE_ITEM_AMOUNT + ",Pass";
                                            section1_results.add(stg_line_amount);
                                        } else {
                                            String stg_line_amount = ",LINE_ITEM_AMOUNT," + db_STG_LINE_ITEM_AMOUNT + "," + db_CONS_LINE_ITEM_AMOUNT + ",Fail";
                                            section1_results.add(stg_line_amount);
                                        }

                                        /*//------------- Validate BASE_LINE_ITEM_AMOUNT ----------------
                                        if (db_STG_BASE_LINE_ITEM_AMOUNT.equals(db_CONS_BASE_LINE_ITEM_AMOUNT)) {
                                            String stg_base_line_amount = ",BASE_LINE_ITEM_AMOUNT," + db_STG_BASE_LINE_ITEM_AMOUNT + "," + db_CONS_BASE_LINE_ITEM_AMOUNT + ",Pass";
                                            section1_results.add(stg_base_line_amount);
                                        } else {
                                            String stg_base_line_amount = ",BASE_LINE_ITEM_AMOUNT," + db_STG_BASE_LINE_ITEM_AMOUNT + "," + db_CONS_BASE_LINE_ITEM_AMOUNT + ",Fail";
                                            section1_results.add(stg_base_line_amount);
                                        }*/

                                        //------------- Validate TRANSACTION_DATE ----------------
                                        if (db_STG_LINE_TRANSACTION_DATE.equals(db_CONS_LINE_TRANSACTION_DATE)) {
                                            String stg_line_transaction_date = ",LINE_TRANSACTION_DATE," + db_STG_LINE_TRANSACTION_DATE + "," + db_CONS_LINE_TRANSACTION_DATE + ",Pass";
                                            section1_results.add(stg_line_transaction_date);
                                        } else {
                                            String stg_line_transaction_date = ",LINE_TRANSACTION_DATE," + db_STG_LINE_TRANSACTION_DATE + "," + db_CONS_LINE_TRANSACTION_DATE + ",Fail";
                                            section1_results.add(stg_line_transaction_date);
                                        }

                                        /*//------------- Validate TAX_CODE ----------------
                                        if (db_STG_TAX_CODE.equals(db_CONS_TAX_CODE)) {
                                            String stg_line_tax_code = ",TAX_CODE," + db_STG_TAX_CODE + "," + db_CONS_TAX_CODE + ",Pass";
                                            section1_results.add(stg_line_tax_code);
                                        } else {
                                            String stg_line_tax_code = ",TAX_CODE," + db_STG_TAX_CODE + "," + db_CONS_TAX_CODE + ",Fail";
                                            section1_results.add(stg_line_tax_code);
                                        }*/





                                    }



                                }

                            }


                        }

                    }
                }
                list.addAll(section1_results);

                // ---------------- HTML Report generation ------------------------
                report_generation.report_Test1(section1_results, "Header", file_name, "STATE MODEL VALIDATION - CONSOLIDATION LAYER", "BMSX PC", "BMSX PC STATE MODEL VALIDATION", "");
                report_generation.report_Test1(section1_results, "Section2", file_name, "STATE MODEL VALIDATION - STAGING LAYER", "BMSX PC", "BMSX PC STATE MODEL VALIDATION", "");

                section1_results.clear();
            }
        }



    }

}
