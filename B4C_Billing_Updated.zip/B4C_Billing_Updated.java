package Pages;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class B4C_Billing_Updated {

    static Statement SQLstmt = null;
    static ResultSet SQLResultset = null;
    public static HTML_Report_Generation report_generation;
    private static File inputFile;

    public static void main(String[] args) throws ParserConfigurationException, IOException, SAXException, SQLException, ParseException {

        report_generation = new HTML_Report_Generation();
        SimpleDateFormat sdf;
        SimpleDateFormat sdf1;
        SimpleDateFormat xml_sdf;



        //------ CONS table variable decleration ---------
        String db_bc_header_id = "null";
        String db_source = "null";
        String db_account_number = "null";
        String db_policy_number = "null";
        String db_transaction_date = "null";
        String db_transaction_sub_type = "null";
        String db_transaction_reason = "null";
        String db_payment_method = "null";
        String db_sun_number = "null";
        String db_mid_number = "null";
        String db_ddi_reference = "null";
        String db_pay_in_slip_number = "null";
        String db_cheque_number = "null";
        String db_card_type = "null";
        String db_bacs_narrative = "null";
        String db_card_narrative = "null";
        String db_channel = "null";
        String db_reversal_indicator = "null";
        String db_currency_code = "null";
        String db_exchange_rate = "null";
        //String db_exchange_rate_type = "null";
        String db_base_currency_amount = "null";
        String db_base_intrest_amount = "null";
        String db_tax_deductible = "null";
        String db_order_number = "null";
        String db_payment_transaction_type_id = "null";
        String db_currency_amount = "null";
        String db_credit_ind = "null";
        String xmlbc_header_id = "null";
        String xml_payment_method = "null";
        String db_underwriter = "null";
        String db_brand = "null";
        String db_product_Type = "null";
        String db_line_of_business = "null";
        String db_transaction_reference = "null";

        //----------- Staging table variable decleration-------------
        String db_stg_reversal_indicator = "null";

        String db_stg_bc_header_id = "null";
        String db_stg_source = "null";
        String db_stg_brand = "null";
        String db_stg_account_number = "null";
        String db_stg_policy_number = "null";
        String db_stg_transaction_date = "null";
        String db_stg_transaction_sub_type = "null";
        String db_stg_transaction_reason = "null";
        String db_stg_payment_method = "null";
        String db_stg_sun_number = "null";
        String db_stg_mid_number = "null";
        String db_stg_ddi_reference = "null";
        String db_stg_pay_in_slip_number = "null";
        String db_stg_cheque_number = "null";
        String db_stg_card_type = "null";
        String db_stg_bacs_narrative = "null";
        String db_stg_card_narrative = "null";
        String db_stg_channel = "null";
        String db_stg_currency_code = "null";
        String db_stg_exchange_rate = "null";
        // db_exchange_rate_type = "null";
        String db_stg_base_currency_amount = "null";
        String db_stg_base_intrest_amount = "null";
        String db_stg_tax_deductible = "null";
        String db_stg_order_number = "null";
        String db_stg_payment_transaction_type_id = "null";
        String db_stg_currency_amount = "null";
        String db_stg_credit_ind = "null";
        String db_stg_underwriter = "null";

        //----------- Aggregate table variable decleration-------------
        String db_aggregate_reversal_indicator = "null";

        String db_aggregate_bc_header_id = "null";
        String db_aggregate_source = "null";
        String db_aggregate_brand = "null";
        String db_aggregate_account_number = "null";
        String db_aggregate_policy_number = "null";
        String db_aggregate_transaction_date = "null";
        String db_aggregate_transaction_sub_type = "null";
        String db_aggregate_transaction_reason = "null";
        String db_aggregate_payment_method = "null";
        String db_aggregate_sun_number = "null";
        String db_aggregate_mid_number = "null";
        String db_aggregate_ddi_reference = "null";
        String db_aggregate_pay_in_slip_number = "null";
        String db_aggregate_cheque_number = "null";
        String db_aggregate_card_type = "null";
        String db_aggregate_bacs_narrative = "null";
        String db_aggregate_card_narrative = "null";
        String db_aggregate_channel = "null";
        String db_aggregate_currency_code = "null";
        String db_aggregate_exchange_rate = "null";
        // db_exchange_rate_type = "null";
        String db_aggregate_base_currency_amount = "null";
        String db_aggregate_base_intrest_amount = "null";
        String db_aggregate_tax_deductible = "null";
        String db_aggregate_order_number = "null";
        String db_aggregate_payment_transaction_type_id = "null";
        String db_aggregate_currency_amount = "null";
        String db_aggregate_credit_ind = "null";


        String Total_time = "null";
        long start_so_cons_time = 0;
        long end_so_cons_time = 0;
        long cons_stg_start_time = 0;
        long cons_stg_end_time = 0;

        long cons_end_time = 0;
        long cons_start_time = 0;
        long timesecond_start = 0;
        long timesecond_end = 0;
        long end_time = 0;


        // --------- fetch the source files -------------
        List<String> filename_list = new ArrayList<String>();
        String path = "C:\\Test\\Phase 2\\Billing\\";
        File[] files = new File(path).listFiles();

        for (File file : files) {
            if (file.isFile()) {
                filename_list.add(file.getName());
            }

        }


        //------------ Split the file names form the list --------------
        for(int file_count = 0; file_count < filename_list.size(); file_count++){
            String no_file = filename_list.get(file_count);
            String[] file_list = no_file.split(",");

            final long start_time = System.nanoTime();


            for(int file_name = 0; file_name < file_list.length; file_name++){
                String xml_file_name = file_list[file_name];
                String inputFile = path+ xml_file_name;

                System.out.println("file name ---" +xml_file_name);


                //Calendar calendar = Calendar.getInstance();
                //Date start_time = calendar.getTime();

                //--------- decleration  of list ------------------
                List<String> final_list_results = new ArrayList<String>();
                List<String> direct_map_list_results = new ArrayList<String>();
                List<String> lookup_list_results = new ArrayList<String>();
                List<String> section3_list_results = new ArrayList<String>();
                List<String> section4_list_results = new ArrayList<String>();




                //-------- Connect to Database --------------
                try {
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                } catch (ClassNotFoundException e) {
                    e.printStackTrace();
                }
                Connection connection = null;
                try {
                    connection = DriverManager.getConnection(
                            "jdbc:oracle:thin:@dcn2ddbx007z.gwd.grpinf.net:1521/FSHTSIT1", "FSH_ORA_DATA", "FSH_SIT1_DATA");
                } catch (SQLException e) {
                    e.printStackTrace();
                }

                // -------------------- Create a statement for sending SQL Query to DB. -----------------
                try {
                    SQLstmt = connection.createStatement();
                } catch (SQLException e) {
                    e.printStackTrace();
                }



                //------------------- XML file reading -----------------------
                DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
                DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
                Document doc = dBuilder.parse(inputFile);
                doc.getDocumentElement().normalize();

                NodeList nList = doc.getElementsByTagName("n1:dlg_bc_header");

                //---- Initialiing row count variables -----
                int direct_map_row = 1;
                int lookup_map_row = 1;
                int TO_table_map_row = 1;


                for (int j = 0; j < nList.getLength(); j++) {
                    Node nNode = nList.item(j);
                    System.out.println("\nCurrent Element :" + nNode.getNodeName());

                    start_so_cons_time = System.nanoTime();

                    if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                        Element eElement = (Element) nNode;
                        xmlbc_header_id = eElement
                                .getElementsByTagName("n1:bc_header_id")
                                .item(0)
                                .getTextContent();
                        System.out.println("xml bc header id: ---" + xmlbc_header_id);

                        //---------- get the Header primary key from the DB ------------------
                        //SQLResultset = SQLstmt.executeQuery("SELECT *  from DLG_FSH_CONS_BC_COMM WHERE REGEXP_SUBSTR(FILE_NAME,'[^/]+',1) = '"+ xml_file_name+"' and BC_HEADER_ID = '"+xmlbc_header_id+ "' ");
                        SQLResultset = SQLstmt.executeQuery("SELECT *  from DLG_FSH_CONS_BC_COMM WHERE FILE_NAME = '" + xml_file_name + "' and BC_HEADER_ID = '" + xmlbc_header_id + "' ");
                        while (SQLResultset.next()) {
                            db_bc_header_id = SQLResultset.getString("BC_HEADER_ID");
                            db_source = SQLResultset.getString("SOURCE");
                            db_account_number = SQLResultset.getString("ACCOUNT_NUMBER");
                            db_policy_number = SQLResultset.getString("POLICY_NUMBER");
                            db_underwriter = SQLResultset.getString("UNDERWRITER");
                            db_brand = SQLResultset.getString("BRAND");
                            db_product_Type = SQLResultset.getString("PRODUCT_TYPE");
                            db_line_of_business = SQLResultset.getString("LINE_OF_BUSINESS");
                            db_transaction_reference = SQLResultset.getString("TRANSACTION_REFERENCE");
                            db_transaction_date = SQLResultset.getString("TRANSACTION_DATE");
                            db_transaction_sub_type = SQLResultset.getString("TRANSACTION_SUBTYPE");
                            db_transaction_reason = SQLResultset.getString("TRANSACTION_REASON");
                            db_payment_method = SQLResultset.getString("PAYMENT_METHOD");
                            db_sun_number = SQLResultset.getString("SUN_NUMBER");
                            db_mid_number = SQLResultset.getString("MID_NUMBER");
                            db_ddi_reference = SQLResultset.getString("DDI_REFERENCE");
                            db_pay_in_slip_number = SQLResultset.getString("PAY_IN_SLIP_NUMBER");
                            db_cheque_number = SQLResultset.getString("CHEQUE_NUMBER");
                            db_card_type = SQLResultset.getString("CARD_TYPE");
                            db_bacs_narrative = SQLResultset.getString("BACS_NARRATIVE");
                            db_card_narrative = SQLResultset.getString("CARD_NARRATIVE");
                            db_channel = SQLResultset.getString("CHANNEL");
                            db_reversal_indicator = SQLResultset.getString("REVERSAL_INDICATOR");
                            db_currency_code = SQLResultset.getString("CURRENCY_CODE");
                            db_exchange_rate = SQLResultset.getString("EXCHANGE_RATE");
                            // db_exchange_rate_type = SQLResultset.getString("EXCHANGE_RATE_TYPE");
                            db_base_currency_amount = SQLResultset.getString("BASE_CURRENCY_AMOUNT");
                            db_base_intrest_amount = SQLResultset.getString("BASE_INTEREST_AMOUNT");
                            db_tax_deductible = SQLResultset.getString("TAX_DEDUCTIBLE");
                            db_order_number = SQLResultset.getString("ORDER_NUMBER");
                            db_payment_transaction_type_id = SQLResultset.getString("PAYMENT_TRANSACTION_TYPE_ID");
                            db_currency_amount = SQLResultset.getString("CURRENCY_AMOUNT");
                            db_credit_ind = SQLResultset.getString("CREDIT_IND");

                            System.out.println("db header ----" + db_bc_header_id);


                            //------------ validate bc header id ------
                            if (db_bc_header_id.equals(xmlbc_header_id)) {
                                String header_id = direct_map_row + ",BC_HEADER_ID," + db_bc_header_id + "," + xmlbc_header_id + ",Pass";
                                direct_map_list_results.add(header_id);
                                direct_map_row++;
                            } else {
                                String header_id = direct_map_row + ",BC_HEADER_ID," + db_bc_header_id + "," + xmlbc_header_id + ",Fail";
                                direct_map_list_results.add(header_id);
                                direct_map_row++;
                            }

                            //------------ validate source -----------------------
                            String xmlSource = eElement
                                    .getElementsByTagName("n1:source")
                                    .item(0)
                                    .getTextContent();
                            System.out.println("xml source ---- ----" + xmlSource);

                            if (db_source.equals(xmlSource)) {
                                String source = ",SOURCE," + db_source + "," + xmlSource + ",Pass";
                                direct_map_list_results.add(source);
                            } else {
                                String source = ",SOURCE," + db_source + "," + xmlSource + ",Fail";
                                direct_map_list_results.add(source);
                            }

                            //------------ validate ACCOUNT_NUMBER ----------------------------
                            String xml_account_number = eElement
                                    .getElementsByTagName("n1:account_number")
                                    .item(0)
                                    .getTextContent();
                            System.out.println("xml account_number ---- ----" + xml_account_number);

                            if (db_account_number.equals(xml_account_number)) {
                                String account_number = ",ACCOUNT_NUMBER," + db_account_number + "," + xml_account_number + ",Pass";
                                direct_map_list_results.add(account_number);
                            } else {
                                String account_number = ",ACCOUNT_NUMBER," + db_account_number + "," + xml_account_number + ",Fail";
                                direct_map_list_results.add(account_number);
                            }

                            //------------ validate POLICY_NUMBER ----------------------------
                            String xml_policy_number = eElement
                                    .getElementsByTagName("n1:policy_number")
                                    .item(0)
                                    .getTextContent();

                            if (db_policy_number.equals(xml_policy_number)) {
                                String policy_number = ",POLICY_NUMBER," + db_policy_number + "," + xml_policy_number + ",Pass";
                                direct_map_list_results.add(policy_number);
                            } else {
                                String policy_number = ",POLICY_NUMBER," + db_policy_number + "," + xml_policy_number + ",Fail";
                                direct_map_list_results.add(policy_number);
                            }


                            //------------ validate UNDERWRITER ----------------------------
                            String xml_underwriter = eElement
                                    .getElementsByTagName("n1:underwriter")
                                    .item(0)
                                    .getTextContent();

                            if (db_underwriter.equals(xml_underwriter)) {
                                String underwriter = ",UNDERWRITER," + db_underwriter + "," + xml_underwriter + ",Pass";
                                direct_map_list_results.add(underwriter);
                            } else {
                                String underwriter = ",UNDERWRITER," + db_underwriter + "," + xml_underwriter + ",Fail";
                                direct_map_list_results.add(underwriter);
                            }

                            //------------ validate BRAND ----------------------------
                            String xml_brand = eElement
                                    .getElementsByTagName("n1:brand")
                                    .item(0)
                                    .getTextContent();

                            if (db_brand.equals(xml_brand)) {
                                String brand = ",BRAND," + db_brand + "," + xml_brand + ",Pass";
                                direct_map_list_results.add(brand);
                            } else {
                                String brand = ",BRAND," + db_brand + "," + xml_brand + ",Fail";
                                direct_map_list_results.add(brand);
                            }

                            //------------ validate PRODUCT_TYPE ----------------------------
                            String xml_product_type = eElement
                                    .getElementsByTagName("n1:product_type")
                                    .item(0)
                                    .getTextContent();

                            if (db_product_Type.equals(xml_product_type)) {
                                String product_type = ",PRODUCT_TYPE," + db_product_Type + "," + xml_product_type + ",Pass";
                                direct_map_list_results.add(product_type);
                            } else {
                                String product_type = ",PRODUCT_TYPE," + db_product_Type + "," + xml_product_type + ",Fail";
                                direct_map_list_results.add(product_type);
                            }

                            //------------ validate LINE_OF_BUSINESS ----------------------------
                            String xml_line_of_business = eElement
                                    .getElementsByTagName("n1:line_of_business")
                                    .item(0)
                                    .getTextContent();

                            if (db_line_of_business.equals(xml_line_of_business)) {
                                String line_of_business = ",LINE_OF_BUSINESS," + db_line_of_business + "," + xml_line_of_business + ",Pass";
                                direct_map_list_results.add(line_of_business);
                            } else {
                                String line_of_business = ",LINE_OF_BUSINESS," + db_line_of_business + "," + xml_line_of_business + ",Fail";
                                direct_map_list_results.add(line_of_business);
                            }

                            //------------ Validate TRANSACTION_REFERENCE ----------------------------
                            String xml_transaction_reference = eElement
                                    .getElementsByTagName("n1:transaction_reference")
                                    .item(0)
                                    .getTextContent();

                            if (db_transaction_reference.equals(xml_transaction_reference)) {
                                String transaction_reference = ",TRANSACTION_REFERENCE," + db_transaction_reference + "," + xml_transaction_reference + ",Pass";
                                direct_map_list_results.add(transaction_reference);
                            } else {
                                String transaction_reference = ",TRANSACTION_REFERENCE," + db_transaction_reference + "," + xml_transaction_reference + ",Fail";
                                direct_map_list_results.add(transaction_reference);
                            }

                            // -------------- Validate TRANSACTION_DATE -------------------------------


                            SimpleDateFormat db_sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
                            //sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
                            xml_sdf = new SimpleDateFormat("yyyy-MM-dd");
                            sdf1 = new SimpleDateFormat("dd-MMM-yy");

                            String xml_transaction_date = eElement
                                    .getElementsByTagName("n1:transaction_date")
                                    .item(0)
                                    .getTextContent();

                            String xml_Split_date = xml_transaction_date.substring(0,10);

                            System.out.println("DB Transaction date ---" + db_transaction_date);
                            System.out.println("xml Transaction date ---" + xml_Split_date);


                            String xmltransaction_date = sdf1.format(xml_sdf.parse(xml_Split_date));


                            String dbTransaction_date = sdf1.format(db_sdf.parse(db_transaction_date));

                            System.out.println("DB Transaction modified date ---" + dbTransaction_date);
                            System.out.println("XML Transaction modified date ---" + xmltransaction_date);

                            if(dbTransaction_date.equals(xmltransaction_date)){
                                String transaction_date = ",TRANSACTION_DATE," + dbTransaction_date + "," + xmltransaction_date + ",Pass";
                                direct_map_list_results.add(transaction_date);
                            }else {
                                String transaction_date = ",TRANSACTION_DATE," + dbTransaction_date + "," + xmltransaction_date + ",Fail";
                                direct_map_list_results.add(transaction_date);
                            }

                            // -------------- Validate TRANSACTION_SUBTYPE -----------------------
                            String xml_transaction_subtype = eElement
                                    .getElementsByTagName("n1:transaction_subtype")
                                    .item(0)
                                    .getTextContent();

                            if (db_transaction_sub_type.equals(xml_transaction_subtype)) {
                                String transaction_subtype = ",TRANSACTION_SUBTYPE," + db_transaction_sub_type + "," + xml_transaction_subtype + ",Pass";
                                direct_map_list_results.add(transaction_subtype);
                            } else {
                                String transaction_subtype = ",TRANSACTION_SUBTYPE," + db_transaction_sub_type + "," + xml_transaction_subtype + ",Fail";
                                direct_map_list_results.add(transaction_subtype);
                            }

                            // -------------- Validate TRANSACTION_REASON ----------------------------
                            String xml_transaction_reason = eElement
                                    .getElementsByTagName("n1:transaction_reason")
                                    .item(0)
                                    .getTextContent();

                            if (db_transaction_reason.equals(xml_transaction_reason)) {
                                String transaction_reason = ",TRANSACTION_REASON," + db_transaction_reason + "," + xml_transaction_reason + ",Pass";
                                direct_map_list_results.add(transaction_reason);
                            } else {
                                String transaction_reason = ",TRANSACTION_REASON," + db_transaction_reason + "," + xml_transaction_reason + ",Fail";
                                direct_map_list_results.add(transaction_reason);
                            }

                            //----------- Validate payment Method --------------------------------
                            xml_payment_method = eElement
                                    .getElementsByTagName("n1:payment_method")
                                    .item(0)
                                    .getTextContent();

                            if (xml_payment_method.equals("BACS")) {
                                String xml_sun_number = eElement
                                        .getElementsByTagName("n1:sun_number")
                                        .item(0)
                                        .getTextContent();

                                if (db_sun_number.equals(xml_sun_number)) {
                                    String sun_number = ",SUN_NUMBER," + db_sun_number + "," + xml_sun_number + ",Pass";
                                    direct_map_list_results.add(sun_number);
                                } else {
                                    String sun_number = ",SUN_NUMBER," + db_sun_number + "," + xml_sun_number + ",Fail";
                                    direct_map_list_results.add(sun_number);
                                }
                            } else if (xml_payment_method.equals("Card")) {
                                String xml_mid_number = eElement
                                        .getElementsByTagName("n1:mid_number")
                                        .item(0)
                                        .getTextContent();
                                if (db_mid_number.equals(xml_mid_number)) {
                                    String mid_number = ",MID_NUMBER," + db_mid_number + "," + xml_mid_number + ",Pass";
                                    direct_map_list_results.add(mid_number);
                                } else {
                                    String mid_number = ",MID_NUMBER," + db_mid_number + "," + xml_mid_number + ",Fail";
                                    direct_map_list_results.add(mid_number);
                                }

                            } else if (xml_payment_method.equals("Cheque")) {
                                String xml_cheque_number = eElement
                                        .getElementsByTagName("n1:cheque_number")
                                        .item(0)
                                        .getTextContent();
                                if (db_cheque_number.equals(xml_cheque_number)) {
                                    String slip_number = ",PAY_IN_SLIP_NUMBER," + db_cheque_number + "," + xml_cheque_number + ",Pass";
                                    direct_map_list_results.add(slip_number);
                                } else {
                                    String slip_number = ",PAY_IN_SLIP_NUMBER," + db_cheque_number + "," + xml_cheque_number + ",Fail";
                                    direct_map_list_results.add(slip_number);
                                }
                            }

                            //--------------- Validate DDI_REFERENCE ---------------------
                            if (xml_payment_method.equals("BACS")) {
                                int ddi_reference_length = eElement
                                        .getElementsByTagName("n1:ddi_reference").getLength();
                                if (ddi_reference_length > 0) {
                                    String xml_ddi_reference = eElement
                                            .getElementsByTagName("n1:ddi_reference")
                                            .item(0)
                                            .getTextContent();

                                    if (db_ddi_reference.equals(xml_ddi_reference) || db_ddi_reference == xml_ddi_reference) {
                                        String ddi_reference = ",DDI_REFERENCE," + db_ddi_reference + "," + xml_ddi_reference + ",Pass";
                                        direct_map_list_results.add(ddi_reference);
                                    } else {
                                        String ddi_reference = ",DDI_REFERENCE," + db_ddi_reference + "," + xml_ddi_reference + ",Fail";
                                        direct_map_list_results.add(ddi_reference);
                                    }
                                } else {
                                    String ddi_reference = ",DDI_REFERENCE," + db_ddi_reference + "," + "ddi_reference  tag is not valiable" + ",Fail";
                                    direct_map_list_results.add(ddi_reference);
                                }

                            }

                            //--------------- Validate CARD_TYPE ------------------------
                            if (xml_payment_method.equals("Card")) {
                                String xml_card_type = eElement
                                        .getElementsByTagName("n1:card_type")
                                        .item(0)
                                        .getTextContent();

                                if (db_card_type.equals(xml_card_type)) {
                                    String card_type = ",CARD_TYPE," + db_card_type + "," + xml_card_type + ",Pass";
                                    direct_map_list_results.add(card_type);
                                } else {
                                    String card_type = ",CARD_TYPE," + db_card_type + "," + xml_card_type + ",Fail";
                                    direct_map_list_results.add(card_type);
                                }
                            }

                            //-------------- validate BACS_NARRATIVE ---------------------
                            if (xml_payment_method.equals("BACS")) {
                                int narrative_length = eElement
                                        .getElementsByTagName("n1:bacs_narrative").getLength();
                                if (narrative_length > 0) {
                                    String xml_bacs_narrative = eElement
                                            .getElementsByTagName("n1:bacs_narrative")
                                            .item(0)
                                            .getTextContent();

                                    if (db_bacs_narrative.equals(xml_bacs_narrative) || db_bacs_narrative == xml_bacs_narrative) {
                                        String bacs_narrative = ",BACS_NARRATIVE," + db_bacs_narrative + "," + xml_bacs_narrative + ",Pass";
                                        direct_map_list_results.add(bacs_narrative);
                                    } else {
                                        String bacs_narrative = ",BACS_NARRATIVE," + db_bacs_narrative + "," + xml_bacs_narrative + ",Fail";
                                        direct_map_list_results.add(bacs_narrative);
                                    }
                                } else {
                                    String bacs_narrative = ",BACS_NARRATIVE," + db_bacs_narrative + "," + "bacs_narrative  tag is not valiable" + ",Fail";
                                    direct_map_list_results.add(bacs_narrative);
                                }

                            }

                            //---------------- Validate CARD_NARRATIVE ----------------------------
                            if (xml_payment_method.equals("Card")) {
                                String xml_card_narrative = eElement
                                        .getElementsByTagName("n1:card_narrative")
                                        .item(0)
                                        .getTextContent();

                                if (db_card_narrative.equals(xml_card_narrative)) {
                                    String card_narrative = ",CARD_NARRATIVE," + db_card_narrative + "," + xml_card_narrative + ",Pass";
                                    direct_map_list_results.add(card_narrative);
                                } else {
                                    String card_narrative = ",CARD_NARRATIVE," + db_card_narrative + "," + xml_card_narrative + ",Fail";
                                    direct_map_list_results.add(card_narrative);
                                }
                            }

                            //--------------------- Validate CHEQUE_NUMBER --------
                            //------- Validate whether tag is available or not ----
                            if (xml_payment_method.equals("Cheque")) {
                                int tag_length = eElement
                                        .getElementsByTagName("n1:cheque_number").getLength();
                                if (tag_length > 0) {
                                    String xml_cheque_number = eElement
                                            .getElementsByTagName("n1:cheque_number")
                                            .item(0)
                                            .getTextContent();

                                    if (db_cheque_number.equals(xml_cheque_number)) {
                                        String cheque_number = ",CHEQUE_NUMBER," + db_cheque_number + "," + xml_cheque_number + ",Pass";
                                        direct_map_list_results.add(cheque_number);
                                    } else {
                                        String cheque_number = ",CHEQUE_NUMBER," + db_cheque_number + "," + xml_cheque_number + ",Fail";
                                        direct_map_list_results.add(cheque_number);
                                    }
                                } else {
                                    String cheque_number = ",CHEQUE_NUMBER," + db_cheque_number + "," + "CHEQUE_NUMBER tag not available" + ",Fail";
                                    direct_map_list_results.add(cheque_number);
                                }
                            }

                            // -------------- Validate CHANNEL ----------------------
                            String xml_channel = eElement
                                    .getElementsByTagName("n1:channel")
                                    .item(0)
                                    .getTextContent();

                            if (db_channel.equals(xml_channel)) {
                                String channel = ",CHANNEL," + db_channel + "," + xml_channel + ",Pass";
                                direct_map_list_results.add(channel);
                            } else {
                                String channel = ",CHANNEL," + db_channel + "," + xml_channel + ",Fail";
                                direct_map_list_results.add(channel);
                            }

                            // -------------- Validate REVERSAL_INDICATOR ----------------------
                            String xml_reversal_indicator = eElement
                                    .getElementsByTagName("n1:reversal_indicator")
                                    .item(0)
                                    .getTextContent();

                            if (db_reversal_indicator.equals(xml_reversal_indicator)) {
                                String reversal_indicator = ",REVERSAL_INDICATOR," + db_reversal_indicator + "," + xml_reversal_indicator + ",Pass";
                                direct_map_list_results.add(reversal_indicator);
                            } else {
                                String reversal_indicator = ",REVERSAL_INDICATOR," + db_reversal_indicator + "," + xml_reversal_indicator + ",Fail";
                                direct_map_list_results.add(reversal_indicator);
                            }

                            // -------------- Validate EXCHANGE_RATE ----------------------
                            String xml_exchange_rate = eElement
                                    .getElementsByTagName("n1:exchange_rate")
                                    .item(0)
                                    .getTextContent();

                            double xml_double_exchange_rate = Double.parseDouble(xml_exchange_rate); // change to double
                            double db_double_exchange_rate = Double.parseDouble(db_exchange_rate); // change to double

                            if (db_double_exchange_rate == xml_double_exchange_rate) {
                                String exchange_rate = ",EXCHANGE_RATE," + db_double_exchange_rate + "," + xml_double_exchange_rate + ",Pass";
                                direct_map_list_results.add(exchange_rate);
                            } else {
                                String exchange_rate = ",EXCHANGE_RATE," + db_double_exchange_rate + "," + xml_double_exchange_rate + ",Fail";
                                direct_map_list_results.add(exchange_rate);
                            }

                           /* // -------------- Validate EXCHANGE_RATE_TYPE --------
                            String xml_exchange_rate_type = eElement
                                    .getElementsByTagName("n1:exchange_rate_type")
                                    .item(0)
                                    .getTextContent();

                            if(db_exchange_rate_type.equals(xml_exchange_rate_type)){
                                String exchange_rate_type = ",EXCHANGE_RATE_TYPE," + db_exchange_rate_type + "," + xml_exchange_rate_type + ",Pass";
                                direct_map_list_results.add(exchange_rate_type);
                            }else {
                                String exchange_rate_type = ",EXCHANGE_RATE_TYPE," + db_exchange_rate_type + "," + xml_exchange_rate_type + ",Fail";
                                direct_map_list_results.add(exchange_rate_type);
                            }*/

                            // -------------- Validate BASE_CURRENCY_AMOUNT ----------------------
                            String xml_base_currency_amount = eElement
                                    .getElementsByTagName("n1:base_currency_amount")
                                    .item(0)
                                    .getTextContent();

                            if (db_base_currency_amount.equals(xml_base_currency_amount)) {
                                String base_currency_amount = ",BASE_CURRENCY_AMOUNT," + db_base_currency_amount + "," + xml_base_currency_amount + ",Pass";
                                direct_map_list_results.add(base_currency_amount);
                            } else {
                                String base_currency_amount = ",BASE_CURRENCY_AMOUNT," + db_base_currency_amount + "," + xml_base_currency_amount + ",Fail";
                                direct_map_list_results.add(base_currency_amount);
                            }

                            // -------------- Validate BASE_INTEREST_AMOUNT ----------------------
                            String xml_base_interest_amount = eElement
                                    .getElementsByTagName("n1:base_interest_amount")
                                    .item(0)
                                    .getTextContent();

                            if (db_base_intrest_amount.equals(xml_base_interest_amount)) {
                                String base_interest_amount = ",BASE_INTEREST_AMOUNT," + db_base_intrest_amount + "," + xml_base_interest_amount + ",Pass";
                                direct_map_list_results.add(base_interest_amount);
                            } else {
                                String base_interest_amount = ",BASE_INTEREST_AMOUNT," + db_base_intrest_amount + "," + xml_base_interest_amount + ",Fail";
                                direct_map_list_results.add(base_interest_amount);
                            }

                            // -------------- Validate TAX_DEDUCTIBLE ----------------------
                            String xml_tax_deductible = eElement
                                    .getElementsByTagName("n1:tax_deductible")
                                    .item(0)
                                    .getTextContent();

                            if (db_tax_deductible.equals(xml_tax_deductible)) {
                                String tax_deductible = ",TAX_DEDUCTIBLE," + db_tax_deductible + "," + xml_tax_deductible + ",Pass";
                                direct_map_list_results.add(tax_deductible);
                            } else {
                                String tax_deductible = ",TAX_DEDUCTIBLE," + db_tax_deductible + "," + xml_tax_deductible + ",Fail";
                                direct_map_list_results.add(tax_deductible);
                            }

                            // -------------- Validate ORDER_NUMBER ----------------------
                            if (xml_payment_method.equals("Card")) {
                                String xml_order_number = eElement
                                        .getElementsByTagName("n1:order_number")
                                        .item(0)
                                        .getTextContent();

                                if (db_order_number.equals(xml_order_number)) {
                                    String order_number = ",ORDER_NUMBER," + db_order_number + "," + xml_order_number + ",Pass";
                                    direct_map_list_results.add(order_number);
                                } else {
                                    String order_number = ",ORDER_NUMBER," + db_order_number + "," + xml_order_number + ",Fail";
                                    direct_map_list_results.add(order_number);
                                }
                            }

                            // -------------- Validate PAYMENT_TRANSACTION_TYPE_ID --------
                            String xml_payment_transaction_type_id = eElement
                                    .getElementsByTagName("n1:payment_transaction_type_id")
                                    .item(0)
                                    .getTextContent();

                            if (db_payment_transaction_type_id.equals(xml_payment_transaction_type_id)) {
                                String payment_transaction_type_id = ",PAYMENT_TRANSACTION_TYPE_ID," + db_payment_transaction_type_id + "," + xml_payment_transaction_type_id + ",Pass";
                                direct_map_list_results.add(payment_transaction_type_id);
                            } else {
                                String payment_transaction_type_id = ",PAYMENT_TRANSACTION_TYPE_ID," + db_payment_transaction_type_id + "," + xml_payment_transaction_type_id + ",Fail";
                                direct_map_list_results.add(payment_transaction_type_id);
                            }

                            // -------------- Validate CURRENCY_AMOUNT ----------------------
                            String xml_currency_amount = eElement
                                    .getElementsByTagName("n1:currency_amount")
                                    .item(0)
                                    .getTextContent();

                            if (db_currency_amount.equals(xml_currency_amount)) {
                                String currency_amount = ",CURRENCY_AMOUNT," + db_currency_amount + "," + xml_currency_amount + ",Pass";
                                direct_map_list_results.add(currency_amount);
                            } else {
                                String currency_amount = ",CURRENCY_AMOUNT," + db_currency_amount + "," + xml_currency_amount + ",Fail";
                                direct_map_list_results.add(currency_amount);
                            }

                            // -------------- Validate CREDIT_IND ----------------------
                            String xml_credit_ind = eElement
                                    .getElementsByTagName("n1:credit_ind")
                                    .item(0)
                                    .getTextContent();

                            if (db_credit_ind.equals(xml_credit_ind)) {
                                String credit_ind = ",CREDIT_IND," + db_credit_ind + "," + xml_credit_ind + ",Pass";
                                direct_map_list_results.add(credit_ind);
                            } else {
                                String credit_ind = ",CREDIT_IND," + db_credit_ind + "," + xml_credit_ind + ",Fail";
                                direct_map_list_results.add(credit_ind);
                            }

                        }
                        end_so_cons_time = System.nanoTime();
                        end_so_cons_time = end_so_cons_time + end_so_cons_time;

                    }


                    //--------------------- CONS TO STAGING VALIDATION START HERE ---------------
                    //---------- get the Header primary key from the DB ------------------

                    cons_stg_start_time = System.nanoTime();
                    cons_start_time = System.currentTimeMillis();
                    timesecond_start = TimeUnit.MILLISECONDS.toSeconds(cons_start_time);

                    SQLResultset = SQLstmt.executeQuery("SELECT *  from DLG_FSH_STG_BC_COMM WHERE REGEXP_SUBSTR(FILE_NAME,'[^/]+',1) = '" + xml_file_name + "' and BC_HEADER_ID = '" + xmlbc_header_id + "'");
                    while (SQLResultset.next()) {
                        db_stg_bc_header_id = SQLResultset.getString("BC_HEADER_ID");
                        db_stg_source = SQLResultset.getString("SOURCE");
                        db_stg_brand = SQLResultset.getString("BRAND");
                        db_stg_account_number = SQLResultset.getString("ACCOUNT_NUMBER");
                        db_stg_policy_number = SQLResultset.getString("POLICY_NUMBER");
                        db_stg_transaction_date = SQLResultset.getString("TRANSACTION_DATE");
                        db_stg_transaction_sub_type = SQLResultset.getString("TRANSACTION_SUB_TYPE");
                        db_stg_transaction_reason = SQLResultset.getString("TRANSACTION_REASON");
                        db_stg_payment_method = SQLResultset.getString("PAYMENT_METHOD");
                        db_stg_sun_number = SQLResultset.getString("SUN_NUMBER");
                        db_stg_mid_number = SQLResultset.getString("MID_NUMBER");
                        db_stg_ddi_reference = SQLResultset.getString("DDI_REFERENCE");
                        db_stg_pay_in_slip_number = SQLResultset.getString("PAY_IN_SLIP_NUMBER");
                        db_stg_cheque_number = SQLResultset.getString("CHEQUE_NUMBER");
                        db_stg_card_type = SQLResultset.getString("CARD_TYPE");
                        db_stg_bacs_narrative = SQLResultset.getString("BACS_NARRATIVE");
                        db_stg_card_narrative = SQLResultset.getString("CARD_NARRATIVE");
                        db_stg_channel = SQLResultset.getString("CHANNEL");
                        db_stg_reversal_indicator = SQLResultset.getString("REVERSAL_INDICATOR");
                        db_stg_currency_code = SQLResultset.getString("CURRENCY_CD");
                        db_stg_exchange_rate = SQLResultset.getString("EXCHANGE_RATE");
                        // db_exchange_rate_type = SQLResultset.getString("EXCHANGE_RATE_TYPE");
                        db_stg_base_currency_amount = SQLResultset.getString("BASE_CURRENCY_AMOUNT");
                        db_stg_base_intrest_amount = SQLResultset.getString("BASE_INTEREST_AMOUNT");
                        db_stg_tax_deductible = SQLResultset.getString("TAX_DEDUCTIBLE");
                        db_stg_order_number = SQLResultset.getString("ORDER_NUMBER");
                        db_stg_payment_transaction_type_id = SQLResultset.getString("PAYMENT_TRANSACTION_TYPE_ID");
                        db_stg_currency_amount = SQLResultset.getString("CURRENCY_AMOUNT");
                        db_stg_credit_ind = SQLResultset.getString("CREDIT_IND");
                        db_stg_underwriter = SQLResultset.getString("UNDERWRITER");

                        //-------------- Validate BC_HEADER_ID -------------
                        if (db_stg_bc_header_id.equals(db_bc_header_id)) {
                            String stg_header_id = lookup_map_row + ",BC_HEADER_ID," + db_stg_bc_header_id + "," + db_bc_header_id + ",Pass";
                            lookup_list_results.add(stg_header_id);
                            lookup_map_row++;
                        } else {
                            String stg_header_id = lookup_map_row + ",BC_HEADER_ID," + db_stg_bc_header_id + "," + db_bc_header_id + ",Fail";
                            lookup_list_results.add(stg_header_id);
                            lookup_map_row++;
                        }

                        //-------------- Validate SOURCE ---------------------------
                        if (db_stg_source.equals(db_source)) {
                            String stg_source = ",SOURCE," + db_stg_source + "," + db_source + ",Pass";
                            lookup_list_results.add(stg_source);
                        } else {
                            String stg_source = ",SOURCE," + db_stg_source + "," + db_source + ",Fail";
                            lookup_list_results.add(stg_source);
                        }

                        //-------------- Validate ACCOUNT_NUMBER ---------------------------
                        if (db_stg_account_number.equals(db_account_number)) {
                            String stg_account_number = ",ACCOUNT_NUMBER," + db_stg_account_number + "," + db_account_number + ",Pass";
                            lookup_list_results.add(stg_account_number);
                        } else {
                            String stg_account_number = ",ACCOUNT_NUMBER," + db_stg_account_number + "," + db_account_number + ",Fail";
                            lookup_list_results.add(stg_account_number);
                        }

                        //-------------- Validate POLICY_NUMBER ---------------------------
                        if (db_stg_policy_number.equals(db_policy_number)) {
                            String stg_policy_number = ",POLICY_NUMBER," + db_stg_policy_number + "," + db_policy_number + ",Pass";
                            lookup_list_results.add(stg_policy_number);
                        } else {
                            String stg_policy_number = ",POLICY_NUMBER," + db_stg_policy_number + "," + db_policy_number + ",Fail";
                            lookup_list_results.add(stg_policy_number);
                        }

                        //-------------- Validate TRANSACTION_DATE ---------------------------
                        if (db_stg_transaction_date.equals(db_transaction_date)) {
                            String stg_transaction_date = ",TRANSACTION_DATE," + db_stg_transaction_date + "," + db_transaction_date + ",Pass";
                            lookup_list_results.add(stg_transaction_date);
                        } else {
                            String stg_transaction_date = ",TRANSACTION_DATE," + db_stg_transaction_date + "," + db_transaction_date + ",Fail";
                            lookup_list_results.add(stg_transaction_date);
                        }

                        //-------------- Validate TRANSACTION_SUB_TYPE ---------------------------
                        if (db_stg_transaction_sub_type.equals(db_transaction_sub_type)) {
                            String stg_transaction_sub_type = ",TRANSACTION_SUB_TYPE," + db_stg_transaction_sub_type + "," + db_transaction_sub_type + ",Pass";
                            lookup_list_results.add(stg_transaction_sub_type);
                        } else {
                            String stg_transaction_sub_type = ",TRANSACTION_SUB_TYPE," + db_stg_transaction_sub_type + "," + db_transaction_sub_type + ",Fail";
                            lookup_list_results.add(stg_transaction_sub_type);
                        }

                        //-------------- Validate TRANSACTION_REASON ---------------------------
                        if (db_stg_transaction_reason.equals(db_transaction_reason)) {
                            String stg_transaction_reason = ",TRANSACTION_REASON," + db_stg_transaction_reason + "," + db_transaction_reason + ",Pass";
                            lookup_list_results.add(stg_transaction_reason);
                        } else {
                            String stg_transaction_reason = ",TRANSACTION_REASON," + db_stg_transaction_reason + "," + db_transaction_reason + ",Fail";
                            lookup_list_results.add(stg_transaction_reason);
                        }

                        //-------------- Validate SUN_NUMBER ---------------------------
                        if (xml_payment_method.equals("BACS")) {
                            if (db_stg_sun_number.equals(db_sun_number)) {
                                String stg_sun_number = ",SUN_NUMBER," + db_stg_sun_number + "," + db_sun_number + ",Pass";
                                lookup_list_results.add(stg_sun_number);
                            } else {
                                String stg_sun_number = ",SUN_NUMBER," + db_stg_sun_number + "," + db_sun_number + ",Fail";
                                lookup_list_results.add(stg_sun_number);
                            }
                        }

                        //-------------- Validate MID_NUMBER ---------------------------
                        if (xml_payment_method.equals("Card")) {
                            if (db_stg_mid_number.equals(db_mid_number)) {
                                String stg_mid_number = ",MID_NUMBER," + db_stg_mid_number + "," + db_mid_number + ",Pass";
                                lookup_list_results.add(stg_mid_number);
                            } else {
                                String stg_mid_number = ",MID_NUMBER," + db_stg_mid_number + "," + db_mid_number + ",Fail";
                                lookup_list_results.add(stg_mid_number);
                            }
                        }

                        //-------------- Validate DDI_REFERENCE ---------------------------
                        if (xml_payment_method.equals("BACS")) {
                            if (db_stg_ddi_reference == db_ddi_reference || db_stg_ddi_reference.equals(db_ddi_reference)) {
                                String stg_ddi_reference = ",DDI_REFERENCE," + db_stg_ddi_reference + "," + db_ddi_reference + ",Pass";
                                lookup_list_results.add(stg_ddi_reference);
                            } else {
                                String stg_ddi_reference = ",DDI_REFERENCE," + db_stg_ddi_reference + "," + db_ddi_reference + ",Fail";
                                lookup_list_results.add(stg_ddi_reference);
                            }
                        }

                        //-------------- Validate PAY_IN_SLIP_NUMBER -------------
                        if (xml_payment_method.equals("Cheque")) {
                            if (db_stg_pay_in_slip_number == db_pay_in_slip_number) {
                                String stg_pay_in_slip_number = ",PAY_IN_SLIP_NUMBER," + db_stg_pay_in_slip_number + "," + db_pay_in_slip_number + ",Pass";
                                lookup_list_results.add(stg_pay_in_slip_number);
                            } else {
                                String stg_pay_in_slip_number = ",PAY_IN_SLIP_NUMBER," + db_stg_pay_in_slip_number + "," + db_pay_in_slip_number + ",Fail";
                                lookup_list_results.add(stg_pay_in_slip_number);
                            }
                        }

                        //-------------- Validate CHEQUE_NUMBER -------------
                        if (xml_payment_method.equals("Cheque")) {
                            if (db_stg_cheque_number.equals(db_cheque_number)) {
                                String stg_cheque_number = ",CHEQUE_NUMBER," + db_stg_cheque_number + "," + db_cheque_number + ",Pass";
                                lookup_list_results.add(stg_cheque_number);
                            } else {
                                String stg_cheque_number = ",CHEQUE_NUMBER," + db_stg_cheque_number + "," + db_cheque_number + ",Fail";
                                lookup_list_results.add(stg_cheque_number);
                            }
                        }

                        //-------------- Validate CARD_TYPE ---------------------------
                        if (xml_payment_method.equals("Card")) {

                            if (db_stg_card_type.equals(db_card_type)) {
                                String stg_card_type = ",CARD_TYPE," + db_stg_card_type + "," + db_card_type + ",Pass";
                                lookup_list_results.add(stg_card_type);
                            } else {
                                String stg_card_type = ",CARD_TYPE," + db_stg_card_type + "," + db_card_type + ",Fail";
                                lookup_list_results.add(stg_card_type);
                            }
                        }

                        //-------------- Validate BACS_NARRATIVE ---------------------------
                        if (xml_payment_method.equals("BACS")) {
                            if (db_stg_bacs_narrative == db_bacs_narrative || db_stg_bacs_narrative.equals(db_bacs_narrative)) {
                                String stg_bacs_narrative = ",BACS_NARRATIVE," + db_stg_bacs_narrative + "," + db_bacs_narrative + ",Pass";
                                lookup_list_results.add(stg_bacs_narrative);
                            } else {
                                String stg_bacs_narrative = ",BACS_NARRATIVE," + db_stg_bacs_narrative + "," + db_bacs_narrative + ",Fail";
                                lookup_list_results.add(stg_bacs_narrative);
                            }
                        }

                        //-------------- Validate CARD_NARRATIVE ---------------------------
                        if (xml_payment_method.equals("Card")) {
                            if (db_stg_card_narrative.equals(db_card_narrative)) {
                                String stg_card_narrative = ",CARD_NARRATIVE," + db_stg_card_narrative + "," + db_card_narrative + ",Pass";
                                lookup_list_results.add(stg_card_narrative);
                            } else {
                                String stg_card_narrative = ",CARD_NARRATIVE," + db_stg_card_narrative + "," + db_card_narrative + ",Fail";
                                lookup_list_results.add(stg_card_narrative);
                            }
                        }

                        //-------------- Validate CHANNEL ---------------------------
                        if (db_stg_channel.equals(db_channel)) {
                            String stg_channel = ",CHANNEL," + db_stg_channel + "," + db_channel + ",Pass";
                            lookup_list_results.add(stg_channel);
                        } else {
                            String stg_channel = ",CHANNEL," + db_stg_channel + "," + db_channel + ",Fail";
                            lookup_list_results.add(stg_channel);
                        }

                        //--------------------- Validate REVERSAL_INDICATOR -------------------
                        if (db_stg_reversal_indicator.equals(db_reversal_indicator)) {
                            String stg_reversal_indicator = ",REVERSAL_INDICATOR," + db_stg_reversal_indicator + "," + db_reversal_indicator + ",Pass";
                            lookup_list_results.add(stg_reversal_indicator);
                        } else {
                            String stg_reversal_indicator = ",REVERSAL_INDICATOR," + db_stg_reversal_indicator + "," + db_reversal_indicator + ",Fail";
                            lookup_list_results.add(stg_reversal_indicator);
                        }

                        /*//--------------------- Validate CURRENCY_CD -------------------
                        if (db_stg_currency_code.equals(db_currency_code)) {
                            String stg_currency_code = ",CURRENCY_CD," + db_stg_currency_code + "," + db_currency_code + ",Pass";
                            lookup_list_results.add(stg_currency_code);
                        } else {
                            String stg_currency_code = ",CURRENCY_CD," + db_stg_currency_code + "," + db_currency_code + ",Fail";
                            lookup_list_results.add(stg_currency_code);
                        }*/

                        /*//--------------------- Validate EXCHANGE_RATE -------------------
                        double db_double_stg_exchange_rate = Double.parseDouble(db_stg_exchange_rate); // change to double
                        double db_double_exchange_rate = Double.parseDouble(db_exchange_rate); // change to double

                        if (db_double_stg_exchange_rate == db_double_exchange_rate) {
                            String stg_exchange_rate = ",EXCHANGE_RATE," + db_double_stg_exchange_rate + "," + db_double_exchange_rate + ",Pass";
                            lookup_list_results.add(stg_exchange_rate);
                        } else {
                            String stg_exchange_rate = ",EXCHANGE_RATE," + db_double_stg_exchange_rate + "," + db_double_exchange_rate + ",Fail";
                            lookup_list_results.add(stg_exchange_rate);
                        }*/

                        //--------------------- Validate BASE_CURRENCY_AMOUNT -------------------
                        if (db_stg_base_currency_amount.equals(db_base_currency_amount)) {
                            String stg_base_currency_amount = ",BASE_CURRENCY_AMOUNT," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Pass";
                            lookup_list_results.add(stg_base_currency_amount);
                        } else {
                            String stg_base_currency_amount = ",BASE_CURRENCY_AMOUNT," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Fail";
                            lookup_list_results.add(stg_base_currency_amount);
                        }

                        //--------------------- Validate BASE_INTEREST_AMOUNT -------------------
                        if (db_stg_base_intrest_amount.equals(db_base_intrest_amount)) {
                            String stg_base_intrest_amount = ",BASE_INTEREST_AMOUNT," + db_stg_base_intrest_amount + "," + db_base_intrest_amount + ",Pass";
                            lookup_list_results.add(stg_base_intrest_amount);
                        } else {
                            String stg_base_intrest_amount = ",BASE_INTEREST_AMOUNT," + db_stg_base_intrest_amount + "," + db_base_intrest_amount + ",Fail";
                            lookup_list_results.add(stg_base_intrest_amount);
                        }

                        //--------------------- Validate TAX_DEDUCTIBLE -------------------
                        if (db_stg_tax_deductible.equals(db_tax_deductible)) {
                            String stg_tax_deductible = ",TAX_DEDUCTIBLE," + db_stg_tax_deductible + "," + db_tax_deductible + ",Pass";
                            lookup_list_results.add(stg_tax_deductible);
                        } else {
                            String stg_tax_deductible = ",TAX_DEDUCTIBLE," + db_stg_tax_deductible + "," + db_tax_deductible + ",Fail";
                            lookup_list_results.add(stg_tax_deductible);
                        }

                        //--------------------- Validate ORDER_NUMBER -------------------
                        if (xml_payment_method.equals("Card")) {
                            if (db_stg_order_number.equals(db_order_number)) {
                                String stg_order_number = ",ORDER_NUMBER," + db_stg_order_number + "," + db_order_number + ",Pass";
                                lookup_list_results.add(stg_order_number);
                            } else {
                                String stg_order_number = ",ORDER_NUMBER," + db_stg_order_number + "," + db_order_number + ",Fail";
                                lookup_list_results.add(stg_order_number);
                            }
                        }

                        //--------------------- Validate PAYMENT_TRANSACTION_TYPE_ID ---------------
                        if (db_stg_payment_transaction_type_id.equals(db_payment_transaction_type_id)) {
                            String stg_payment_transaction_type_id = ",PAYMENT_TRANSACTION_TYPE_ID," + db_stg_payment_transaction_type_id + "," + db_payment_transaction_type_id + ",Pass";
                            lookup_list_results.add(stg_payment_transaction_type_id);
                        } else {
                            String stg_payment_transaction_type_id = ",PAYMENT_TRANSACTION_TYPE_ID," + db_stg_payment_transaction_type_id + "," + db_payment_transaction_type_id + ",Fail";
                            lookup_list_results.add(stg_payment_transaction_type_id);
                        }

                        //--------------------- Validate CURRENCY_AMOUNT ---------------
                        if (db_stg_currency_amount.equals(db_currency_amount)) {
                            String stg_currency_amount = ",CURRENCY_AMOUNT," + db_stg_currency_amount + "," + db_currency_amount + ",Pass";
                            lookup_list_results.add(stg_currency_amount);
                        } else {
                            String stg_currency_amount = ",CURRENCY_AMOUNT," + db_stg_currency_amount + "," + db_currency_amount + ",Fail";
                            lookup_list_results.add(stg_currency_amount);
                        }

                        //--------------------- Validate CREDIT_IND ---------------
                        if (db_stg_credit_ind.equals(db_credit_ind)) {
                            String stg_credit_ind = ",CREDIT_IND," + db_stg_credit_ind + "," + db_credit_ind + ",Pass";
                            lookup_list_results.add(stg_credit_ind);
                        } else {
                            String stg_credit_ind = ",CREDIT_IND," + db_stg_credit_ind + "," + db_credit_ind + ",Fail";
                            lookup_list_results.add(stg_credit_ind);
                        }


                        //========================== LookUp Validation ==========================

                        //----------------------- Brand validation -----------------
                        String db_stg_brand_meaning = "null";
                        String db_lookup_brand_meaning = "null";
                        String db_lookup_underWriter_meaning = "null";

                        SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_TYPE = '"+db_brand+"' ");
                        while (SQLResultset.next()){
                            db_lookup_brand_meaning = SQLResultset.getString("MEANING");

                        }
                        if(db_lookup_brand_meaning.equals("null")){
                            String lookup_brand_meaning = ",Brand Meaning lookup," + "LookUp value not found" + "," + db_stg_brand + ",Fail";
                            lookup_list_results.add(lookup_brand_meaning);
                        }else if(db_lookup_brand_meaning != null){
                            if(db_lookup_brand_meaning.equals(db_stg_brand)){
                                String lookup_brand_meaning = ",Brand Meaning," + db_lookup_brand_meaning + "," + db_stg_brand + ",Pass";
                                lookup_list_results.add(lookup_brand_meaning);
                            }else {
                                String lookup_brand_meaning = ",Brand Meaning lookup," + db_lookup_brand_meaning + "," + db_stg_brand + ",Fail";
                                lookup_list_results.add(lookup_brand_meaning);
                            }
                        }



                        //------------------------ UnderWriter Validation -----------------
                        SQLResultset = SQLstmt.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '"+db_underwriter+"' and LOOKUP_TYPE = 'underwriter' ");
                        while (SQLResultset.next()){
                            db_lookup_underWriter_meaning = SQLResultset.getString("MEANING");

                        }

                        if(db_lookup_underWriter_meaning.equals("null")){
                            String lookup_underWriter_meaning = ",Underwriter Meaning lookup," + "LookUp value not found" + "," + db_stg_underwriter + ",Fail";
                            lookup_list_results.add(lookup_underWriter_meaning);
                        }else if(db_lookup_underWriter_meaning != null){
                            if(db_lookup_underWriter_meaning.equals(db_stg_underwriter)){
                                String lookup_underWriter_meaning = ",Underwriter Meaning," + db_lookup_underWriter_meaning + "," + db_stg_underwriter + ",Pass";
                                lookup_list_results.add(lookup_underWriter_meaning);
                            }else {
                                String lookup_underWriter_meaning = ",Underwriter Meaning lookup," + db_lookup_underWriter_meaning + "," + db_stg_underwriter + ",Fail";
                                lookup_list_results.add(lookup_underWriter_meaning);
                            }
                        }


                       /*if(db_lookup_underWriter_meaning != null){
                            if(db_lookup_underWriter_meaning.equals(db_stg_underwriter)){
                                String lookup_underWriter_meaning = ",Underwriter Meaning," + db_lookup_underWriter_meaning + "," + db_stg_underwriter + ",Pass";
                                lookup_list_results.add(lookup_underWriter_meaning);
                            }else {
                                String lookup_underWriter_meaning = ",Underwriter Meaning lookup," + db_lookup_underWriter_meaning + "," + db_stg_underwriter + ",Fail";
                                lookup_list_results.add(lookup_underWriter_meaning);
                            }
                        }else if(db_lookup_underWriter_meaning.equals("null")) {
                           String lookup_underWriter_meaning = ",Underwriter Meaning lookup," + "LookUp value not found" + "," + db_stg_underwriter + ",Fail";
                           lookup_list_results.add(lookup_underWriter_meaning);
                       }*/


                    }
                    cons_end_time = System.currentTimeMillis();
                    cons_end_time = cons_end_time + cons_end_time;
                    timesecond_end = TimeUnit.MILLISECONDS.toSeconds(cons_end_time);
                    timesecond_end = timesecond_end + timesecond_end;

                    cons_stg_end_time = System.nanoTime();
                    cons_stg_end_time = cons_stg_end_time + cons_stg_end_time;

                    //}

                    /*//-------------- Commented for testing Section 3 ----------------------

                    //------------- Section 3 Start Here --------------------
                    if (db_stg_reversal_indicator.equals("N") && (db_stg_transaction_sub_type.equals("DirectBillMoneyeceived") || db_stg_transaction_sub_type.equals("DisbursementPaid")) && xml_payment_method.equals("BACS")) {
                        SQLResultset = SQLstmt.executeQuery("SELECT count(BC_Header_id) No_of_Rcds_before_summarization FROM DLG_FSH_STG_BC_COMM WHERE FILE_NAME = '" + xml_file_name + "'");
                        while (SQLResultset.next()) {
                            String db_No_of_Rcds_before_summarization = SQLResultset.getString("No_of_Rcds_before_summarization");
                            SQLResultset = SQLstmt.executeQuery("SELECT count(BC_Header_id) No_of_Rcds_STGAgg FROM dlg_fsh_stg_bc_comm_agg WHERE FILE_NAME = '" + xml_file_name + "'");
                            while (SQLResultset.next()) {
                                String db_No_of_Rcds_STGAgg = SQLResultset.getString("db_No_of_Rcds_STGAgg");
                                SQLResultset = SQLstmt.executeQuery("SELECT count(*) No_of_Rcds_After_summarization FROM" +
                                        "(SELECT BC_HEADER_ID,ROW_NUMBER() OVER(Partition by SOURCE,UNDERWRITER,BRAND,PRODUCT_TYPE,LINE_OF_BUSINESS,TRANSACTION_REFERENCE,TRANSACTION_DATE,TRANSACTION_SUB_TYPE,TRANSACTION_REASON,SUN_NUMBER," +
                                        "BACS_NARRATIVE,BATCH_FKEY Order BY SOURCE,UNDERWRITER,BRAND,PRODUCT_TYPE,LINE_OF_BUSINESS,TRANSACTION_REFERENCE,TRANSACTION_DATE,TRANSACTION_SUB_TYPE,TRANSACTION_REASON,SUN_NUMBER," +
                                        "BACS_NARRATIVE,BATCH_FKEY)Rowno FROM DLG_FSH_STG_BC_COMM WHERE FILE_NAME = '" + xml_file_name + "')abc Where abc.Rowno = 1");
                                while (SQLResultset.next()) {
                                    String db_No_of_Rcds_After_summarization = SQLResultset.getString("No_of_Rcds_After_summarization");
                                    if (db_No_of_Rcds_After_summarization.equals(db_No_of_Rcds_STGAgg)) {
                                        String pc_stg_header = 1 + "," + db_No_of_Rcds_before_summarization + "," + db_No_of_Rcds_After_summarization + "," + db_No_of_Rcds_STGAgg + ",Pass";
                                        section3_list_results.add(pc_stg_header);
                                    } else {
                                        String pc_stg_header = 1 + "," + db_No_of_Rcds_before_summarization + "," + db_No_of_Rcds_After_summarization + "," + db_No_of_Rcds_STGAgg + ",Fail";
                                        section3_list_results.add(pc_stg_header);
                                    }

                                }

                            }
                        }
                    } else if (db_stg_reversal_indicator.equals("N") && (db_stg_transaction_sub_type.equals("DirectbillMoneyRecvdTxn") || db_stg_transaction_sub_type.equals("DisbursementPaid")) && xml_payment_method.equals("CARD")) {
                        SQLResultset = SQLstmt.executeQuery("SELECT count(BC_Header_id) No_of_Rcds_before_summarization FROM DLG_FSH_STG_BC_COMM WHERE FILE_NAME = '" + xml_file_name + "'");
                        while (SQLResultset.next()) {
                            String db_No_of_Rcds_before_summarization = SQLResultset.getString("No_of_Rcds_before_summarization");
                            SQLResultset = SQLstmt.executeQuery("SELECT count(BC_Header_id) No_of_Rcds_STGAgg FROM dlg_fsh_stg_bc_comm_agg WHERE FILE_NAME = '" + xml_file_name + "'");
                            while (SQLResultset.next()) {
                                String db_No_of_Rcds_STGAgg = SQLResultset.getString("db_No_of_Rcds_STGAgg");
                                SQLResultset = SQLstmt.executeQuery("SELECT count(*) No_of_Rcds_After_summarization FROM" +
                                        "(SELECT BC_HEADER_ID,ROW_NUMBER() OVER(Partition by SOURCE,UNDERWRITER,BRAND,PRODUCT_TYPE,LINE_OF_BUSINESS,TRANSACTION_REFERENCE,TRANSACTION_DATE,TRANSACTION_SUB_TYPE," +
                                        "TRANSACTION_REASON,CHANNEL,MID_NUMBER,CARD_NARRATIVE,BATCH_FKEY Order BY SOURCE,UNDERWRITER,BRAND,PRODUCT_TYPE,LINE_OF_BUSINESS,TRANSACTION_REFERENCE,TRANSACTION_DATE," +
                                        "TRANSACTION_SUB_TYPE,TRANSACTION_REASON,CHANNEL,REVERSAL_INDICATOR,MID_NUMBER,CARD_NARRATIVE,BATCH_FKEY)Rowno FROM DLG_FSH_STG_BC_COMM WHERE FILE_NAME = '" + xml_file_name + "')abc Where abc.Rowno = 1");
                                while (SQLResultset.next()) {
                                    String db_No_of_Rcds_After_summarization = SQLResultset.getString("No_of_Rcds_After_summarization");
                                    if (db_No_of_Rcds_After_summarization.equals(db_No_of_Rcds_STGAgg)) {
                                        String pc_stg_header = 1 + "," + db_No_of_Rcds_before_summarization + "," + db_No_of_Rcds_After_summarization + "," + db_No_of_Rcds_STGAgg + ",Pass";
                                        section3_list_results.add(pc_stg_header);
                                    } else {
                                        String pc_stg_header = 1 + "," + db_No_of_Rcds_before_summarization + "," + db_No_of_Rcds_After_summarization + "," + db_No_of_Rcds_STGAgg + ",Fail";
                                        section3_list_results.add(pc_stg_header);
                                    }
                                }
                            }

                        }
                    } else if (db_stg_reversal_indicator.equals("N") && db_stg_transaction_sub_type.equals("DirectbillMoneyRecvdTxn") && xml_payment_method.equals("CHEQUE")) {
                        SQLResultset = SQLstmt.executeQuery("SELECT count(BC_Header_id) No_of_Rcds_before_summarization FROM DLG_FSH_STG_BC_COMM WHERE FILE_NAME = '" + xml_file_name + "'");
                        while (SQLResultset.next()) {
                            String db_No_of_Rcds_before_summarization = SQLResultset.getString("No_of_Rcds_before_summarization");
                            SQLResultset = SQLstmt.executeQuery("SELECT count(BC_Header_id) No_of_Rcds_STGAgg FROM dlg_fsh_stg_bc_comm_agg WHERE FILE_NAME = '" + xml_file_name + "'");
                            while (SQLResultset.next()) {
                                String db_No_of_Rcds_STGAgg = SQLResultset.getString("db_No_of_Rcds_STGAgg");
                                SQLResultset = SQLstmt.executeQuery("SELECT count(*) No_of_Rcds_After_summarization FROM" +
                                        "(SELECT BC_HEADER_ID,ROW_NUMBER() OVER(Partition by SOURCE,UNDERWRITER,BRAND,PRODUCT_TYPE,LINE_OF_BUSINESS,TRANSACTION_REFERENCE,TRANSACTION_DATE,TRANSACTION_SUB_TYPE," +
                                        "TRANSACTION_REASON,CHANNEL,PAY_IN_SLIP_NUMBER,CHEQUE_NUMBER,BATCH_FKEY Order BY SOURCE,UNDERWRITER,BRAND,PRODUCT_TYPE,LINE_OF_BUSINESS,TRANSACTION_REFERENCE,TRANSACTION_DATE," +
                                        "TRANSACTION_SUB_TYPE,TRANSACTION_REASON,CHANNEL,REVERSAL_INDICATOR,PAY_IN_SLIP_NUMBER,CHEQUE_NUMBER,BATCH_FKEY) Rowno FROM DLG_FSH_STG_BC_COMM WHERE FILE_NAME = '" + xml_file_name + "')abc Where abc.Rowno = 1");
                                while (SQLResultset.next()) {
                                    String db_No_of_Rcds_After_summarization = SQLResultset.getString("No_of_Rcds_After_summarization");
                                    if (db_No_of_Rcds_After_summarization.equals(db_No_of_Rcds_STGAgg)) {
                                        String pc_stg_header = 1 + "," + db_No_of_Rcds_before_summarization + "," + db_No_of_Rcds_After_summarization + "," + db_No_of_Rcds_STGAgg + ",Pass";
                                        section3_list_results.add(pc_stg_header);
                                    } else {
                                        String pc_stg_header = 1 + "," + db_No_of_Rcds_before_summarization + "," + db_No_of_Rcds_After_summarization + "," + db_No_of_Rcds_STGAgg + ",Fail";
                                        section3_list_results.add(pc_stg_header);
                                    }
                                }
                            }
                        }

                    } else if (db_stg_reversal_indicator.equals("N") && db_stg_transaction_sub_type.equals("DisbursementPaid") && xml_payment_method.equals("CHEQUE")) {
                        SQLResultset = SQLstmt.executeQuery("SELECT count(BC_Header_id) No_of_Rcds_before_summarization FROM DLG_FSH_STG_BC_COMM WHERE FILE_NAME = '" + xml_file_name + "'");
                        while (SQLResultset.next()) {
                            String db_No_of_Rcds_before_summarization = SQLResultset.getString("No_of_Rcds_before_summarization");
                            SQLResultset = SQLstmt.executeQuery("SELECT count(BC_Header_id) No_of_Rcds_STGAgg FROM dlg_fsh_stg_bc_comm_agg WHERE FILE_NAME = '" + xml_file_name + "'");
                            while (SQLResultset.next()) {
                                String db_No_of_Rcds_STGAgg = SQLResultset.getString("db_No_of_Rcds_STGAgg");
                                SQLResultset = SQLstmt.executeQuery("SELECT count(BC_Header_id) No_of_Rcds_After_summarization FROM DLG_FSH_STG_BC_COMM WHERE FILE_NAME = '" + xml_file_name + "'");
                                while (SQLResultset.next()) {
                                    String db_No_of_Rcds_After_summarization = SQLResultset.getString("No_of_Rcds_After_summarization");
                                    if (db_No_of_Rcds_After_summarization.equals(db_No_of_Rcds_STGAgg)) {
                                        String pc_stg_header = 1 + "," + db_No_of_Rcds_before_summarization + "," + db_No_of_Rcds_After_summarization + "," + db_No_of_Rcds_STGAgg + ",Pass";
                                        section3_list_results.add(pc_stg_header);
                                    } else {
                                        String pc_stg_header = 1 + "," + db_No_of_Rcds_before_summarization + "," + db_No_of_Rcds_After_summarization + "," + db_No_of_Rcds_STGAgg + ",Fail";
                                        section3_list_results.add(pc_stg_header);
                                    }
                                }
                            }
                        }
                    } else if (db_stg_reversal_indicator.equals("N") && (db_stg_transaction_sub_type.equals("Chargewrittenoff") || db_stg_transaction_sub_type.equals("AccountcollectionTxn") || db_stg_transaction_sub_type.equals("AccountGoodwillTxn") || db_stg_transaction_sub_type.equals("AccountNegativeWriteoffTxn") || db_stg_transaction_sub_type.equals("AccountInterestTxn") || db_stg_transaction_sub_type.equals("AccountOtherTxn"))) {
                        SQLResultset = SQLstmt.executeQuery("SELECT count(BC_Header_id) No_of_Rcds_before_summarization FROM DLG_FSH_STG_BC_COMM WHERE FILE_NAME = '" + xml_file_name + "'");
                        while (SQLResultset.next()) {
                            String db_No_of_Rcds_before_summarization = SQLResultset.getString("No_of_Rcds_before_summarization");
                            SQLResultset = SQLstmt.executeQuery("SELECT count(BC_Header_id) No_of_Rcds_STGAgg FROM dlg_fsh_stg_bc_comm_agg WHERE FILE_NAME = '" + xml_file_name + "'");
                            while (SQLResultset.next()) {
                                String db_No_of_Rcds_STGAgg = SQLResultset.getString("db_No_of_Rcds_STGAgg");
                                SQLResultset = SQLstmt.executeQuery("SELECT count(*) No_of_Rcds_After_summarization FROM" +
                                        "(SELECT BC_HEADER_ID,ROW_NUMBER() OVER(Partition by SOURCE,UNDERWRITER,BRAND,PRODUCT_TYPE,LINE_OF_BUSINESS,TRANSACTION_REFERENCE,TRANSACTION_DATE,TRANSACTION_SUB_TYPE," +
                                        "TRANSACTION_REASON,CHANNEL,BATCH_FKEY Order BY SOURCE,UNDERWRITER,BRAND,PRODUCT_TYPE,LINE_OF_BUSINESS,TRANSACTION_REFERENCE,TRANSACTION_DATE," +
                                        "TRANSACTION_SUB_TYPE,TRANSACTION_REASON,CHANNEL,REVERSAL_INDICATOR,BATCH_FKEY) Rowno FROM DLG_FSH_STG_BC_COMM WHERE FILE_NAME = '" + xml_file_name + "')abc Where abc.Rowno = 1");
                                while (SQLResultset.next()) {
                                    String db_No_of_Rcds_After_summarization = SQLResultset.getString("No_of_Rcds_After_summarization");
                                    if (db_No_of_Rcds_After_summarization.equals(db_No_of_Rcds_STGAgg)) {
                                        String pc_stg_header = 1 + "," + db_No_of_Rcds_before_summarization + "," + db_No_of_Rcds_After_summarization + "," + db_No_of_Rcds_STGAgg + ",Pass";
                                        section3_list_results.add(pc_stg_header);
                                    } else {
                                        String pc_stg_header = 1 + "," + db_No_of_Rcds_before_summarization + "," + db_No_of_Rcds_After_summarization + "," + db_No_of_Rcds_STGAgg + ",Fail";
                                        section3_list_results.add(pc_stg_header);
                                    }
                                }
                            }
                        }

                    }*/


                    //------------- Section 4 Aggregate to TO table validation Start Here --------------------
                    SQLResultset = SQLstmt.executeQuery("SELECT * FROM dlg_fsh_stg_bc_comm_agg WHERE FILE_NAME = '" + xml_file_name + "' and BC_HEADER_ID = '" + xmlbc_header_id + "'");
                    while (SQLResultset.next()) {
                        db_aggregate_bc_header_id = SQLResultset.getString("BC_HEADER_ID");
                        db_aggregate_source = SQLResultset.getString("SOURCE");
                        db_aggregate_brand = SQLResultset.getString("BRAND");
                        db_aggregate_account_number = SQLResultset.getString("ACCOUNT_NUMBER");
                        db_aggregate_policy_number = SQLResultset.getString("POLICY_NUMBER");
                        db_aggregate_transaction_date = SQLResultset.getString("TRANSACTION_DATE");
                        db_aggregate_transaction_sub_type = SQLResultset.getString("TRANSACTION_SUB_TYPE");
                        db_aggregate_transaction_reason = SQLResultset.getString("TRANSACTION_REASON");
                        db_aggregate_payment_method = SQLResultset.getString("PAYMENT_METHOD");
                        db_aggregate_sun_number = SQLResultset.getString("SUN_NUMBER");
                        db_aggregate_mid_number = SQLResultset.getString("MID_NUMBER");
                        db_aggregate_ddi_reference = SQLResultset.getString("DDI_REFERENCE");
                        db_aggregate_pay_in_slip_number = SQLResultset.getString("PAY_IN_SLIP_NUMBER");
                        db_aggregate_cheque_number = SQLResultset.getString("CHEQUE_NUMBER");
                        db_aggregate_card_type = SQLResultset.getString("CARD_TYPE");
                        db_aggregate_bacs_narrative = SQLResultset.getString("BACS_NARRATIVE");
                        db_aggregate_card_narrative = SQLResultset.getString("CARD_NARRATIVE");
                        db_aggregate_channel = SQLResultset.getString("CHANNEL");
                        db_aggregate_reversal_indicator = SQLResultset.getString("REVERSAL_INDICATOR");
                        db_aggregate_currency_code = SQLResultset.getString("CURRENCY_CD");
                        db_aggregate_exchange_rate = SQLResultset.getString("EXCHANGE_RATE");
                        // db_exchange_rate_type = SQLResultset.getString("EXCHANGE_RATE_TYPE");
                        db_aggregate_base_currency_amount = SQLResultset.getString("BASE_CURRENCY_AMOUNT");
                        db_aggregate_base_intrest_amount = SQLResultset.getString("BASE_INTEREST_AMOUNT");
                        db_aggregate_tax_deductible = SQLResultset.getString("TAX_DEDUCTIBLE");
                        db_aggregate_order_number = SQLResultset.getString("ORDER_NUMBER");
                        db_aggregate_payment_transaction_type_id = SQLResultset.getString("PAYMENT_TRANSACTION_TYPE_ID");
                        db_aggregate_currency_amount = SQLResultset.getString("CURRENCY_AMOUNT");
                        db_aggregate_credit_ind = SQLResultset.getString("CREDIT_IND");
                        //}


                        SQLResultset = SQLstmt.executeQuery("SELECT *  from DLG_PCBC_BC_TO WHERE FILE_NAME = '" + xml_file_name + "' and BC_HEADER_ID = '" + xmlbc_header_id + "'");
                        if(SQLResultset.next() == false){
                            System.out.println("Satging table does not have records");
                            String pc_TO_header_line = 1 + ",Staging Table" + "No records" + "," + "No records" + ",Fail";
                            section4_list_results.add(pc_TO_header_line);
                        }else{
                            do{
                                System.out.println("Satging table  have records");
                                String db_TO_bc_header_id = SQLResultset.getString("BC_HEADER_ID");
                                String db_TO_source = SQLResultset.getString("SOURCE");
                                String db_TO_brand = SQLResultset.getString("BRAND");
                                String db_TO_account_number = SQLResultset.getString("ACCOUNT_NUMBER");
                                String db_TO_policy_number = SQLResultset.getString("POLICY_NUMBER");
                                String db_TO_transaction_date = SQLResultset.getString("TRANSACTION_DATE");
                                String db_TO_transaction_sub_type = SQLResultset.getString("TRANSACTION_SUB_TYPE");
                                String db_TO_transaction_reason = SQLResultset.getString("TRANSACTION_REASON");
                                String db_TO_payment_method = SQLResultset.getString("PAYMENT_METHOD");
                                String db_TO_sun_number = SQLResultset.getString("SUN_NUMBER");
                                String db_TO_mid_number = SQLResultset.getString("MID_NUMBER");
                                String db_TO_ddi_reference = SQLResultset.getString("DDI_REFERENCE");
                                String db_TO_pay_in_slip_number = SQLResultset.getString("PAY_IN_SLIP_NUMBER");
                                String db_TO_cheque_number = SQLResultset.getString("CHEQUE_NUMBER");
                                String db_TO_card_type = SQLResultset.getString("CARD_TYPE");
                                String db_TO_bacs_narrative = SQLResultset.getString("BACS_NARRATIVE");
                                String db_TO_card_narrative = SQLResultset.getString("CARD_NARRATIVE");
                                String db_TO_channel = SQLResultset.getString("CHANNEL");
                                String db_TO_reversal_indicator = SQLResultset.getString("REVERSAL_INDICATOR");
                                String db_TO_currency_code = SQLResultset.getString("CURRENCY_CD");
                                String db_TO_exchange_rate = SQLResultset.getString("EXCHANGE_RATE");
                                // db_exchange_rate_type = SQLResultset.getString("EXCHANGE_RATE_TYPE");
                                String db_TO_base_currency_amount = SQLResultset.getString("BASE_CURRENCY_AMOUNT");
                                String db_TO_base_intrest_amount = SQLResultset.getString("BASE_INTEREST_AMOUNT");
                                String db_TO_tax_deductible = SQLResultset.getString("TAX_DEDUCTIBLE");
                                String db_TO_order_number = SQLResultset.getString("ORDER_NUMBER");
                                String db_TO_payment_transaction_type_id = SQLResultset.getString("PAYMENT_TRANSACTION_TYPE_ID");
                                String db_TO_currency_amount = SQLResultset.getString("CURRENCY_AMOUNT");
                                String db_TO_credit_ind = SQLResultset.getString("CREDIT_IND");

                                // --------------- Validate header ------------------------
                                if (db_aggregate_bc_header_id.equals(db_TO_bc_header_id)) {
                                    String pc_TO_header_line = TO_table_map_row + ",bc_header_id" + db_aggregate_bc_header_id + "," + db_TO_bc_header_id + ",Pass";

                                    section4_list_results.add(pc_TO_header_line);
                                    TO_table_map_row++;
                                } else {
                                    String pc_TO_header_line = TO_table_map_row + ",bc_header_id" + db_aggregate_bc_header_id + "," + db_TO_bc_header_id + ",Fail";
                                    section4_list_results.add(pc_TO_header_line);
                                    TO_table_map_row++;
                                }

                                //-------------- Validate SOURCE ---------------------------
                                if (db_TO_source.equals(db_aggregate_source)) {
                                    String TO_source = ",SOURCE," + db_TO_source + "," + db_aggregate_source + ",Pass";
                                    section4_list_results.add(TO_source);
                                } else {
                                    String TO_source = ",SOURCE," + db_TO_source + "," + db_aggregate_source + ",Fail";
                                    section4_list_results.add(TO_source);
                                }

                                //-------------- Validate ACCOUNT_NUMBER ---------------------------
                                if (db_TO_account_number.equals(db_aggregate_account_number)) {
                                    String to_account_number = ",ACCOUNT_NUMBER," + db_TO_account_number + "," + db_aggregate_account_number + ",Pass";
                                    section4_list_results.add(to_account_number);
                                } else {
                                    String to_account_number = ",ACCOUNT_NUMBER," + db_TO_account_number + "," + db_aggregate_account_number + ",Fail";
                                    section4_list_results.add(to_account_number);
                                }

                                //-------------- Validate POLICY_NUMBER ---------------------------
                                if (db_TO_policy_number.equals(db_aggregate_policy_number)) {
                                    String to_policy_number = ",POLICY_NUMBER," + db_TO_policy_number + "," + db_aggregate_policy_number + ",Pass";
                                    section4_list_results.add(to_policy_number);
                                } else {
                                    String to_policy_number = ",POLICY_NUMBER," + db_TO_policy_number + "," + db_aggregate_policy_number + ",Fail";
                                    section4_list_results.add(to_policy_number);
                                }

                                //-------------- Validate TRANSACTION_DATE ---------------------------
                                if (db_TO_transaction_date.equals(db_aggregate_transaction_date)) {
                                    String to_transaction_date = ",TRANSACTION_DATE," + db_TO_transaction_date + "," + db_aggregate_transaction_date + ",Pass";
                                    section4_list_results.add(to_transaction_date);
                                } else {
                                    String to_transaction_date = ",TRANSACTION_DATE," + db_TO_transaction_date + "," + db_aggregate_transaction_date + ",Fail";
                                    section4_list_results.add(to_transaction_date);
                                }

                                //-------------- Validate TRANSACTION_SUB_TYPE ---------------------------
                                if (db_TO_transaction_sub_type.equals(db_aggregate_transaction_sub_type)) {
                                    String to_transaction_sub_type = ",TRANSACTION_SUB_TYPE," + db_TO_transaction_sub_type + "," + db_aggregate_transaction_sub_type + ",Pass";
                                    section4_list_results.add(to_transaction_sub_type);
                                } else {
                                    String to_transaction_sub_type = ",TRANSACTION_SUB_TYPE," + db_TO_transaction_sub_type + "," + db_aggregate_transaction_sub_type + ",Fail";
                                    section4_list_results.add(to_transaction_sub_type);
                                }

                                //-------------- Validate TRANSACTION_REASON ---------------------------
                                if (db_TO_transaction_reason.equals(db_aggregate_transaction_reason)) {
                                    String to_transaction_reason = ",TRANSACTION_REASON," + db_TO_transaction_reason + "," + db_aggregate_transaction_reason + ",Pass";
                                    section4_list_results.add(to_transaction_reason);
                                } else {
                                    String to_transaction_reason = ",TRANSACTION_REASON," + db_TO_transaction_reason + "," + db_aggregate_transaction_reason + ",Fail";
                                    section4_list_results.add(to_transaction_reason);
                                }

                                //-------------- Validate SUN_NUMBER ---------------------------
                                if (xml_payment_method.equals("BACS")) {
                                    if (db_TO_sun_number.equals(db_aggregate_sun_number)) {
                                        String to_sun_number = ",SUN_NUMBER," + db_TO_sun_number + "," + db_aggregate_sun_number + ",Pass";
                                        section4_list_results.add(to_sun_number);
                                    } else {
                                        String to_sun_number = ",SUN_NUMBER," + db_TO_sun_number + "," + db_aggregate_sun_number + ",Fail";
                                        section4_list_results.add(to_sun_number);
                                    }
                                }

                                //-------------- Validate MID_NUMBER ---------------------------
                                if (xml_payment_method.equals("Card")) {
                                    if (db_TO_mid_number.equals(db_aggregate_mid_number)) {
                                        String to_mid_number = ",MID_NUMBER," + db_TO_mid_number + "," + db_aggregate_mid_number + ",Pass";
                                        section4_list_results.add(to_mid_number);
                                    } else {
                                        String to_mid_number = ",MID_NUMBER," + db_TO_mid_number + "," + db_aggregate_mid_number + ",Fail";
                                        section4_list_results.add(to_mid_number);
                                    }
                                }

                                //-------------- Validate DDI_REFERENCE ---------------------------
                                if (xml_payment_method.equals("BACS")) {
                                    if (db_TO_ddi_reference == db_aggregate_ddi_reference || db_TO_ddi_reference.equals(db_aggregate_ddi_reference)) {
                                        String to_ddi_reference = ",DDI_REFERENCE," + db_TO_ddi_reference + "," + db_aggregate_ddi_reference + ",Pass";
                                        section4_list_results.add(to_ddi_reference);
                                    } else {
                                        String to_ddi_reference = ",DDI_REFERENCE," + db_TO_ddi_reference + "," + db_aggregate_ddi_reference + ",Fail";
                                        section4_list_results.add(to_ddi_reference);
                                    }
                                }

                                //-------------- Validate PAY_IN_SLIP_NUMBER -------------
                                if (xml_payment_method.equals("Cheque")) {
                                    if (db_TO_pay_in_slip_number == db_aggregate_pay_in_slip_number) {
                                        String to_pay_in_slip_number = ",PAY_IN_SLIP_NUMBER," + db_TO_pay_in_slip_number + "," + db_aggregate_pay_in_slip_number + ",Pass";
                                        section4_list_results.add(to_pay_in_slip_number);
                                    } else {
                                        String to_pay_in_slip_number = ",PAY_IN_SLIP_NUMBER," + db_TO_pay_in_slip_number + "," + db_aggregate_pay_in_slip_number + ",Fail";
                                        section4_list_results.add(to_pay_in_slip_number);
                                    }
                                }

                                //-------------- Validate CHEQUE_NUMBER -------------
                                if (xml_payment_method.equals("Cheque")) {
                                    if (db_TO_cheque_number.equals(db_aggregate_cheque_number)) {
                                        String to_cheque_number = ",CHEQUE_NUMBER," + db_TO_cheque_number + "," + db_aggregate_cheque_number + ",Pass";
                                        section4_list_results.add(to_cheque_number);
                                    } else {
                                        String to_cheque_number = ",CHEQUE_NUMBER," + db_TO_cheque_number + "," + db_aggregate_cheque_number + ",Fail";
                                        section4_list_results.add(to_cheque_number);
                                    }
                                }

                                //-------------- Validate CARD_TYPE ---------------------------
                                if (xml_payment_method.equals("Card")) {
                                    if (db_TO_card_type.equals(db_aggregate_card_type)) {
                                        String to_card_type = ",CARD_TYPE," + db_TO_card_type + "," + db_aggregate_card_type + ",Pass";
                                        section4_list_results.add(to_card_type);
                                    } else {
                                        String to_card_type = ",CARD_TYPE," + db_TO_card_type + "," + db_aggregate_card_type + ",Fail";
                                        section4_list_results.add(to_card_type);
                                    }
                                }

                                //-------------- Validate BACS_NARRATIVE ---------------------------
                                if (xml_payment_method.equals("BACS")) {
                                    if (db_TO_bacs_narrative == db_aggregate_bacs_narrative || db_TO_bacs_narrative.equals(db_aggregate_bacs_narrative)) {
                                        String to_bacs_narrative = ",BACS_NARRATIVE," + db_TO_bacs_narrative + "," + db_aggregate_bacs_narrative + ",Pass";
                                        section4_list_results.add(to_bacs_narrative);
                                    } else {
                                        String to_bacs_narrative = ",BACS_NARRATIVE," + db_TO_bacs_narrative + "," + db_aggregate_bacs_narrative + ",Fail";
                                        section4_list_results.add(to_bacs_narrative);
                                    }
                                }

                                //-------------- Validate CARD_NARRATIVE ---------------------------
                                if (xml_payment_method.equals("Card")) {
                                    if (db_TO_card_narrative.equals(db_aggregate_card_narrative)) {
                                        String to_card_narrative = ",CARD_NARRATIVE," + db_TO_card_narrative + "," + db_aggregate_card_narrative + ",Pass";
                                        section4_list_results.add(to_card_narrative);
                                    } else {
                                        String to_card_narrative = ",CARD_NARRATIVE," + db_TO_card_narrative + "," + db_aggregate_card_narrative + ",Fail";
                                        section4_list_results.add(to_card_narrative);
                                    }
                                }

                                //-------------- Validate CHANNEL ---------------------------
                                if (db_TO_channel.equals(db_aggregate_channel)) {
                                    String to_channel = ",CHANNEL," + db_TO_channel + "," + db_aggregate_channel + ",Pass";
                                    section4_list_results.add(to_channel);
                                } else {
                                    String to_channel = ",CHANNEL," + db_TO_channel + "," + db_aggregate_channel + ",Fail";
                                    section4_list_results.add(to_channel);
                                }

                                //--------------------- Validate REVERSAL_INDICATOR -------------------
                                if (db_TO_reversal_indicator.equals(db_aggregate_reversal_indicator)) {
                                    String to_reversal_indicator = ",REVERSAL_INDICATOR," + db_TO_reversal_indicator + "," + db_aggregate_reversal_indicator + ",Pass";
                                    section4_list_results.add(to_reversal_indicator);
                                } else {
                                    String to_reversal_indicator = ",REVERSAL_INDICATOR," + db_TO_reversal_indicator + "," + db_aggregate_reversal_indicator + ",Fail";
                                    section4_list_results.add(to_reversal_indicator);
                                }

                                //--------------------- Validate CURRENCY_CD -------------------
                                if (db_TO_currency_code.equals(db_aggregate_currency_code)) {
                                    String to_currency_code = ",CURRENCY_CD," + db_TO_currency_code + "," + db_aggregate_currency_code + ",Pass";
                                    section4_list_results.add(to_currency_code);
                                } else {
                                    String to_currency_code = ",CURRENCY_CD," + db_TO_currency_code + "," + db_aggregate_currency_code + ",Fail";
                                    section4_list_results.add(to_currency_code);
                                }

                                //--------------------- Validate EXCHANGE_RATE -------------------
                                double db_double_TO_exchange_rate = Double.parseDouble(db_TO_exchange_rate); // change to double
                                double db_double_aggregate_exchange_rate = Double.parseDouble(db_aggregate_exchange_rate); // change to double

                                if (db_double_TO_exchange_rate == db_double_aggregate_exchange_rate) {
                                    String to_exchange_rate = ",EXCHANGE_RATE," + db_double_TO_exchange_rate + "," + db_double_aggregate_exchange_rate + ",Pass";
                                    section4_list_results.add(to_exchange_rate);
                                } else {
                                    String to_exchange_rate = ",EXCHANGE_RATE," + db_double_TO_exchange_rate + "," + db_double_aggregate_exchange_rate + ",Fail";
                                    section4_list_results.add(to_exchange_rate);
                                }

                                //--------------------- Validate BASE_CURRENCY_AMOUNT -------------------
                                if (db_TO_base_currency_amount.equals(db_aggregate_base_currency_amount)) {
                                    String to_base_currency_amount = ",BASE_CURRENCY_AMOUNT," + db_TO_base_currency_amount + "," + db_aggregate_base_currency_amount + ",Pass";
                                    section4_list_results.add(to_base_currency_amount);
                                } else {
                                    String to_base_currency_amount = ",BASE_CURRENCY_AMOUNT," + db_TO_base_currency_amount + "," + db_aggregate_base_currency_amount + ",Fail";
                                    section4_list_results.add(to_base_currency_amount);
                                }

                                //--------------------- Validate BASE_INTEREST_AMOUNT -------------------
                                if (db_TO_base_intrest_amount.equals(db_aggregate_base_intrest_amount)) {
                                    String to_base_intrest_amount = ",BASE_INTEREST_AMOUNT," + db_TO_base_intrest_amount + "," + db_aggregate_base_intrest_amount + ",Pass";
                                    section4_list_results.add(to_base_intrest_amount);
                                } else {
                                    String to_base_intrest_amount = ",BASE_INTEREST_AMOUNT," + db_TO_base_intrest_amount + "," + db_aggregate_base_intrest_amount + ",Fail";
                                    section4_list_results.add(to_base_intrest_amount);
                                }

                                //--------------------- Validate TAX_DEDUCTIBLE -------------------
                                if (db_TO_tax_deductible.equals(db_aggregate_tax_deductible)) {
                                    String to_tax_deductible = ",TAX_DEDUCTIBLE," + db_TO_tax_deductible + "," + db_aggregate_tax_deductible + ",Pass";
                                    section4_list_results.add(to_tax_deductible);
                                } else {
                                    String to_tax_deductible = ",TAX_DEDUCTIBLE," + db_TO_tax_deductible + "," + db_aggregate_tax_deductible + ",Fail";
                                    section4_list_results.add(to_tax_deductible);
                                }

                                //--------------------- Validate ORDER_NUMBER -------------------
                                if (xml_payment_method.equals("Card")) {
                                    if (db_TO_order_number.equals(db_aggregate_order_number)) {
                                        String to_order_number = ",ORDER_NUMBER," + db_TO_order_number + "," + db_aggregate_order_number + ",Pass";
                                        section4_list_results.add(to_order_number);
                                    } else {
                                        String to_order_number = ",ORDER_NUMBER," + db_TO_order_number + "," + db_aggregate_order_number + ",Fail";
                                        section4_list_results.add(to_order_number);
                                    }
                                }

                                //--------------------- Validate PAYMENT_TRANSACTION_TYPE_ID ---------------
                                if (db_TO_payment_transaction_type_id.equals(db_aggregate_payment_transaction_type_id)) {
                                    String to_payment_transaction_type_id = ",PAYMENT_TRANSACTION_TYPE_ID," + db_TO_payment_transaction_type_id + "," + db_aggregate_payment_transaction_type_id + ",Pass";
                                    section4_list_results.add(to_payment_transaction_type_id);
                                } else {
                                    String to_payment_transaction_type_id = ",PAYMENT_TRANSACTION_TYPE_ID," + db_TO_payment_transaction_type_id + "," + db_aggregate_payment_transaction_type_id + ",Fail";
                                    section4_list_results.add(to_payment_transaction_type_id);
                                }

                                //--------------------- Validate CURRENCY_AMOUNT ---------------
                                if (db_TO_currency_amount.equals(db_aggregate_currency_amount)) {
                                    String to_currency_amount = ",CURRENCY_AMOUNT," + db_TO_currency_amount + "," + db_aggregate_currency_amount + ",Pass";
                                    section4_list_results.add(to_currency_amount);
                                } else {
                                    String to_currency_amount = ",CURRENCY_AMOUNT," + db_TO_currency_amount + "," + db_aggregate_currency_amount + ",Fail";
                                    section4_list_results.add(to_currency_amount);
                                }

                                //--------------------- Validate CREDIT_IND ---------------
                                if (db_TO_credit_ind.equals(db_aggregate_credit_ind)) {
                                    String to_credit_ind = ",CREDIT_IND," + db_TO_credit_ind + "," + db_aggregate_credit_ind + ",Pass";
                                    section4_list_results.add(to_credit_ind);
                                } else {
                                    String to_credit_ind = ",CREDIT_IND," + db_TO_credit_ind + "," + db_aggregate_credit_ind + ",Fail";
                                    section4_list_results.add(to_credit_ind);
                                }

                            }while (SQLResultset.next());

                        }

                        //while (SQLResultset.next()) {

                            /*String db_TO_bc_header_id = SQLResultset.getString("BC_HEADER_ID");
                            String db_TO_source = SQLResultset.getString("SOURCE");
                            String db_TO_brand = SQLResultset.getString("BRAND");
                            String db_TO_account_number = SQLResultset.getString("ACCOUNT_NUMBER");
                            String db_TO_policy_number = SQLResultset.getString("POLICY_NUMBER");
                            String db_TO_transaction_date = SQLResultset.getString("TRANSACTION_DATE");
                            String db_TO_transaction_sub_type = SQLResultset.getString("TRANSACTION_SUB_TYPE");
                            String db_TO_transaction_reason = SQLResultset.getString("TRANSACTION_REASON");
                            String db_TO_payment_method = SQLResultset.getString("PAYMENT_METHOD");
                            String db_TO_sun_number = SQLResultset.getString("SUN_NUMBER");
                            String db_TO_mid_number = SQLResultset.getString("MID_NUMBER");
                            String db_TO_ddi_reference = SQLResultset.getString("DDI_REFERENCE");
                            String db_TO_pay_in_slip_number = SQLResultset.getString("PAY_IN_SLIP_NUMBER");
                            String db_TO_cheque_number = SQLResultset.getString("CHEQUE_NUMBER");
                            String db_TO_card_type = SQLResultset.getString("CARD_TYPE");
                            String db_TO_bacs_narrative = SQLResultset.getString("BACS_NARRATIVE");
                            String db_TO_card_narrative = SQLResultset.getString("CARD_NARRATIVE");
                            String db_TO_channel = SQLResultset.getString("CHANNEL");
                            String db_TO_reversal_indicator = SQLResultset.getString("REVERSAL_INDICATOR");
                            String db_TO_currency_code = SQLResultset.getString("CURRENCY_CD");
                            String db_TO_exchange_rate = SQLResultset.getString("EXCHANGE_RATE");
                            // db_exchange_rate_type = SQLResultset.getString("EXCHANGE_RATE_TYPE");
                            String db_TO_base_currency_amount = SQLResultset.getString("BASE_CURRENCY_AMOUNT");
                            String db_TO_base_intrest_amount = SQLResultset.getString("BASE_INTEREST_AMOUNT");
                            String db_TO_tax_deductible = SQLResultset.getString("TAX_DEDUCTIBLE");
                            String db_TO_order_number = SQLResultset.getString("ORDER_NUMBER");
                            String db_TO_payment_transaction_type_id = SQLResultset.getString("PAYMENT_TRANSACTION_TYPE_ID");
                            String db_TO_currency_amount = SQLResultset.getString("CURRENCY_AMOUNT");
                            String db_TO_credit_ind = SQLResultset.getString("CREDIT_IND");

                            // --------------- Validate header ------------------------
                            if (db_aggregate_bc_header_id.equals(db_TO_bc_header_id)) {
                                String pc_TO_header_line = TO_table_map_row + ",bc_header_id" + db_aggregate_bc_header_id + "," + db_TO_bc_header_id + ",Pass";

                                section4_list_results.add(pc_TO_header_line);
                                TO_table_map_row++;
                            } else {
                                String pc_TO_header_line = TO_table_map_row + ",bc_header_id" + db_aggregate_bc_header_id + "," + db_TO_bc_header_id + ",Fail";
                                section4_list_results.add(pc_TO_header_line);
                                TO_table_map_row++;
                            }

                            //-------------- Validate SOURCE ---------------------------
                            if (db_TO_source.equals(db_aggregate_source)) {
                                String TO_source = ",SOURCE," + db_TO_source + "," + db_aggregate_source + ",Pass";
                                section4_list_results.add(TO_source);
                            } else {
                                String TO_source = ",SOURCE," + db_TO_source + "," + db_aggregate_source + ",Fail";
                                section4_list_results.add(TO_source);
                            }

                            //-------------- Validate ACCOUNT_NUMBER ---------------------------
                            if (db_TO_account_number.equals(db_aggregate_account_number)) {
                                String to_account_number = ",ACCOUNT_NUMBER," + db_TO_account_number + "," + db_aggregate_account_number + ",Pass";
                                section4_list_results.add(to_account_number);
                            } else {
                                String to_account_number = ",ACCOUNT_NUMBER," + db_TO_account_number + "," + db_aggregate_account_number + ",Fail";
                                section4_list_results.add(to_account_number);
                            }

                            //-------------- Validate POLICY_NUMBER ---------------------------
                            if (db_TO_policy_number.equals(db_aggregate_policy_number)) {
                                String to_policy_number = ",POLICY_NUMBER," + db_TO_policy_number + "," + db_aggregate_policy_number + ",Pass";
                                section4_list_results.add(to_policy_number);
                            } else {
                                String to_policy_number = ",POLICY_NUMBER," + db_TO_policy_number + "," + db_aggregate_policy_number + ",Fail";
                                section4_list_results.add(to_policy_number);
                            }

                            //-------------- Validate TRANSACTION_DATE ---------------------------
                            if (db_TO_transaction_date.equals(db_aggregate_transaction_date)) {
                                String to_transaction_date = ",TRANSACTION_DATE," + db_TO_transaction_date + "," + db_aggregate_transaction_date + ",Pass";
                                section4_list_results.add(to_transaction_date);
                            } else {
                                String to_transaction_date = ",TRANSACTION_DATE," + db_TO_transaction_date + "," + db_aggregate_transaction_date + ",Fail";
                                section4_list_results.add(to_transaction_date);
                            }

                            //-------------- Validate TRANSACTION_SUB_TYPE ---------------------------
                            if (db_TO_transaction_sub_type.equals(db_aggregate_transaction_sub_type)) {
                                String to_transaction_sub_type = ",TRANSACTION_SUB_TYPE," + db_TO_transaction_sub_type + "," + db_aggregate_transaction_sub_type + ",Pass";
                                section4_list_results.add(to_transaction_sub_type);
                            } else {
                                String to_transaction_sub_type = ",TRANSACTION_SUB_TYPE," + db_TO_transaction_sub_type + "," + db_aggregate_transaction_sub_type + ",Fail";
                                section4_list_results.add(to_transaction_sub_type);
                            }

                            //-------------- Validate TRANSACTION_REASON ---------------------------
                            if (db_TO_transaction_reason.equals(db_aggregate_transaction_reason)) {
                                String to_transaction_reason = ",TRANSACTION_REASON," + db_TO_transaction_reason + "," + db_aggregate_transaction_reason + ",Pass";
                                section4_list_results.add(to_transaction_reason);
                            } else {
                                String to_transaction_reason = ",TRANSACTION_REASON," + db_TO_transaction_reason + "," + db_aggregate_transaction_reason + ",Fail";
                                section4_list_results.add(to_transaction_reason);
                            }

                            //-------------- Validate SUN_NUMBER ---------------------------
                            if (xml_payment_method.equals("BACS")) {
                                if (db_TO_sun_number.equals(db_aggregate_sun_number)) {
                                    String to_sun_number = ",SUN_NUMBER," + db_TO_sun_number + "," + db_aggregate_sun_number + ",Pass";
                                    section4_list_results.add(to_sun_number);
                                } else {
                                    String to_sun_number = ",SUN_NUMBER," + db_TO_sun_number + "," + db_aggregate_sun_number + ",Fail";
                                    section4_list_results.add(to_sun_number);
                                }
                            }

                            //-------------- Validate MID_NUMBER ---------------------------
                            if (xml_payment_method.equals("Card")) {
                                if (db_TO_mid_number.equals(db_aggregate_mid_number)) {
                                    String to_mid_number = ",MID_NUMBER," + db_TO_mid_number + "," + db_aggregate_mid_number + ",Pass";
                                    section4_list_results.add(to_mid_number);
                                } else {
                                    String to_mid_number = ",MID_NUMBER," + db_TO_mid_number + "," + db_aggregate_mid_number + ",Fail";
                                    section4_list_results.add(to_mid_number);
                                }
                            }

                            //-------------- Validate DDI_REFERENCE ---------------------------
                            if (xml_payment_method.equals("BACS")) {
                                if (db_TO_ddi_reference == db_aggregate_ddi_reference || db_TO_ddi_reference.equals(db_aggregate_ddi_reference)) {
                                    String to_ddi_reference = ",DDI_REFERENCE," + db_TO_ddi_reference + "," + db_aggregate_ddi_reference + ",Pass";
                                    section4_list_results.add(to_ddi_reference);
                                } else {
                                    String to_ddi_reference = ",DDI_REFERENCE," + db_TO_ddi_reference + "," + db_aggregate_ddi_reference + ",Fail";
                                    section4_list_results.add(to_ddi_reference);
                                }
                            }

                            //-------------- Validate PAY_IN_SLIP_NUMBER -------------
                            if (xml_payment_method.equals("Cheque")) {
                                if (db_TO_pay_in_slip_number == db_aggregate_pay_in_slip_number) {
                                    String to_pay_in_slip_number = ",PAY_IN_SLIP_NUMBER," + db_TO_pay_in_slip_number + "," + db_aggregate_pay_in_slip_number + ",Pass";
                                    section4_list_results.add(to_pay_in_slip_number);
                                } else {
                                    String to_pay_in_slip_number = ",PAY_IN_SLIP_NUMBER," + db_TO_pay_in_slip_number + "," + db_aggregate_pay_in_slip_number + ",Fail";
                                    section4_list_results.add(to_pay_in_slip_number);
                                }
                            }

                            //-------------- Validate CHEQUE_NUMBER -------------
                            if (xml_payment_method.equals("Cheque")) {
                                if (db_TO_cheque_number.equals(db_aggregate_cheque_number)) {
                                    String to_cheque_number = ",CHEQUE_NUMBER," + db_TO_cheque_number + "," + db_aggregate_cheque_number + ",Pass";
                                    section4_list_results.add(to_cheque_number);
                                } else {
                                    String to_cheque_number = ",CHEQUE_NUMBER," + db_TO_cheque_number + "," + db_aggregate_cheque_number + ",Fail";
                                    section4_list_results.add(to_cheque_number);
                                }
                            }

                            //-------------- Validate CARD_TYPE ---------------------------
                            if (xml_payment_method.equals("Card")) {
                                if (db_TO_card_type.equals(db_aggregate_card_type)) {
                                    String to_card_type = ",CARD_TYPE," + db_TO_card_type + "," + db_aggregate_card_type + ",Pass";
                                    section4_list_results.add(to_card_type);
                                } else {
                                    String to_card_type = ",CARD_TYPE," + db_TO_card_type + "," + db_aggregate_card_type + ",Fail";
                                    section4_list_results.add(to_card_type);
                                }
                            }

                            //-------------- Validate BACS_NARRATIVE ---------------------------
                            if (xml_payment_method.equals("BACS")) {
                                if (db_TO_bacs_narrative == db_aggregate_bacs_narrative || db_TO_bacs_narrative.equals(db_aggregate_bacs_narrative)) {
                                    String to_bacs_narrative = ",BACS_NARRATIVE," + db_TO_bacs_narrative + "," + db_aggregate_bacs_narrative + ",Pass";
                                    section4_list_results.add(to_bacs_narrative);
                                } else {
                                    String to_bacs_narrative = ",BACS_NARRATIVE," + db_TO_bacs_narrative + "," + db_aggregate_bacs_narrative + ",Fail";
                                    section4_list_results.add(to_bacs_narrative);
                                }
                            }

                            //-------------- Validate CARD_NARRATIVE ---------------------------
                            if (xml_payment_method.equals("Card")) {
                                if (db_TO_card_narrative.equals(db_aggregate_card_narrative)) {
                                    String to_card_narrative = ",CARD_NARRATIVE," + db_TO_card_narrative + "," + db_aggregate_card_narrative + ",Pass";
                                    section4_list_results.add(to_card_narrative);
                                } else {
                                    String to_card_narrative = ",CARD_NARRATIVE," + db_TO_card_narrative + "," + db_aggregate_card_narrative + ",Fail";
                                    section4_list_results.add(to_card_narrative);
                                }
                            }

                            //-------------- Validate CHANNEL ---------------------------
                            if (db_TO_channel.equals(db_aggregate_channel)) {
                                String to_channel = ",CHANNEL," + db_TO_channel + "," + db_aggregate_channel + ",Pass";
                                section4_list_results.add(to_channel);
                            } else {
                                String to_channel = ",CHANNEL," + db_TO_channel + "," + db_aggregate_channel + ",Fail";
                                section4_list_results.add(to_channel);
                            }

                            //--------------------- Validate REVERSAL_INDICATOR -------------------
                            if (db_TO_reversal_indicator.equals(db_aggregate_reversal_indicator)) {
                                String to_reversal_indicator = ",REVERSAL_INDICATOR," + db_TO_reversal_indicator + "," + db_aggregate_reversal_indicator + ",Pass";
                                section4_list_results.add(to_reversal_indicator);
                            } else {
                                String to_reversal_indicator = ",REVERSAL_INDICATOR," + db_TO_reversal_indicator + "," + db_aggregate_reversal_indicator + ",Fail";
                                section4_list_results.add(to_reversal_indicator);
                            }

                            //--------------------- Validate CURRENCY_CD -------------------
                            if (db_TO_currency_code.equals(db_aggregate_currency_code)) {
                                String to_currency_code = ",CURRENCY_CD," + db_TO_currency_code + "," + db_aggregate_currency_code + ",Pass";
                                section4_list_results.add(to_currency_code);
                            } else {
                                String to_currency_code = ",CURRENCY_CD," + db_TO_currency_code + "," + db_aggregate_currency_code + ",Fail";
                                section4_list_results.add(to_currency_code);
                            }

                            //--------------------- Validate EXCHANGE_RATE -------------------
                            double db_double_TO_exchange_rate = Double.parseDouble(db_TO_exchange_rate); // change to double
                            double db_double_aggregate_exchange_rate = Double.parseDouble(db_aggregate_exchange_rate); // change to double

                            if (db_double_TO_exchange_rate == db_double_aggregate_exchange_rate) {
                                String to_exchange_rate = ",EXCHANGE_RATE," + db_double_TO_exchange_rate + "," + db_double_aggregate_exchange_rate + ",Pass";
                                section4_list_results.add(to_exchange_rate);
                            } else {
                                String to_exchange_rate = ",EXCHANGE_RATE," + db_double_TO_exchange_rate + "," + db_double_aggregate_exchange_rate + ",Fail";
                                section4_list_results.add(to_exchange_rate);
                            }

                            //--------------------- Validate BASE_CURRENCY_AMOUNT -------------------
                            if (db_TO_base_currency_amount.equals(db_aggregate_base_currency_amount)) {
                                String to_base_currency_amount = ",BASE_CURRENCY_AMOUNT," + db_TO_base_currency_amount + "," + db_aggregate_base_currency_amount + ",Pass";
                                section4_list_results.add(to_base_currency_amount);
                            } else {
                                String to_base_currency_amount = ",BASE_CURRENCY_AMOUNT," + db_TO_base_currency_amount + "," + db_aggregate_base_currency_amount + ",Fail";
                                section4_list_results.add(to_base_currency_amount);
                            }

                            //--------------------- Validate BASE_INTEREST_AMOUNT -------------------
                            if (db_TO_base_intrest_amount.equals(db_aggregate_base_intrest_amount)) {
                                String to_base_intrest_amount = ",BASE_INTEREST_AMOUNT," + db_TO_base_intrest_amount + "," + db_aggregate_base_intrest_amount + ",Pass";
                                section4_list_results.add(to_base_intrest_amount);
                            } else {
                                String to_base_intrest_amount = ",BASE_INTEREST_AMOUNT," + db_TO_base_intrest_amount + "," + db_aggregate_base_intrest_amount + ",Fail";
                                section4_list_results.add(to_base_intrest_amount);
                            }

                            //--------------------- Validate TAX_DEDUCTIBLE -------------------
                            if (db_TO_tax_deductible.equals(db_aggregate_tax_deductible)) {
                                String to_tax_deductible = ",TAX_DEDUCTIBLE," + db_TO_tax_deductible + "," + db_aggregate_tax_deductible + ",Pass";
                                section4_list_results.add(to_tax_deductible);
                            } else {
                                String to_tax_deductible = ",TAX_DEDUCTIBLE," + db_TO_tax_deductible + "," + db_aggregate_tax_deductible + ",Fail";
                                section4_list_results.add(to_tax_deductible);
                            }

                            //--------------------- Validate ORDER_NUMBER -------------------
                            if (xml_payment_method.equals("Card")) {
                                if (db_TO_order_number.equals(db_aggregate_order_number)) {
                                    String to_order_number = ",ORDER_NUMBER," + db_TO_order_number + "," + db_aggregate_order_number + ",Pass";
                                    section4_list_results.add(to_order_number);
                                } else {
                                    String to_order_number = ",ORDER_NUMBER," + db_TO_order_number + "," + db_aggregate_order_number + ",Fail";
                                    section4_list_results.add(to_order_number);
                                }
                            }

                            //--------------------- Validate PAYMENT_TRANSACTION_TYPE_ID ---------------
                            if (db_TO_payment_transaction_type_id.equals(db_aggregate_payment_transaction_type_id)) {
                                String to_payment_transaction_type_id = ",PAYMENT_TRANSACTION_TYPE_ID," + db_TO_payment_transaction_type_id + "," + db_aggregate_payment_transaction_type_id + ",Pass";
                                section4_list_results.add(to_payment_transaction_type_id);
                            } else {
                                String to_payment_transaction_type_id = ",PAYMENT_TRANSACTION_TYPE_ID," + db_TO_payment_transaction_type_id + "," + db_aggregate_payment_transaction_type_id + ",Fail";
                                section4_list_results.add(to_payment_transaction_type_id);
                            }

                            //--------------------- Validate CURRENCY_AMOUNT ---------------
                            if (db_TO_currency_amount.equals(db_aggregate_currency_amount)) {
                                String to_currency_amount = ",CURRENCY_AMOUNT," + db_TO_currency_amount + "," + db_aggregate_currency_amount + ",Pass";
                                section4_list_results.add(to_currency_amount);
                            } else {
                                String to_currency_amount = ",CURRENCY_AMOUNT," + db_TO_currency_amount + "," + db_aggregate_currency_amount + ",Fail";
                                section4_list_results.add(to_currency_amount);
                            }

                            //--------------------- Validate CREDIT_IND ---------------
                            if (db_TO_credit_ind.equals(db_aggregate_credit_ind)) {
                                String to_credit_ind = ",CREDIT_IND," + db_TO_credit_ind + "," + db_aggregate_credit_ind + ",Pass";
                                section4_list_results.add(to_credit_ind);
                            } else {
                                String to_credit_ind = ",CREDIT_IND," + db_TO_credit_ind + "," + db_aggregate_credit_ind + ",Fail";
                                section4_list_results.add(to_credit_ind);
                            }*/


                        //}

                    }
                }





                //------ Time calculation -------
                end_time = System.nanoTime();
                end_time = end_time+end_time;

                long actual_tme = end_time - start_time;

                System.out.println("Total time ------> " + actual_tme);
                double start_time_sec = (double)start_time/ 1000000000.0;
                double end_time_sec = (double)end_time/ 1000000000.0;
                double total_sec = (double)(end_time_sec - start_time_sec)/1000/60;

                Total_time = 2+",Total time," + start_time_sec + "," + end_time_sec + "," + total_sec;
                final_list_results.add(Total_time);
                System.out.println("Total time duration  :- "+ Total_time + " Secs");

                //------------- Time duration calculation for Source to Cons --------------
                long actual_time = end_so_cons_time - start_so_cons_time;

                double start_time_sec_cons = (double)start_so_cons_time/ 1000000000.0;
                double end_time_sec_cons = (double)end_so_cons_time/ 1000000000.0;
                double total_sec_cons = (double) (end_time_sec_cons - start_time_sec_cons)/ 1000 /60;

                String Total_time_cons = 1+",Total time_cons," + start_time_sec_cons + "," + end_time_sec_cons + "," + total_sec_cons;
                final_list_results.add(Total_time_cons);

                System.out.println("Total time duration for Source to Cons :- "+ total_sec_cons + " Secs");


                //------------- Time duration calculation for Cons to Staging--------------
                long actual_time_cons_to_stg = cons_stg_end_time - cons_stg_start_time;

                double cons_stg_start_time_sec = (double)cons_stg_start_time/ 1000000000.0;
                double cons_stg_end_time_sec = (double)cons_stg_end_time/ 1000000000.0;
                double actual_time_cons_to_stg_sec = (double)actual_time_cons_to_stg / 1000000000.0;

                double duration = (double) (cons_stg_end_time_sec - cons_stg_start_time_sec)/1000/60;


                String Total_time_cons_to_stg = 3 +",Total time_Cons_to_stg," + cons_stg_start_time_sec + "," + cons_stg_end_time_sec + "," + duration;
                final_list_results.add(Total_time_cons_to_stg);






                List<String> list = new ArrayList<String>();
                list.addAll(lookup_list_results);
                list.addAll(direct_map_list_results);
                list.addAll(final_list_results);
                list.addAll(section4_list_results);



                report_generation.report_Test1(direct_map_list_results, "Section1",xml_file_name, "BC SOURCE TO CONS VALIDATION","B4C_Billing" ,"BC VALIDATION");
                report_generation.report_Test1(lookup_list_results, "Section2",xml_file_name, "BC CONS TO STAGING VALIDATION","B4C_Billing" ,"BC VALIDATION");
                //report_generation.report_Test1(final_list_results, "Section3",xml_file_name, "TOTAL TIME","B4C_Billing");
                report_generation.report_Test1(section4_list_results, "Section4",xml_file_name, "AGGREGATE to TO TABLE VALIDATION","B4C_Billing" ,"BC VALIDATION");


            }

        }
    }

}
