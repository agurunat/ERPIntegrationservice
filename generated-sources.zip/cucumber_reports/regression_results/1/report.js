$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("D:/Workspace/EVO-TestAutomation/src/test/resources/features/Ebuz/Test.feature");
formatter.feature({
  "name": "AR File Compare",
  "description": "",
  "keyword": "Feature"
});
formatter.scenario({
  "name": "AR Direct Mapping File Comparision",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@ARFileCompare"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Source xml file",
  "keyword": "Given "
});
formatter.match({
  "location": "FileCompare.sourceXmlFile()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Target csv file",
  "keyword": "When "
});
formatter.match({
  "location": "FileCompare.targetCsvFile()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "validate the tags",
  "keyword": "Then "
});
formatter.write("\t\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eAquarium AR : File - DB Comparision Report\u003c/B\u003e\u003c/font\u003e\t\t\t\t\t");
formatter.write("\nCurrent Element :dlg_ar_transaction");
formatter.write("----------------------------");
formatter.write("-------------------------------------------------------------------------------------------------------------------");
formatter.write("\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eField Name\u003c/B\u003e\u003c/font\u003e \t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eSource Value\u003c/B\u003e\u003c/font\u003e\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eDB value\u003c/B\u003e\u003c/font\u003e \t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eSTATUS\u003c/B\u003e\u003c/font\u003e\t\t\t");
formatter.write("-------------------------------------------------------------------------------------------------------------------");
formatter.write("id \t\t\t\t25857104 \t\t\t\t25857104 \t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("Base Currency Amount\t\t125.75\t\t\t\t\t125.75\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("Currency_cd\t\t\tGBP\t\t\t\t\tGBP\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("Document Number \t\t25857103\t\t\t\t25857103\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("interface_line_attribute1\tMy Airlines\t\t\t\tMy Airlines\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("interface_line_attribute2\t2017-11-07T00:00:00\t\t\t2017-11-07T00:00:00\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("interface_line_attribute4\t0\t\t\t\t\t0\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("interface_line_attribute5\t1.0\t\t\t\t\t1.0\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("interface_line_attribute6\tGBP\t\t\t\t\tGBP\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("interface_line_attribute7\t125.75\t\t\t\t\t125.75\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("interface_line_attribute8\tHardcoded value - \u0027LINE\u0027\t\t\u0027LINE\u0027\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("interface_line_attribute9\t27592289\t\t\t\t27592289\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("interface_line_attribute14\t25857103\t\t\t\t25857103\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("header_attribute1\t\t27592289\t\t\t\t27592289\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("header_attribute2\t\t25857103\t\t\t\t25857103\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("header_attribute3\t\t26355014\t\t\t\t26355014\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("header_attribute4\t\tOther\t\t\t\t\tOther\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("header_attribute5\t\tMy Airlines\t\t\t\tMy Airlines\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("header_attribute6\t\t9999\t\t\t\t\t9999\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("header_attribute7\t\tNatWest_Tvl\t\t\t\tNatWest_Tvl\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("header_attribute8\t\tTVANNUAL\t\t\t\tTVANNUAL\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("header_attribute9\t\trecovery_Ins\t\t\t\trecovery_Ins\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("header_attribute10\t\tOther\t\t\t\t\tOther\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("header_attribute11\t\tinitial_Ins\t\t\t\tinitial_Ins\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("header_attribute12\t\tGBP\t\t\t\t\tGBP\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("header_attribute13\t\t125.75\t\t\t\t\t125.75\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("header_attribute14\t\t25857103\t\t\t\t25857103\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("line_type\t\t\tHardcoded value - \u0027LINE\u0027\t\t\u0027LINE\u0027\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("taxable_flag\t\t\tHardcoded value - \u0027N\u0027\t\t\t\u0027N\u0027\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("trx_date\t\t\t2017-11-20T11:40:03\t\t\t2017-11-20T11:40:03\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("unit_selling_price\t\t125.75\t\t\t\t\t125.75\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("HEADER_GDF_ATTRIBUTE1\t\tAQUA:25857104\t\t\t\tAQUA:25857104\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("\nCurrent Element :dlg_ar_transaction");
formatter.write("----------------------------");
formatter.write("---------------------------------------------------------------------------------------------------------------");
formatter.write("\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eTOTAL VERIFICATION\u003c/B\u003e\u003c/font\u003e:\t\t\t32\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePassed\u003c/B\u003e\u003c/font\u003e\t:32\t\t\t\u003cfont color \u003d\"#ff1a1a\"\u003e\u003cB\u003eFailed\u003c/B\u003e\u003c/font\u003e\t:0");
formatter.write("---------------------------------------------------------------------------------------------------------------");
formatter.match({
  "location": "FileCompare.validateTheTags()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "AR Source Tag Concatenate and Validate in Target Table",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@ARFileCompare"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Xml Source file",
  "keyword": "Given "
});
formatter.match({
  "location": "ARConcatenateTags.XmlSourceFile()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Target CSV File with Concatenate value",
  "keyword": "When "
});
formatter.match({
  "location": "ARConcatenateTags.targetCSVFileWithNullValue()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Validate the Concatenate values in Target Table",
  "keyword": "Then "
});
formatter.write("\t\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eAquarium AR : File - DB Comparision Report\u003c/B\u003e\u003c/font\u003e\t\t\t\t\t");
formatter.write("File Name   :\t\tARConcatenateTagFileCompare.csv");
formatter.write("\nCurrent Element :dlg_ar_transaction");
formatter.write("----------------------------");
formatter.write("-------------------------------------------------------------------------------------------------------------------");
formatter.write("\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eField Name\u003c/B\u003e\u003c/font\u003e\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eSource Value\u003c/B\u003e\u003c/font\u003e\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eDB value\u003c/B\u003e\u003c/font\u003e\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eSTATUS\u003c/B\u003e\u003c/font\u003e\t\t\t\t");
formatter.write("-------------------------------------------------------------------------------------------------------------------");
formatter.write("id \t\t\t\t25857104\t\t\t\t25857104\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("description\t\t\t2759228925857103\t\t\t2759228925857103\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("Brand\t\t\t\tNatWest_Tvl\t\t\t\tNatWest_Tvl\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("trx_number \t\t\t27592289~25857103\t\t\t27592289~25857103\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("cust_trx_type_name \t\tTVANNUAL~TVNATPLAT~New~0~N\t\tTVANNUAL~TVNATPLAT~New~0~N\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("\nCurrent Element :dlg_ar_transaction");
formatter.write("----------------------------");
formatter.write("---------------------------------------------------------------------------------------------------------------");
formatter.write("\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eTOTAL VERIFICATION\u003c/B\u003e\u003c/font\u003e:\t\t\t5\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePassed\u003c/B\u003e\u003c/font\u003e\t:5\t\t\t\u003cfont color \u003d\"#ff1a1a\"\u003e\u003cB\u003eFailed\u003c/B\u003e\u003c/font\u003e\t:0");
formatter.write("---------------------------------------------------------------------------------------------------------------");
formatter.match({
  "location": "ARConcatenateTags.validateMissingTagValuesInTargetTable()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
formatter.scenario({
  "name": "AR Source Missing Tag and Validate LookUp Value in Target Table",
  "description": "",
  "keyword": "Scenario",
  "tags": [
    {
      "name": "@ARFileCompare"
    }
  ]
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.before({
  "status": "passed"
});
formatter.step({
  "name": "Xml Source file with Missing LookUp Fields",
  "keyword": "Given "
});
formatter.match({
  "location": "ARLookUpValue.XmlSourceFileWithMissingLookUpFields()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Target CSV File with LookUp value",
  "keyword": "When "
});
formatter.match({
  "location": "ARLookUpValue.targetCSVFileWithLookUpValue()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Read the LookUp file",
  "keyword": "Then "
});
formatter.match({
  "location": "ARLookUpValue.readTheLookUpFile()"
});
formatter.result({
  "status": "passed"
});
formatter.step({
  "name": "Validate the LookUp values in Target Table",
  "keyword": "Then "
});
formatter.write("\t\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eAquarium AR : File - DB Comparision Report\u003c/B\u003e\u003c/font\u003e\t\t\t\t\t");
formatter.write("\nCurrent Element :dlg_ar_transaction");
formatter.write("----------------------------");
formatter.write("\t\t\t\t\t Maintainable Lookup \t\t\t\t\t");
formatter.write("-------------------------------------------------------------------------------------------------------------------");
formatter.write("\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eSystem Maintainable Field Name\u003c/B\u003e\u003c/font\u003e\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eLookUp Value\u003c/B\u003e\u003c/font\u003e\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eDB value\u003c/B\u003e\u003c/font\u003e\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eSTATUS\u003c/B\u003e\u003c/font\u003e\t\t\t\t");
formatter.write("-------------------------------------------------------------------------------------------------------------------");
formatter.write("id \t\t\t\t\t25857104\t\t\t\t25857104\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("conversion_type \t\t\tUser\t\t\t\t\tUser\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("conversion_rate\t\t\t\t1\t\t\t\t\t1\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("batch_source_name \t\t\tRBS AQU recoveries\t\t\tRBS AQU recoveries\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("interface_line_context\t\t\tAQU CLAIMS INVOICE\t\t\tAQU CLAIMS INVOICE\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("attribute_category\t\t\tAQU CLAIMS INVOICE\t\t\tAQU CLAIMS INVOICE\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("header_attribute_category\t\tAQU CLAIMS INVOICE\t\t\tAQU CLAIMS INVOICE\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("orig_system_bill_address_ref \t\t874501\t\t\t\t\t874501\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("orig_system_bill_customer_ref \t\t5157708\t\t\t\t\t5157708\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("quantity \t\t\t\t1\t\t\t\t\t1\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("quantity_ordered \t\t\t1\t\t\t\t\t1\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("set_of_books_id \t\t\t2021\t\t\t\t\t2021\t\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("tax_rate_code\t\t\t\tSTANDARD VAT\t\t\t\tSTANDARD VAT\t\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePASS\u003c/B\u003e\u003c/font\u003e");
formatter.write("\nCurrent Element :dlg_ar_transaction");
formatter.write("----------------------------");
formatter.write("---------------------------------------------------------------------------------------------------------------");
formatter.write("\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003eTOTAL PASS VERIFICATION\u003c/B\u003e\u003c/font\u003e:\t\t\t13\t\t\u003cfont color \u003d\"#0E1FED\"\u003e\u003cB\u003ePassed\u003c/B\u003e\u003c/font\u003e\t:13\t\t\t\u003cfont color \u003d\"#ff1a1a\"\u003e\u003cB\u003eFailed\u003c/B\u003e\u003c/font\u003e\t:0");
formatter.write("---------------------------------------------------------------------------------------------------------------");
formatter.match({
  "location": "ARLookUpValue.validateTheLookUpValuesInTargetTable()"
});
formatter.result({
  "status": "passed"
});
formatter.after({
  "status": "passed"
});
});