import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
        strict = true,
        features = {"D:/Workspace/EVO-TestAutomation/src/test/resources/features/Ebuz/Test.feature"},
        plugin = {"json:D:/Workspace/EVO-TestAutomation/target/cucumber_reports/regression_results/1.json", "html:D:/Workspace/EVO-TestAutomation/target/cucumber_reports/regression_results/1", "junit:D:/Workspace/EVO-TestAutomation/target/cucumber_reports/regression_results/1.xml", "rerun:D:/Workspace/EVO-TestAutomation/target/cucumber_reports/regression_results/1.txt"},
        monochrome = true,
        tags = {"@ARFileCompare"},
        glue = {"co.uk.directlinegroup.evo.step_definitions", "co.uk.directlinegroup.evo.hooks"})
public class Test_Parallel01Test {
}
