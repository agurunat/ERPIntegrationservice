package co.uk.directlinegroup.evo.step_definitions;

import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;


public class AR_Param {

    String xmlId = null;
    String csvSplitBy = ",";
    private File inputFile;
    private Scenario scenario;
    String filename = "ARConcatenateTagFileCompare.csv";

    int pass_count = 0;
    int fail_count = 0;
    String Pass = "<font color =\"#0E1FED\"><B>PASS</B></font>";
    String Fail = "<font color =\"#ff1a1a\"><B>FAIL</B></font>";
    String v_pass = "<font color =\"#0E1FED\"><B>Passed</B></font>";
    String v_fail = "<font color =\"#ff1a1a\"><B>Failed</B></font>";
    String Total_Pass = "<font color =\"#0E1FED\"><B>TOTAL VERIFICATION</B></font>";
    String reportHeader = "<font color =\"#0E1FED\"><B>Aquarium AR : File - DB Comparision Report</B></font>";

    String fieldname = "<font color =\"#0E1FED\"><B>Field Name</B></font>";
    String SourceValue = "<font color =\"#0E1FED\"><B>Source Value</B></font>";
    String dbvalue = "<font color =\"#0E1FED\"><B>DB value</B></font>";
    String status = "<font color =\"#0E1FED\"><B>STATUS</B></font>";


    @Before()
    public void before(Scenario scenario) {
        this.scenario = scenario;
    }



    /*@Given("^Select the source file \"([^\"]*)\"$")
    public File selectTheSourceFileXmlFile(String XmlSourcefile) throws Throwable {
        inputFile = new File(XmlSourcefile);
        return inputFile;
    }

    @When("^select the dbFile\"([^\"]*)\"$")
    public void selectTheDbFileCsvFile(String csvFile) throws Throwable {
        Scanner out = new Scanner(new BufferedReader(new FileReader(csvFile)));
    }*/

    @Given("^Select the source file 'C:\\\\Test\\\\AR_Trans.xml'$")
    public File selectTheSourceFileXmlFile(String XmlSourcefile) throws Throwable {
        inputFile = new File(XmlSourcefile);
        return inputFile;

    }

    /*@Given("^Select the source file \"([^\"]*)\"$")
    public File select_the_source_file_C_Test_AR_Trans_xml(String XmlSourcefile) throws Exception {
        inputFile = new File(XmlSourcefile);
        return inputFile;
    }*/

    @When("^select the dbFile\"([^\"]*)\"$")
    public void select_the_dbFile_C_Test_AR_CSV_ARConcatenateTagFileCompare_csv(String csvFile) throws Exception {
        try (Scanner out = new Scanner(new BufferedReader(new FileReader(csvFile)))) {
        }catch(Exception e){
            e.printStackTrace();
        }
    }


    @Then("^Congatenate xml values and validate against csv file$")
    public void congatenateXmlValuesAndValidateAgainstCsvFile() throws Throwable {
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(inputFile);
        doc.getDocumentElement().normalize();

        //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
        NodeList nList = doc.getElementsByTagName("dlg_ar_transaction");
        //scenario.write("Root element :" + doc.getDocumentElement().getNodeName());
        //System.out.println("----------------------------");
        scenario.write("\t\t\t\t\t"+reportHeader+ "\t\t\t\t\t");
        scenario.write("File Name   :\t\t" + filename);

        for (int j = 0; j < nList.getLength(); j++) {
            Node nNode = nList.item(j);
            System.out.println("\nCurrent Element :" + nNode.getNodeName());
            scenario.write("\nCurrent Element :" + nNode.getNodeName());
            scenario.write("----------------------------");
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                String xmlId = eElement
                        .getElementsByTagName("id")
                        .item(0)
                        .getTextContent();

                // --------- Read the csv file ------------------
                Scanner out = new Scanner(new BufferedReader(new FileReader("C:\\Test\\AR_CSV\\ARConcatenateTagFileCompare.csv")));
                while (out.hasNextLine()) {
                    String data = out.nextLine();
                    String[] value = data.split(csvSplitBy);
                    for (int csv = 0; csv < value.length; csv++) {
                        if (value[csv].equals(xmlId)) {
                            //------------ validate id tag ---------------
                            String xmlID = eElement
                                    .getElementsByTagName("id")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("XML id validation:- Source id is matching with CSV value", value[csv].equals(xmlID));
                            if (value[csv].equals(xmlID)) {
                                System.out.println("XML id :-" + xmlID + " is matching with CSV File:-" + value[csv] + " ------------ > PASS");
                                scenario.write("-------------------------------------------------------------------------------------------------------------------");
                                scenario.write(fieldname + " \t\t\t\t" + SourceValue + "\t\t\t\t" + dbvalue + " \t\t\t" + status + "\t\t\t");
                                scenario.write("-------------------------------------------------------------------------------------------------------------------");
                                scenario.write("id      \t\t\t\t" + xmlID + "      \t\t\t\t  " + value[csv] + "\t\t\t" + Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("id is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("id      \t\t\t\t" + xmlID + "      \t\t\t\t  " + value[csv] + "\t\t\t FAIL");
                            }
                        /*
                            //------------ validate Base Currency Amount  ---------------
                            String xmlbaseCurrencyAmount = eElement
                                    .getElementsByTagName("base_currency_amount")
                                    .item(0)
                                    .getTextContent();

                            if (value[csv].equals(eElement
                                    .getElementsByTagName("base_currency_amount")
                                    .item(0)
                                    .getTextContent())) {
                                System.out.println("XML Base Currency Amount :-" + xmlbaseCurrencyAmount + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("XML Base Currency Amount :-" + xmlbaseCurrencyAmount + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                csv++;
                            } else {
                                //System.out.println("Base Currency Amount is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("XML Base Currency Amount :-" + xmlbaseCurrencyAmount + " is not matching with CSV File:-" + value[csv] + " ----- > FAIL");
                            }

                            //------------ validate Currency cd  ---------------
                            String xmlcurrencyCode = eElement
                                    .getElementsByTagName("currency_cd")
                                    .item(0)
                                    .getTextContent();

                            if (value[csv].equals(eElement
                                    .getElementsByTagName("currency_cd")
                                    .item(0)
                                    .getTextContent())) {
                                System.out.println("XML Currency cd :-" + xmlcurrencyCode + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("XML Currency cd :-" + xmlcurrencyCode + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                csv++;
                            } else {
                                System.out.println("Currency cd is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("XML Currency cd :-" + xmlcurrencyCode + " is not matching with CSV File:-" + value[csv] + " ----- > FAIL");
                            }
                        */
                            //------------ validate claim number ---------------
                            String xmlclaimNumber = eElement
                                    .getElementsByTagName("claim_number")
                                    .item(0)
                                    .getTextContent();

                            //------------ validate Transaction id ---------------
                            String xmltransactionId = eElement
                                    .getElementsByTagName("transaction_id")
                                    .item(0)
                                    .getTextContent();
                            String xmlupdateTransID = xmlclaimNumber + xmltransactionId;

                            //----------- CSV transaction value concatenate claim number and transaction id in xml -------
                            if (value[csv].equals(xmlupdateTransID)) {
                                System.out.println("XML Transaction id :-" + xmltransactionId + " is matching concatenated Claim number with CSV File:-" + value[csv] + " ------ > PASS");
                                //scenario.write("XML Transaction id :-" + xmltransactionId + " is matching concatenated Claim number with CSV File:-" + value[csv] + " ------ > PASS");
                                scenario.write("Transaction and Claim Number  \t\t" + xmlupdateTransID + " \t\t\t" + value[csv] + " \t\t" + Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("XML Transaction id :-" + xmltransactionId + " is not matching concatenated Claim number with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("XML Transaction id :-" + xmltransactionId + " is not matching concatenated Claim number with CSV File:-" + value[csv] + " ------ > FAIL");
                            }

                            //------------ validate Transaction id alone ---------------
                            String xmltransactionId1 = eElement
                                    .getElementsByTagName("transaction_id")
                                    .item(0)
                                    .getTextContent();

                            if (value[csv].equals(eElement
                                    .getElementsByTagName("transaction_id")
                                    .item(0)
                                    .getTextContent())) {
                                System.out.println("XML Transaction id :-" + xmltransactionId1 + " is matching with CSV File:-" + value[csv] + " ------------ > PASS");
                                scenario.write("Transaction id \t\t\t\t" + xmltransactionId1 + " \t\t\t\t" + value[csv] + " \t\t\t" + Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("XML Transaction id is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("Transaction id \t\t" + xmltransactionId1 + " \t\t\t" + value[csv] + " \t\t FAIL");
                            }


                            //------------ validate Brand ---------------
                            String xmlbrand = eElement
                                    .getElementsByTagName("brand")
                                    .item(0)
                                    .getTextContent();
                            if (xmlbrand.equals("BIS_Ins")) {
                                xmlbrand = "BIS_Ins";
                                String csvbrand = value[csv];
                                if (csvbrand.equals("NIG_Ins")) {
                                    System.out.println("XML Brand :- " + xmlbrand + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                    scenario.write("Brand \t\t\t\t\t" + xmlbrand + " \t\t\t" + value[csv] + " \t\t\t" + Pass);
                                    csv++;
                                    pass_count++;
                                }
                            } else if (value[csv].equals(xmlbrand)) {
                                System.out.println("XML Brand :- " + xmlbrand + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                scenario.write("Brand \t\t\t\t\t" + xmlbrand + " \t\t\t\t" + value[csv] + " \t\t\t" + Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("Brand is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("Brand \t\t\t" + xmlbrand + " \t\t\t" + value[csv] + " \t\t FAIL");
                            }

                            /*---------- trx_number -------------
                                    claim_number || '~' || cr_dat.transaction_id
                             */

                            String trx_number = xmlclaimNumber + "~" + xmltransactionId;
                            if (value[csv].equals(trx_number)) {
                                System.out.println("XML Transaction id :-" + trx_number + " is matching concatenated Claim number with CSV File:-" + value[csv] + " ------ > PASS");
                                //scenario.write("XML Transaction id :-" + xmltransactionId + " is matching concatenated Claim number with CSV File:-" + value[csv] + " ------ > PASS");
                                scenario.write("trx_number  \t\t\t\t" + trx_number + " \t\t\t" + value[csv] + " \t\t" + Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("XML Transaction id :-" + trx_number + " is not matching concatenated Claim number with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("trx_number  \t\t\t" + trx_number + " \t\t\t" + value[csv] + " \t\t FAIL");
                            }

                            /*---------- cust_trx_type_name -------------
                                    product||'~'||product_type||'~'||transaction_type'~'||0||'~'||'N'
                             */

                            String xmlproduct = eElement
                                    .getElementsByTagName("product")
                                    .item(0)
                                    .getTextContent();

                            String xmlproductType = eElement
                                    .getElementsByTagName("product_type")
                                    .item(0)
                                    .getTextContent();
                            String xmltransaction_type = eElement
                                    .getElementsByTagName("transaction_type")
                                    .item(0)
                                    .getTextContent();

                            String cust_trx_type_name = xmlproduct + "~" + xmlproductType + "~" + xmltransaction_type + "~" + 0 + "~" + 'N';
                            if (value[csv].equals(cust_trx_type_name)) {
                                System.out.println("XML Transaction id :-" + cust_trx_type_name + " is matching concatenated Claim number with CSV File:-" + value[csv] + " ------ > PASS");
                                scenario.write("cust_trx_type_name  \t\t" + cust_trx_type_name + " \t\t" + value[csv] + " \t\t" + Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("XML Transaction id :-" + cust_trx_type_name + " is not matching concatenated Claim number with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("cust_trx_type_name  \t\t" + cust_trx_type_name + " \t\t" + value[csv] + " \t\t" + Fail);
                                csv++;
                                fail_count++;
                            }

                        }
                    }
                }
            }
        }
        int tot_count =  pass_count+fail_count;
        scenario.write("---------------------------------------------------------------------------------------------------------------");
        scenario.write(Total_Pass + ": \t\t\t" + tot_count + "\t\t" + v_pass+"\t:" + pass_count +"\t\t\t" + v_fail+ "\t:" + fail_count);
        scenario.write("---------------------------------------------------------------------------------------------------------------");

    }



}
