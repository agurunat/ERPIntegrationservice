package pages;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class Travel_Reserve {

    static Statement SQLstmt_fsh = null;
    static Statement SQLstmt_isci = null;
    static ResultSet SQLResultset_fsh = null;
    static ResultSet SQLResultset_icsi = null;
    DecimalFormat df2 = new DecimalFormat(".##");
    public static HTML_Report_Generation report_generation;


    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, SQLException, ParseException {

        int direct_map_row = 1;
        int cons_stg_map_row = 1;
        int lookup_map_row = 1;
        int count = 0;
        String db_stg_reversal_indicator = null;
        int TO_table_map_row = 1;
        int EBS_table_row = 1;
        report_generation = new HTML_Report_Generation();
        DBconnectivity db = new DBconnectivity();


        // Conslidation table  initialisation
        String db_GL_ID = null;
        String db_source = null;
		String db_event_id = null;
		String db_underwriter = null;
        String db_claim_number = null;
        String db_brand = null;
        String db_product_type = null;
		String db_product = null;
		String db_channel = null;
		String db_transaction_date = null;
        String db_currency = null;
        String db_accident_year= null;
        String db_exchange_rate = null;
        String db_exchange_rate_type = null;
        String db_transaction_amount = null;
        String db_base_currency_amount = null;
		String db_claim_number = null;
		String db_policy_term_months = null;
   //    String db_reverses_flag= null;
        
 
        // XML data initialisation
        String GL_ID = null;
        String source = null;
        String claim_number;
        String underwriter;
        String brand;
        String product_type;
        String channel;
        String event_id;
        String transaction_date;
        String product;
        String transaction_amount;
        String currency_code;
        String exchange_rate;
        String exchange_rate_type;
        String base_currency_amount;
        String accident_year= null;
        String policy_term_months=null;


        //Staging table initialisation
        String db_stg_CC_HEADER_ID;
        String db_stg_SOURCE;
		String db_stg_SOURCE_EVENT_ID;
		String db_stg_UNDERWRITER;
		String db_stg_BRAND;
		String db_stg_PRODUCT_TYPE;
		String db_stg_PRODUCT;
		String db_stg_CHANNEL;
		String db_stg_TRANSACTION_DATE;
		String db_stg_CURRENCY_CODE;
		String db_stg_FSH_ATTRIBUTE_01;
		String db_stg_EXCHANGE_RATE;
        String db_stg_EXCHANGE_RATE_TYPE;
		String db_stg_TRANSACTION_AMOUNT;
		String db_stg_BASE_CURRENCY_AMOUNT;
		String db_stg_CLAIM_NUMBER;
		
/* To be reviewed
        String db_stg_POLICY_NUMBER;
        String db_stg_LINE_OF_BUSINESS;
        String db_stg_LOSS_DATE;
        String db_stg_EVENT_CODE;
        String db_stg_ENTITY_TYPE_CODE;
        String db_stg_reverses_flag;
        String db_dummary_flag;         */

        List<String> filename_list = new ArrayList<String>();
        String field_split = ",";
        String SIT1_url = "null";
        String SIT1_user_name = "null";
        String SIT1_password = "null";
        String ICSI_URL = "null";
        String ICSI_User_name = "null";
        String ICSI_password = "null";

        // --------- fetch the source files -------------
        String path = "C:\\Test\\Phase 2\\Travel_Reserve\\";
        File[] files = new File(path).listFiles();
        String URL_ICSI = "jdbc:oracle:thin:@dcn2ddbx340.gwd.grpinf.net:1618:ICSI";
        String Username_ICSI = "apps";
        String password_ICSI = "apps4icsi";
       /*List<String> database_data = db.read_data();
        SIT1_url= database_data.get(2);
        SIT1_user_name = database_data.get(1);
        SIT1_password = database_data.get(2);
        ICSI_URL = database_data.get(3);
        ICSI_User_name = database_data.get(4);
        ICSI_password = database_data.get(5);*/
        report_generation.clean_report("Travel RESERVE");

        for (File file : files) {
            if (file.isFile()) {
                filename_list.add(file.getName());
                System.out.println("Total number of files" + filename_list.size());
            } else {
                System.out.println("File Not found exception");
                System.exit(1);
            }

        }

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        Connection connection = null;
        Connection connection_icsi = null;

        try {
           /* connection = DriverManager.getConnection(
                    "jdbc:oracle:thin:@dcn2ddbx007z.gwd.grpinf.net:1521/FSHTSIT1", "FSH_ORA_DATA", "FSH_SIT1_DATA");*/
            connection = DriverManager.getConnection(
                    "jdbc:oracle:thin:@172.30.235.67:1521/FSHDTST3", "FSH_ORA_DATA", "Development_Test3");
            connection_icsi = DriverManager.getConnection(
                    URL_ICSI, Username_ICSI, password_ICSI);
            SQLstmt_fsh = connection.createStatement();
            SQLstmt_isci = connection_icsi.createStatement();
            System.out.println("Connection established");
        } catch (SQLException e) {
            e.printStackTrace();
        }


        for (String file_list : filename_list) {

            //initialising Array

            List<String> section2_list_results = new ArrayList<String>();
            List<String> final_list_results = new ArrayList<String>();
            List<String> section1_list_results = new ArrayList<String>();
            List<String> section3_list_results = new ArrayList<String>();
            List<String> section4_list_results = new ArrayList<String>();
            List<String> section5_list_results = new ArrayList<String>();
            List<String> section6_list_results = new ArrayList<String>();
            List<String> list1 = new ArrayList<String>();
            String db_cons_status;

            String inputFile = path + file_list;
            System.out.println("Input file in processing is" + inputFile);

            System.out.println("********************************************");

            boolean sec3flag = true;
            String db_STG_ACTL_RCDS = null;
            Integer db_STG_ACTL_RCDS1 = 0;
            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT COUNT(CC_HEADER_ID) as STG_ACTL_RCDS FROM DLG_FSH_CONS_AQUA_GL_RES_HDR WHERE FILE_NAME = '" + file_list + "'");
            while (SQLResultset_fsh.next()) {
                db_STG_ACTL_RCDS = SQLResultset_fsh.getString("STG_ACTL_RCDS");
                db_STG_ACTL_RCDS1 = SQLResultset_fsh.getInt("STG_ACTL_RCDS");
                System.out.println("stag count ----" + db_STG_ACTL_RCDS);
            }

            if (db_STG_ACTL_RCDS1 == 0) {  //--- Zero record validation
                sec3flag = false;
                String pc_stg_header_line = 1 + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_AGG_ACTUAL_HEADER DB Does not have any records" + ",Fail";
                section3_list_results.add(pc_stg_header_line);
            }
            if (sec3flag) {
                do {
                    SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT COUNT(a.CC_HEADER_ID) AS STG_EXP_SUM_HDRS FROM ( SELECT CC_HEADER_ID,row_number() over(partition BY SOURCE,UNDERWRITER,LINE_OF_BUSINESS,BRAND,CHANNEL,PRODUCT_TYPE,TRANSACTION_DATE,LOSS_DATE,PRODUCT,EXCHANGE_RATE_TYPE,SOURCE_EVENT_ID,FILE_NAME,RESERVES_FLAG ORDER BY SOURCE,UNDERWRITER,LINE_OF_BUSINESS,BRAND,CHANNEL,PRODUCT_TYPE,TRANSACTION_DATE,LOSS_DATE,PRODUCT,EXCHANGE_RATE_TYPE,SOURCE_EVENT_ID,FILE_NAME,RESERVES_FLAG) row_1 FROM DLG_FSH_STG_COMM_CC_HDR WHERE FILE_NAME = '" + file_list + "')a WHERE a.row_1 = 1");
                    while (SQLResultset_fsh.next()) {
                        String STG_EXP_SUM_HDRS = SQLResultset_fsh.getString("STG_EXP_SUM_HDRS");
                        SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT count(TOH_ID)as STG_AGG_ACTUAL_HEADER FROM DLG_FSH_STG_COMM_CC_AGG_HDR WHERE FILE_NAME = '" + file_list + "'");
                        while (SQLResultset_fsh.next()) {
                            String STG_AGG_ACTUAL_HEADER = SQLResultset_fsh.getString("STG_AGG_ACTUAL_HEADER");
                            System.out.println("stag actual header count ----" + STG_AGG_ACTUAL_HEADER);
                            if (STG_EXP_SUM_HDRS.equals(STG_AGG_ACTUAL_HEADER)) {
                                String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Pass";
                                section3_list_results.add(pc_stg_header_line);
                            } else {
                                String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Fail";
                                section3_list_results.add(pc_stg_header_line);
                            }
                            /* else {
                                if (STG_EXP_SUM_HDRS.equals(STG_AGG_ACTUAL_HEADER)) {
                                    String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Pass";
                                    section3_list_results.add(pc_stg_header_line);
                                } else {
                                    String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Fail";
                                    section3_list_results.add(pc_stg_header_line);
                                }

                            }*/
                        }
                    }

                } while (SQLResultset_fsh.next());

            }

            //Section 5 - ICSI Aggregation
            String TOH_ID_CON = null;
            String db_TOH_ID1 = null;

            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT COUNT(TOH_ID)as count FROM DLG_FSH_STG_COMM_CC_AGG_HDR WHERE FILE_NAME = '" + file_list + "' ");
            while (SQLResultset_fsh.next()) {
                Integer COUNT_TOHID = SQLResultset_fsh.getInt("count");
                System.out.println(COUNT_TOHID);
                SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT TOH_ID FROM DLG_FSH_STG_COMM_CC_AGG_HDR WHERE FILE_NAME = '" + file_list + "'");
                while (SQLResultset_fsh.next()) {
                    list1.add(SQLResultset_fsh.getString("TOH_ID"));
                }
                if (COUNT_TOHID == 1) {
                    //TOH_ID_CON = "'" + SQLResultset.getString("TOH_ID") + "'";
                    TOH_ID_CON = "'" + list1.get(0) + "'";
                } else {
                    for (int i = 0; i < list1.size(); i++) {
                        if (i == 0) {
                            TOH_ID_CON = "'" + list1.get(i) + "'" + ",";
                        } else {
                            if (i == list1.size() - 1) {
                                TOH_ID_CON = TOH_ID_CON + "'" + list1.get(i) + "'";
                            } else {
                                TOH_ID_CON = TOH_ID_CON + "'" + list1.get(i) + "'" + ",";
                            }

                        }
                    }
                }
                System.out.println("TOH_ID_CON ------->" + TOH_ID_CON);

            }
            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT TOH_ID FROM DLG_FSH_STG_COMM_CC_AGG_HDR WHERE FILE_NAME = '" + file_list + "' ");
            while (SQLResultset_fsh.next()) {
                db_TOH_ID1 = SQLResultset_fsh.getString("TOH_ID");
            }

            boolean agg_to_flag = true;
            Integer STG_AGG_ACTL_RCDS1 = 0;
            String STG_AGG_ACTL_RCDS = "null";
            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECt COUNT(TOH_ID) as STG_AGG_ACTL_RCDS FROM DLG_FSH_STG_COMM_CC_AGG_HDR WHERE FILE_NAME = '" + file_list + "'");
            while (SQLResultset_fsh.next()) {
                STG_AGG_ACTL_RCDS1 = SQLResultset_fsh.getInt("STG_AGG_ACTL_RCDS");
                STG_AGG_ACTL_RCDS = SQLResultset_fsh.getString("STG_AGG_ACTL_RCDS");
            }
            if (STG_AGG_ACTL_RCDS1 == 0) {
                agg_to_flag = false;
                String pc_stg_header_line = 1 + "," + "STG_AGG_ACTL_RCDS table does not have records. Pls check Batch control table" + "," + "TO_ACTL_RCDS table does not have records. Pls check Batch control table" + "," + "STG_AGG_ACTL_RCDS table does not have records. Pls check Batch control table" + ",Fail";
                section5_list_results.add(pc_stg_header_line);
            }

            if (agg_to_flag) {
                do {
                    SQLResultset_icsi = SQLstmt_isci.executeQuery("SELECT COUNT(TOH_ID) as TO_ACTL_RCDS FROM apps.DLG_FSH_TO_CC WHERE TOH_ID in( " + TOH_ID_CON + ")");
                    while (SQLResultset_icsi.next()) {
                        String TO_ACTL_RCDS = SQLResultset_icsi.getString("TO_ACTL_RCDS");
                        if (STG_AGG_ACTL_RCDS.equals(TO_ACTL_RCDS)) {
                            String pc_stg_header_line = 1 + "," + STG_AGG_ACTL_RCDS + "," + TO_ACTL_RCDS + "," + STG_AGG_ACTL_RCDS + ",Pass";
                            section5_list_results.add(pc_stg_header_line);
                        } else {
                            String pc_stg_header_line = 1 + "," + STG_AGG_ACTL_RCDS + "," + TO_ACTL_RCDS + "," + STG_AGG_ACTL_RCDS + ",Fail";
                            section5_list_results.add(pc_stg_header_line);
                        }
                    }
                } while (SQLResultset_icsi.next());
            }


            //XML File reading

            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            Element ele = doc.getDocumentElement();
            NodeList child_node = ele.getElementsByTagName("cc:dlg_cc_header");
            System.out.println("Length of child node is " + child_node.getLength());

            // Validating data  in CONS table
            for (int i = 0; i < child_node.getLength(); i++) {
                Node Header_fields = child_node.item(i);
                System.out.println("\nCurrent Element :" + Header_fields.getNodeName());
                if (Header_fields.getNodeType() == Node.ELEMENT_NODE) {
                    Element tags = (Element) Header_fields;
                    GL_ID = tags.getElementsByTagName("ns1:gl_id").item(0).getTextContent();
                    source = tags.getElementsByTagName("ns1:source").item(0).getTextContent();
                    //policy_number = tags.getElementsByTagName("cc:policy_number").item(0).getTextContent();
                    claim_number = tags.getElementsByTagName("ns1:claim_number").item(0).getTextContent();
                    underwriter = tags.getElementsByTagName("ns1:underwriter").item(0).getTextContent();
                    brand = tags.getElementsByTagName("ns1:brand").item(0).getTextContent();
                    //line_of_business = tags.getElementsByTagName("cc:line_of_business").item(0).getTextContent();
                    product_type = tags.getElementsByTagName("ns1:product_type").item(0).getTextContent();
                    channel = tags.getElementsByTagName("ns1:channel").item(0).getTextContent();
                    event_id = tags.getElementsByTagName("ns1:event_id").item(0).getTextContent();
                    transaction_date = tags.getElementsByTagName("ns1:transaction_date").item(0).getTextContent();
                    //loss_date = tags.getElementsByTagName("cc:loss_date").item(0).getTextContent();
                    product = tags.getElementsByTagName("ns1:product").item(0).getTextContent();
                    policy_term_months = tags.getElementsByTagName("ns1:policy_term_months").item(0).getTextContent();
                    transaction_amount = tags.getElementsByTagName("ns1:transaction_amount").item(0).getTextContent();
                    currency_code = tags.getElementsByTagName("ns1:currency").item(0).getTextContent();
                    accident_year = tags.getElementsByTagName("ns1:accident_year").item(0).getTextContent();
                    exchange_rate = tags.getElementsByTagName("ns1:exchange_rate").item(0).getTextContent();
                    exchange_rate_type = tags.getElementsByTagName("ns1:exchange_rate_type").item(0).getTextContent();
                    base_currency_amount = tags.getElementsByTagName("ns1:base_currency_amount").item(0).getTextContent();
                    System.out.println("********************************************");

                    System.out.println("Header validation starts here");
                    SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT  * FROM DLG_FSH_CONS_AQUA_GL_RES_HDR  WHERE FILE_NAME = '" + file_list + "' and CC_HEADER_ID = '" + GL_ID + "'");
                    Boolean data_in_DB = true;
                    if (!SQLResultset_fsh.next()) {
                        data_in_DB = false;
                        String header_id = direct_map_row + ",CC_GL_ID," + "CONS Table does not have records. please verify Batch Control table" + "," + GL_ID + ",Fail";
                        section1_list_results.add(header_id);
                        direct_map_row++;
                    }
                    if (data_in_DB) {
                        do {
                            db_GL_ID = SQLResultset_fsh.getString("GL_ID");
                            db_source = SQLResultset_fsh.getString("SOURCE");
							db_event_id = SQLResultset_fsh.getString("EVENT_ID");
							db_underwriter = SQLResultset_fsh.getString("UNDERWRITER");
							db_brand = SQLResultset_fsh.getString("BRAND");
							db_product_type = SQLResultset_fsh.getString("PRODUCT_TYPE");
							db_product = SQLResultset_fsh.getString("PRODUCT");
							db_channel = SQLResultset_fsh.getString("CHANNEL");
							db_transaction_date = SQLResultset_fsh.getString("TRANSACTION_DATE");
							db_currency_code = SQLResultset_fsh.getString("CURRENCY");
							db_accident_year = SQLResultset_fsh.getString("ACCIDENT_YEAR");
							db_exchange_rate = SQLResultset_fsh.getString("EXCHANGE_RATE");
							db_exchange_rate_type = SQLResultset_fsh.getString("EXCHANGE_RATE_TYPE");
							db_transaction_amount = SQLResultset_fsh.getString("TRANSACTION_AMOUNT");
							db_base_currency_amount = SQLResultset_fsh.getString("BASE_CURRENCY_AMOUNT");
							db_claim_number = SQLResultset_fsh.getString("CLAIM_NUMBER");
							db_policy_term_months = SQLResultset_fsh.getString("POLICY_TERM_MONTHS");
							
							
   /* To be reviewed         //db_policy_number = SQLResultset_fsh.getString("POLICY_NUMBER"); 
                            //db_line_of_business = SQLResultset_fsh.getString("LINE_OF_BUSINESS");
                            //db_loss_date = SQLResultset_fsh.getString("LOSS_DATE");
                            db_cons_status = SQLResultset_fsh.getString("STATUS");
                            db_loss_date =  SQLResultset_fsh.getString("LOSS_DATE");  To be reviewed */

                        } while (SQLResultset_fsh.next());

                        if (GL_ID.equals(db_GL_ID)) {
                            String STR_GL_ID = direct_map_row + ",GL_ID," + db_GL_ID + "," + GL_ID + ",Pass";
                            section1_list_results.add(STR_GL_ID);
                            direct_map_row++;
                        } else {
                            String STR_GL_ID = ",GL_ID," + db_GL_ID + "," + GL_ID + ",Fail";
                            section1_list_results.add(STR_GL_ID);
                            direct_map_row++;
                        }
                        if (source.equals(db_source)) {
                            String str_source = ",SOURCE," + db_source + "," + source + ",Pass";
                            section1_list_results.add(str_source);

                        } else {
                            String str_source = ",SOURCE," + db_source + "," + source + ",Fail";
                            section1_list_results.add(str_source);

                        }
                        if (claim_number.equals(db_claim_number)) {
                            String str_claim_number = ",CLAIM_NUMBER," + db_claim_number + "," + claim_number + ",Pass";
                            section1_list_results.add(str_claim_number);

                        } else {
                            String str_claim_number = ",CLAIM_NUMBER," + db_claim_number + "," + claim_number + ",Fail";
                            section1_list_results.add(str_claim_number);

                        }
                        if (underwriter.equals(db_underwriter)) {
                            String str_underwriter = ",UNDERWRITER," + db_underwriter + "," + underwriter + ",Pass";
                            section1_list_results.add(str_underwriter);

                        } else {
                            String str_underwriter = ",UNDERWRITER," + db_underwriter + "," + underwriter + ",Fail";
                            section1_list_results.add(str_underwriter);

                        }
                        if (brand.equals(db_brand)) {
                            String str_brand = ",BRAND," + db_brand + "," + brand + ",Pass";
                            section1_list_results.add(str_brand);

                        } else {
                            String str_brand = ",BRAND," + db_brand + "," + brand + ",Fail";
                            section1_list_results.add(str_brand);

                        }
                        if (product_type.equals(db_product_type)) {
                            String str_product_type = ",PRODUCT_TYPE," + db_product_type + "," + product_type + ",Pass";
                            section1_list_results.add(str_product_type);

                        } else {
                            String str_product_type = ",PRODUCT_TYPE," + db_product_type + "," + product_type + ",Fail";
                            section1_list_results.add(str_product_type);

                        }
                        if (channel.equals(db_channel)) {
                            String str_channel = ",CHANNEL," + db_channel + "," + channel + ",Pass";
                            section1_list_results.add(str_channel);

                        } else {
                            String str_channel = ",CHANNEL," + db_channel + "," + channel + ",Fail";
                            section1_list_results.add(str_channel);

                        }
                        if (event_id.equals(db_event_id)) {
                            String str_event_id = ",EVENT_ID," + db_event_id + "," + event_id + ",Pass";
                            section1_list_results.add(str_event_id);

                        } else {
                            String str_event_id = ",EVENT_ID," + db_event_id + "," + event_id + ",Fail";
                            section1_list_results.add(str_event_id);

                        }
                        if (transaction_date.equals(db_transaction_date)) {
                            String str_transaction_date = ",TRANSACTION_DATE," + db_transaction_date + "," + transaction_date + ",Pass";
                            section1_list_results.add(str_transaction_date);

                        } else {
                            String str_transaction_date = ",TRANSACTION_DATE," + db_transaction_date + "," + transaction_date + ",Fail";
                            section1_list_results.add(str_transaction_date);

                        }
                        if (product.equals(db_product)) {
                            String str_product = ",PRODUCT," + db_product + "," + product + ",Pass";
                            section1_list_results.add(str_product);

                        } else {
                            String str_product = ",PRODUCT," + db_product + "," + product + ",Fail";
                            section1_list_results.add(str_product);

                        }
                        if (transaction_amount.equals(db_transaction_amount)) {
                            String str_transaction_amount = ",TRANSACTION_AMOUNT," + db_transaction_amount + "," + transaction_amount + ",Pass";
                            section1_list_results.add(str_transaction_amount);

                        } else {
                            String str_transaction_amount = ",TRANSACTION_AMOUNT," + db_transaction_amount + "," + transaction_amount + ",Fail";
                            section1_list_results.add(str_transaction_amount);

                        }
                        if (exchange_rate.equals(db_exchange_rate)) {
                            String str_exchange_rate = ",EXCHANGE_RATE," + db_exchange_rate + "," + exchange_rate + ",Pass";
                            section1_list_results.add(str_exchange_rate);

                        } else {
                            String str_exchange_rate = ",EXCHANGE_RATE," + db_exchange_rate + "," + exchange_rate + ",Fail";
                            section1_list_results.add(str_exchange_rate);

                        }
                        if (currency_code.equals(db_currency_code)) {
                            String str_currency_code = ",CURRENCY_CODE," + db_currency_code + "," + currency_code + ",Pass";
                            section1_list_results.add(str_currency_code);

                        } else {
                            String str_currency_code = ",CURRENCY_CODE," + db_currency_code + "," + currency_code + ",Fail";
                            section1_list_results.add(str_currency_code);

                        }
                        if (exchange_rate_type.equals(db_exchange_rate_type)) {
                            String str_exchange_rate_type = ",EXCHANGE_RATE_TYPE," + db_exchange_rate_type + "," + exchange_rate_type + ",Pass";
                            section1_list_results.add(str_exchange_rate_type);

                        } else {
                            String str_exchange_rate_type = ",EXCHANGE_RATE_TYPE," + db_exchange_rate_type + "," + exchange_rate_type + ",Fail";
                            section1_list_results.add(str_exchange_rate_type);

                        }
                        if (base_currency_amount.equals(db_base_currency_amount)) {
                            String str_base_currency_amount = ",BASE_CURRENCY_AMOUNT," + db_base_currency_amount + "," + base_currency_amount + ",Pass";
                            section1_list_results.add(str_base_currency_amount);

                        } else {
                            String str_base_currency_amount = ",BASE_CURRENCY_AMOUNT," + db_base_currency_amount + "," + base_currency_amount + ",Fail";
                            section1_list_results.add(str_base_currency_amount);

                        }
                        if (accident_year.equals(db_accident_year)) {
                            String str_accident_year = ",ACCIDENT YEAR," + db_accident_year + "," + accident_year + ",Pass";
                            section1_list_results.add(str_accident_year);

                        } else {
                            String str_accident_year = ",ACCIDENT YEAR," + db_accident_year + "," + accident_year + ",Fail";
                            section1_list_results.add(str_accident_year);

                        }
                        if (policy_term_months.equals(db_policy_term_months)) {
                            String str_policy_term_months = ",BASE_CURRENCY_AMOUNT," + db_policy_term_months + "," + policy_term_months + ",Pass";
                            section1_list_results.add(str_policy_term_months);

                        } else {
                            String str_policy_term_months = ",BASE_CURRENCY_AMOUNT," + db_policy_term_months + "," + policy_term_months + ",Fail";
                            section1_list_results.add(str_policy_term_months);

                        }
                        String Record_status = "Actual Record Status in FSH : " + db_cons_status;
                        section1_list_results.add(Record_status);

                    }


                }

                //Cons to stage validation
                SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT *  from DLG_FSH_STG_COMM_CC_HDR WHERE FILE_NAME = '" + file_list + "' and CC_HEADER_ID = '" + GL_ID + "'");
                boolean stg_flag = true;

                if (!SQLResultset_fsh.next()) {
                    stg_flag = false;
                    if (GL_ID != null) {
                        String stg_header_id = lookup_map_row + ",CC_GL_ID," + "Staging DB Does not have any records. please verify in the Batch Control table" + "," + GL_ID + ",Fail";
                        section2_list_results.add(stg_header_id);
                        lookup_map_row++;
                    } else {
                        String stg_header_id = lookup_map_row + ",CC_GL_ID," + "Staging Table Does not have any records. please verify in the Batch Control table" + "," + "Cons table Does not have any records. please verify in the Batch Control table" + ",Fail";
                        section2_list_results.add(stg_header_id);
                        lookup_map_row++;
                    }
                }

                if (stg_flag) {

                    do {
                        db_stg_CC_HEADER_ID = SQLResultset_fsh.getString("CC_HEADER_ID");
                        db_stg_SOURCE = SQLResultset_fsh.getString("SOURCE");
						db_stg_SOURCE_EVENT_ID = SQLResultset_fsh.getString("SOURCE_EVENT_ID");
						db_stg_UNDERWRITER = SQLResultset_fsh.getString("UNDERWRITER");
						db_stg_BRAND = SQLResultset_fsh.getString("BRAND");
						db_stg_PRODUCT_TYPE = SQLResultset_fsh.getString("PRODUCT_TYPE");
						db_stg_PRODUCT = SQLResultset_fsh.getString("PRODUCT");
						db_stg_CHANNEL = SQLResultset_fsh.getString("CHANNEL");
						db_stg_TRANSACTION_DATE = SQLResultset_fsh.getString("TRANSACTION_DATE");
						db_stg_CURRENCY_CODE = SQLResultset_fsh.getString("CURRENCY_CODE");
						db_stg_FSH_ATTRIBUTE_01 = SQLResultset_fsh.getString("FSH_ATTRIBUTE_01");
						db_stg_EXCHANGE_RATE = SQLResultset_fsh.getString("EXCHANGE_RATE");
                        db_stg_EXCHANGE_RATE_TYPE = SQLResultset_fsh.getString("EXCHANGE_RATE_TYPE");
						db_stg_TRANSACTION_AMOUNT = SQLResultset_fsh.getString("TRANSACTION_AMOUNT");
						db_stg_BASE_CURRENCY_AMOUNT = SQLResultset_fsh.getString("BASE_CURRENCY_AMOUNT");
						db_stg_CLAIM_NUMBER = SQLResultset_fsh.getString("CLAIM_NUMBER");
						
 /* To be reviewed      //db_stg_POLICY_NUMBER = SQLResultset_fsh.getString("POLICY_NUMBER");
                        //db_stg_LINE_OF_BUSINESS = SQLResultset_fsh.getString("LINE_OF_BUSINESS");
                        db_stg_LOSS_DATE = SQLResultset_fsh.getString("LOSS_DATE");
                        db_stg_EVENT_CODE = SQLResultset_fsh.getString("EVENT_CODE");
                        db_stg_ENTITY_TYPE_CODE = SQLResultset_fsh.getString("ENTITY_TYPE_CODE");
                        db_stg_reverses_flag = SQLResultset_fsh.getString("RESERVES_FLAG");
                        String db_stg_status = SQLResultset_fsh.getString("STATUS");                  to be reviewed */

                        if (db_GL_ID.equals(db_stg_CC_HEADER_ID)) {
                            String stg_header_id = lookup_map_row + ",CC_HEADER_ID," + db_stg_CC_HEADER_ID + "," + db_GL_ID + ",Pass";
                            section2_list_results.add(stg_header_id);
                            lookup_map_row++;
                        } else {
                            String stg_header_id = lookup_map_row + ",CC_HEADER_ID," + db_stg_CC_HEADER_ID + "," + db_GL_ID + ",Fail";
                            section2_list_results.add(stg_header_id);
                            lookup_map_row++;
                        }

                        if (db_stg_SOURCE.equals(db_source)) {
                            String stg_header_id = ",SOURCE," + db_stg_SOURCE + "," + db_source + ",Pass";
                            section2_list_results.add(stg_header_id);

                        } else {
                            String stg_header_id = ",SOURCE," + db_stg_SOURCE + "," + db_source + ",Fail";
                            section2_list_results.add(stg_header_id);

                        }

                        if (db_stg_CLAIM_NUMBER.equals(db_claim_number)) {
                            String stg_header_id = ",CLAIM_NUMBER," + db_stg_CLAIM_NUMBER + "," + db_claim_number + ",Pass";
                            section2_list_results.add(stg_header_id);

                        } else {
                            String stg_header_id = ",CLAIM_NUMBER," + db_stg_CLAIM_NUMBER + "," + db_claim_number + ",Fail";
                            section2_list_results.add(stg_header_id);

                        }


                        if (db_stg_TRANSACTION_DATE.equals(db_transaction_date)) {
                            String stg_header_id = ",TRANSACTION_DATE," + db_stg_TRANSACTION_DATE + "," + db_transaction_date + ",Pass";
                            section2_list_results.add(stg_header_id);

                        } else {
                            String stg_header_id = ",TRANSACTION_DATE," + db_stg_TRANSACTION_DATE + "," + db_transaction_date + ",Fail";
                            section2_list_results.add(stg_header_id);

                        }

                        if (db_stg_LOSS_DATE.equals(db_loss_date)) {
                            String stg_header_id = ",LOSS_DATE," + db_stg_LOSS_DATE + "," + db_loss_date + ",Pass";
                            section2_list_results.add(stg_header_id);

                        } else {
                            String stg_header_id = ",LOSS_DATE," + db_stg_LOSS_DATE + "," + db_loss_date + ",Fail";
                            section2_list_results.add(stg_header_id);

                        }


                        if (db_stg_TRANSACTION_AMOUNT.equals(db_transaction_amount)) {
                            String stg_header_id = ",TRANSACTION_AMOUNT," + db_stg_TRANSACTION_AMOUNT + "," + db_transaction_amount + ",Pass";
                            section2_list_results.add(stg_header_id);

                        } else {
                            String stg_header_id = ",TRANSACTION_AMOUNT," + db_stg_TRANSACTION_AMOUNT + "," + db_transaction_amount + ",Fail";
                            section2_list_results.add(stg_header_id);

                        }

                        if (db_stg_EXCHANGE_RATE.equals(db_exchange_rate)) {
                            String stg_header_id = ",EXCHANGE_RATE," + db_stg_EXCHANGE_RATE + "," + db_exchange_rate + ",Pass";
                            section2_list_results.add(stg_header_id);

                        } else {
                            String stg_header_id = ",EXCHANGE_RATE," + db_stg_EXCHANGE_RATE + "," + db_exchange_rate + ",Fail";
                            section2_list_results.add(stg_header_id);

                        }

                        if (db_stg_EXCHANGE_RATE_TYPE.equals(db_exchange_rate_type)) {
                            String stg_header_id = ",EXCHANGE_RATE_TYPE," + db_stg_EXCHANGE_RATE_TYPE + "," + db_exchange_rate_type + ",Pass";
                            section2_list_results.add(stg_header_id);

                        } else {
                            String stg_header_id = ",EXCHANGE_RATE_TYPE," + db_stg_EXCHANGE_RATE_TYPE + "," + db_exchange_rate_type + ",Fail";
                            section2_list_results.add(stg_header_id);

                        }

                        if (db_stg_BASE_CURRENCY_AMOUNT.equals(db_base_currency_amount)) {
                            String stg_header_id = ",BASE_CURRENCY_AMOUNT," + db_stg_BASE_CURRENCY_AMOUNT + "," + db_base_currency_amount + ",Pass";
                            section2_list_results.add(stg_header_id);

                        } else {
                            String stg_header_id = ",BASE_CURRENCY_AMOUNT," + db_stg_BASE_CURRENCY_AMOUNT + "," + db_base_currency_amount + ",Fail";
                            section2_list_results.add(stg_header_id);

                        }
                        if (db_stg_FSH_ATTRIBUTE_01.equals(db_accident_year)) {
                            String stg_fsh_attribute_01 = ",FSH_ATTRIBUTE_01," + db_stg_FSH_ATTRIBUTE_01 + "," + db_accident_year + ",Pass";
                            section2_list_results.add(stg_fsh_attribute_01);

                        } else {
                            String stg_fsh_attribute_01 = ",FSH_ATTRIBUTE_01," + db_stg_FSH_ATTRIBUTE_01 + "," + db_accident_year + ",Fail";
                            section2_list_results.add(stg_fsh_attribute_01);

                        }


                        //Lookup Validation

                        String db_source_event_id = "null";
                        String db_lookup_underWriter = "null";
                        String db_lookup_brand = "null";
                        //String db_lookup_line_of_business = "null";
                        String db_lookup_product_TYPE = "null";
                        String db_lookup_channel = "null";
                        String db_lookup_event_Id = "null";
                        String db_lookup_product = "null";
                        String db_lookup_currency_code = "null";
                        String db_lookup_event_code = null;
                        String db_loopkup_entity_type_code = null;
                        String db_reserves_flag = null;
                        String db_loss_date = null;
                        String db_lookup_transaction_date = null;

						//------------------------ UNDERWRITER Validation -----------------
                        SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = " + db_underwriter + " and LOOKUP_TYPE = 'underwriter' and System = 'AQUA' and pattern = 'GLReserves'");
                        while (SQLResultset_fsh.next()) {
                            db_lookup_underWriter = SQLResultset_fsh.getString("MEANING");

                        }
                        if (db_lookup_underwriter.equals(null)) {
                            String lookup_underwriter_meaning = ",UNDERWRITER lookup," + "LookUp value not found" + "," + db_stg_underwriter + ",Fail";
                            section2_list_results.add(lookup_underwriter_meaning);
                        } else if (db_lookup_underWriter != null) {
                            if (db_lookup_underWriter.equals(db_stg_underwriter)) {
                                String lookup_underwriter_meaning = ",UNDERWRITER lookup," + db_lookup_underwriter + "," + db_stg_underwriter + ",Pass";
                                section2_list_results.add(lookup_underwriter_meaning);

                            } else {
                                String lookup_underwriter_meaning = ",UNDERWRITER lookup," + db_lookup_underwriter + "," + db_stg_underwriter + ",Fail";
                                section2_list_results.add(lookup_underwriter_meaning);

                            }
                        }
						//------------------------ TRANSACTION_DATE Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE TRUNC(TRANSACTION_DATE) = TRUNC('" + db_transaction_date + "') and LOOKUP_TYPE = 'TRANSACTION_DATE' and System = 'AQUA' and pattern = 'GLBilling'");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_transaction_date_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_transaction_date_meaning.equals("null")) {
                                                String lookup_transaction_date_meaning = ",TRANSACTION_DATE LOOKUP," + "LookUp value not found" + "," + db_stg_transaction_date + ",Fail";
                                                section2_list_results.add(lookup_transaction_date_meaning);
                                            } else if (db_lookup_transaction_date_meaning != null) {
                                                if (db_lookup_transaction_date_meaning.equals(db_stg_transaction_date)) {
                                                    String lookup_transaction_date_meaning = ",TRANSACTION_DATE LOOKUP," + db_lookup_transaction_date_meaning + "," + db_stg_transaction_date + ",Pass";
                                                    section2_list_results.add(lookup_transaction_date_meaning);
                                                } else {
                                                    String lookup_transaction_date_meaning = ",TRANSACTION_DATE LOOKUP," + db_lookup_transaction_date_meaning + "," + db_stg_transaction_date + ",Fail";
                                                    section2_list_results.add(lookup_transaction_date_meaning);
                                                }
                                     }
											
                          //------------------------ BRAND Validation -----------------
                        SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_brand + "' and LOOKUP_TYPE = 'brand' and System = 'AQUA' and pattern = 'GLReserves'");
                        while (SQLResultset_fsh.next()) {
                            db_lookup_brand = SQLResultset_fsh.getString("MEANING");

                        }
                        if (db_lookup_brand.equals(null)) {
                            String lookup_brand_meaning = ",Brand lookup," + "LookUp value not found" + "," + db_stg_BRAND + ",Fail";
                            section2_list_results.add(lookup_brand_meaning);
                        } else if (db_lookup_brand != null) {
                            if (db_lookup_brand.equals(db_stg_BRAND)) {
                                String lookup_brand_meaning = ",Brand lookup," + db_lookup_brand + "," + db_stg_BRAND + ",Pass";
                                section2_list_results.add(lookup_brand_meaning);

                            } else {
                                String lookup_brand_meaning = ",Brand lookup," + db_lookup_brand + "," + db_stg_BRAND + ",Fail";
                                section2_list_results.add(lookup_brand_meaning);

                            }
                        }
						
						 //------------------------ LINE_OF_BUSINESS Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_line_of_business + "' and LOOKUP_TYPE = 'LINE_OF_BUSINESS' and System = 'AQUA' and pattern = 'GLReserves'");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_line_of_business_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_line_of_business_meaning.equals("null")) {
                                                String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS LOOKUP," + "LookUp value not found" + "," + db_stg_line_of_business + ",Fail";
                                                section2_list_results.add(lookup_line_of_business_meaning);
                                            } else if (db_lookup_line_of_business_meaning != null) {
                                                if (db_lookup_line_of_business_meaning.equals(db_stg_line_of_business)) {
                                                    String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS LOOKUP," + db_lookup_line_of_business_meaning + "," + db_stg_line_of_business + ",Pass";
                                                    section2_list_results.add(lookup_line_of_business_meaning);
                                                } else {
                                                    String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS LOOKUP," + db_lookup_line_of_business_meaning + "," + db_stg_line_of_business + ",Fail";
                                                    section2_list_results.add(lookup_line_of_business_meaning);
                                                }
                                            }

                        /*SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE UPPER(LOOKUP_CODE) = UPPER('" + db_line_of_business + "') and LOOKUP_TYPE = 'line_of_business' and System = 'AQUA' and pattern = 'GLReserves'");
                        while (SQLResultset_fsh.next()) {
                            db_lookup_line_of_business = SQLResultset_fsh.getString("MEANING");

                        }
                        if (db_lookup_line_of_business.equals(null)) {
                            String lookup_brand_meaning = ",LINE_OF_BUSINESS lookup," + "LookUp value not found" + "," + db_stg_LINE_OF_BUSINESS + ",Fail";
                            section2_list_results.add(lookup_brand_meaning);
                        } else if (db_lookup_line_of_business != null) {
                            if (db_lookup_line_of_business.equals(db_stg_LINE_OF_BUSINESS)) {
                                String lookup_brand_meaning = ",LINE_OF_BUSINESS lookup," + db_lookup_line_of_business + "," + db_stg_LINE_OF_BUSINESS + ",Pass";
                                section2_list_results.add(lookup_brand_meaning);

                            } else {
                                String lookup_brand_meaning = ",LINE_OF_BUSINESS lookup," + db_lookup_line_of_business + "," + db_stg_LINE_OF_BUSINESS + ",Fail";
                                section2_list_results.add(lookup_brand_meaning);

                            }
                        }
                        SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE UPPER(LOOKUP_CODE) = UPPER('" + db_channel + "') and LOOKUP_TYPE = 'channel' and System = 'AQUA' and pattern = 'GLReserves'");
                        while (SQLResultset_fsh.next()) {
                            db_lookup_channel = SQLResultset_fsh.getString("MEANING");

                        }
                        if (db_lookup_channel.equals(null)) {
                            String lookup_brand_meaning = ",Channel lookup," + "LookUp value not found" + "," + db_stg_CHANNEL + ",Fail";
                            section2_list_results.add(lookup_brand_meaning);
                        } else if (db_lookup_channel != null) {
                            if (db_lookup_channel.equals(db_stg_CHANNEL)) {
                                String lookup_brand_meaning = ",Channel lookup," + db_lookup_channel + "," + db_stg_CHANNEL + ",Pass";
                                section2_list_results.add(lookup_brand_meaning);

                            } else {
                                String lookup_brand_meaning = ",Channel lookup," + db_lookup_channel + "," + db_stg_CHANNEL + ",Fail";
                                section2_list_results.add(lookup_brand_meaning);

                            }
                        }*/
						
						//------------------------ PRODUCT_TYPE Validation -----------------
                        SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = " + db_product_type + " and LOOKUP_TYPE = 'product_type' and System = 'AQUA' and pattern = 'GLReserves'");
                        while (SQLResultset_fsh.next()) {
                            db_lookup_product_type = SQLResultset_fsh.getString("MEANING");

                        }
                        if (db_lookup_product_type.equals(null)) {
                            String lookup_product_type_meaning = ",Product Type lookup," + "LookUp value not found" + "," + db_stg_product_type + ",Fail";
                            section2_list_results.add(lookup_product_type_meaning);
                        } else if (db_lookup_product_type != null) {
                            if (db_lookup_product_type.equals(db_stg_product_type)) {
                                String lookup_product_type_meaning = ",Product_Type lookup," + db_lookup_product_type + "," + db_stg_product_type + ",Pass";
                                section2_list_results.add(lookup_product_type_meaning);

                            } else {
                                String lookup_product_type_meaning = ",Product_Type lookup," + db_lookup_product_type + "," + db_stg_product_type + ",Fail";
                                section2_list_results.add(lookup_product_type_meaning);

                            }
                        }
						
						//------------------------ POLICY_NUMBER Validation -----------------
                        SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = " + db_policy_number + " and LOOKUP_TYPE = 'POLICY_NUMBER' and System = 'AQUA' and pattern = 'GLReserves'");
                        while (SQLResultset_fsh.next()) {
                            db_lookup_policy_number = SQLResultset_fsh.getString("MEANING");

                        }
                        if (db_lookup_policy_number.equals(null)) {
                            String lookup_policy_number_meaning = ",POLICY_NUMBER lookup," + "LookUp value not found" + "," + db_stg_policy_number + ",Fail";
                            section2_list_results.add(lookup_policy_number_meaning);
                        } else if (db_lookup_policy_number != null) {
                            if (db_lookup_policy_number.equals(db_stg_policy_number)) {
                                String lookup_policy_number_meaning = ",POLICY_NUMBER lookup," + db_lookup_policy_number + "," + db_stg_policy_number + ",Pass";
                                section2_list_results.add(lookup_policy_number_meaning);

                            } else {
                                String lookup_policy_number_meaning = ",POLICY_NUMBER lookup," + db_lookup_policy_number + "," + db_stg_policy_number + ",Fail";
                                section2_list_results.add(lookup_policy_number_meaning);

                            }
                        }
						
						//------------------------ SUMMARY_FLAG Validation -----------------
                        SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = " + db_summary_flag + " and LOOKUP_TYPE = 'SUMMARISE_DATA_FLAG' and System = 'AQUA' and pattern = 'GLReserves'");
                        while (SQLResultset_fsh.next()) {
                            db_lookup_summary_flag = SQLResultset_fsh.getString("MEANING");

                        }
                        if (db_lookup_summary_flag.equals(null)) {
                            String lookup_summary_flag_meaning = ",SUMMARY_FLAG lookup," + "LookUp value not found" + "," + db_stg_summary_flag + ",Fail";
                            section2_list_results.add(lookup_summary_flag_meaning);
                        } else if (db_lookup_summary_flag != null) {
                            if (db_lookup_summary_flag.equals(db_stg_summary_flag)) {
                                String lookup_summary_flag_meaning = ",SUMMARY_FLAG lookup," + db_lookup_summary_flag + "," + db_stg_summary_flag + ",Pass";
                                section2_list_results.add(lookup_summary_flag_meaning);

                            } else {
                                String lookup_summary_flag_meaning = ",SUMMARY_FLAG lookup," + db_lookup_summary_flag + "," + db_stg_summary_flag + ",Fail";
                                section2_list_results.add(lookup_summary_flag_meaning);

                            }
                        }
                        /*SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE UPPER(LOOKUP_CODE) = UPPER('" + db_channel + "') and LOOKUP_TYPE = 'brand' and System = 'AQUA' and pattern = 'GLReserves'");
                        while (SQLResultset_fsh.next()) {
                            db_lookup_channel = SQLResultset_fsh.getString("MEANING");

                        }
                        if (db_lookup_channel.equals(null)) {
                            String lookup_brand_meaning = ",Channel lookup," + "LookUp value not found" + "," + db_stg_CHANNEL + ",Fail";
                            section2_list_results.add(lookup_brand_meaning);
                        } else if (db_lookup_product_TYPE != null) {
                            if (db_lookup_channel.equals(db_stg_CHANNEL)) {
                                String lookup_brand_meaning = ",Channel lookup," + db_lookup_channel + "," + db_stg_CHANNEL + ",Pass";
                                section2_list_results.add(lookup_brand_meaning);

                            } else {
                                String lookup_brand_meaning = ",Channel lookup," + db_lookup_channel + "," + db_stg_CHANNEL + ",Fail";
                                section2_list_results.add(lookup_brand_meaning);

                            }
                        }*/
						//------------------------ EVENT_CODE Validation -----------------
                        SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = " + db_event_code + " and LOOKUP_TYPE = 'GLEVENTS' and System = 'AQUA' and pattern = 'GLReserves'");
                        while (SQLResultset_fsh.next()) {
                            db_lookup_event_code = SQLResultset_fsh.getString("MEANING");

                        }
                        if (db_lookup_event_code.equals(null)) {
                            String lookup_event_code_meaning = ",EVENT ID lookup," + "LookUp value not found" + "," + db_stg_event_code + ",Fail";
                            section2_list_results.add(lookup_event_code_meaning);
                        } else if (db_lookup_event_code != null) {
                            if (db_lookup_event_code.equals(db_stg_event_code)) {
                                String lookup_event_code_meaning = ",Event_ID lookup," + db_lookup_event_code + "," + db_stg_event_code + ",Pass";
                                section2_list_results.add(lookup_event_code_meaning);

                            } else {
                                String lookup_event_code_meaning = ",Event_ID lookup," + db_lookup_event_code + "," + db_stg_event_code + ",Fail";
                                section2_list_results.add(lookup_event_code_meaning);

                            }
                        }
						
						//------------------------ PRODUCT Validation -----------------
                        SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = " + db_product + " and LOOKUP_TYPE = 'product' and System = 'AQUA' and pattern = 'GLReserves'");
                        while (SQLResultset_fsh.next()) {
                            db_lookup_product = SQLResultset_fsh.getString("MEANING");

                        }
                        if (db_lookup_product.equals(null)) {
                            String lookup_product_meaning = ",PRODUCT LOOKUP," + "LookUp value not found" + "," + db_stg_product + ",Fail";
                            section2_list_results.add(lookup_product_meaning);
                        } else if (db_lookup_product != null) {
                            if (db_lookup_event_Id.equals(db_stg_product)) {
                                String lookup_product_meaning = ",PRODUCT LOOKUP," + db_lookup_product + "," + db_stg_product + ",Pass";
                                section2_list_results.add(lookup_product_meaning);

                            } else {
                                String lookup_product_meaning = ",PRODUCT LOOKUP," + db_lookup_product + "," + db_stg_product + ",Fail";
                                section2_list_results.add(lookup_product_meaning);

                            }
                        }
                      /*  SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE UPPER(LOOKUP_CODE) = UPPER('" + db_stg_EVENT_CODE + "') and LOOKUP_TYPE = EVENT_CODE' and System = 'AQUA' and pattern = 'GLReserves'");
                        while (SQLResultset_fsh.next()) {
                            db_lookup_event_code = SQLResultset_fsh.getString("MEANING");

                        }
                        if (db_lookup_event_code.equals(null)) {
                            String lookup_brand_meaning = ",EVENT_CODE LOOKUP," + "LookUp value not found" + "," + db_stg_CURRENCY_CODE + ",Fail";
                            section2_list_results.add(lookup_brand_meaning);
                        } else if (db_lookup_event_code != null) {
                            if (db_lookup_event_code.equals(db_stg_EVENT_CODE)){
                                String lookup_brand_meaning = ",EVENT_CODE LOOKUP," + db_lookup_event_code + "," + db_stg_EVENT_CODE + ",Pass";
                                section2_list_results.add(lookup_brand_meaning);

                            } else {
                                String lookup_brand_meaning =  ",EVENT_CODE LOOKUP," + db_lookup_event_code + "," + db_stg_EVENT_CODE + ",Fail";
                                section2_list_results.add(lookup_brand_meaning);
                            }
                        }*/
						//------------------------ SOURCE_EVENT_ID Validation -----------------
                       SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = " + db_source_event_id + " and LOOKUP_TYPE = 'GLEVENTS' and System = 'AQUA' and pattern = 'GLReserves'");
                        while (SQLResultset_fsh.next()) {
                            db_lookup_source_event_id = SQLResultset_fsh.getString("MEANING");

                        }
                        if (db_lookup_source_event_id.equals(null)) {
                            String lookup_source_event_id_meaning = ",SOURCE_EVENT_ID," + "LookUp value not found" + "," + db_stg_source_event_id + ",Fail";
                            section2_list_results.add(lookup_source_event_id_meaning);
                        } else if (db_lookup_source_event_id != null) {
                            if (db_lookup_source_event_id.equals(db_stg_source_event_id)) {
                                String lookup_source_event_id_meaning = ",SOURCE_EVENT_ID," + db_lookup_source_event_id + "," + db_stg_source_event_id + ",Pass";
                                section2_list_results.add(lookup_source_event_id_meaning);

                            } else {
                                String lookup_source_event_id_meaning = ",SOURCE_EVENT_ID," + db_lookup_source_event_id + "," + db_stg_source_event_id + ",Fail";
                                section2_list_results.add(lookup_source_event_id_meaning);
                            }
                        }
						//------------------------ EVENT_CODE Validation -----------------
                       SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_CODE = " + db_event_code + " and LOOKUP_TYPE = 'GLEVENTS' and System = 'AQUA' and pattern = 'GLReserves'");
                        while (SQLResultset_fsh.next()) {
                            db_lookup_source_event_id = SQLResultset_fsh.getString("MEANING");

                        }
                        if (db_lookup_source_event_id.equals(null)) {
                            String lookup_source_event_id_meaning = ",EVENT_CODE LOOKUP," + "LookUp value not found" + "," + db_stg_source_event_id + ",Fail";
                            section2_list_results.add(lookup_source_event_id_meaning);
                        } else if (db_lookup_source_event_id != null) {
                            if (db_lookup_source_event_id.equals(db_stg_source_event_id)) {
                                String lookup_source_event_id_meaning = ",EVENT_CODE LOOKUP," + db_lookup_source_event_id + "," + db_stg_source_event_id + ",Pass";
                                section2_list_results.add(lookup_source_event_id_meaning);

                            } else {
                                String lookup_source_event_id_meaning = ",EVENT_CODE," + db_lookup_source_event_id + "," + db_stg_source_event_id + ",Fail";
                                section2_list_results.add(lookup_source_event_id_meaning);
                            }
                        }
                     /* SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE UPPER(LOOKUP_CODE) = UPPER('" + db_stg_SOURCE_EVENT_ID + "') and LOOKUP_TYPE = 'EVENT_CODE' and System = 'AQUA' and pattern = 'GLReserves'");
                        while (SQLResultset_fsh.next()) {
                            db_lookup_event_code = SQLResultset_fsh.getString("MEANING");

                        }
                        if (db_lookup_event_code.equals(null)) {
                            String lookup_event_code_meaning = ",EVENT_CODE LOOKUP," + "LookUp value not found" + "," + db_stg_CURRENCY_CODE + ",Fail";
                            section2_list_results.add(lookup_event_code_meaning);
                        } else if (db_lookup_event_code != null) {
                            if (db_lookup_event_code.equals(db_stg_EVENT_CODE)){
                                String lookup_brand_meaning = ",EVENT_CODE LOOKUP," + db_lookup_event_code + "," + db_stg_EVENT_CODE + ",Pass";
                                section2_list_results.add(lookup_brand_meaning);

                            } else {
                                String lookup_brand_meaning =  ",EVENT_CODE LOOKUP," + db_lookup_event_code + "," + db_stg_EVENT_CODE + ",Fail";
                                section2_list_results.add(lookup_brand_meaning);
                            }
                        }  */
						//------------------------ ENTITY_TYPE_CODE Validation -----------------
                       SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_SYS_LOOKUP_VALUES WHERE LOOKUP_TYPE = 'ENTITY_TYPE_CODE' and System = 'AQUA' and pattern = 'GLReserves'");
                        while (SQLResultset_fsh.next()) {
                            db_loopkup_entity_type_code = SQLResultset_fsh.getString("MEANING");

                        }
                        if (db_loopkup_entity_type_code.equals(null)) {
                            String lookup_entity_type_code_meaning = ",ENTITY_TYPE_CODE LOOKUP," + "LookUp value not found" + "," + db_stg_entity_type_CODE + ",Fail";
                            section2_list_results.add(lookup_entity_type_code_meaning);
                        } else if (db_loopkup_entity_type_code != null) {
                            if (db_loopkup_entity_type_code.equals(db_stg_entity_type_CODE)) {
                                String lookup_entity_type_code_meaning = ",ENTITY_TYPE_CODE LOOKUP," + db_loopkup_entity_type_code + "," + db_stg_entity_type_CODE + ",Pass";
                                section2_list_results.add(lookup_entity_type_code_meaning);

                            } else {
                                String lookup_entity_type_code_meaning = ",ENTITY_TYPE_CODE LOOKUP," + db_loopkup_entity_type_code + "," + db_stg_entity_type_CODE + ",Fail";
                                section2_list_results.add(lookup_entity_type_code_meaning);
                            }
                        }
						//------------------------ CURRENCY_CODE Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE UPPER(LOOKUP_CODE) = UPPER('" + db_currency_code + "') and LOOKUP_TYPE = 'CURRENCY_CODE' and System = 'AQUA' and pattern = 'GLReserves'");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_currency_code_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_currency_code_meaning.equals("null")) {
                                                String lookup_currency_code_meaning = ",CURRENCY_CODE LOOKUP," + "LookUp value not found" + "," + db_stg_currency_code + ",Fail";
                                                section2_list_results.add(lookup_currency_code_meaning);
                                            } else if (db_lookup_currency_code_meaning != null) {
                                                if (db_lookup_currency_code_meaning.equals(db_stg_currency_code)) {
                                                    String lookup_currency_code_meaning = ",CURRENCY_CODE LOOKUP," + db_lookup_currency_code_meaning + "," + db_stg_currency_code + ",Pass";
                                                    section2_list_results.add(lookup_currency_code_meaning);
                                                } else {
                                                    String lookup_currency_code_meaning = ",CURRENCY_CODE LOOKUP," + db_lookup_currency_code_meaning + "," + db_stg_currency_code + ",Fail";
                                                    section2_list_results.add(lookup_currency_code_meaning);
                                                }
                                            }


            //Section 4

            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT COUNT(TOH_ID) as COUNT_TOH_ID FROM DLG_FSH_STG_COMM_CC_AGG_HDR WHERE FILE_NAME = '" + file_list + "' ");
            while (SQLResultset_fsh.next()) {
                count = SQLResultset_fsh.getInt("COUNT_TOH_ID");
            }
            System.out.println("Count of the record is " + count);
            ArrayList<String> list_toh = new ArrayList<String>();
            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT TOH_ID FROM DLG_FSH_STG_COMM_CC_AGG_HDR WHERE FILE_NAME = '" + file_list + "' ");
            for (int j = 0; j < count; j++) {
                while (SQLResultset_fsh.next()) {
                    list_toh.add(SQLResultset_fsh.getString("TOH_ID"));
                }
            }
            for (int k = 0; k < list_toh.size(); k++) {
                SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT * FROM DLG_FSH_STG_COMM_CC_AGG_HDR WHERE TOH_ID = '" + list_toh.get(k) + "' ");
                while (SQLResultset_fsh.next()) {
                    String db_aggregate_toh_id = SQLResultset_fsh.getString("TOH_ID");
					String db_aggregate_source = SQLResultset_fsh.getString("SOURCE");
					String db_aggregate_source_event_id = SQLResultset_fsh.getString("SOURCE_EVENT_ID");
					String db_aggregate_underwriter = SQLResultset_fsh.getString("UNDERWRITER");
					String db_aggregate_brand = SQLResultset_fsh.getString("BRAND");
					String db_aggregate_product_type = SQLResultset_fsh.getString("PRODUCT_TYPE");
					String db_aggregate_product = SQLResultset_fsh.getString("PRODUCT");
					String db_aggregate_channel = SQLResultset_fsh.getString("CHANNEL");
					String db_aggregate_transaction_date = SQLResultset_fsh.getString("TRANSACTION_DATE");
					String db_aggregate_currency_code = SQLResultset_fsh.getString("CURRENCY_CODE");
					String db_aggregate_exchange_rate = SQLResultset_fsh.getString("EXCHANGE_RATE");
                    String db_aggregate_exchange_rate_type = SQLResultset_fsh.getString("EXCHANGE_RATE_TYPE");
					String db_aggregate_base_currency_amount = SQLResultset_fsh.getString("BASE_CURRENCY_AMOUNT");
                    String db_aggregate_policy_number = SQLResultset_fsh.getString("POLICY_NUMBER");
                    String db_aggregate_claim_number = SQLResultset_fsh.getString("CLAIM_NUMBER");
                    String db_aggregate_event_code = SQLResultset_fsh.getString("EVENT_CODE");
                    String db_aggregate_entity_type_code = SQLResultset_fsh.getString("ENTITY_TYPE_CODE");
					String db_aggregate_reverses_flag = SQLResultset_fsh.getString("RESERVES_FLAG");
					String db_aggregate_product_key = SQLResultset_fsh.getString("PRODUCT KEY");
					String db_aggregate_batch_fkey = SQLResultset_fsh.getString("BATCH_FKEY");
                    String db_aggregate_line_of_business = SQLResultset_fsh.getString("LINE_OF_BUSINESS");
					String db_aggregate_summary_flag = SQLResultset_fsh.getString("SUMMARY_FLAG");
                    String db_aggregate_loss_date = SQLResultset_fsh.getString("LOSS_DATE");     
                //    String db_aggregate_transaction_amount = SQLResultset_fsh.getString("TRANSACTION_AMOUNT");
				
                    boolean TO_table_flag = true;
                    SQLResultset_icsi = SQLstmt_isci.executeQuery("SELECT *  from apps.DLG_FSH_TO_CC WHERE TOH_ID = '" + list_toh.get(k) + "'");

                    if (!SQLResultset_icsi.next()) {
                        TO_table_flag = false;
                        String pc_TO_header_line = TO_table_map_row + ",cc_header_id" + "," + db_aggregate_toh_id + "," + "TO table does not have records. please verify Batch control table" + ",Fail";
                        section4_list_results.add(pc_TO_header_line);
                        TO_table_map_row++;
                    }
                    if (TO_table_flag) {
                        SQLResultset_icsi = SQLstmt_isci.executeQuery("SELECT *  from apps.DLG_FSH_TO_CC WHERE TOH_ID = '" + list_toh.get(k) + "'");
                        while (SQLResultset_icsi.next()) {
                            String db_TO_toh_id = SQLResultset_icsi.getString("TOH_ID");
                            String db_to_source = SQLResultset_icsi.getString("SOURCE"); 
							String db_to_source_event_id = SQLResultset_icsi.getString("SOURCE_EVENT_ID");
							String db_to_underwriter = SQLResultset_icsi.getString("UNDERWRITER");
							String db_to_brand = SQLResultset_icsi.getString("BRAND");
							String db_to_product_type = SQLResultset_icsi.getString("PRODUCT_TYPE");
							String db_to_product = SQLResultset_icsi.getString("PRODUCT");
							String db_to_channel = SQLResultset_icsi.getString("CHANNEL");
							String db_to_transaction_date = SQLResultset_icsi.getString("TRANSACTION_DATE");
							String db_to_currency_code = SQLResultset_icsi.getString("CURRENCY_CODE");
							String db_to_exchange_rate = SQLResultset_icsi.getString("EXCHANGE_RATE");
                            String db_to_exchange_rate_type = SQLResultset_icsi.getString("EXCHANGE_RATE_TYPE");
							String db_to_transaction_amount = SQLResultset_icsi.getString("TRANSACTION_AMOUNT");
							String db_to_base_currency_amount = SQLResultset_icsi.getString("BASE_CURRENCY_AMOUNT");
                            String db_to_policy_number = SQLResultset_icsi.getString("POLICY_NUMBER");
                            String db_to_claim_number = SQLResultset_icsi.getString("CLAIM_NUMBER");
                            String db_to_event_code = SQLResultset_icsi.getString("EVENT_CODE");
							String db_to_entity_type_code = SQLResultset_icsi.getString("ENTITY_TYPE_CODE");
                            String db_to_reverses_flag = SQLResultset_fsh.getString("RESERVES_FLAG");
							String db_to_product_key =  SQLResultset_icsi.getString("PRODUCT_KEY");
							String db_to_batch_fkey = SQLResultset_icsi.getString("BATCH_FKEY");
                            String db_to_line_of_business = SQLResultset_icsi.getString("LINE_OF_BUSINESS");
                            String db_to_summary_flag =  SQLResultset_icsi.getString("SUMMARY_FLAG");
                            String db_to_loss_date = SQLResultset_icsi.getString("LOSS_DATE");
							   
    /* To be reviewed       Date db_to_trans_date = SQLResultset_icsi.getDate("TRANSACTION_DATE");
                            Date db_to_loss = SQLResultset_icsi.getDate("LOSS_DATE");
                            String db_to_event_id = SQLResultset_icsi.getString("EVENT_ID");
                            String db_to_creation_date = SQLResultset_icsi.getString("CREATION_DATE");
                            String db_to_last_update_date = SQLResultset_icsi.getString("LAST_UPDATE_DATE");
                            String db_to_source_file_header_id =  SQLResultset_icsi.getString("SOURCE_FILE_HEADER_ID");
                            String db_to_source_file_name =  SQLResultset_icsi.getString("SOURCE_FILE_NAME");
                            String db_to_request_id =  SQLResultset_icsi.getString("REQUEST_ID");             to be reviewed */



                            if (db_aggregate_toh_id.equals(db_TO_toh_id)) {
                                String pc_TO_toh_id = TO_table_map_row + ",TOH_ID" + "," + db_TO_toh_id + "," + db_aggregate_toh_id + ",Pass";
                                section4_list_results.add(pc_TO_toh_id);
                                TO_table_map_row++;
                            } else {
                                String pc_TO_toh_id = TO_table_map_row + ",TOH_ID" + "," + db_TO_toh_id + "," + db_aggregate_toh_id + ",Fail";
                                section4_list_results.add(pc_TO_toh_id);
                                TO_table_map_row++;

                            }

                            if (db_aggregate_source.equals(db_to_source)) {
                                String pc_to_source = ",SOURCE" + "," + db_to_source + "," + db_aggregate_source + ",Pass";
                                section4_list_results.add(pc_to_source);
                            } else {
                                String pc_to_source = ",SOURCE" + "," + db_to_source + "," + db_aggregate_source + ",Fail";
                                section4_list_results.add(pc_to_source);
                            }

                            if (db_aggregate_policy_number.equals(db_to_policy_number)) {
                                String pc_to_underwriter = ",POLICY_NUMBER" + "," + db_to_policy_number + "," + db_aggregate_policy_number + ",Pass";
                                section4_list_results.add(pc_to_underwriter);
                            } else {
                                String pc_to_underwriter = ",POLICY_NUMBER" + "," + db_to_policy_number + "," + db_aggregate_policy_number + ",Fail";
                                section4_list_results.add(pc_to_underwriter);
                            }

                            if (db_aggregate_claim_number.equals(db_to_claim_number)) {
                                String pc_to_underwriter = ",CLAIM_NUMBER" + "," + db_to_claim_number + "," + db_aggregate_policy_number + ",Pass";
                                section4_list_results.add(pc_to_underwriter);
                            } else {
                                String pc_to_underwriter = ",CLAIM_NUMBER" + "," + db_to_claim_number + "," + db_aggregate_policy_number + ",Fail";
                                section4_list_results.add(pc_to_underwriter);
                            }

                            if (db_aggregate_underwriter.equals(db_to_underwriter)) {
                                String pc_to_underwriter = ",UNDERWRITER" + "," + db_to_underwriter + "," + db_aggregate_underwriter + ",Pass";
                                section4_list_results.add(pc_to_underwriter);
                            } else {
                                String pc_to_underwriter = ",UNDERWRITER" + "," + db_to_underwriter + "," + db_aggregate_underwriter + ",Fail";
                                section4_list_results.add(pc_to_underwriter);
                            }

                            if (db_aggregate_brand.equals(db_to_brand)) {
                                String pc_to_brand = ",BRAND" + "," + db_to_brand + "," + db_aggregate_brand + ",Pass";
                                section4_list_results.add(pc_to_brand);
                            } else {
                                String pc_to_brand = ",BRAND" + "," + db_to_brand + "," + db_aggregate_brand + ",Fail";
                                section4_list_results.add(pc_to_brand);
                            }

                            if (db_aggregate_line_of_business.equals(db_to_line_of_business)) {
                                String pc_to_line_of_business = ",LINE_OF_BUSINESS" + "," + db_to_line_of_business + "," + db_aggregate_line_of_business + ",Pass";
                                section4_list_results.add(pc_to_line_of_business);
                            } else {
                                String pc_to_line_of_business = ",LINE_OF_BUSINESS" + "," + db_to_line_of_business + "," + db_aggregate_line_of_business + ",Fail";
                                section4_list_results.add(pc_to_line_of_business);
                            }

                            if (db_aggregate_product_type.equals(db_to_product_type)) {
                                String pc_to_product_type = ",PRODUCT_TYPE" + "," + db_to_product_type + "," + db_aggregate_product_type + ",Pass";
                                section4_list_results.add(pc_to_product_type);
                            } else {
                                String pc_to_product_type = ",PRODUCT_TYPE" + "," + db_to_product_type + "," + db_aggregate_product_type + ",Fail";
                                section4_list_results.add(pc_to_product_type);
                            }

                            if (db_aggregate_channel.equals(db_to_channel)) {
                                String pc_to_channel = ",CHANNEL" + "," + db_to_channel + "," + db_aggregate_channel + ",Pass";
                                section4_list_results.add(pc_to_channel);
                            } else {
                                String pc_to_channel = ",CHANNEL" + "," + db_to_channel + "," + db_aggregate_channel + ",Fail";
                                section4_list_results.add(pc_to_channel);
                            }

                            if (db_aggregate_transaction_date.equals(db_to_transaction_date)) {
                                String pc_to_transaction_date = ",TRANSACTION_DATE" + "," + db_to_transaction_date + "," + db_aggregate_transaction_date + ",Pass";
                                section4_list_results.add(pc_to_transaction_date);
                            } else {
                                String pc_to_transaction_date = ",TRANSACTION_DATE" + "," + db_to_transaction_date + "," + db_aggregate_transaction_date + ",Fail";
                                section4_list_results.add(pc_to_transaction_date);
                            }

                            if (db_aggregate_loss_date.equals(db_to_loss_date)) {
                                String pc_to_transaction_date = ",LOSS_DATE" + "," + db_to_loss_date + "," + db_aggregate_loss_date + ",Pass";
                                section4_list_results.add(pc_to_transaction_date);
                            } else {
                                String pc_to_transaction_date = ",LOSS_DATE" + "," + db_to_loss_date + "," + db_aggregate_loss_date + ",Fail";
                                section4_list_results.add(pc_to_transaction_date);
                            }

                            if (db_aggregate_product.equals(db_to_product)) {
                                String pc_to_transaction_date = ",PRODUCT" + "," + db_to_product + "," + db_aggregate_product + ",Pass";
                                section4_list_results.add(pc_to_transaction_date);
                            } else {
                                String pc_to_transaction_date = ",PRODUCT" + "," + db_to_product + "," + db_aggregate_product + ",Fail";
                                section4_list_results.add(pc_to_transaction_date);
                            }

                            if (db_aggregate_transaction_amount.equals(db_to_transaction_amount)) {
                                String pc_to_transaction_date = ",TRANSACTION_AMOUNT" + "," + db_to_transaction_amount + "," + db_aggregate_transaction_amount + ",Pass";
                                section4_list_results.add(pc_to_transaction_date);
                            } else {
                                String pc_to_transaction_date = ",TRANSACTION_AMOUNT" + "," + db_to_transaction_amount + "," + db_aggregate_transaction_amount + ",Fail";
                                section4_list_results.add(pc_to_transaction_date);
                            }

                            if (db_aggregate_currency_code.equals(db_to_currency_code)) {
                                String pc_to_transaction_date = ",CURRENCY_CODE" + "," + db_to_currency_code + "," + db_aggregate_currency_code + ",Pass";
                                section4_list_results.add(pc_to_transaction_date);
                            } else {
                                String pc_to_transaction_date = ",CURRENCY_CODE" + "," + db_to_currency_code + "," + db_aggregate_currency_code + ",Fail";
                                section4_list_results.add(pc_to_transaction_date);
                            }

                            if (db_aggregate_exchange_rate.equals(db_to_exchange_rate)) {
                                String pc_to_transaction_date = ",EXCHANGE_RATE" + "," + db_to_exchange_rate + "," + db_aggregate_exchange_rate + ",Pass";
                                section4_list_results.add(pc_to_transaction_date);
                            } else {
                                String pc_to_transaction_date = ",EXCHANGE_RATE" + "," + db_to_exchange_rate + "," + db_aggregate_exchange_rate + ",Fail";
                                section4_list_results.add(pc_to_transaction_date);
                            }

                            if (db_aggregate_exchange_rate_type.equals(db_to_exchange_rate_type)) {
                                String pc_to_transaction_date = ",EXCHANGE_RATE" + "," + db_to_exchange_rate_type + "," + db_aggregate_exchange_rate_type + ",Pass";
                                section4_list_results.add(pc_to_transaction_date);
                            } else {
                                String pc_to_transaction_date = ",EXCHANGE_RATE" + "," + db_to_exchange_rate_type + "," + db_aggregate_exchange_rate_type + ",Fail";
                                section4_list_results.add(pc_to_transaction_date);
                            }

                            if (db_aggregate_base_currency_amount.equals(db_to_base_currency_amount)) {
                                String pc_to_transaction_date = ",BASE_CURRENCY_AMOUNT" + "," + db_to_base_currency_amount + "," + db_aggregate_base_currency_amount + ",Pass";
                                section4_list_results.add(pc_to_transaction_date);
                            } else {
                                String pc_to_transaction_date = ",BASE_CURRENCY_AMOUNT" + "," + db_to_base_currency_amount + "," + db_aggregate_base_currency_amount + ",Fail";
                                section4_list_results.add(pc_to_transaction_date);
                            }

                            if (db_aggregate_event_code.equals(db_to_event_code)) {
                                String pc_to_transaction_date = ",EVENT_CODE" + "," + db_to_event_code + "," + db_aggregate_event_code + ",Pass";
                                section4_list_results.add(pc_to_transaction_date);
                            } else {
                                String pc_to_transaction_date = ",EVENT_CODE" + "," + db_to_event_code + "," + db_aggregate_event_code + ",Fail";
                                section4_list_results.add(pc_to_transaction_date);
                            }

                            if (db_aggregate_entity_type_code.equals(db_to_entity_type_code)) {
                                String pc_to_transaction_date = ",ENTITY_TYPE_CODE" + "," + db_to_entity_type_code + "," + db_aggregate_entity_type_code + ",Pass";
                                section4_list_results.add(pc_to_transaction_date);
                            } else {
                                String pc_to_transaction_date = ",ENTITY_TYPE_CODE" + "," + db_to_entity_type_code + "," + db_aggregate_entity_type_code + ",Fail";
                                section4_list_results.add(pc_to_transaction_date);
                            }
                            if (db_aggregate_product_key.equals(db_to_product_key)) {
                                String pc_to_product_key = ",PRODUCT KEY" + "," + db_to_product_key + "," + db_aggregate_product_key + ",Pass";
                                section4_list_results.add(pc_to_product_key);
                            } else {
                                String pc_to_product_key = ",PRODUCT KEY" + "," + db_to_product_key + "," + db_aggregate_product_key + ",Fail";
                                section4_list_results.add(pc_to_product_key);
                            }
                            section4_list_results.add(db_to_summary_flag);
                            section4_list_results.add(db_to_product_key);
                            section4_list_results.add(db_to_event_id);

                           /* if(db_to_event_id != null) {


                                //Posting Rule starts here
                                boolean data_in_ebs = true;
                                String db_Batch_Name = "null";
                                String db_journal_name = "null";
                                String db_line_num = "null";
                                String db_bc_entered_dr = "null";
                                String db_bc_entered_cr = "null";
                                String db_concatenated_seg = "null";
                                String credit = "null";
                                String debit = "null";
                                String EVENT_ID = null;

                                DateFormat df = new SimpleDateFormat("YYYY");
                                Date trans_date_trunc = (Date) df.parse(db_to_transaction_date);
                                Date loss_date_trunc = (Date) df.parse(db_to_loss_date);

                                if (db_to_brand.equalsIgnoreCase("privilege") && db_to_channel.equalsIgnoreCase("pwc") && db_to_product.equalsIgnoreCase("Motor") && (trans_date_trunc).before(loss_date_trunc) || (trans_date_trunc).equals(loss_date_trunc)) {
                                    if (db_aggregate_source_event_id.equals("1A") || db_aggregate_source_event_id.equals("1B")) {
                                        debit = "320.GWC000.20700.208.CD000.PCW00";
                                        credit = "320.GWC000.90300.208.CD000.000";
                                    } else {
                                        debit = "320.GWC000.90301.208.CD000.000";
                                        credit = "320.GWC000.20100.208.CD000.PCW00";
                                    }

                                } else {
                                    if (db_to_brand.equalsIgnoreCase("privilege") && db_to_channel.equalsIgnoreCase("pwc") && db_to_product.equalsIgnoreCase("Motor") && (trans_date_trunc).after(loss_date_trunc)) {
                                        if (db_aggregate_source_event_id.equals("1A") || db_aggregate_source_event_id.equals("1B")) {
                                            debit = "320.GWC000.20710.208.CD000.PCW00";
                                            credit = "320.GWC000.90310.208.CD000.000";
                                        } else {
                                            debit = "320.GWC000.90301.208.CD000.000";
                                            credit = "320.GWC000.20100.208.CD000.PCW00";
                                        }
                                    }

                                }


                                if (db_to_brand.equalsIgnoreCase("privilege") && db_to_channel.equalsIgnoreCase("digital") && db_to_product.equalsIgnoreCase("Motor") && (trans_date_trunc).before(loss_date_trunc) || (trans_date_trunc).equals(loss_date_trunc)) {
                                    if (db_aggregate_source_event_id.equals("1A") || db_aggregate_source_event_id.equals("1B")) {
                                        debit = "320.GWC000.20700.208.CD000.WEB00";
                                        credit = "320.GWC000.90300.208.CD000.000";
                                    } else {
                                        debit = "320.GWC000.90301.208.CD000.000";
                                        credit = "320.GWC000.20100.208.CD000.WEB00";
                                    }
                                } else {
                                    if (db_to_brand.equalsIgnoreCase("privilege") && db_to_channel.equalsIgnoreCase("digital") && db_to_product.equalsIgnoreCase("Motor") && (trans_date_trunc).after(loss_date_trunc)) {
                                        if (db_aggregate_source_event_id.equals("1A") || db_aggregate_source_event_id.equals("1B")) {
                                            debit = "320.GWC000.20710.208.CD000.WEB00";
                                            credit = "320.GWC000.90310.208.CD000.000";
                                        } else {
                                            debit = "320.GWC000.90310.208.CD000.000";
                                            credit = "320.GWC000.20100.208.CD000.WEB00";
                                        }
                                    }

                                }
                                if (db_to_brand.equalsIgnoreCase("privilege") && db_to_channel.equalsIgnoreCase("contactcentre") && db_to_product.equalsIgnoreCase("Motor") && (trans_date_trunc).before(loss_date_trunc) || (trans_date_trunc).equals(loss_date_trunc)) {
                                    if (db_aggregate_source_event_id.equals("1A") || db_aggregate_source_event_id.equals("1B")) {
                                        debit = "320.GWC000.20700.208.CD000.PHONE";
                                        credit = "320.GWC000.90300.208.CD000.000";
                                    } else {
                                        debit = "320.GWC000.90301.208.CD000.000";
                                        credit = "320.GWC000.20100.208.CD000.PHONE";
                                    }
                                } else {
                                    if (db_to_brand.equalsIgnoreCase("privilege") && db_to_channel.equalsIgnoreCase("contactcentre") && db_to_product.equalsIgnoreCase("Motor") && (trans_date_trunc).after(loss_date_trunc)) {
                                        if (db_aggregate_source_event_id.equals("1A") || db_aggregate_source_event_id.equals("1B")) {
                                            debit = "320.GWC000.20710.208.CD000.PHONE";
                                            credit = "320.GWC000.90310.208.CD000.000";
                                        } else {
                                            debit = "320.GWC000.90301.208.CD000.000";
                                            credit = "320.GWC000.20100.208.CD000 PHONE";
                                        }
                                    }

                                }
                                SQLResultset_icsi = SQLstmt_isci.executeQuery("select b.ae_header_id,c.ae_line_num,g.name as \"Batch Name\",f.je_header_id,f.je_category,f.je_source,f.name,f.currency_code,f.running_total_dr,f.running_total_cr,c.entered_dr as \"BC Entered DR\"\n" +
                                        ",c.entered_cr as \"BC Entered CR\",e.je_line_num,e.entered_dr,e.entered_cr,e.description,e.code_combination_id,j.concatenated_segments,i.segment1 \"Company\",i.segment2 \"Cost center\",i.segment3 \"Account\",i.segment4 \"Product\"\n" +
                                        ",i.segment5 \"Brand\",i.segment6 \"Channel\" FROM apps.xla_events a,apps.xla_ae_headers b,apps.xla_ae_lines c,apps.XLA_TRANSACTION_ENTITIES h,apps.GL_IMPORT_REFERENCES d,apps.GL_JE_LINES e,apps.GL_JE_HEADERS_V f,apps.GL_JE_BATCHES g\n" +
                                        ",apps.gl_code_combinations i,apps.gl_code_combinations_kfv j where a.application_id = 20003 and a.event_id = '" + db_to_event_id + "' and  a.event_id = b.event_id and a.application_id = h.application_id and a.entity_id = h.entity_id and b.ae_header_id = c.ae_header_id\n" +
                                        "and c.gl_sl_link_table = d.gl_sl_link_table and c.gl_sl_link_table = 'XLAJEL' and c.gl_sl_link_id  = d.gl_sl_link_id and d.je_header_id = e.je_header_id and  d.je_line_num = e. je_line_num and i.code_combination_id = e.code_combination_id\n" +
                                        "and i.code_combination_id = j.code_combination_id and e.je_header_id = f.je_header_id and f.je_batch_id = g.je_batch_id order by e.je_line_num");
                                if (!SQLResultset_icsi.next()) {
                                    data_in_ebs = false;
                                    String pc_TO_header_line = EBS_table_row + "," + ",TOH_ID" + "," + list_toh.get(k) + "," + "," + "," + "," + "Journal are not created in GL" + ",Fail";
                                    section6_list_results.add(pc_TO_header_line);
                                    EBS_table_row++;
                                }
                                if (data_in_ebs) {
                                    while (SQLResultset_icsi.next()) {
                                        System.out.println("*******************"+db_concatenated_seg);
                                        System.out.println("*******************"+credit);
                                        System.out.println("*******************"+debit);
                                        db_Batch_Name = SQLResultset_icsi.getString("Batch Name");
                                        db_journal_name = SQLResultset_icsi.getString("Name");
                                        db_line_num = SQLResultset_icsi.getString("AE_LINE_NUM");
                                        db_bc_entered_dr = SQLResultset_icsi.getString("BC Entered DR");
                                        db_bc_entered_cr = SQLResultset_icsi.getString("BC Entered CR");
                                        db_concatenated_seg = SQLResultset_icsi.getString("CONCATENATED_SEGMENTS");
                                        SimpleDateFormat formatter = new SimpleDateFormat("dd/mm/yyyy");
                                        //Date ebs_trans_date = formatter.parse(db_to_transaction_date);

                                        if (db_bc_entered_cr != null) {
                                            if (db_concatenated_seg.equals(credit)) {
                                                String batch2 = 1 + "," + db_Batch_Name + "," + db_journal_name + "," + db_line_num + "," + db_bc_entered_dr + "," + db_bc_entered_cr + "," + credit + "," + db_concatenated_seg + "," + "Pass";
                                                section6_list_results.add(batch2);
                                            } else {
                                                //String batch2 = 1 + "," + db_Batch_Name + "," + db_journal_name + "," + db_line_num + "," + db_bc_entered_dr + "," + db_bc_entered_cr + "," + credit + "," + db_concatenated_seg + "," + "Fail";
                                                String batch2 = 1 + "," + db_Batch_Name + "," + db_journal_name + "," + db_line_num + "," + db_bc_entered_dr + "," + db_bc_entered_cr + "," + credit + "," + db_concatenated_seg + "," + "Fail";
                                                section6_list_results.add(batch2);
                                            }
                                        }

                                        if (db_bc_entered_dr != null) {
                                            if (db_concatenated_seg.equals(debit)) {
                                                String batch2 = 1 + "," + db_Batch_Name + "," + db_journal_name + "," + db_line_num + "," + db_bc_entered_dr + "," + db_bc_entered_cr + "," + debit + "," + db_concatenated_seg + "," + "Pass";
                                                section6_list_results.add(batch2);
                                            } else {
                                                //String batch2 = 1 + "," + db_Batch_Name + "," + db_journal_name + "," + db_line_num + "," + db_bc_entered_dr + "," + db_bc_entered_cr + "," + debit + "," + db_concatenated_seg + "," + "Fail";
                                                String batch2 = 1 + "," + db_Batch_Name + "," + db_journal_name + "," + db_line_num + "," + db_bc_entered_dr + "," + db_bc_entered_cr + "," + debit + "," + db_concatenated_seg + "," + "Fail";
                                                section6_list_results.add(batch2);
                                            }
                                        }


                                    }
                                }
                            }
                            else{

                                String pc_TO_header_line = EBS_table_row + "," + ",TOH_ID" + "," + list_toh.get(k) + "," + "," + "," + "," + "Journal are not created in GL" + ",Fail";
                                section6_list_results.add(pc_TO_header_line);
                            }*/

                        }
                    }
                }

            }


            List<String> list = new ArrayList<String>();
            list.addAll(section2_list_results);
            list.addAll(section1_list_results);
            list.addAll(final_list_results);
            list.addAll(section4_list_results);
            list.addAll(section5_list_results);
            list.addAll(section6_list_results);

            //-------------- Report generation -------------
            report_generation.report_Test1(section1_list_results, "Section1", file_list, "AQUA RESERVE SOURCE TO CONS VALIDATION", "AQUA RESERVE", "AQUA RESERVE VALIDATION");
            report_generation.report_Test1(section2_list_results, "Section2", file_list, "AQUA RESERVE CONS TO STAGING VALIDATION", "AQUA RESERVE", "AQUA RESERVE VALIDATION");
            report_generation.report_Test1(section3_list_results, "Section3", file_list, "AQUA RESERVE STG TO STGAGG VALIDATION", "AQUA RESERVE", "AQUA RESERVE VALIDATION");
            report_generation.report_Test1(section4_list_results, "Section4", file_list, "AQUA RESERVE AGGREGATE to ICSI TO TABLE DETAILS VALIDATION", "AQUA RESERVE", "AQUA RESERVE VALIDATION");
            report_generation.report_Test1(section5_list_results, "Section5", file_list, "AQUA RESERVE AGGREGATE to ICSI TO TABLE VALIDATION", "AQUA RESERVE", "AQUA RESERVE VALIDATION");
            report_generation.report_Test1(section6_list_results, "Section6", file_list, "POSTING RULES VALIDATION", "AQUA RESERVE", "AQUA RESERVE VALIDATION");


        }


    }
}
