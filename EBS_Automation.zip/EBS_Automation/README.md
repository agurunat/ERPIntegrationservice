# EVO-Test automation
We are maintaining multiple branch codes, list and requirements given below

#master:
Will hold major development code for R1.2 (OPR) 

#R1_1: 
Maintraning this branch to execute in SIT1.1 environment and adhoc bug fix testing.This environment will hold only R1.0 and R1.1 code.

#perf:
This branch will hold the code for on  demand performance test scripts from UI.

#cognos*:
Code optimisation is identified, 
*Soon this branch will be deleted.

#UAT2:
Code base for OPR sprint N-1, targeted to run on UAT2/SIT1.2

*At present this branch holding SIT1.1 targeted code as temporary. 