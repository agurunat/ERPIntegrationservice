package co.uk.directlinegroup.evo.utils;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Created by 289949 on 9/20/2017.
 */
public class ReportUtil {
    // TODO Auto-generated method stub

    // TODO Auto-generated method stub


    public void ReportUtil() throws Exception {
        createExcel("D:\\Automation\\test.xls");
    }

    public void createExcel(String strPath) throws Exception {
        // TODO Auto-generated method stub

        HSSFWorkbook WorkBook = new HSSFWorkbook();
        HSSFSheet sheet = WorkBook.createSheet("Summary");
        HSSFSheet sheet1 = WorkBook.createSheet("Integration_Results");
        HSSFSheet sheet2 = WorkBook.createSheet("Cognos_Results");
        FileOutputStream fo = new FileOutputStream(new File("D:\\Automation\\test.xls"));

        HSSFRow SummaryRow = sheet.createRow(0);
        SummaryRow.createCell(0).setCellValue("TC_ID");
        SummaryRow.createCell(1).setCellValue("ModuleName");
        SummaryRow.createCell(2).setCellValue("Result");
        HSSFRow integerationRow = sheet1.createRow(0);
        integerationRow.createCell(0).setCellValue("TC_ID");
        integerationRow.createCell(1).setCellValue("Expected Content");
        integerationRow.createCell(2).setCellValue("Actual Content");
        integerationRow.createCell(3).setCellValue("Status");
        HSSFRow cognosRow = sheet2.createRow(0);
        cognosRow.createCell(0).setCellValue("TC_ID");
        cognosRow.createCell(1).setCellValue("Expected Content");
        cognosRow.createCell(2).setCellValue("Actual Content");
        cognosRow.createCell(3).setCellValue("Status");
        cognosRow.createCell(4).setCellValue("Reference");
        WorkBook.write(fo);
        fo.close();
    }


    public void excelwrite(String SummarySheet, String IntegerationSheet, String CognosSheet, ArrayList<String> sourceVal, ArrayList<String> targetVal) throws IOException {
        ArrayList<String> oIntegerationArray = new ArrayList<String>();
        ArrayList<String> oSummaryarray = new ArrayList<String>();
        ArrayList<String> oCognosArray = new ArrayList<String>();
        FileInputStream fis = new FileInputStream("D:\\Automation\\test.xls");
        HSSFWorkbook oIntegerationWb = new HSSFWorkbook(fis);
        FileOutputStream f2 = new FileOutputStream("D:\\Automation\\test.xls");
        FileOutputStream fileOut = new FileOutputStream("D:\\Automation\\test.xls");
        FileOutputStream fileOut2 = new FileOutputStream("D:\\Automation\\test.xls");
        HSSFWorkbook oSummaryWb = oIntegerationWb;
//        HSSFWorkbook oCognosWB=oIntegerationWb;
        HSSFSheet oIntegerationSheet = oIntegerationWb.getSheet(IntegerationSheet);
        HSSFSheet oSummarySheet = oIntegerationWb.getSheet(SummarySheet);
        HSSFSheet oCognosSheet = oIntegerationWb.getSheet(SummarySheet);
        int CognosTotalRow = oCognosSheet.getLastRowNum();
        int CognoscolCount = oCognosSheet.getRow(0).getLastCellNum();
        HSSFRow cRow = oSummarySheet.getRow(0);
        for (int i = 0; i < CognoscolCount; i++) {
            oCognosArray.add(cRow.getCell(i).getStringCellValue());
        }
        int SummaryTotalRow = oSummarySheet.getLastRowNum();
        int SummarycolCount = oSummarySheet.getRow(0).getLastCellNum();
        HSSFRow sRow = oSummarySheet.getRow(0);
        for (int i = 0; i < SummarycolCount; i++) {
            oSummaryarray.add(sRow.getCell(i).getStringCellValue());
        }
        int IntegerationTotalRow = oIntegerationSheet.getLastRowNum();
        int IntegerationColCount = oIntegerationSheet.getRow(0).getLastCellNum();
        int tccol0 = 0, tccol3 = 0, tccol4 = 0, tccol5 = 0, tccol6 = 0, tccol = 0, tccol1 = 0, tccol2 = 0;
        HSSFRow iRow = oIntegerationSheet.getRow(0);
        for (int i = 0; i < IntegerationColCount; i++) {
            oIntegerationArray.add(iRow.getCell(i).getStringCellValue());
        }

        for (int i = 0; i <= IntegerationTotalRow; i++) {
            for (int j = 0; j < IntegerationColCount; j++) {

                if (oIntegerationArray.get(j).equalsIgnoreCase("TC_ID")) {
                    tccol0 = j;
                }

                if (oIntegerationArray.get(j).equalsIgnoreCase("Actual Content")) {
                    tccol = j;
                }
                if (oIntegerationArray.get(j).equalsIgnoreCase("Expected Content")) {
                    tccol1 = j;
                }
                if (oIntegerationArray.get(j).equalsIgnoreCase("Status")) {
                    tccol2 = j;
                }
            }
        }
        if (targetVal != null) {
            for (int i = 0; i < targetVal.size(); i++) {
                HSSFRow integerationTotalRow = oIntegerationSheet.createRow(IntegerationTotalRow + 1);
                integerationTotalRow.createCell(tccol0).setCellValue("TC0001");
                integerationTotalRow.createCell(tccol).setCellValue(targetVal.get(i));
                integerationTotalRow.createCell(tccol1).setCellValue(sourceVal.get(i));
                boolean flag = true;
                integerationTotalRow.createCell(tccol2).setCellValue("FAIL");
                IntegerationTotalRow = IntegerationTotalRow + 1;
            }
            oIntegerationWb.write(f2);
            f2.close();
        }


        for (int c = 0; c <= CognosTotalRow; c++) {
            for (int cc = 0; cc < CognoscolCount; cc++) {
                if (oCognosArray.get(cc).equalsIgnoreCase("TC_ID")) {
                    tccol0 = cc;
                }

                if (oCognosArray.get(cc).equalsIgnoreCase("Actual Content")) {
                    tccol = cc;
                }
                if (oCognosArray.get(cc).equalsIgnoreCase("Expected Content")) {
                    tccol1 = cc;
                }
                if (oCognosArray.get(cc).equalsIgnoreCase("Status")) {
                    tccol3 = cc;
                }
            }
        }
        for (int i = 0; i < targetVal.size(); i++) {
            HSSFRow cognosTotalRow = oIntegerationSheet.createRow(CognosTotalRow + 1);
            cognosTotalRow.createCell(tccol0).setCellValue("TC0001");
            cognosTotalRow.createCell(tccol).setCellValue(targetVal.get(i));
            cognosTotalRow.createCell(tccol1).setCellValue(sourceVal.get(i));
            boolean flag = true;
            cognosTotalRow.createCell(tccol2).setCellValue("FAIL");
            CognosTotalRow = CognosTotalRow + 1;
        }
        oIntegerationWb.write(f2);
        f2.close();

        for (int s = 0; s <= SummaryTotalRow; s++) {
            for (int ss = 0; ss < SummarycolCount; ss++) {
                if (oSummaryarray.get(ss).equalsIgnoreCase("Result")) {
                    tccol2 = ss;
                }
            }
        }

        if (targetVal.size() != 0) {
            for (int pageRow = 0; pageRow < 1; pageRow++) {
                HSSFRow summaryTotalRow = oSummarySheet.createRow(SummaryTotalRow + 1);
                summaryTotalRow.createCell(tccol0).setCellValue("TC0001");
                summaryTotalRow.createCell(tccol2).setCellValue("FAIL");
                SummaryTotalRow = SummaryTotalRow + 1;
            }
            oSummaryWb.write(fileOut);
            fileOut.close();
        }
    }


}
