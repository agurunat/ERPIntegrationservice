package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Obj_Contacts extends AbstractPage {

    public WebElement makeChangesYesRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C1__QUE_48BDF1EEA3569326409122']/label[1]/span"));
    }

    public WebElement makeChangesNoRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C1__QUE_48BDF1EEA3569326409122']/label[2]/span"));
    }

    public WebElement checkOutButton() {
        return waitForUnstableElement(By.id("C1__BUT_48BDF1EEA3569326413916"));
    }
}