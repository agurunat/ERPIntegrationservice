package co.uk.directlinegroup.evo.utils.common;

/**
 * Created by 323996 on 11/15/2017.
 */

import java.io.*;
import java.net.*;

public class TCPClient {
    public static DatagramSocket clientsocket;
    public static DatagramPacket dp;
    public static BufferedReader dis;
    public static InetAddress ia;
    public static byte buf[] = new byte[1024];
    public static int cport = 789, sport = 790;

    public static void main(String str) {
//        maincall(str);
    }

    public static void maincall(String str) {

        try {

            Socket clientSocket = new Socket("localhost", 6789);
            DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
            outToServer.writeBytes(str);
            clientSocket.close();


        } catch (SocketException e) {
            e.printStackTrace();
        } catch (UnknownHostException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        finally {

        }
    }
}