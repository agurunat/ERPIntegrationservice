package co.uk.directlinegroup.evo.utils;
        import java.io.File;
        import java.io.FileInputStream;
        import java.io.FileNotFoundException;
        import java.io.FileOutputStream;
        import java.io.IOException;
        import java.io.InputStream;
        import java.io.OutputStream;
        import java.io.PrintStream;
        import java.text.DateFormat;
        import java.text.ParseException;
        import java.text.SimpleDateFormat;
        import java.util.Calendar;
        import java.util.Date;

        import org.openqa.selenium.WebDriver;
        import org.openqa.selenium.chrome.ChromeDriver;
        import org.openqa.selenium.firefox.FirefoxDriver;
        import org.openqa.selenium.firefox.FirefoxProfile;
        import org.openqa.selenium.firefox.internal.ProfilesIni;
        import org.openqa.selenium.ie.InternetExplorerDriver;
        import org.openqa.selenium.remote.DesiredCapabilities;

public class driver {

    /* Initialize webdriver */
    public void launchBrowser(String browser) {

        if (browser.equalsIgnoreCase("FF")) {

            ProfilesIni profile = new ProfilesIni();
            FirefoxProfile myprofile = profile.getProfile("default");
                WebDriver driver = new FirefoxDriver(myprofile);
                driver.manage().window().maximize();

        } else if (browser.equalsIgnoreCase("IE")) {

            System.setProperty("webdriver.ie.driver",
                    "C:\\Users\\sunil.wali\\Desktop\\Framework\\DM\\resources\\IEDriverServer.exe");
            DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
            capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
            WebDriver driver = new InternetExplorerDriver(capabilities);

            driver.manage().window().maximize();
        }

        else if (browser.equalsIgnoreCase("Chrome")) {

            System.setProperty("webdriver.chrome.driver",
                    "C:\\Users\\sunil.wali\\Desktop\\Framework\\DM\\resources\\chromedriver.exe");
            WebDriver driver = new ChromeDriver();
            driver.manage().window().maximize();
        }

    }

// Static HTML Reporting Methods

    public static PrintStream reporter = null;
    public static DateFormat dateFormat;
    public static Calendar cal;
    public static String currenTimeStamp;

    public void reportSetup() {
        if (reporter == null) {
            File targetFile = null;
            Calendar currentDate = Calendar.getInstance();
            SimpleDateFormat displayFormat = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss");
            SimpleDateFormat parseFormat = new SimpleDateFormat("MM_dd_yyyy_HH_mm_ss" + " a");
            Date date = null;
            try {
                date = parseFormat.parse(parseFormat.format(currentDate.getTime()));
            } catch (ParseException ex) {
            }
            currenTimeStamp = displayFormat.format(date);
// Create a TestResults folder in path directory if not exist
            String destPath = System.getProperty("user.dir") + "\\" + "TestResults";
            targetFile = new File(destPath);
            if (!targetFile.exists()) {
                targetFile.mkdir();
            }
// Copy the ResultsFolder from the resource in to result folder
// Rename the folder
// Copy the path of result folder
// Create a print handle to the result summary
            String srcResultfolder = System.getProperty("user.dir") + "\\Resources\\ResultsFolder";
            File destinationLocation = new File(destPath);
            File sourceLocation = new File(srcResultfolder);
            try {
                copyFolder(sourceLocation, destinationLocation);
            }

            catch (IOException e) {
            }
            String destResultPath = destPath + "\\ResultSummary";
            String resultSummaryFolderPath = System.getProperty("user.dir") + "\\" + "TestResults\\ProjectName_Result_"
            + currenTimeStamp;
// Change Project name
// Rename the dirctory
            File file = new File(destResultPath);
            File newFilePath = new File(resultSummaryFolderPath);
            file.renameTo(newFilePath);
            String resultSummaryFilePath = resultSummaryFolderPath + "\\Index.html";
// Create a handle to dump the results
            try {
                reporter = new PrintStream(new FileOutputStream(resultSummaryFilePath, true), true);
            } catch (FileNotFoundException e) {
                System.out.println("");
            }
        }
    }

    public static void copyFolder(File src, File dest) throws IOException {
        if (src.isDirectory()) {
// if directory not exists, create it
            if (!dest.exists()) {
                dest.mkdir();
            }
// list all the directory contents
            String files[] = src.list();
            for (String file : files) {
// construct the src and dest file
// structure
                File srcFile = new File(src, file);
                File destFile = new File(dest, file);
// recursive copy
                copyFolder(srcFile, destFile);
            }
        } else {
// if file, then copy it
// Use bytes stream to support all file types
            InputStream in = new FileInputStream(src);
            OutputStream out = new FileOutputStream(dest);
            byte[] buffer = new byte[1024];
            int length;
// copy the file content in bytes
            while ((length = in.read(buffer)) > 0) {
                out.write(buffer, 0, length);
            }
            in.close();
            out.close();
        }

    }

}