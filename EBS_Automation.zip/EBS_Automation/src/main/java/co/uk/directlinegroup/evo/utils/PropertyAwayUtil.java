package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_Propertyaway;
import com.usmanhussain.habanero.framework.AbstractPage;

import java.util.List;

public class PropertyAwayUtil extends AbstractPage {

    private CommonUtil commonUtil = new CommonUtil();
    private Obj_Propertyaway propertyaway = new Obj_Propertyaway();

    public void insureBusinessTools(List<List<String>> data, String fieldName) throws Throwable {
        String options = commonUtil.datapicker(data, fieldName);
        if (!options.equalsIgnoreCase("")) {
            if (options.equalsIgnoreCase("No")) {
                commonUtil.clickbyJS(propertyaway.businessToolsEquipmentNoRadiobutton());
            } else {
                propertyaway.executeScript("arguments[0].click();", propertyaway.businessToolsEquipmentYesRadiobutton());
            }
        }
    }

    public void insureStocks(List<List<String>> data, String fieldName) throws Throwable {
        String options = commonUtil.datapicker(data, fieldName);
        if (!options.equalsIgnoreCase("")) {
            if (options.equalsIgnoreCase("No")) {
                commonUtil.clickbyJS(propertyaway.insureYourStockNoRadiobutton());
            } else if (options.equalsIgnoreCase("Yes")) {
                propertyaway.executeScript("arguments[0].click();", propertyaway.insureYourStockYesRadiobutton());
            }
        } else {
        }
    }

    public void insureThirdPartyStocks(List<List<String>> data, String fieldName) throws Throwable {
        String options = commonUtil.datapicker(data, fieldName);
        if (!options.equalsIgnoreCase("")) {
            if (options.equalsIgnoreCase("No")) {
                commonUtil.clickbyJS(propertyaway.TransitViaThirdPartyNoRadiobutton());
            } else if (options.equalsIgnoreCase("Yes")) {
                propertyaway.executeScript("arguments[0].click();", propertyaway.TransitViaThirdPartyYesRadiobutton());
            }
        } else {
        }
    }
}