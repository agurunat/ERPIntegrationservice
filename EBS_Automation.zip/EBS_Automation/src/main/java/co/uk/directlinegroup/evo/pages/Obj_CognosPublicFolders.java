package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 * Created by 323996 on 9/5/2017.
 */
public class Obj_CognosPublicFolders extends AbstractPage {
    public WebElement pathLeaf1() {
        return waitForElementVisible(By.xpath("//*[@id='breadcrumbContainer']/span[2]"));
    }

    public WebElement pathLeaf2() {
        return waitForElementVisible(By.xpath("//*[@id='breadcrumbContainer']/span[4]"));
    }

    public WebElement pathLeaf3() {
        return waitForElementVisible(By.xpath("//*[@id='breadcrumbContainer']/span[6]"));
    }

    public WebElement linkDL4B_Test() {
        return waitForElementVisible(By.linkText("DL4B_Test"));

    }

    public WebElement linkDL4B() {
        return waitForElementVisible(By.linkText("DL4B"));

    }

    public WebElement maxEntriesTextbox() {
        return waitForElementVisible(By.id("pagerto"));
    }

    public WebElement setEntriesButton() {
        return waitForElementVisible(By.id("img__gotop"));
    }

    public WebElement marketingPreferenceReportLink() {
        return waitForElementVisible(By.linkText("Marketing Preference Report"));

    }

    public WebElement workbasketStatusReportLink() {
        return waitForElementVisible(By.linkText("Workbasket Status Report"));

    }

    public WebElement transactionReportLink() {
        return waitForElementVisible(By.linkText("Transaction Report"));

    }

    public WebElement futuresReportLink() {
        return waitForElementVisible(By.linkText("Futures Report"));

    }


    public WebElement TaxReportLink() {
        return waitForElementVisible(By.linkText("Tax Report"));
    }

    public WebElement OutputsReportLink() {
        return waitForElementVisible(By.linkText("Outputs Report"));
    }

    public WebElement OverallPerformanceReportLink() {
        return waitForElementVisible(By.linkText("Overall Performance Report"));
    }

    public WebElement EarnedVsUnearnedReportPremiumLink() {
        return waitForElementVisible(By.linkText("Earned Vs Unearned Premium with Accounting Periods"));
    }

    public WebElement PayBlockLink() {
        return waitForElementVisible(By.linkText("Payment Blocking Suspend Client Removal Report"));
    }


    public WebElement Futures_FolderLink() {
        return waitForElementVisible(By.linkText("Futures"));
    }
    public WebElement Marketing_Preference_FolderLink() {
        return waitForElementVisible(By.linkText("Marketing Preference"));
    }
    public WebElement Outputs_FolderLink() {
        return waitForElementVisible(By.linkText("Outputs"));
    }
    public WebElement Overall_Performance_FolderLink() {
        return waitForElementVisible(By.linkText("Overall Performance"));
    }
    public WebElement Payment_Blocking_Suspend_Client_Removal_FolderLink() {
        return waitForElementVisible(By.linkText("Payment Blocking Suspend Client Removal"));
    }
    public WebElement Tax_FolderLink() {
        return waitForElementVisible(By.linkText("Tax"));
    }
    public WebElement Transaction_FolderLink() {
        return waitForElementVisible(By.linkText("Transaction"));
    }
    public WebElement UEPR_FolderLink() {
        return waitForElementVisible(By.linkText("UEPR"));
    }
    public WebElement Workbasket_Status_FolderLink() {
        return waitForElementVisible(By.linkText("Workbasket Status"));
    }

    public WebElement ReportHomeIcon() {
        return waitForElementVisible(By.xpath("(//td[@class='homeContainer']/div/table//div)[1]"));
    }


    public WebElement UAC_FolderLink() {
        return waitForElementVisible(By.linkText("UAC"));
    }

    public WebElement uacReportLink() {
        return waitForElementVisible(By.linkText("UAC Report"));
    }

    public WebElement ChannelPerformance_FolderLink() {
        return waitForElementVisible(By.linkText("Channel Performance"));
    }

    public WebElement ChannelPerformanceReportPremiumLink() {
        return waitForElementVisible(By.linkText("Channel Performance Report"));
    }

    public WebElement ContactKPIs_FolderLink() {
        return waitForElementVisible(By.linkText("Contact KPIs"));
    }

    public WebElement ContactKPIsReportLink() {
        return waitForElementVisible(By.linkText("Contact KPIs Report"));
    }

    public WebElement BusinessKPI_FolderLink() {
        return waitForElementVisible(By.linkText("Business Other KPI's"));
    }

    public WebElement BusinessKPIReportLink() {
        return waitForElementVisible(By.linkText("Business Other KPI's Report"));
    }

    public WebElement Upsells_FolderLink() {
        return waitForElementVisible(By.linkText("Upsells"));

    }

    public WebElement UpsellsReportLink() {
        return waitForElementVisible(By.linkText("Upsells Report"));
    }
}
