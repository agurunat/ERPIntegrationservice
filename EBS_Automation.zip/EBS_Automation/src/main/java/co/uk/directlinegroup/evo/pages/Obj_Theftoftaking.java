package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import net.serenitybdd.core.annotations.findby.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class Obj_Theftoftaking extends AbstractPage {

    public WebElement theftOfTakingDropdown() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__QUE_006AB5B0B0C7206C1536392' or @id='C9__QUE_006AB5B0B0C7206C1397467']"));
    }

    public WebElement TOTdropDown() {
        return waitForUnstableElement(By.id("C9__QUE_006AB5B0B0C7206C1397467"));
    }

    public WebElement nextButton() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__BUT_006AB5B0B0C7206C1539605' or @id='C9__BUT_006AB5B0B0C7206C1539605']"));
    }

    public WebElement saveAndExitButton() {
        return waitForUnstableElement(By.id("C2__BUT_D3E81D5ED026892F942222"));
    }

    public WebElement accordionTOT() {
        return waitForUnstableElement(By.id("TOfTaking"));
    }

    public WebElement increaseCoverLimitText() {
        return waitForUnstableElement(By.id("C9__TXT_006AB5B0B0C7206C1534566"));
    }

    public WebElement premisesWhilstUnattendedAndsafeText() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_006AB5B0B0C7206C1512469']/div/table/tbody/tr[1]/td[1]"));
    }

    public WebElement premisesWhilstUnattendedAndNotInsafeText() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_006AB5B0B0C7206C1512469']/div/table/tbody/tr[2]/td[1]"));
    }

    public WebElement homeAnyAuthorisedPersonWorkingText() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_006AB5B0B0C7206C1512469']/div/table/tbody/tr[3]/td[1]"));
    }

    public WebElement thirdPartyPremisesWhereYouWorkText() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_006AB5B0B0C7206C1512469']/div/table/tbody/tr[4]/td[1]"));
    }

    public WebElement premisesWhilstUnattendedAndsafeValue() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_006AB5B0B0C7206C1512469']/div/table/tbody/tr[1]/td[2]"));
    }

    public WebElement premisesWhilstUnattendedAndNotInsafeValue() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_006AB5B0B0C7206C1512469']/div/table/tbody/tr[2]/td[2]"));
    }

    public WebElement homeAnyAuthorisedPersonWorkingValue() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_006AB5B0B0C7206C1512469']/div/table/tbody/tr[3]/td[2]"));
    }

    public WebElement thirdPartyPremisesWhereYouWorkValue() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_006AB5B0B0C7206C1512469']/div/table/tbody/tr[4]/td[2]"));
    }

    public WebElement saveAndExitPopUp() {
        return waitForUnstableElement(By.id("BUT_D3E81D5ED026892F1577152"));
    }

    public WebElement exit() {
        return waitForUnstableElement(By.id("BUT_879C6A11B52E18633458448"));
    }

    public WebElement previousLossexit() {
        return waitForUnstableElement(By.id("BUT_B098F5691AD7B0DE560426"));
    }

    public WebElement totLink() {
        return waitForUnstableElement(By.id("C2__BUT_24D9276FBA6E19C58823816"));
    }

    public WebElement coverMoneyTransitText() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_006AB5B0B0C7206C1535980']/div/p"));
    }

    public WebElement howMuchTotCoverText() {
        return waitForUnstableElement(By.xpath("//*[@id='C9__TXT_006AB5B0B0C7206C1535623']/div/p"));
    }

    public WebElement binButtonTOT()
    {
        return waitForElementPresent(By.id("C9__BUT_E51B872E5D2AA440635540"));
    }
    public List<WebElement> eleAccordionTOT() {
        return findElements(By.xpath("//*[@id='TOfTaking']/span[1]"));
    }
    public WebElement moreOptionTOT() {
        return waitForElementPresent(org.openqa.selenium.By.xpath("//*[@id='C2__QUE_24D9276FBA6E19C58823812']/p"));
    }
    public WebElement validationPopUp(){
        return waitForElementPresent(org.openqa.selenium.By.id("C9__HEAD_E51B872E5D2AA440635672"));
    }
    public WebElement validationPopUpYesButton(){
        return waitForElementPresent(org.openqa.selenium.By.id("C9__BUT_E51B872E5D2AA440635827"));
    }
    public WebElement validationPopUpNoButton(){
        return waitForElementPresent(org.openqa.selenium.By.id("C9__BUT_E51B872E5D2AA440635832"));
    }
    public WebElement moreOptionaddTOTDropdown() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__C1__QUE_24D9276FBA6E19C58823800']"));
    }
    public WebElement moreOptionaddTOTAddToQuote() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__C1__BUT_24D9276FBA6E19C58823806']"));
    }
    public WebElement moreOptionaddTOT() {
        return waitForElementPresent(org.openqa.selenium.By.xpath("//*[@id='C2__BUT_B27861E7D1B6D9CA1420839']/span"));
    }
    public WebElement removeTOT() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__BUT_24D9276FBA6E19C58823822']/span]"));
    }

}
