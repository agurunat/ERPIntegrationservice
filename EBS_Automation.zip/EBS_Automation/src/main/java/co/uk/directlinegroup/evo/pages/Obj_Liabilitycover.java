package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class Obj_Liabilitycover extends AbstractPage {

    public WebElement public_LiabilitycoverDropdown() {
        return waitForUnstableElement(By.id("C3__QUE_5847B0D83AF0F962260731"));
    }

    public WebElement productsOutsideukDropdown() {
        return waitForUnstableElement(By.id("C3__QUE_5847B0D83AF0F962260734"));
    }

    public WebElement productsOutsideukDropdownList() {
        return waitForUnstableElement(By.xpath("//*[@id='C3__QUE_5847B0D83AF0F962260734']/option[2]"));
    }

    public WebElement liabilityCoverNextButton() {
        return waitForUnstableElement(By.id("C3__BUT_5847B0D83AF0F962260745"));
    }

    public WebElement saveExitButton() {
        return waitForUnstableElement(By.id("C2__BUT_D3E81D5ED026892F942222"));
    }

    public WebElement saveExitPopUpButton() {
        return waitForUnstableElement(By.xpath("//*[@id='C1__BUT_391E4BE220C07767120913'][@class='save ga_save ssc_exit']"));
    }

    public WebElement checkOutButton() {
        return waitForUnstableElement(By.id("C1__BUT_48BDF1EEA3569326413916"));
    }
    public List<WebElement> outsideUKQuestion(){
        return findElements(By.xpath("//*[@id='C3__p1_QUE_5847B0D83AF0F962260734']/div/label"));
    }
    public List<WebElement> binButton(){
        return findElements(By.id("C3__BUT_E51B872E5D2AA440704822"));
    }
    public WebElement yesOrNo(String YOrN){
        return findElement(By.xpath("//div[@id='C3__row_BUT_523D3ECD008FAE54670027']/div/div/button[@title='"+YOrN+"']"));
    }
    public WebElement warningMsg(){
        return findElement(By.xpath("//*[@id='C3__HEAD_523D3ECD008FAE54669865']"));
    }
}