package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_Directdebit;

import java.util.List;

public class DirectdebitUtil {

    private CommonUtil commonutil = new CommonUtil();
    private Obj_Directdebit directdebit = new Obj_Directdebit();

    public void directDebit(List<List<String>> data, String fieldName) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        if (StrVal.equalsIgnoreCase("yes")) {
            directdebit.executeScript("arguments[0].click();", directdebit.directdebitYesRadiobutton());
        } else {
            directdebit.executeScript("arguments[0].click();", directdebit.directDebitNoRadiobutton());
        }
    }
}
