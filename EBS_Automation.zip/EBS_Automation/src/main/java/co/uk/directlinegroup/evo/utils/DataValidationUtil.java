package co.uk.directlinegroup.evo.utils;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class DataValidationUtil {
    public static void main(String[] args) throws IOException {
        String first = "C:\\Users\\470774\\Desktop\\Pradeep\\Verf\\AutoFile.txt";
        String second = "C:\\Users\\470774\\Desktop\\Pradeep\\Verf\\BatchFile.txt";
        BufferedReader fBr = new BufferedReader(new FileReader(first));
        BufferedReader sBr = new BufferedReader(new FileReader(second));
        ArrayList<String> strings = new ArrayList<String>();
        ArrayList<String> strings1 = new ArrayList<String>();
        while ((first = fBr.readLine()) != null) {
            strings.add(first);
        }
        while ((second = sBr.readLine()) != null) {
            strings1.add(second);
            String[] arr2 = second.split("\\|");

            if (strings.contains(second)) {

                for (int i = 0; i < strings.size(); i++) {
                }
            }
        }
        fBr.close();
        sBr.close();
    }
}
