package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import net.serenitybdd.core.annotations.findby.By;
import org.junit.Assert;
import org.openqa.selenium.WebElement;

import java.util.List;

public class Obj_Businesspremises extends AbstractPage {

    public WebElement postCodetextbox(int i) {
        return waitForUnstableElement(By.id("C6__QUE_487C210376DC00A33351352_R" + i));
    }

    public WebElement findAddressButton(int i) {
        return waitForUnstableElement(By.xpath("//*[@id='C6__BUT_487C210376DC00A33351355_R" + i + "']"));
    }

    public WebElement selectAddressDropdown(int i) {
        return waitForUnstableElement(By.id("C6__QUE_487C210376DC00A33351357_R" + i));
    }

    public WebElement selectPremisesTypeDropdown(int i) {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351376_R" + i));
    }

    public WebElement selectATM(int i) {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351421_R" + i));
    }

    public WebElement premisesOccupiedYesRadiobutton(int i) {
        return waitForElementPresent(By.xpath(".//*[@id='radio_C6__QUE_487C210376DC00A33351404_R" + i + "']/label[1]/span"));
    }

    public WebElement premisesOccupiedNoRadiobutton(int i) {
        return waitForElementPresent(By.xpath(".//*[@id='radio_C6__QUE_487C210376DC00A33351404_R" + i + "']/label[2]/span"));
    }

    public WebElement commercialpremisesOccupiedYesRadiobutton(int i) {
        return waitForElementPresent(By.xpath(".//*[@id='radio_C6__QUE_487C210376DC00A33351407_R" + i + "']/label[1]/span"));
    }

    public WebElement commercialpremisesOccupiedNoRadiobutton(int i) {
        return waitForElementPresent(By.xpath(".//*[@id='radio_C6__QUE_487C210376DC00A33351407_R" + 1 + "']/label[2]/span"));
    }

    public WebElement haventStartedTradeRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351418_R" + i + "']/label[1]"));
    }

    public WebElement premisesOnlyOccupiped(String YorN, int i) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].PREMISESONLYOCCUPIED'][value=" + value + "]";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement buildingOccupied(String YorN, int i) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].BUILDINGOCCUPIED'][value=" + value + "]";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement applyToYpurBusiness(String text, int i) {
        String xpath = "//div[@id='checkbox_C6__QUE_487C210376DC00A33351418_R" + i + "']//input[@type='checkbox']/following-sibling::label[contains(.,'" + text + "')]";
        return waitForElementPresent(org.openqa.selenium.By.xpath(xpath));
    }


    public WebElement roofs(String YorN, int i) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].THEMAINBUILDING[1].ISROOFMATERIALS'][value=" + value + "]";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement subsidenceCover(String YorN, int i) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].SUBSIDENCE[1].COVERFORSUBSIDENCE'][value=" + value + "]";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }


    public WebElement portableElectricHeater(String value, int i) {
        String text = "", Option = "";
        if (value.equalsIgnoreCase("heatone") || value.equalsIgnoreCase("Y")) {
            text = "heatone";
            Option = "Yes";
        } else if (value.equalsIgnoreCase("heattwo") || value.equalsIgnoreCase("N")) {
            text = "heattwo";
            Option = "No";
        } else if (value.equalsIgnoreCase("heathree")) {
            text = "heathree";
            Option = "Not heated";
        } else {
            Assert.assertTrue("Optional Field", true);
        }
        String cssSelector = "//*[@id='C6__row_heatingList2_R" + i + "' or @id='C6__row_heatingList_R" + i + "']/div[4]/div/div/input[@type='radio'][@value='" + text + "'][not(@disabled='disabled')]/../label/span[text()='" + Option + "']";
        return waitForElementPresent(org.openqa.selenium.By.xpath(cssSelector));
    }

    public WebElement wallsYes(int i) {

        return waitForElementPresent(By.xpath("//*[@id='radio_C6__wallMaterialTimber_R" + i + "']/label[1]/span"));
    }

    public WebElement walls(String YorN, int i) {
        String value = "N";
        if ((YorN.equalsIgnoreCase("Y") || (YorN.equalsIgnoreCase("Yes")))) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].THEMAINBUILDING[1].ISWALLSMADETIMBER'][value='" + value + "']";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement wallsMade(String YorN, int i) {
        String value = "N";
        if ((YorN.equalsIgnoreCase("Y") || (YorN.equalsIgnoreCase("Yes")))) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].THEMAINBUILDING[1].ISWALLSMADE'][value=" + value + "]";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement outBuildingWallsMade(String YorN, int i) {
        String value = "N";
        if ((YorN.equalsIgnoreCase("Y") || (YorN.equalsIgnoreCase("Yes")))) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].OUTBUILDINGSFORCC[1].ISWALLSMADE'][value=" + value + "]";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement outBuildingWallTimber(String YorN, int i) {

        String value = "N";
        if ((YorN.equalsIgnoreCase("Y") || (YorN.equalsIgnoreCase("Yes")))) {
            value = "Y";
        }

        int size = getDriver.findElements(By.id("radio_C6__wallMaterialTimberOB_R" + i)).size();
        if (size == 0) {
            return waitForElementPresent(By.xpath("//*[@id='radio_C6__wallMaterialOB_R" + i + "']/label[1]/span"));
        } else {
            return waitForElementPresent(By.xpath("((//*[@id='radio_C6__wallMaterialTimberOB_R" + i + "' or @id='radio_C6__wallMaterialOB_R" + i + "']/input[@value='" + value + "'][not(@disabled='disabled')])/..)//label[1]/span"));
        }

    }

    public WebElement outBuildingRoofs(String YorN, int i) {
        String value = "N";
        if ((YorN.equalsIgnoreCase("Y") || (YorN.equalsIgnoreCase("Yes")))) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].OUTBUILDINGSFORCC[1].ISROOFMATERIALS'][value=" + value + "]";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement outPremiseGrade1(String YorN, int i) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].OUTBUILDINGSFORCC[1].PREMISESGRADELIST'][value=" + value + "]";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }


    public WebElement premiseCurrentlyUnoccupiedRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351418_R" + i + "']/label[2]"));
    }

    public WebElement premiseUnoccupied30daysRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351418_R" + i + "']/label[3]"));
    }

    public WebElement noneOftheAboveRadiobutton(int i) {
        return waitForElementPresent(By.xpath(".//*[@id='checkbox_C6__QUE_487C210376DC00A33351418_R" + i + "']/label[4]"));
    }

    public WebElement anyOutBuildingNoRadiobutton(int i) {
        return waitForElementPresent(By.xpath(".//*[@id='radio_C6__QUE_487C210376DC00A33351423_R" + i + "']/label[2]/span"));
    }

    public WebElement anyOutBuildingYesRadiobutton(int i) {
        return waitForElementPresent(By.xpath(".//*[@id='radio_C6__QUE_487C210376DC00A33351423_R" + i + "']/label[1]/span"));
    }

    public WebElement yourBuildingAddCoverLink(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351450_R" + i));
    }

    public WebElement outBuildingyourBuildingAddCoverLink(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_487C210376DC00A33351514_R" + i + "']"));
    }

    public WebElement outBuildingYourBuildingTextBox(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351506_R" + i + "']"));
    }

    public WebElement yourBuildingValueTextbox(int i) {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351442_R" + i));
    }

    public WebElement buildingShopValueTextbox(int i) {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351462_R" + i));
    }

    public WebElement buildingShopAddCoverLink(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351470_R" + i));
    }

    public WebElement buildingfittingValueTextbox(int i) {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351482_R" + i));
    }

    public WebElement buildingfittingAddCoverLink(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351490_R" + i));
    }


    public WebElement businessContentAddCoverLink(int i) {
        return waitForUnstableElement(By.id("C6__BUT_487C210376DC00A33351584_R" + i));
    }

    public WebElement businessContentValueTextbox(int i) {
        return waitForUnstableElement(By.id("C6__QUE_487C210376DC00A33351576_R" + i));
    }

    public WebElement stockAddCoverLink(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351604_R" + i));
    }

    public WebElement stockWSAddCoverLink(int i) {
        return waitForElementPresent(By.id("C6__BUT_130910B8F1739FAC1055250_R" + i));
    }

    public WebElement outbuildingStockWSAddCoverLink(int i) {
        return waitForElementPresent(By.id("C6__BUT_130910B8F1739FAC1055160_R" + i));
    }

    public WebElement premiseYourStockWinesAndSpirits(int i) {
        return waitForElementPresent(By.cssSelector("input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].CONTENTS[1].MAINBUILDINGS[1].YOURSTOCKOFWINESANDSPIRITS']"));
    }

    public WebElement stockValueTextbox(int i) {
        return waitForElementPresent(By.cssSelector("input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].CONTENTS[1].MAINBUILDINGS[1].YOURSTOCK']"));
    }

    public WebElement stockValueSpiritTextbox(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_130910B8F1739FAC998004_R" + i + "']"));
    }

    public WebElement businessContentLabel(int i){
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_BD3550F8E469E3F81315171_R"+i+"']/div/label"));
    }
    public WebElement stockLabel(int i){
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_130910B8F1739FAC997984_R"+i+"']/div/label"));
    }

    public WebElement outbuildingStockValueSpiritTextbox(int i) {
        return waitForElementPresent(By.cssSelector("input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].CONTENTS[1].OUTBUILDINGS[1].YOURSTOCKOFWINESANDSPIRITS']"));
    }

    public WebElement stockValueTextboxVal(int i) {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351596_R" + i));
    }

    public WebElement stockValueRemovebutton(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351600_R" + i));
    }

    public WebElement householdContentAddCoverLink(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351624_R" + i));
    }

    public WebElement householdContentValueTextbox(int i) {
        return waitForElementPresent(By.id("C6__main_household_content_R" + i));
    }

    public WebElement buildingTypedDrodown(int i) {

        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351721_R" + i + "']"));

    }

    public WebElement propertyBuiltDrodown(int i) {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351723_R" + i));
    }

    public WebElement premiseGradeYesRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351725_R" + i + "']/label[1]/span"));
    }

    public WebElement premiseGradeNoRadiobutton(int i) {
        //*[@id="radio_C6__QUE_487C210376DC00A33351725_R1"]/label[2]/span
        return waitForUnstableElement(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351725_R" + i + "']/label[2]/span"));
    }

    public WebElement wallMaterialYesRadiobutton(int i) {
        int size = getDriver.findElements(By.id("radio_C6__wallMaterialTimber_R" + i)).size();
        if (size == 0) {
            return waitForElementPresent(By.xpath("//*[@id='radio_C6__wallMaterial_R" + i + "']/label[1]/span"));
        } else {
            return waitForElementPresent(By.xpath("((//*[@id='radio_C6__wallMaterialTimber_R" + i + "' or @id='radio_C6__wallMaterial_R" + i + "']/input[@value='Y'][not(@disabled='disabled')])/..)//label[1]/span"));
        }
    }

    public WebElement individualItemOfHouseHoldNoRadioButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__namedItem_R" + i + "']/label[2]/span"));
    }

    public WebElement wallMaterialNoRadiobutton(int i) {
        int size = getDriver.findElements(By.id("radio_C6__wallMaterialTimber_R" + i)).size();
        if (size == 0) {
            return waitForElementPresent(By.xpath("//*[@id='radio_C6__wallMaterial_R" + i + "']/label[2]/span"));
        } else {
            return waitForElementPresent(By.xpath("((//*[@id='radio_C6__wallMaterialTimber_R" + i + "' or @id='radio_C6__wallMaterial_R" + i + "']/input[@value='N'][not(@disabled='disabled')])/..)//label[2]/span"));
        }
    }

    public WebElement roofMaterialYesRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__roofMaterial_R" + i + "']/label[1]/span"));
    }

    public WebElement roofMaterialNoRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__roofMaterial_R" + i + "']/label[2]/span"));
    }

    public WebElement commWallMaterialYesRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__wallMaterial_R" + i + "']/label[1]/span"));
    }

    public WebElement commWallMaterialNoRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__wallMaterial_R" + i + "']/label[2]/span"));
    }

    public WebElement openFirePlacesYesRadiobutton(int i) {
        return waitForUnstableElement(By.xpath("//*[@id='radio_C6__heatingList_R" + i + "' or @id='radio_C6__heatingList2_R" + i + "']/label[1]/span"));
    }

    public WebElement openFirePlacesNoRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__heatingList_R" + i + "']/label[2]/span"));
    }

    public WebElement openFirePlacesNotheatedRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__heatingList_R" + i + "']/label[3]/span"));
    }

    public WebElement commOpenFirePlacesYesRadiobutton(int i) {

        return waitForElementPresent(By.xpath("//*[@id='radio_C6__heatingList2_R" + i + "']/label[1]/span"));
    }

    public WebElement commOpenFirePlacesNoRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__heatingList2_R" + i + "']/label[2]/span"));
    }

    public WebElement commOpenFirePlacesNotheatedRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__heatingList2_R" + i + "']/label[3]/span"));
    }

    public WebElement subsidenceCoverNoRadiobutton(int i) {
        return waitForElementPresent(By.xpath(".//*[@id='radio_C6__QUE_487C210376DC00A33351804_R" + i + "']/label[2]/span"));
    }

    public WebElement subsidenceNoRadiobutton() {
        return waitForElementPresent(By.xpath(".//*[@id='radio_C6__QUE_487C210376DC00A33351804_R1']/label[2]/span"));
    }

    public WebElement subsidenceCoverYesRadiobutton(int i) {
        return waitForElementPresent(By.xpath(".//*[@id='radio_C6__QUE_487C210376DC00A33351804_R" + i + "']/label[1]/span"));
    }

    public void pageLoading() {
        waitForElementEnabled(org.openqa.selenium.By.xpath("//*[@id='TXT_FAE554C988A5F3932837']/div/div[2]/div"));
    }

    public WebElement premiseOccupiedByYourBusiness(String YorN, int i) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].PREMISESONLYOCCUPIED'][value='" + value + "']";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement buildingOccupiedByYourBusiness(String YorN, int i) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].BUILDINGOCCUPIED'][value='" + value + "']";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement insureAnyOutBuilding(String YorN, int i) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].INSUREANYOUTBUILDING'][value=" + value + "]";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement premiseGrade1(String YorN, int i) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].THEMAINBUILDING[1].PREMISESGRADELIST'][value=" + value + "]";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement nextButton() {
        return waitForElementVisible(By.id("C6__btntest-click"));
    }

    public WebElement accomodation(String YorN, int i) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].ANYOTHERSERVICESORACTIVITIES'][value='" + value + "']";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement alcohol(String YorN, int i) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].ALCOHOLLICENSEATPREMISES'][value=" + value + "]";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement individualItemOfHouseHold(String YorN, int i) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].THEMAINBUILDING[1].INDIVIDUALITEMOFHOUSEHOLD'][value='" + value + "']";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement accomodationYesRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_ADFA26B138E8374B565428_R" + i + "']/label[1]/span"));
    }

    public WebElement accomodationNoRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_ADFA26B138E8374B565428_R" + i + "']/label[2]/span"));
    }

    public WebElement homeSoleOccupancyYesButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351404_R" + i + "']/label[1]/span"));
    }

    public WebElement homeSoleOccupancyNoButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351404_R" + i + "']/label[2]/span"));
    }

    public WebElement commercialSoleOccupancyYesButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351407_R" + i + "']/label[1]/span"));

    }

    public WebElement commercialSoleOccupancyNoButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351407_R" + i + "']/label[2]/span"));
    }

    public WebElement accomodationQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_ADFA26B138E8374B565428_R1']/div/label"));
    }

    public WebElement accomodationHelpTextSymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_ADFA26B138E8374B565428_R1']/div/div[1]"));
    }

    public WebElement accomodationHelpTextRadiobutton() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_ADFA26B138E8374B565428_R1']/div/div[1]"));
    }

    public WebElement accomodationHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_ADFA26B138E8374B565428_R1']/div/div[1]/div"));
    }

    public WebElement requiredErrorMessageText(int i) {
        return waitForElementPresent(By.id("C6__QUE_ADFA26B138E8374B565428_ERRORMESSAGE_R" + i));
    }

    public WebElement outbuildingQuestionText() {
        return waitForElementPresent(By.xpath(".//*[@id='C6__p1_QUE_487C210376DC00A33351423_R1']/div/label"));
    }

    public WebElement outbuildingHelpTextRadioButton(int i) {
        return waitForElementPresent(By.xpath(".//*[@id='C6__p4_QUE_487C210376DC00A33351423_R" + i + "']/div/div[1]"));
    }

    public WebElement outbuildingHelpText(int i) {
        return waitForElementPresent(By.xpath(".//*[@id='C6__p4_QUE_487C210376DC00A33351423_R" + i + "']/div/div[1]/div"));
    }

    public WebElement bbOutbuildingText(int i) {
        return waitForElementPresent(By.xpath(".//*[@id='C6__p1_QUE_487C210376DC00A33351423_R" + i + "']/div/label"));
    }

    public WebElement bbOutbuildingContent() {
        return waitForElementPresent(By.xpath(".//*[@id='C6__TXT_D4741E93375DE4193330430_R1']/div/div/p/strong"));
    }

    public WebElement bbOutbuildingHelpTextRadioButton() {
        return waitForElementPresent(By.xpath(".//*[@id='C6__p4_QUE_487C210376DC00A33351423_R1']/div/div[1]"));
    }

    public WebElement bbOutbuildingHelpText() {
        return waitForElementPresent(By.xpath(".//*[@id='C6__p4_QUE_487C210376DC00A33351423_R1']/div/div[1]/div"));
    }

    public WebElement selectBedRoomDropdownMain(int i) {
        return waitForElementVisible(By.xpath("//*[@id='C6__QUE_986DDA71FAE05BED355864_R" + i + "']"));
    }

    public WebElement selectBedRoomDropdownOut(int i) {
        return waitForElementVisible(By.xpath("//*[@id='C6__QUE_986DDA71FAE05BED363966_R" + i + "']"));
    }

    public WebElement selectBedRoomDropdownMainLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_986DDA71FAE05BED355864_R1']/div/label"));
    }

    public WebElement selectBedRoomDropdownOutLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_986DDA71FAE05BED363966_R1']/div/label"));
    }

    public WebElement bedRoomFreeFormatMain(int i) {
        return waitForElementPresent(By.id("C6__QUE_986DDA71FAE05BED355905_R" + i));
    }

    public WebElement bedRoomFreeFormatOut(int i) {
        return waitForElementPresent(By.id("C6__QUE_986DDA71FAE05BED363971_R" + i));
    }

    public WebElement bedRommHelpTextMain() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_986DDA71FAE05BED355864_R1']/div/div[1]/div"));
    }

    public WebElement bedRommHelpTextOut() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_986DDA71FAE05BED363966_R1']/div/div[1]/div"));
    }

    public WebElement bedRommHelpTextSymbolMain() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_986DDA71FAE05BED355864_R1']/div/div[1]"));
    }

    public WebElement bedRommHelpTextSymbolOut() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_986DDA71FAE05BED363966_R1']/div/div[1]"));
    }

    public WebElement validationText() {
        return waitForElementPresent(By.xpath("//*[@id='p4_QUE_F1AFB36AC27BEA642943621_R1']/div"));
    }

    public WebElement requiredTextMain() {
        return waitForElementPresent(By.id("C6__QUE_986DDA71FAE05BED355864_ERRORMESSAGE_R1"));
    }

    public WebElement requiredTextOut() {
        return waitForElementPresent(By.id("C6__QUE_986DDA71FAE05BED363966_ERRORMESSAGE_R1"));
    }

    public WebElement bedRoomFreeFormatMainLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_986DDA71FAE05BED355905_R1']/div/label"));
    }

    public WebElement bedRoomFreeFormatOutLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_986DDA71FAE05BED363971_R1']/div/label"));
    }

    public WebElement overallErrorMessage() {
        return waitForElementPresent(By.xpath("//*[@id='C6__TXT_5A8BE163633AF278269307']/div/div"));
    }

    public WebElement electricheaterOutRadiobutton(String value, int i) {

        String text = "", Option = "";
        if (value.equalsIgnoreCase("heatone") || value.equalsIgnoreCase("Y")) {
            text = "heatone";
            Option = "Yes";
        } else if (value.equalsIgnoreCase("heattwo") || value.equalsIgnoreCase("N")) {
            text = "heattwo";
            Option = "No";
        } else if (value.equalsIgnoreCase("heathree")) {
            text = "heathree";
            Option = "Not heated";
        } else {
            Assert.assertTrue("Optional Field", true);
        }

        String xpath = "//*[@id='C6__row_heatingListOB1_R" + i + "' or @id='C6__row_heatingListOB2_R" + i + "']/div[4]/div/div/input[@type='radio'][@value='" + text + "'][not(@disabled='disabled')]/../label/span[text()='" + Option + "']";
        return waitForElementPresent(org.openqa.selenium.By.xpath(xpath));
    }


    public WebElement fireplaceOutYesRadiobutton(int i) {

        return waitForElementPresent(By.xpath("//*[@id='radio_C6__heatingListOB1_R" + i + "' or @id='radio_C6__heatingListOB2_R" + i + "']/label[1]/span"));

    }

    public WebElement fireplaceOutNoRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__heatingListOB1_R" + i + "']/label[2]/span"));
    }

    public WebElement fireplaceOutNotheatedRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__heatingListOB1_R" + i + "']/label[3]/span"));
    }

    public List<WebElement> selfCateringQuestionLabelHB() {
        return findElements(By.xpath("//*[@id='C6__p1_QUE_F5A203272682B5E7508623_R1']/div/label"));
    }

    public WebElement selfCateringQuestionLabel() {

        return waitForElementVisible(By.xpath("//*[@id='C6__p1_QUE_F5A203272682B5E7508623_R1']/div/label"));
    }

    public WebElement selfCateringHelpTextQuestion() {
        return waitForElementVisible(By.xpath("//*[@id='C6__p4_QUE_F5A203272682B5E7508551_R1']/div/div[1]"));
    }

    public WebElement selfCateringHelpTextValue() {
        return waitForUnstableElement(By.xpath("//*[@id='C6__p4_QUE_F5A203272682B5E7508551_R1']/div/div[1]/div"));
    }

    public WebElement selfCateringQuestionYesRadioButton() {
        return waitForElementPresent(By.xpath(""));
    }

    public WebElement mainBuildingUsageDropDown(int i) {
        return waitForElementVisible(By.xpath("//select[starts-with(@name,'C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].THEMAINBUILDING[1].BUILDINGUSAGE')][not(@disabled='disabled')]"));
    }

    public WebElement buiildingUsageFreeformattext(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_F5A203272682B5E7222275_R" + i + "']"));
    }

    public WebElement outBuildingUsageDropDown(int i) {
        return waitForElementPresent(By.xpath("//select[starts-with(@name,'C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].OUTBUILDINGS[1].BUILDINGUSAGE')][not(@disabled='disabled')]"));
    }

    public WebElement outbuildingUsageFreeformattext(int i) {
        return waitForElementPresent(By.id("C6__QUE_F5A203272682B5E7230463_R" + i));
    }

    public WebElement commMainBuildingUsageDropDown(int i) {
        //*[@id="C6__QUE_1AD6973D247511431021240_R2"]
        //*[@id="C6__QUE_1AD6973D247511431021443_R2"]
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_1AD6973D247511431021240_R" + i + "']"));
    }

    public WebElement commOutBuildingUsageDropDown(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_1AD6973D247511431037585_R" + i + "' or @id='C6__QUE_1AD6973D247511431037596_R" + i + "']"));
    }

    public WebElement mainBuildingUsageDropDownLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_1AD6973D247511431021240_R1']/div/label"));
    }

    public List<WebElement> mainBuildingUsageDropDownLabel(int i){
         return findElements(By.xpath("//*[@id='C6__p1_QUE_1AD6973D247511431021240_R" + i + "']/div/label"));
    }

    public WebElement outBuildingUsageDropDownLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_1AD6973D247511431037607_R1']/div/label"));
    }

    public WebElement mainSelfCateringQuestionYesRadioButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_F5A203272682B5E7508551_R" + i + "']/label[1]/span"));
    }

    public WebElement mainSelfCateringQuestionNoRadioButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_F5A203272682B5E7508551_R" + i + "']/label[2]/span"));
    }

    public WebElement outSelfCateringQuestionYesRadioButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_F5A203272682B5E7508623_R" + i + "']/label[1]/span"));
    }

    public WebElement outSelfCateringQuestionNoRadioButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_F5A203272682B5E7508623_R" + i + "']/label[2]/span"));
    }

    public WebElement strPremiseIsThisYourHome(String YorN, int i) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].ISTHISALSOYOURHOME'][value='" + value + "']";
        return waitForElementPresent(By.cssSelector(cssSelector));

    }

    public WebElement riskAddressQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_E920C764E3F51E921816825_R1']/div/label"));
    }

    public WebElement riskAddressYesRadioButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_E920C764E3F51E921816825_R" + i + "']/label[1]/span"));
    }

    public WebElement riskAddressNoRadioButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_E920C764E3F51E921816825_R" + i + "']/label[2]/span"));
    }

    public WebElement requiredTextFreeFormatMain(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_986DDA71FAE05BED355905_ERRORMESSAGE_R" + i + "']"));
    }

    public WebElement requiredTextFreeFormatOut(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_986DDA71FAE05BED363971_ERRORMESSAGE_R" + i + "']"));
    }

    public WebElement addAnotherPremise() {

        return waitForElementPresent(By.xpath(".//*[@id='C6__BUT_C199340925265878334264']"));
    }

    public WebElement premiseSection() {
        return waitForElementPresent(By.xpath("//*[@id='premises-table']"));
    }

    public WebElement riskAddressButtonList(int i) {
        return waitForElementPresent(By.id("C6__QUE_E920C764E3F51E921816825_0_R" + i));
    }

    public WebElement premiseGrade1ListedLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351725_R1']/div/label"));
    }

    public WebElement checkedPremisesType(int i) {
        return waitForElementPresent(By.cssSelector("[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].ISTHISALSOYOURHOME']"));
    }

    public WebElement outPremiseGrade1ListedLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351835_R1']/div/label"));
    }

    public WebElement outPremiseGradeYesRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351835_R" + i + "']/label[1]/span"));
    }

    public WebElement outPremiseGradeNoRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351835_R" + i + "']/label[2]/span"));
    }

    public WebElement outWallMaterialYesRadiobutton(int i) {

        return waitForUnstableElement(By.xpath("//*[@id='C6__row_wallMaterialTimberOB_R" + i + "' or @id='C6__row_wallMaterialOB_R" + i + "' or @id='C6__wallMaterialOB_R" + i + "']/div[4]/div/div/input[@type='radio'][@value='Y'][not(@disabled='disabled')]/../label/span[text()='Yes']"));
    }       //*[@id="radio_C6__wallMaterialOB_R1"]/label[1]/span

    public WebElement outWallMaterialNoRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__row_wallMaterialTimberOB_R" + i + "' or @id='C6__row_wallMaterialOB_R" + i + "' or @id='C6__wallMaterialOB_R" + i + "']/div[4]/div/div/input[@type='radio'][@value='N'][not(@disabled='disabled')]/../label/span[text()='No']"));
    }

    public WebElement outWallMaterialTimberYesRadiobutton(int i) {

        return waitForUnstableElement(By.xpath("//*[@id='C6__row_wallMaterialTimberOB_R" + i + "' or @id='C6__wallMaterialOB_R" + i + "']/div[4]/div/div/input[@type='radio'][@value='Y'][not(@disabled='disabled')]/../label/span[text()='Yes']"));
    }       //*[@id="radio_C6__wallMaterialOB_R1"]/label[1]/span

    public WebElement outWallMaterialTimberNoRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__row_wallMaterialTimberOB_R" + i + "' or @id='C6__wallMaterialOB_R" + i + "']/div[4]/div/div/input[@type='radio'][@value='N'][not(@disabled='disabled')]/../label/span[text()='No']"));
    }

    public WebElement outRoofMaterialYesRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__roofMaterialOB_R" + i + "']/label[1]/span"));
    }

    public WebElement outRoofMaterialNoRadiobutton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__roofMaterialOB_R" + i + "']/label[2]/span"));
    }

    public WebElement flatsOption() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351412_R1']/label[1]/p/span"));
    }

    public WebElement officesOption() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351412_R1']/label[2]/p/span"));
    }

    public WebElement foodTakeAwayOption() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351412_R1']/label[3]/p/span"));
    }

    public WebElement retailOption() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351412_R1']/label[4]/p/span"));
    }

    public WebElement vacantOption() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351412_R1']/label[5]/p/span"));
    }

    public WebElement commercialOption() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351412_R1']/label[6]/p/span"));
    }

    public WebElement soleControlYesButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351415_R" + i + "']/label[1]/span"));
    }

    public WebElement soleControlNoButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351415_R" + i + "']/label[2]/span"));
    }

    public String salonSharedOccupancyLbl() {
        return "//*[@id='C6__p1_QUE_487C210376DC00A33351407_R1']/div/label";
    }

    public String homeSharedOccupancyLbl() {
        return "//*[@id='C6__p1_QUE_487C210376DC00A33351404_R1']/div/label";
    }

    public WebElement buildingUsageFreeFormatlbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_F5A203272682B5E7222275_R1']/div/label"));
    }

    public WebElement buildingUsageDropDown() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_1AD6973D247511431021443_R1']"));
    }

    public WebElement PleaseTellUsBuildingUsedFor(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_F5A203272682B5E7222275_R" + i + "']"));
    }

    public WebElement buildingUsageHelpTextQuestionMark() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_1AD6973D247511431021443_R1']/div/div[1]"));
    }

    public WebElement buildingUsageHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_1AD6973D247511431021443_R1']/div/div[1]/div"));
    }

    public WebElement buildingUsageValidationMessage() {
        return waitForElementPresent(By.id("C6__QUE_1AD6973D247511431021443_ERRORMESSAGE_R1"));
    }

    public WebElement FreeFormatBUValidationMessage() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_F5A203272682B5E7222275_ERRORMESSAGE_R1']"));
    }

    public WebElement houseHoldContentLable() {
        return waitForElementPresent(By.xpath("//*[@id='C6__TXT_487C210376DC00A33382609_R1']/div"));
    }

    public List<WebElement> buildingTypeDropDown(int i) {
        return findElements(By.xpath(".//*[@id='C6__QUE_487C210376DC00A33351721_R" + i + "']"));
    }

    public WebElement buildingTypeLable() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351721_R1']/div/label"));
    }

    public WebElement lableATM() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351421_R1']/div/label"));
    }

    public WebElement mainBuildingStockRemoveButton(int i) {
        return waitForElementPresent(By.id("C6__BUT_130910B8F1739FAC1055243_R" + i));
    }

    public WebElement outBuildingStockWSRemoveButton(int i) {
        return waitForElementPresent(By.id("C6__BUT_130910B8F1739FAC1055153_R" + i));
    }

    public WebElement outBuildingStockRemoveButton(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351664_R" + i));
    }

    public WebElement outBusninessContentAddCover(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351648_R" + i));
    }

    public WebElement outBusinessContentTextBox(int i) {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351640_R" + i + ""));
    }

    public WebElement outStockAddCover(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351668_R" + i + ""));
    }

    public WebElement outBusinessStockTextBox(int i) {
        return waitForElementPresent(org.openqa.selenium.By.cssSelector("input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].CONTENTS[1].OUTBUILDINGS[1].YOURSTOCK']"));
    }

    public WebElement outStockWinesSpiritTextBox(int i) {
        String cssSelector = "C6__QUE_130910B8F1739FAC998070_R" + i;
        return waitForElementPresent(By.id(cssSelector));
    }

    public WebElement outHouseholdContentAddCover(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351688_R" + i + ""));
    }

    public WebElement outHouseholdContentTextBox(int i) {
        return waitForElementPresent(By.id("C6__outter_household_content_R" + i + ""));
    }

    public WebElement outbuildingAddCover(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351514_R" + i + ""));
    }

    public WebElement outBuildingTextBox(int i) {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351506_R" + i));
    }

    public WebElement storageHeatingYesRadiobutton(int i) {

        return waitForElementPresent(By.xpath("((//*[@id='radio_C6__heatingList_R" + i + "' or @id='radio_C6__heatingList2_R" + i + "']/input[@value='heatone'][not(@disabled='disabled')])/..)//label[1]/span"));
    }

    public WebElement storageHeatingNoRadiobutton(int i) {
        return waitForElementPresent(By.xpath("((//*[@id='radio_C6__heatingList_R" + i + "' or @id='radio_C6__heatingList2_R" + i + "']/input[@value='heattwo'][not(@disabled='disabled')])/..)//label[2]/span"));
    }

    public WebElement storageHeatingNotHeatedRadiobutton(int i) {
        return waitForElementPresent(By.xpath("((//*[@id='radio_C6__heatingList_R" + i + "' or @id='radio_C6__heatingList2_R" + i + "']/input[@value='heathree'][not(@disabled='disabled')])/..)//label[3]/span"));
    }

    public WebElement typeOfBuglarAlarmLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351789_R1']/div/label"));
    }

    public WebElement alarmSoleControlLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351791_R1']/div/label"));
    }

    public WebElement alarmPoliceResponseLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351794_R1']/div/label"));
    }

    public WebElement alarmMaintainLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351796_R1']/div/label"));
    }

    public WebElement outTypeOfBuglarAlarmLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351893_R1']/div/label"));
    }

    public WebElement outAlarmSoleControlLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351895_R1']/div/label"));
    }

    public WebElement outAlarmPoliceResponseLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351898_R1']/div/label"));
    }

    public WebElement outAlarmMaintainLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351900_R1']/div/label"));
    }

    public WebElement salonBars(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351786_R" + i + "']/label[1]/p/span"));
    }

    public WebElement salonSteel(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351786_R" + i + "']/label[2]/p/span"));
    }

    public WebElement salonMetal(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351786_R" + i + "']/label[3]/p/span"));
    }

    public WebElement salonShopping(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351786_R" + i + "']/label[6]/p/span"));
    }

    public WebElement salonFamily(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351786_R" + i + "']/label[7]/p/span"));
    }

    public WebElement homeFeaturesList() {
        return waitForElementPresent(By.id("checkbox_C6__QUE_2C52FB4E7723E7D53616194_R1"));
    }

    public WebElement salonFeaturesList() {
        return waitForElementPresent(By.id("checkbox_C6__QUE_487C210376DC00A33351786_R1"));
    }

    public WebElement outSalonFeaturesList() {
        return waitForElementPresent(By.id("checkbox_C6__QUE_487C210376DC00A33351890_R1"));
    }

    public WebElement outHomeFeaturesList() {
        return waitForElementPresent(By.id("checkbox_C6__QUE_01CCC26BF28AA7161411763_R1"));
    }

    public WebElement homeCctvOption(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_2C52FB4E7723E7D53616194_R" + i + "']/label[1]/p/span"));
    }
    public WebElement homeCctvOptionOutBuilding(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_01CCC26BF28AA7161411763_R" + i + "']/label[1]/p/span"));
    }

    public WebElement homeBurglarOption(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_2C52FB4E7723E7D53616194_R" + i + "']/label[2]/p/span"));
    }

    public WebElement homeBurglarOptionid(int i) {
        return waitForUnstableElement(By.id("C6__QUE_2C52FB4E7723E7D53616194_1_R" + i));
    }

    public WebElement securityFeatureMainBuildingNone(int i) {
        return waitForUnstableElement(By.xpath("//*[@id='checkbox_C6__QUE_2C52FB4E7723E7D53616194_R" + i + "']/label[3]|//*[@id='checkbox_C6__QUE_487C210376DC00A33351786_R" + i + "']/label[8]"));
    }

    public WebElement securityFeatureOutBuildingNone(int i) {
        return waitForUnstableElement(By.xpath("//*[@id='checkbox_C6__QUE_01CCC26BF28AA7161411763_R" + i + "']/label[3]|//*[@id='checkbox_C6__QUE_487C210376DC00A33351890_R" + i + "']/label[8]"));
    }

    public WebElement homeNoneOption(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_2C52FB4E7723E7D53616194_R" + i + "']/label[3]/p/span"));
    }

    public WebElement homeNoneOptionid(int i) {
        return waitForElementPresent(By.id("C6__QUE_2C52FB4E7723E7D53616194_2_R" + i));
    }

    public WebElement saloncctvOption(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351786_R" + i + "']/label[4]/p/span"));
    }

    public WebElement saloncctvOptionid(int i) {
        return waitForUnstableElement(By.id("C6__QUE_2C52FB4E7723E7D53616194_0_R" + i));
    }

    public WebElement salonNoneOption(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351786_R" + i + "']/label[8]/p/span"));
    }

    public WebElement salonBurglarOption(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351786_R" + i + "']/label[5]/p/span"));
    }

    public WebElement alarmUnderyourBusiness(String YorN, int i) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].ALARM[1].ALARMUNDERBUSINESS'][value=" + value + "]";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement alarmType(int i) {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351789_R" + i));
    }

    public WebElement underControlYes(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351791_R" + i + "']/label[1]/span"));
    }

    public WebElement underControlNo(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351791_R" + i + "']/label[2]/span"));
    }

    public WebElement policeResponse(int i) {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351794_R" + i));
    }

    public WebElement alarmMaintenance(int i) {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351796_R" + i));
    }

    public WebElement alcoholYesButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_C52562CE2C2637941591450_R" + i + "']/label[1]/span"));
    }

    public WebElement alcoholNoButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_C52562CE2C2637941591450_R" + i + "']/label[2]/span"));
    }

    public List<WebElement> alcoholQuestionLbl() {
        return findElements(By.xpath("//*[@id='C6__p1_QUE_C52562CE2C2637941591450_R1']/div/label"));
    }

    public WebElement alcoholQuesLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_C52562CE2C2637941591450_R1']/div/label"));
    }

    public WebElement alcoholQuestionRequiredMsg(int i) {
        return waitForElementPresent(By.id("C6__QUE_C52562CE2C2637941591450_ERRORMESSAGE_R" + i));
    }

    public WebElement outbuildingFirePlace(String value, int i) {
        String text = "heathree";
        if (value.equalsIgnoreCase("heatone")) {
            text = "heatone";
        } else if (text.equalsIgnoreCase("heattwo")) {
            text = "heattwo";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].OUTBUILDINGSFORCC[1].OPENFIREPLACES'][value=" + text + "]";
        return waitForUnstableElement(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement outbuildingElectricHeater(String value, int i) {
        String text = "", Option = "";
        if (value.equalsIgnoreCase("heatone") || value.equalsIgnoreCase("Y")) {
            text = "heatone";
            Option = "Yes";
        } else if (value.equalsIgnoreCase("heattwo") || value.equalsIgnoreCase("N")) {
            text = "heattwo";
            Option = "No";
        } else if (value.equalsIgnoreCase("heathree")) {
            text = "heathree";
            Option = "Not heated";
        }
        String xpath = "(//div[@id='C6__p4_heatingListOB2_R" + i + "' or @id='C6__p4_heatingListOB1_R" + i + "' or @id='C6__p4_heatingList3_R" + i + "']/div/div/input[@type='radio'][@value='" + text + "'][not(@disabled='disabled')]/..)/label/span[text()='" + Option + "']";
        return waitForElementPresent(By.xpath(xpath));
    }


    public WebElement businessContentAndStockMainLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_BD3550F8E469E3F81315171_R1']/div/label"));
    }

    public WebElement businessContentAndStockOutLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_BD3550F8E469E3F81315180_R1']/div/label"));
    }

    public WebElement businessContentAndStockMainSymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_BD3550F8E469E3F81315171_R1']/div/div"));
    }

    public WebElement businessContentAndStockOutSymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_BD3550F8E469E3F81315180_R1']/div/div"));
    }

    public WebElement businessContentAndStockMainHelptext() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_BD3550F8E469E3F81315171_R1']/div/div/div"));
    }

    public WebElement businessContentAndStockOutHelptext() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_BD3550F8E469E3F81315180_R1']/div/div/div"));
    }

    public WebElement businessContentMainLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_BD3550F8E469E3F81315171_R1']/div/label"));
    }

    public WebElement businessContentOutLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_BD3550F8E469E3F81315180_R1']/div/label"));
    }

    public WebElement businessStockMainLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__TXT_487C210376DC00A33382589_R1']/div"));
    }

    public WebElement businessStockOutLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__TXT_487C210376DC00A33382653_R1']/div"));
    }

    public WebElement householdContentMainLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__TXT_487C210376DC00A33382609_R1']/div"));
    }

    public WebElement householdContentOutLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__TXT_487C210376DC00A33382673_R1']/div"));
    }

    public WebElement reqMsgExWSMain() {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351576_ERRORMESSAGE_R1"));
    }

    public WebElement reqMsgExWSOut() {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351640_ERRORMESSAGE_R1"));
    }

    public WebElement reqMsgWSMain() {
        return waitForElementPresent(By.id("C6__QUE_130910B8F1739FAC998004_ERRORMESSAGE_R1"));
    }

    public WebElement reqMsgWSOut() {
        return waitForElementPresent(By.id("C6__QUE_130910B8F1739FAC998070_ERRORMESSAGE_R1"));
    }

    public WebElement alcoholLicMsg() {
        return waitForElementPresent(By.id("C6__QUE_C52562CE2C2637941591450_ERRORMESSAGE_R1"));
    }


    public WebElement excludingWSMainLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_BD3550F8E469E3F81315171_R1']/div/label"));
    }

    public WebElement excludingElectricalItemsQues(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_BD3550F8E469E3F81315171_R"+i+"']/div/label"));
    }

    public WebElement excludingWSOutLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_BD3550F8E469E3F81315180_R1']/div/label"));
    }

    public WebElement excludingWSMainTextbox(int i) {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351576_R" + i));
    }

    public WebElement excludingWSOutTextbox(int i) {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351640_R" + i));
    }

    public WebElement excludingWSMainSymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_BD3550F8E469E3F81315171_R1']/div/div"));
    }

    public WebElement excludingWSOutSymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_BD3550F8E469E3F81315180_R1']/div/div"));
    }

    public WebElement excludingWSMainHepltext() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_BD3550F8E469E3F81315171_R1']/div/div/div"));
    }

    public WebElement excludingElectricalItemsHT(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_BD3550F8E469E3F81315171_R"+i+"']/div/div/div"));
    }

    public WebElement excludingWSOutHepltext() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_BD3550F8E469E3F81315180_R1']/div/div/div"));
    }

    public WebElement wineSpiritMainLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_130910B8F1739FAC997984_R1']/div/label"));
    }

    public WebElement stockQues(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_A186727BE6B54A084071175_R"+i+"']/div/label"));
    }


    public WebElement electricalItemsQues(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_130910B8F1739FAC997984_R"+i+"']/div/label"));
    }



    public WebElement wineSpiritOutLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_130910B8F1739FAC998053_R1']/div/label"));
    }

    public WebElement wineSpiritMainSymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_130910B8F1739FAC997984_R1']/div/div"));
    }

    public WebElement wineSpiritOutSymbol() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_130910B8F1739FAC998053_R1']/div/div"));
    }

    public WebElement wineSpiritMainHepltext() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_130910B8F1739FAC997984_R1']/div/div/div"));
    }

    public WebElement stocksHelpText(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_A186727BE6B54A084071175_R"+i+"']/div/div/div"));
    }

    public WebElement electricalItemsHT(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_130910B8F1739FAC997984_R"+i+"']/div/div/div"));
    }

    public WebElement wineSpiritOutHepltext() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_130910B8F1739FAC998053_R1']/div/div/div"));
    }


    public WebElement wineSpiritOutTextbox(int i) {
        return waitForElementPresent(By.id("C6__QUE_130910B8F1739FAC998070_R" + i));
    }

    public WebElement wineSpiritRemoveCover(int i) {
        return waitForElementPresent(By.id("C6__BUT_130910B8F1739FAC1055243_R" + i));
    }

    public WebElement mainBuildingUsageDDL(int i) {
        return waitForElementVisible(By.xpath("//select[starts-with(@name,'C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].THEMAINBUILDING[1].BUILDINGUSAGE')][not(@disabled='disabled')]"));
    }

    public WebElement requiredBedRoomDDL() {
        return waitForElementPresent(By.id("C6__QUE_986DDA71FAE05BED355864_ERRORMESSAGE_R1"));
    }

    public List<WebElement> building1Heading() {
        return findElements(By.xpath(".//*[@id='C6__TXT_487C210376DC00A33382430_R1']/div/p"));
    }

    public WebElement addWallMaterial(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351743_R" + i));
    }

    public List<WebElement> building2Heading() {
        return findElements(By.xpath(".//*[@id='C6__TXT_487C210376DC00A33382494_R1']/div/p"));
    }

    public WebElement wallmaterialdropdown() {
        return waitForElementPresent(By.id("C6__QUE_F3873DAD39E5FC15268256"));
    }

    public List<WebElement> building1ContentHeading() {
        return findElements(By.xpath(".//*[@id='C6__TXT_487C210376DC00A33382564_R1']/div/p"));
    }

    public WebElement wallMaterialPopupAddMaterial() {
        return waitForElementPresent(By.id("C6__BUT_18A2076AEDA65E8E300485"));

    }

    public List<WebElement> building2ContentHeading() {
        return findElements(By.xpath(".//*[@id='C6__TXT_487C210376DC00A33382628_R1']/div/p"));
    }

    public WebElement addARoofMaterial(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351759_R" + i));
    }

    public List<WebElement> building1SectionHeading() {
        return findElements(By.xpath(".//*[@id='C6__TXT_487C210376DC00A33382717_R1']/div/div/p/strong"));
    }

    public WebElement addRoofMaterialPopupDropdon() {
        return waitForElementPresent(By.id("C6__QUE_867EFCFA124662CA686584"));
    }

    public List<WebElement> building2SectionHeading() {
        return findElements(By.xpath(".//*[@id='C6__TXT_487C210376DC00A33382831_R1']/div/div/p/strong"));
    }

    public WebElement addRoofMaterialPopupAdd() {
        return waitForElementPresent(By.id("C6__BUT_FD68CC7E83AB4EB3414919"));
    }

    public WebElement wallsMadeSololyBrickYes(int i) {
        return waitForElementPresent(By.id("C6__wallMaterialTimber_0_R" + i));
    }

    public WebElement wallsMadeSololyBrickNo(int i) {
        return waitForElementPresent(By.id("C6__wallMaterialTimber_1_R" + i));
    }

    public WebElement householdremovecover(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351620_R" + i));
    }

    public WebElement validationMessageGAResidentialCC() {
        return waitForElementPresent(By.xpath(""));
    }

    public WebElement validationMessageGAResidentialWJ() {
        return waitForElementPresent(By.xpath(""));
    }

    public WebElement validationMessageResidentialCC() {
        return waitForElementPresent(By.xpath(""));
    }

    public WebElement validationMessageResidentialWJ() {
        return waitForElementPresent(By.xpath(""));
    }

    public WebElement validationMessageGACC() {
        return waitForElementPresent(By.xpath(""));
    }

    public WebElement validationMessageGAWJ() {
        return waitForElementPresent(By.xpath(""));
    }

    public WebElement validationMessageGAOnlyCC() {
        return waitForElementPresent(By.xpath(""));
    }

    public WebElement validationMessageGAOnlyWJ() {
        return waitForElementPresent(By.xpath(""));
    }

    public WebElement buildingCoverLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_B477726732A860C1416209_R1']/div/label"));
    }

    public WebElement glassLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_B477726732A860C1446742_R1']/div/label"));
    }

    public WebElement fixturesFittingsLbl() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_B477726732A860C1446760_R1']/div/label"));
    }

    public WebElement staticText() {
        return waitForElementPresent(By.xpath("//*[@id='C6__TXT_BAD930B9FE7D30651043528_R1']/div/p"));
    }

    public WebElement textOR() {
        return waitForElementPresent(By.xpath("//*[@id='C6__TXT_BAD930B9FE7D3065583522_R1']/div/p/strong"));
    }

    public List<WebElement> tradeTableRow() {
        return findElements(org.openqa.selenium.By.xpath("//table[@id='C6__TBL_7BD680E924B876701932320_R1']/tbody/tr/td[1]"));
    }

    public WebElement trade(int i) {
        return waitForElementPresent(By.id("C6__p1_TBL_7BD680E924B876701932320_R" + i));
    }

    public WebElement tradeselect(int i, int trade) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_7BD680E924B876701944052_R" + i + "_" + trade + "']/label"));
    }

    public WebElement premiseTypeOfItem() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_880160F8F183EC16674655']"));
    }

    public WebElement premiseValueOfItem() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_880160F8F183EC16674665']"));
    }

    public WebElement premiseItemDescription() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_880160F8F183EC16674670']"));
    }

    public WebElement premiseNamedItemPopUpAddButton() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_880160F8F183EC16674764']"));
    }

    public WebElement premiseNamedItemAddButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_880160F8F183EC16836993_R" + i + "']"));
    }

    public WebElement propertyAwayNoRadioButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351810_R1']/label[2]/span"));

    }


    public WebElement propertyDamageNoRadioButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351807_R1']/label[2]/span"));

    }

    public WebElement validationMessage() {
        return waitForElementPresent(By.xpath("//*[@id='p4_QUE_F1AFB36AC27BEA642943621_R1']/div"));
    }

    public WebElement saveAndExit() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_C1993409252658783074906']"));
    }

    public WebElement saveAndExitPopUp() {
        return waitForElementPresent(By.xpath("//*[@id='BUT_D3E81D5ED026892F1577152']"));
    }

    public WebElement householdContentNoValue() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__namedItem_R1']/label[2]/span"));
    }

    public WebElement premiseGrade1ListedQuestion1() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351725_R1']/div/label"));
    }

    public WebElement premiseGrade1ListedQuestion2() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351835_R1']/div/label"));
    }

    public WebElement mainbuildingYearOfConstruction() {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351723_ERRORMESSAGE_R1"));
    }

    public WebElement outbuildingYearOfConstruction() {
        return waitForElementPresent(By.id("C6__QUE_39714F51D2CE4499244134_ERRORMESSAGE_R1"));
    }

    public WebElement outbuildingShopAddCoverLink(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351534_R" + i));
    }

    public WebElement outbuildingShopValueTextbox(int i) {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351526_R" + i));
    }

    public WebElement outbuildingfittingValueTextbox(int i) {
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351546_R" + i));
    }

    public WebElement outbuildingfittingAddCoverLink(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351554_R" + i));
    }

    public WebElement outbuildingPropertyBuiltDrodown(int i) {
        return waitForElementPresent(By.id("C6__QUE_39714F51D2CE4499244134_R" + i));
    }

    public WebElement itemTable() {
        return waitForElementPresent(By.id("C6__row_namedItemTable"));
    }

    public WebElement premiseItemKept(String buildingType) {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_FC0945D6732BAE231299027']//span[contains(text(),'" + buildingType + "')]"));
    }

    public WebElement premiseAddAnotherNamedItemButton(int i) {
        return waitForElementPresent(By.xpath("//button[@id='C6__BUT_880160F8F183EC16836993_R1']"));
    }

    public WebElement gradeQuesHelpText() {
        return waitForUnstableElement(org.openqa.selenium.By.xpath("//*[@id='C6__p4_QUE_487C210376DC00A33351725_R1']/div/div[1]/div"));

    }

    public WebElement yourBuildingQuesText() {
        return waitForUnstableElement(org.openqa.selenium.By.xpath("//*[@id='C6__p4_QUE_B477726732A860C1416209_R1']/div/div/div"));

    }

    public WebElement popupItemValueHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_880160F8F183EC16674665']/div/div/div"));
    }

    public WebElement buildingFixtureFitGlassHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_B477726732A860C1416209_R1']/div/div/div"));
    }

    public WebElement glassHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_B477726732A860C1446742_R1']/div/div/div"));
    }

    public WebElement fixturesFittings() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_B477726732A860C1446760_R1']/div/div/div"));
    }



    public WebElement excludingElectricItemsHT() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_BD3550F8E469E3F81315171_R1']/div/div/div"));
    }


    public WebElement premisesUnoccupiedText(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351418_R" + i + "']/label[3]/p/span"));
    }

    public WebElement premisesUnoccupiedHelptext(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_487C210376DC00A33351418_R" + i + "']/div/div[1]/div"));
    }

    public WebElement premisesUnoccupiedHelptextSymbol(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_487C210376DC00A33351418_R" + i + "']/div/div[1]"));
    }

    public WebElement postcodeRequiredMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351352_ERRORMESSAGE_R1']"));
    }

    public WebElement premisesTypeRequiredMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351376_ERRORMESSAGE_R1']"));
    }

    public WebElement applyBusinessRequiredMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351418_ERRORMESSAGE_R1']"));
    }

    public WebElement insureOutContentActualRequiredMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351423_ERRORMESSAGE_R1']"));
    }

    public WebElement subsidenceRequiredMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351804_ERRORMESSAGE_R1']"));
    }

    public WebElement haveStartedTrade() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351418_R1']//span[contains(text(),'trading')]"));
    }

    public WebElement premisesUnoccupied() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351418_R1']//span[contains(text(),'The premises are currently unoccupied')]"));
    }

    public WebElement duringYearUnoccupied() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351418_R1']//span[contains(text(),'During the year')]"));
    }

    public WebElement noneAbove() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351418_R1']//span[contains(text(),'None')]"));
    }

    public WebElement subsidenceYes() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351804_R1']/label[1]/span"));
    }

    public WebElement propertyDamageRequiredMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351807_ERRORMESSAGE_R1']"));
    }

    public WebElement riverBankRequiredMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351810_ERRORMESSAGE_R1']"));
    }

    public WebElement enterAddressManually() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_DC5F6B3F96DFE011398257_R1']"));
    }
    public WebElement firstLineAddress(){
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351361_R1"));
    }
    public WebElement secondLineAddress(){
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351364_R1"));
    }
    public WebElement addressTown(){
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351367_R1"));
    }
    public WebElement addressCounty(){
        return waitForElementPresent(By.id("C6__QUE_4DACBD9E1710D5B24685571_R1"));
    }
    public WebElement addressCountry(){
        return waitForElementPresent(By.id("C6__QUE_487C210376DC00A33351370_R1"));
    }
    public WebElement businessLineOneMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351361_ERRORMESSAGE_R1']"));
    }

    public WebElement businessCityMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351367_ERRORMESSAGE_R1']"));
    }

    public WebElement businessCountryMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351370_ERRORMESSAGE_R1']"));
    }

    public WebElement findAddress() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_487C210376DC00A33351355_R1']"));
    }

    public WebElement noResultsFound() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351352_ERRORMESSAGE_R1']"));
    }

    public WebElement premisesFamily() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351404_ERRORMESSAGE_R1']"));
    }

    public WebElement occupiedBusinessNoButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351407_R1']/label[2]/span"));
    }

    public WebElement otherPortionRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351412_ERRORMESSAGE_R1']"));
    }

    public WebElement soleControlRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351415_ERRORMESSAGE_R1']"));
    }

    public WebElement mainBuildingRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351442_ERRORMESSAGE_R1']"));
    }

    public WebElement outBuildingRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351506_ERRORMESSAGE_R1']"));
    }

    public WebElement busContentMainRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351506_ERRORMESSAGE_R1']"));
    }

    public WebElement busContentOutRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351506_ERRORMESSAGE_R1']"));
    }

    public WebElement stockMainRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351506_ERRORMESSAGE_R1']"));
    }

    public WebElement stockOutRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351506_ERRORMESSAGE_R1']"));
    }

    public WebElement houseMainRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351506_ERRORMESSAGE_R1']"));
    }

    public WebElement houseOutRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351506_ERRORMESSAGE_R1']"));
    }

    public WebElement houseMoreRqdMsg() {
        return waitForElementPresent(By.id("C6__namedItem_ERRORMESSAGE_R1"));
    }

    public WebElement buildingTypeRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351721_ERRORMESSAGE_R1']"));
    }

    public WebElement propertyBuiltRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351723_ERRORMESSAGE_R1']"));
    }

    public WebElement gradeOneRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351725_ERRORMESSAGE_R1']"));
    }

    public WebElement wallRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__wallMaterialTimber_ERRORMESSAGE_R1']"));
    }

    public WebElement roofRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__roofMaterial_ERRORMESSAGE_R1']"));
    }

    public WebElement heatRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__heatingList_ERRORMESSAGE_R1']"));
    }

    public WebElement securityRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_2C52FB4E7723E7D53616194_ERRORMESSAGE_R1']"));
    }

    public WebElement typeBurglarRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351789_ERRORMESSAGE_R1']"));
    }

    public WebElement alarmControlRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351791_ERRORMESSAGE_R1']"));
    }

    public WebElement policeResponseRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351794_ERRORMESSAGE_R1']"));
    }

    public WebElement maintainAlarmRqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351796_ERRORMESSAGE_R1']"));
    }

    public WebElement gradeOneORqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351835_ERRORMESSAGE_R1']"));
    }

    public WebElement wallORqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__wallMaterialTimberOB_ERRORMESSAGE_R1']"));
    }

    public WebElement roofORqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__roofMaterialOB_ERRORMESSAGE_R1']"));
    }

    public WebElement heatORqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__heatingListOB1_ERRORMESSAGE_R1']"));
    }

    public WebElement securityORqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_01CCC26BF28AA7161411763_ERRORMESSAGE_R1']"));
    }

    public WebElement burglarOutCheckBox() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_01CCC26BF28AA7161411763_R1']/label[2]"));
    }

    public WebElement burglarMainCheckBox() {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_2C52FB4E7723E7D53616194_R1']/label[2]"));
    }

    public WebElement typeBurglarORqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351893_ERRORMESSAGE_R1']"));
    }

    public WebElement alarmControlORqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351895_ERRORMESSAGE_R1']"));
    }

    public WebElement policeResponseORqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351898_ERRORMESSAGE_R1']"));
    }

    public WebElement maintainAlarmORqdMsg() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351900_ERRORMESSAGE_R1']"));
    }

    public WebElement removePremButton() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_487C210376DC00A33351904_R1']"));
    }

    public WebElement warningNoButton() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_C733B28AC91D29DA1202534_R1']"));
    }

    public WebElement warningMsgPremises() {
        return waitForElementPresent(By.xpath("//*[@id='C6__HEAD_C733B28AC91D29DA1190876_R1']"));
    }

    public WebElement warningMsgNamed() {
        return waitForElementPresent(By.xpath("(//div/div/div/div/div/div/div/div/h3[@id='C6__HEAD_0B1BD47FE63EAAAC291602'][contains(text(),'Warning - you will lose the items you have added, do you want to continue?')])[1]"));
    }

    public WebElement warningNamedYesButton() {
        return waitForElementPresent(By.xpath("(//div/div/div/div/div/button[@id='C6__BUT_0B1BD47FE63EAAAC291605'])[1]"));
    }

    public WebElement addWallMainButton(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_487C210376DC00A33351743_R"+i+"']"));
    }

    public WebElement addWallPopUp() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_18A2076AEDA65E8E300485']"));
    }

    public WebElement warningWallMain() {
        return waitForElementPresent(By.xpath("(//div/div/div/div/div/div/div/h3[@id='C6__HEAD_977561E84369E78A216212'][contains(text(),'Warning - you will lose the materials you have chosen, do you want to continue?')])[1]"));
    }

    public WebElement warningWallNoButton() {
        return waitForElementPresent(By.xpath("(//div/div/div/button[@id='C6__BUT_977561E84369E78A216220'])[1]"));
    }

    public WebElement addRoofMainButton() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_487C210376DC00A33351759_R1']"));
    }

    public WebElement roofMaterialDropdown() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_867EFCFA124662CA686584']"));
    }

    public WebElement addRoofPopUp() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_FD68CC7E83AB4EB3414919']"));
    }

    public WebElement warningRoofMain() {
        return waitForElementPresent(By.xpath("(//div/div/div/div/div/div/div/h3[@id='C6__HEAD_E0EEAF9A4A59B12D293050'][contains(text(),'Warning - you will lose the materials you have chosen, do you want to continue?')])[1]"));
    }

    public WebElement warningRoofNoButton() {
        return waitForElementPresent(By.xpath("(//div/div/div/button[@id='C6__BUT_E0EEAF9A4A59B12D293058'])[1]"));
    }

    public WebElement heatMainNoButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__heatingList_R1']/label[2]/span"));
    }

    public WebElement addheatingButton() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_487C210376DC00A33351781_R1']"));
    }

    public WebElement heatingTypeDropdown() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_BB4C41678E291D4F282857']"));
    }

    public WebElement fuelTypeDropdown() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_BB4C41678E291D4F282860']"));
    }

    public WebElement addHeatPopUp() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_FD68CC7E83AB4EB3576765']"));
    }

    public WebElement heatYesButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__heatingList_R1']/label[1]/span"));
    }

    public WebElement warningHeatMain() {
        return waitForElementPresent(By.xpath("(//div/div/div/div/h3[@id='C6__HEAD_E0EEAF9A4A59B12D293069'][contains(text(),'Warning - you will lose the heating and fuel types you have chosen, do you want to continue?')])[1]"));
    }

    public WebElement warningHeatNoButton() {
        return waitForElementPresent(By.xpath("(//div/div/button[@id='C6__BUT_E0EEAF9A4A59B12D293077'])[1]"));
    }

    public WebElement addWallOutButton() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_487C210376DC00A33351853_R1']"));
    }

    public WebElement wallMaterialOutDropdown() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_B16092F17278F551924955']"));
    }

    public WebElement addWallOutPopUp() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_3B0A30BCE66AE2CE514601']"));
    }

    public WebElement warningWallOut() {
        return waitForElementPresent(By.xpath("(//div/div/div/div/div/h3[@id='C6__HEAD_F0FAC779A7A126421932819'][contains(text(),'Warning - you will lose the materials you have chosen, do you want to continue?')])[1]"));
    }

    public WebElement warningWallOutNoButton() {
        return waitForElementPresent(By.xpath("(//div/div/button[@id='C6__BUT_F0FAC779A7A126421993175'])[1]"));
    }

    public WebElement addRoofOutButton() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_487C210376DC00A33351869_R1']"));
    }

    public WebElement roofOutDropdown() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_B16092F17278F551924976']"));
    }

    public WebElement addRoofOutPopUp() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_3B0A30BCE66AE2CE514624']"));
    }

    public WebElement warningRoofOut() {
        return waitForElementPresent(By.xpath("(//div/div/div/div/div/h3[@id='C6__HEAD_F0FAC779A7A126422008194'][contains(text(),'Warning - you will lose the materials you have chosen, do you want to continue?')])[1]"));
    }

    public WebElement warningRoofOutNoButton() {
        return waitForElementPresent(By.xpath("(//div/div/button[@id='C6__BUT_F0FAC779A7A126422008285'])[1]"));
    }

    public WebElement heatOutNoButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__heatingListOB1_R1']/label[2]/span"));
    }

    public WebElement addheatingOutButton() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_487C210376DC00A33351887_R1']"));
    }

    public WebElement heatingTypeOutDropdown() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_B16092F17278F551924998']"));
    }

    public WebElement fuelTypeOutDropdown() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_B16092F17278F551925005']"));
    }

    public WebElement addHeatOutPopUp() {
        return waitForElementPresent(By.xpath("//*[@id='C6__BUT_3B0A30BCE66AE2CE514647']"));
    }

    public WebElement heatOutYesButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__heatingListOB1_R1']/label[1]/span"));
    }

    public WebElement warningHeatOut() {
        return waitForElementPresent(By.xpath("(//div/div/div/div/div/h3[@id='C6__HEAD_F0FAC779A7A126422015863'][contains(text(),'Warning - you will lose the heating and fuel types you have chosen, do you want to continue?')])[1]"));
    }

    public WebElement warningHeatOutNoButton() {
        return waitForElementPresent(By.xpath("(//div/div/button[@id='C6__BUT_F0FAC779A7A126422015958'])[1]"));
    }

    public WebElement sumInsuredGreaterText() {
        return waitForElementPresent(By.xpath("//*[@id='p4_QUE_F1AFB36AC27BEA642943621_R1']/div"));
    }

    public WebElement namedItemWorthText() {
        return waitForElementPresent(By.xpath("//*[@id='C6__namedItem_ERRORMESSAGE_R1']"));
    }

    public WebElement premisesItemKeptMainbuilding() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_FC0945D6732BAE231299027']/label[1]/span"));
    }

    public WebElement rqdMsgItem() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_880160F8F183EC16674655_ERRORMESSAGE']"));
    }

    public WebElement rqdMsgValue() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_880160F8F183EC16674665_ERRORMESSAGE']"));
    }

    public WebElement rqdMsgDesc() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_880160F8F183EC16674670_ERRORMESSAGE']"));
    }

    public WebElement outRoofNoButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__roofMaterialOB_R1']/label[2]/span"));
    }

    public WebElement outRoofYesButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__roofMaterialOB_R1']/label[1]/span"));
    }

    public WebElement subsidenceNoButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__QUE_487C210376DC00A33351804_R1']/label[2]/span"));
    }

    public WebElement outWallNoButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__wallMaterialTimberOB_R1']/label[2]/span"));
    }

    public WebElement outWallYesButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C6__wallMaterialTimberOB_R1']/label[1]/span"));
    }
    public WebElement commonAccordion(String accordionName){
        return waitForElementPresent(By.xpath("//div[contains(text(),'"+accordionName+"')]"));
    }
    public List<WebElement> plAccordion(){
        return findElements(By.xpath("//span[contains(text(),'Your liability cover')]"));
    }
    public WebElement premisesAccorion(String name){
        return waitForElementPresent(By.xpath("//span[contains(text(),'"+name+"')]"));
    }
    public List<WebElement> commonAccordionNotPresent(){
        return findElements(By.xpath("//div[contains(text(),'Business Premises')]"));
    }

    public WebElement excludingElectricItemsRemoveCoverButton(int i) {
        return waitForElementPresent(By.id("C6__BUT_130910B8F1739FAC1055243_R"+i));
    }

    public WebElement excludingElectricItemsAddCoverButton(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351584_R"+i));
    }

    public WebElement stocksAddCoverButton(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351604_R"+i));
    }
    public WebElement excludingElectricItemsTextBox(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351576_R"+i+"']"));
    }

    public WebElement electricItemsRemoveCoverButton(int i) {
        return waitForElementPresent(By.id("C6__BUT_130910B8F1739FAC1055243_R"+i));
    }

    public WebElement electricItemsAddCoverButton(int i) {
        return waitForElementPresent(By.id("C6__BUT_130910B8F1739FAC1055250_R"+i));
    }

    public WebElement stocksRemoveCoverButton(int i) {
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351600_R"+i));
    }

    public WebElement stocksTextBox(int i) {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_487C210376DC00A33351596_R"+i+"']"));
    }

    public WebElement premisesClick(String premises) {
        return waitForElementPresent(By.xpath("//p/a[contains(text(),'"+premises+"')]"));
    }
    public WebElement homeCctvOptionOut(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_01CCC26BF28AA7161411763_R" + i + "']/label[1]/p/span"));
    }
    public WebElement homeBurglarOptionOut(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_01CCC26BF28AA7161411763_R" + i + "']/label[2]/p/span"));
    }
    public WebElement homeNoneOptionOut(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_01CCC26BF28AA7161411763_R" + i + "']/label[3]/p/span"));
    }
    public WebElement saloncctvOptionOut(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351890_R" + i + "']/label[4]/p/span"));
    }
    public WebElement salonBurglarOptionOut(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351890_R" + i + "']/label[5]/p/span"));
    }
    public WebElement salonNoneOptionOut(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351890_R" + i + "']/label[8]/p/span"));
    }
    public WebElement salonBarsOut(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351890_R" + i + "']/label[1]/p/span"));
    }
    public WebElement salonSteelOut(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351890_R" + i + "']/label[2]/p/span"));
    }
    public WebElement salonMetalOut(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351890_R" + i + "']/label[3]/p/span"));
    }
    public WebElement salonShoppingOut(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351890_R" + i + "']/label[6]/p/span"));
    }
    public WebElement salonFamilyOut(int i) {
        return waitForElementPresent(By.xpath("//*[@id='checkbox_C6__QUE_487C210376DC00A33351890_R" + i + "']/label[7]/p/span"));
    }
    public WebElement mainbuildingBuildingCoverRemoveButton(int i){
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351446_R"+i));
    }
    public WebElement outbuildingBuildingCoverRemoveButton(int i){
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351510_R"+i));
    }
    public WebElement mainbuildingFittingsRemoveButton(int i){
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351486_R"+i));
    }
    public WebElement mainbuildingGlassRemoveButton(int i){
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351466_R"+i));
    }
    public WebElement mainBuildingBusinessContentRemoveButton(int i){
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351580_R"+i));
    }
    public WebElement outbuildingGlassRemoveButton(int i){
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351530_R"+i));
    }
    public WebElement outbuildingFittingsRemoveButton(int i){
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351550_R"+i));
    }
    public WebElement outBuildingBusinessContentRemoveButton(int i){
        return waitForElementPresent(By.id("C6__BUT_487C210376DC00A33351644_R"+i));
    }

    public WebElement accordionPA(){
        return waitForElementVisible(By.xpath("//*[@id='propertyAwayMoreLi']/span[1]"));
    }
    public List<WebElement> totAccordian(){
        return findElements(By.xpath("//span[contains(text(),'Theft of takings')]"));
    }
    public WebElement subsidenceCoverHistory(String YorN, int i) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].SUBSIDENCE[1].SIGNSOFDAMAGE'][value=" + value + "]";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }

    public WebElement subsidenceCoverProximity(String YorN, int i) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Y")) {
            value = "Y";
        }
        String cssSelector = "input[name='C6__DIRECTLINE[1].YOURBUSINESS[1].PF[1].PREMISES[" + i + "].SUBSIDENCE[1].RAILWAYCUTTING'][value=" + value + "]";
        return waitForElementPresent(org.openqa.selenium.By.cssSelector(cssSelector));
    }
    public WebElement accomodationHT() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_ADFA26B138E8374B565428_R1']/div/div[1]"));
    }
    public WebElement bedroomHT() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_986DDA71FAE05BED355864_R1']/div/div[1]"));
    }
    public WebElement businessContentStockHT() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_BD3550F8E469E3F81315171_R1']/div/div"));
    }
    public WebElement winesandSpiritHT() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_130910B8F1739FAC997984_R1']/div/div"));
    }
    public WebElement selfCaterHT() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_F5A203272682B5E7508551_R1']/div/div[1]"));
    }
    public WebElement insureBuildingHT() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_487C210376DC00A33351423_R1']/div/div[1]"));
    }
    public WebElement buildingUsedHT() {
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_1AD6973D247511431021240_R1']/div/div[1]"));
    }
    public WebElement homeAssumpContent(int i)
    {
        return waitForElementPresent(org.openqa.selenium.By.xpath("//*[@id='C6__FMT_081B7A67BC5B17F91516207_R" + i + "']"));
    }
    public WebElement commAssumpContent(int i)
    {
        return waitForElementPresent(org.openqa.selenium.By.xpath("//*[@id='C6__FMT_081B7A67BC5B17F91516207_R" + i + "']"));
    }
    public WebElement assumpAgree(int i)
    {
        return waitForElementPresent(org.openqa.selenium.By.xpath("//*[@id='C6__p4_QUE_081B7A67BC5B17F91541469_R" + i + "']/div/div/label[1]/span"));
    }
     public WebElement assumpAgreeComm(int i)
    {
        return waitForElementPresent(org.openqa.selenium.By.xpath("//*[@id='radio_C6__QUE_081B7A67BC5B17F91541469_R" + i + "']/label[1]/span"));

    }
    public WebElement assumpDisagree(int i)
    {
        return waitForElementPresent(org.openqa.selenium.By.xpath("//*[@id='C6__p4_QUE_081B7A67BC5B17F91541469_R" + i + "']/div/div/label[2]/span"));
    }
    public WebElement assumpDisagreeComm(int i)
    {
        return waitForElementPresent(org.openqa.selenium.By.xpath("//*[@id='radio_C6__QUE_081B7A67BC5B17F91541469_R" + i + "']/label[2]/span"));
    }

    public List<WebElement> assumptions() {
        return findElements(By.xpath(""));
    }
    public WebElement typeOfBuildingDDL(int i){
        return waitForElementPresent(By.id("C6__QUE_A65ABE33E35BB605239181_R"+i));
    }
    public List<WebElement> typeOfBuildingQuestion(int i){
        return findElements(By.xpath("//*[@id='C6__p1_QUE_A65ABE33E35BB605239181_R" + i + "']/div/label"));
    }
    public WebElement typeOfBuildingHelpText(int i){
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_A65ABE33E35BB605239181_R" + i + "']/div/div[1]/div"));
    }

    public List<WebElement> typeOfBuildingHT(int i){
        return findElements(By.xpath("//*[@id='C6__p4_QUE_A65ABE33E35BB605239181_R" + i + "']/div/div[1]/div"));
    }
    public WebElement typeOfBuildingOutDDL(int i){
        return waitForElementPresent(By.id("C6__QUE_A65ABE33E35BB605239127_R"+i));
    }
    public List<WebElement> typeOfBuildingOutQuestion(int i){
        return findElements(By.xpath("//*[@id='C6__p1_QUE_A65ABE33E35BB605239127_R" + i + "']/div/label"));
    }
    public WebElement typeOfBuildingOutHelpText(int i){
        return waitForElementPresent(By.xpath("//*[@id='C6__p4_QUE_A65ABE33E35BB605239127_R" + i +"']/div/div[1]/div"));
    }

    public List<WebElement> typeOfBuildingOutHT(int i){
        return findElements(By.xpath("//*[@id='C6__p4_QUE_A65ABE33E35BB605239127_R" + i +"']/div/div[1]/div"));
    }

    public WebElement typeOfBuildingReqMsg(int i){
        return waitForElementPresent(By.id("C6__QUE_A65ABE33E35BB605239181_ERRORMESSAGE_R"+i));
    }


    public WebElement typeOfBuildingOutReqMsg(int i){
        return waitForElementPresent(By.id("C6__QUE_A65ABE33E35BB605239127_ERRORMESSAGE_R"+i));
    }

    public List<WebElement> premisesTypeQues(int i){
        return findElements(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351376_R"+i+"']/div/label"));
    }
    public List<WebElement> buildingTypeQues(int i){
        return findElements(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351721_R"+i+"']/div/label"));
    }
    public List<WebElement> premisesOccupiedQues(int i){
        return findElements(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351404_R"+i+"']/div/label"));
    }
    public List<WebElement> buildingOccupiedQues(int i){
        return findElements(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351407_R"+i+"']/div/label"));
    }
    public List<WebElement> tradeSelectionQues(int i){
        return findElements(By.xpath("//*[@id='C6__p1_QUE_1236C719475D23F8462721_R"+i+"']/div/label"));
    }
    public List<WebElement> otherPortionQues(int i){
        return findElements(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351412_R"+i+"']/div/label"));
    }
    public List<WebElement> soleAccessControlQues(int i){
        return findElements(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351415_R"+i+"']/div/label"));
    }
    public List<WebElement> applyBusinessQues(int i){
        return findElements(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351418_R"+i+"']/div/label"));
    }
    public List<WebElement> propertyBuiltQues(int i){
        return findElements(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351723_R"+i+"']/div/label"));
    }
    public List<WebElement> buildings1Heading(int i){
        return findElements(By.xpath("//*[@id='C6__p1_HEAD_D1B862FA824993411790194_R"+i+"']/div"));
    }
    public List<WebElement> buildings1Heading1(int i){
        return findElements(By.xpath("//*[@id='C6__p1_HEAD_D1B862FA824993411810970_R"+i+"']/div"));
    }
    public List<WebElement> buildings2Heading(int i){
        return findElements(By.xpath("//*[@id='C6__p1_HEAD_15C5391E90AD948A1199699_R"+i+"']/div"));
    }
    public List<WebElement> buildings2Heading2(int i){
        return findElements(By.xpath("//*[@id='C6__p1_HEAD_D1B862FA824993411838517_R"+i+"']/div"));
    }
    public List<WebElement> alarmTypeQuestionMain(int i){
        return findElements(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351789_R"+i+"']/div/label"));
    }
    public List<WebElement> policeResponseQuestionMain(int i){
        return findElements(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351794_R"+i+"']/div/label"));
    }
    public List<WebElement> alarmMaintainQuestionMain(int i){
        return findElements(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351796_R"+i+"']/div/label"));
    }
    public List<WebElement> alarmUnderyourBusinessQuestionMain(int i){
        return findElements(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351791_R"+i+"']/div/label"));
    }
    public List<WebElement> buildingTypeQuestionMain(int i){
        return findElements(By.xpath("//*[@id='C6__p1_QUE_487C210376DC00A33351721_R"+i+"']/div/label"));
    }
    public List<WebElement> homeTypeRequired(int i){
        return findElements(By.id("C6__QUE_487C210376DC00A33351721_ERRORMESSAGE_R"+i));
    }
}
