package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class Obj_Coverwizard extends AbstractPage {

    public WebElement securityTextbox() {
        return waitForUnstableElement(By.id("QUE_046FC879087B6FA0110419"));
    }

    public WebElement proceedButton() {
        return waitForUnstableElement(By.xpath("//*[@id='BUT_046FC879087B6FA0110427']"));
    }

    public WebElement tradeNameTextbox() {
        return waitAndFindElement(By.xpath("//*[@id='what']"));
    }
    public WebElement tradeNameSelect() {
        return waitForUnstableElement(By.xpath("//*[@id='profession2']/ul"));
    }

    public WebElement businessFromCheckbox(String businessFrom) {
        String xpath = "//span[contains(.,'" + businessFrom + "')]";
        return waitForUnstableElement(By.xpath(xpath));
    }

    public WebElement workFromHomeCheckbox() {
        return waitForElementToBeClickableAndReturnElement(By.xpath("//*[@id='business']/div[1]/div/div[2]/div[2]/div[2]/label/span"));
    }

    public WebElement ownSalonCheckbox() {
        return waitForElementToBeClickableAndReturnElement(By.xpath("//*[@id='business']/div[1]/div/div[2]/div[1]/div[1]/label/span"));
    }

    public WebElement rentChairCheckbox() {
        return waitForElementToBeClickableAndReturnElement(By.xpath("//*[@id='business']/div[1]/div/div[2]/div[1]/div[2]/label/span"));
    }

    public WebElement mobileCheckbox() {
        return waitForElementToBeClickableAndReturnElement(By.xpath("//*[@id='business']/div[1]/div/div[2]/div[2]/div[1]/label/span"));
    }

    public WebElement businessNextButton() {
        return waitForElementToBeClickableAndReturnElement(By.xpath("//*[@id='products' or @id='business']/div[5]/button[not(@disabled='disabled')]"));
    }

    public WebElement employersLiabilityCoverRadiobutton(String YorN) {
        String id = "elcover_" + YorN.toLowerCase();
        return waitForUnstableElement(By.id(id));
    }

    public WebElement employersLiabilityCoverNoRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='elcover']/div[1]/div/div[2]/div/div[1]/label/span"));
    }

    public WebElement employersLiabilityCoverYesRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='elcover']/div[1]/div/div[2]/div/div[2]/label/span"));
    }

    public WebElement noEmployeesRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='employee']/div[1]/div/div[2]/div[1]/div[1]/label/span"));
    }

    public WebElement haveEmployeesButton(String haveEmployees) {
        String cssSelector = "input[ng-model^='questions[section.id]'][Value='" + haveEmployees + "']";
        return waitForUnstableElement(By.cssSelector(cssSelector));
    }

    public WebElement permanentEmployeesRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='employee']/div[1]/div/div[2]/div[2]/div[1]/label/span"));
    }

    public WebElement temporaryEmployeesRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='employee']/div[1]/div/div[2]/div[1]/div[2]/label/span"));
    }

    public WebElement permanentTemporaryEmployeesRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='employee']/div[1]/div/div[2]/div[2]/div[2]/label/span"));
    }

    public WebElement hairAndBeautyCheckbox() {
        return waitForUnstableElement(By.cssSelector("input[ng-model^='questions[section.id]'][value='trt']"));
    }

    public WebElement businessStockCheckbox() {
        return waitForUnstableElement(By.cssSelector("input[ng-model^='questions[section.id]'][value='stock']"));
    }

    public WebElement theftOfTakingsCheckbox() {
        return waitForUnstableElement(By.cssSelector("input[ng-model^='questions[section.id]'][value='tot']"));
    }

    public WebElement businessToolsCheckbox() {
        return waitForUnstableElement(By.cssSelector("input[ng-model^='questions[section.id]'][value='business_tools_equ']"));
    }

    public WebElement businessInterruptionCheckbox() {
        return waitForUnstableElement(By.cssSelector("input[ng-model^='questions[section.id]'][value='bi']"));
    }

    public WebElement noneCheckbox() {
        return waitForUnstableElement(By.cssSelector("input[ng-model^='questions[section.id]'][value='none']"));
    }

    public WebElement livePremisesNoRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='business']/div[1]/div/div[2]/div/div[1]/label/span"));
    }

    public WebElement livePremisesYesRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='business']/div[1]/div/div[2]/div/div[2]/label/span"));
    }

    public WebElement bbLivepremisesNextbutton() {
        return waitForElementToBeClickableAndReturnElement(By.xpath("//*[@id='business']/div[5]/button"));
    }

    public WebElement retailLivepremisesNextbutton() {
        return waitForElementToBeClickableAndReturnElement(By.xpath("//*[@id='products' or @id='business']/div[4]/button[not(@disabled='disabled')]"));
    }

    public WebElement bbHaveEmpNoRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='employee']/div[1]/div/div[2]/div/div[1]/label/span"));
    }

    public WebElement bbHaveEmpYesRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='employee']/div[1]/div/div[2]/div/div[2]/label/span"));
    }

    public WebElement bbEmployersLiabilityCoverNoRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='elcover']/div[1]/div/div[2]/div/div[1]/label/span"));
    }

    public WebElement bbEmployersLiabilityCoverYesRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='elcover']/div[1]/div/div[2]/div/div[2]/label/span"));
    }

    public WebElement oprEmployersLiabilityCoverNoRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='employee']/div[1]/div/div[2]/div/div[1]/label/span"));
    }

    public WebElement oprEmployersLiabilityCoverYesRadiobutton() {
        return waitForUnstableElement(By.xpath("//*[@id='employee']/div[1]/div/div[2]/div/div[2]/label/span"));
    }

    public WebElement bbCoverBusinessContentsCheckbox() {
        return waitForUnstableElement(By.cssSelector("input[ng-model^='questions[section.id]'][value='business_cont']"));
    }

    public WebElement bbCoverYourHomeCheckbox() {
        return waitForUnstableElement(By.cssSelector("input[ng-model^='questions[section.id]'][value='homebuilding']"));
    }

    public WebElement bbCoverYourPremisesCheckbox() {
        return waitForUnstableElement(By.xpath("//*[@id='covers']/div[1]/div/div[2]/div[1]/div[1]/label/span"));
    }

    public WebElement bbCoverYourhouseholdCheckbox() {
        return waitForUnstableElement(By.cssSelector("input[ng-model^='questions[section.id]'][value='household']"));
    }

    public WebElement bbCoverBusinessInterruptionCheckbox() {
        return waitForUnstableElement(By.cssSelector("input[ng-model^='questions[section.id]'][value='bi']"));
    }

    public WebElement bbCoverHomeEmergencyCheckbox() {
        return waitForUnstableElement(By.xpath("//*[@id='bb-four']/div/div[2]/div/label[6]/span"));
    }

    public WebElement bbCoverCyberRisksCheckbox() {
        return waitForUnstableElement(By.xpath("//*[@id='bb-four']/div/div[2]/div/label[7]/span"));
    }

    public WebElement bbCoverTheftoftakeCheckbox() {
        return waitForUnstableElement(By.cssSelector("input[ng-model^='questions[section.id]'][value='tot']"));
    }

    public WebElement bbCoverLegalExpCheckbox() {
        return waitForUnstableElement(By.cssSelector("input[ng-model^='questions[section.id]'][value='legal_exp']"));
    }

    public WebElement bbCoverTheftbyempCheckbox() {
        return waitForUnstableElement(By.xpath("//*[@id='bb-four']/div/div[2]/div/label[10]/span"));
    }

    public WebElement bbCoverNoneCheckbox() {
        return waitForUnstableElement(By.cssSelector("input[ng-model^='questions[section.id]'][value='none']"));
    }

    public WebElement bbCoverBICheckbox() {
        return waitForUnstableElement(By.xpath("//*[@id=\"covers\"]/div[1]/div/div[2]/div[2]/div[1]/label/span"));
    }

    public WebElement coversContinueButton() {
        return waitForUnstableElement(By.xpath("//*[@id='wizardTemplate']/div[1]/div/div/div[3]/button"));
    }

    public WebElement businessContentCheckbox() {
        return waitForUnstableElement(By.cssSelector("input[ng-model^='questions[section.id]'][value='business_cont']"));
    }

    public WebElement coversCheckbox(String text) {
        String xpath = "(//label/span[contains(text(),'" + text + "')])[1]";
        return waitForElementPresent(By.xpath(xpath));
    }

    public WebElement coversCheckboxHB(String text) {
        String cssSelector = "(//label/span[contains(text(),'" + text + "')])[1]";
        return waitForElementPresent(By.xpath(cssSelector));
    }

    public List<WebElement> coversNames(String text) {
        return findElements(By.xpath("(//label/span[contains(text(),'" + text + "')])[1]"));
    }

    public WebElement TradeList() {
        return waitForElementPresent(By.xpath("//*[@id='profession2']/ul"));
    }
    public List<WebElement> tradeList() {
        return findElements(By.xpath("/html/body/div[5]"));
    }

    public WebElement wizardTradeList() {
        return waitForElementPresent(By.xpath("//*[@id='profession2']/ul/li[1]"));
    }
    public WebElement wizardTradeListAcct() {
        return waitForElementPresent(By.xpath("//*[@id='profession2']/ul/li[1]"));
    }
    public WebElement wizardTradeListFurniture() {
        return waitForElementPresent(By.xpath("//*[@id='profession2']/ul/li[2]"));
    }

    public List<WebElement> CoverList() {
        return findElements(By.xpath("//*[@id='FMT_93FDCE37EC9029A85040']"));
    }

    public List<WebElement> SelectedCoverList() {
        return findElements(By.xpath("//*[@id='FMT_A903798532EBC2D01791']"));

    }

    public WebElement ClkemployersLiabilityCoverRadiobutton(String YorN) {
        String xpath = "//*[@id='elcover']/div[1]/div/div[2]/div/div/label/span[contains(text(),'" + YorN + "')]";
        return waitForUnstableElement(By.xpath(xpath));
    }

    public WebElement searchbusinessTextbox() {
        return waitForUnstableElement(By.id("C2__QUE_3EEBD499DACB35483315854"));
    }

    public WebElement ManagequoteButton() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__C6__TXT_C1866409B7CE50882281927']/div/div/ul/li[3]/a"));
    }

    public WebElement editButton() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__C6__TXT_C1866409B7CE50882281927']/div/div/ul/li[3]/ul/li/a"));
    }

    public WebElement buyButton() {
        return waitForUnstableElement(By.xpath("//*[@id='BuyQuoteEnable']"));
    }

    public WebElement coverBasket() {
        return waitForElementPresent(By.xpath("//*[@id='FMT_A903798532EBC2D01791']"));
    }

    public WebElement coverBasketPL() {
        return waitForElementPresent(By.xpath("//*[@id='TXT_5BCEE98A41C855D51223']/div/span"));
    }

    public WebElement coverBasketGE() {
        return waitForElementPresent(By.xpath("//*[@id='guest-effect']"));
    }

    public WebElement coverBasketEL() {
        return waitForElementPresent(By.xpath("//*[@id='example-2']"));
    }

    public WebElement SelectedListForCover(String value) {
        return waitForElementPresent(By.xpath("//ul[@id='FMT_5BCEE98A41C855D51203']//span[contains(text()," + value + ")]"));
    }

    public WebElement coverBasketTradeBox(String text) {
        if (text.equalsIgnoreCase("Business Interruption")) {
            text = "Business interruption";
        } else if (text.equalsIgnoreCase("Your premises (the building)")) {
            text = "Your salon (the building)";
        } else if (text.equalsIgnoreCase("Business Contents and stock")) {
            text = "Business contents";
        }
        return waitForElementPresent(By.xpath("//*[@id='FMT_A903798532EBC2D01791']//span[contains(text(),'" + text + "')]"));
    }

    public WebElement coverBasketRedBox() {
        return waitForElementPresent(By.xpath("//*[@id='TXT_C0F2294D3D598AD34869']/div"));
    }

    //   ----------------------------Wizard Objects----------------------------------------------------
    public WebElement wizardCoverBasketEmpty() {
        return waitForElementPresent(By.xpath("//*[@id='wizardTemplate']/div[1]/div/div/div[2]"));
    }

    public WebElement wizardTradeNameTextBox() {
        return waitForElementPresent(By.xpath("//*[@id='what']"));
    }

    public WebElement wizardCoverBasketRedBox() {
        return waitForElementPresent(By.xpath("//*[@id='wizardTemplate']/div[1]/div/div/div[2]/div[1]/div[2]"));
    }

    public WebElement wizardCoverBasketPL() {
        return waitForElementPresent(By.xpath("//*[@id='public_liability_cover_basket']/span"));
    }

    public WebElement wizardCoverBasketGE() {
        return waitForElementPresent(By.xpath("//*[@id='guest_effect_basket']"));
    }

    public WebElement wizardBusinessFromCheckbox(String text) {
        return waitForElementPresent(By.xpath("//span[contains(.,'" + text + "')]"));
    }

    public WebElement wizardHaveEmployeesButton(String text) {
        return waitForElementPresent(By.cssSelector("input[ng-model^='questions[section.id]'][Value='" + text + "']"));
    }

    public WebElement wizardEmployersLiabilityCoverYesRadiobutton() {
        return waitForElementPresent(By.xpath("//*[@id='elcover']/div[1]/div/div[2]/div/div[2]/label/span"));
    }

    public WebElement wizardEmployersLiabilityCoverNoRadiobutton() {
        return waitForElementPresent(By.xpath("//*[@id='elcover']/div[1]/div/div[2]/div/div[1]/label/span"));
    }

    public WebElement wizardCoverBasketEL() {
        return waitForElementPresent(By.xpath("//*[@id='el_basket']"));
    }

    public WebElement wizardIsThisAlsoYourHomeYesRadioButton() {
        return waitForElementPresent(By.xpath("//*[@id='business']/div[1]/div/div[2]/div/div[2]/label/span"));
    }

    public WebElement wizardIsThisAlsoYourHomeNoRadioButton() {
        return waitForElementPresent(By.xpath("//*[@id='business']/div[1]/div/div[2]/div/div[1]/label/span"));
    }

    public WebElement wizardBBHaveEmpYesRadioButton() {
        return waitForElementPresent(By.xpath("//*[@id='employee']/div[1]/div/div[2]/div/div[2]/label/span"));
    }

    public WebElement wizardBBHaveEmpNoRadioButton() {
        return waitForElementPresent(By.xpath("//*[@id='employee']/div[1]/div/div[2]/div/div[1]/label/span"));
    }

    public WebElement wizardCovers(String text) {
        return waitForElementPresent(By.cssSelector("input[ng-model^='questions[section.id]'][value='" + text + "']"));
    }

    public WebElement wizardCoverBasketCovers(String text) {
        return waitForElementPresent(By.xpath("//*[@id='" + text + "']"));
    }

    public WebElement wizardContinueButton() {
        return waitForElementPresent(By.xpath("//*[@id='wizardTemplate']/div[1]/div/div/div[3]/button"));
    }

    public WebElement wizardSellYourProductsCheckBox(String text) {
        return waitForElementPresent(By.cssSelector("input[ng-model^='questions[section.id]'][value='" + text + "']"));
    }

    public WebElement WizardSellYourProductsNext() {
        return waitForElementPresent(By.xpath("//*[@id='products']/div[4]/button"));
    }

    public WebElement wizardRunYourProductFromCheckBox(String text) {
        return waitForElementPresent(By.cssSelector("input[ng-model^='questions[section.id]'][value='" + text + "']"));
    }

    public WebElement wizardRunYourProductFromNext() {
        return waitForElementPresent(By.xpath("//*[@id='business']/div[5]/button"));//same for RunBusinessFrom/IsThisAlsoYourHome Next
    }

    public WebElement wizardCoverBasketYourHomeHelpTextQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='homebuilding_basket']/div"));
    }

    public WebElement wizardCoverBasketYourHomeHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='homebuilding_basket']/div/div"));
    }

    public WebElement wizardCoverBasketHouseHoldHelpTextQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='household_basket']/div"));
    }

    public WebElement wizardCoverBasketHouseHoldHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='household_basket']/div/div"));
    }

    public WebElement wizardCoverBasketBIHelpTextQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='bi_basket']/div"));
    }

    public WebElement wizardCoverBasketBIHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='bi_basket']/div/div"));
    }

    public WebElement wizardCoverBasketTOTHelpTextQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='tot_basket']/div"));
    }

    public WebElement wizardCoverBasketTOTHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='tot_basket']/div/div"));
    }

    public WebElement wizardCoverBasketLegExpHelpTextQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='legal_exp_basket']/div"));
    }

    public WebElement wizardCoverBasketLegExpHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='legal_exp_basket']/div/div"));
    }

    public WebElement wizardCoverBasketSalonHelpTextQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='salonbuild_basket']/div"));
    }

    public WebElement wizardCoverBasketSalonHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='salonbuild_basket']/div/div"));
    }

    public WebElement wizardCoverBasketHairBeautyHelpTextQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='trt_basket']/div"));
    }

    public WebElement wizardCoverBasketHairBeautyHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='trt_basket']/div/div"));
    }

    public WebElement wizardCoverBasketStockHelpTextQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='stock_basket']/div"));
    }

    public WebElement wizardCoverBasketStockHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='stock_basket']/div/div"));
    }

    public WebElement wizardCoverBasketBusinessContentHelpTextQuestion() {
        return waitForElementPresent(By.xpath("//*[@id='business_cont_basket']/div"));
    }

    public WebElement wizardCoverBasketBusinessContentHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='business_cont_basket']/div/div"));
    }

    public WebElement sellProductRunBusinessCoversCommonOPR(String details) {
        return waitForElementPresent(By.xpath("//div/div/label/span[contains(text(),'" + details + "')]"));
    }

    public WebElement sellProductNextButton() {
        return waitForElementPresent(By.xpath("//*[@id='products']/div[4]/button"));
    }

    public WebElement offoiceConsultantLink() {
        return waitForElementPresent(By.xpath("//a[contains(text(),'Offices & Consultants')]"));
    }

    public WebElement getQuoteOnlineLink() {
        return waitForElementPresent(By.xpath("//a[contains(text(),'Get a quote online')]"));
    }

    public WebElement hbLink() {
        return waitForElementPresent(By.xpath("//a[contains(text(),'Hair & Beauty')]"));
    }

    public WebElement bbLink() {
        return waitForElementPresent(By.xpath("//a[contains(text(),'Bed & Breakfast')]"));
    }

    public WebElement retailLink() {
        return waitForElementPresent(By.xpath("//a[text()='Retail']"));
    }

    public WebElement foodRetailLink() {
        return waitForElementPresent(By.xpath("//a[text()='Food Retail']"));
    }

    public void switchWindow() {
        for (String winHandle : getDriver.getWindowHandles()) {
            getDriver.switchTo().window(winHandle);
        }

    }

    public WebElement GIQuestionCheck(String text){
        return waitForElementPresent(By.xpath("//label[contains(text(),'"+text+"')]"));
    }

    public WebElement sellProductDecline() {
        return waitForElementPresent(By.xpath("//*[@id='wizardTemplate']/div[2]/div[1]/div[2]"));
    }
    public List<WebElement> basketStatus(){
        return findElements(By.xpath("//div/p/strong[contains(text(),'You have no items in your basket')]"));
    }
    public List<WebElement> plcoverText(){
        return findElements(By.xpath("//*[@id='covers']/div[2]/p"));
    }
    public WebElement businessContentAndStock() {
        return waitForElementPresent(By.xpath("//*[@id='bcs_cover_basket']/span"));
    }
    public List<WebElement> piDeclineContent()
    {
        return findElements(By.xpath("//*[@id='covers']/div[2]/p"));
    }
    public List<WebElement> coverHelpText()
    {
        return waitForElementsPresent(By.xpath("//span[contains(text(),'"+"')]/../../div/div"));
    }
}