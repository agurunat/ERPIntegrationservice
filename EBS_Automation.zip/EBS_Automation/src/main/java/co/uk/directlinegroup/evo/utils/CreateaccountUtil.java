package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_Createaccount;
import com.usmanhussain.habanero.framework.AbstractPage;

import java.util.List;
import java.util.Random;


public class CreateaccountUtil extends AbstractPage {
    private CommonUtil commonutil = new CommonUtil();
    private Obj_Createaccount createaccount = new Obj_Createaccount();

    public void selectOption(List<List<String>> data, String fieldName) throws Throwable {

        String StrVal = commonutil.datapicker(data, fieldName);
        waitForPageLoad();

        String[] sele = StrVal.split(";");
        for (int i = 0; i < sele.length; i++) {

            if (sele[i].equalsIgnoreCase("Email")) {
                commonutil.clickbyJS(createaccount.emailRadiobutton());

            } else if (sele[i].equalsIgnoreCase("Text")) {
                commonutil.clickbyJS(createaccount.textRadiobutton());

            } else if (sele[i].equalsIgnoreCase("Telephone")) {
                commonutil.clickbyJS(createaccount.telephoneRadiobutton());

            }
        }
    }

    public String randomemail() {
        Random rand = new Random();
        String strcharacters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        int randomNum1 = rand.nextInt(25) + 0;
        String strcharacter1 = strcharacters.substring(randomNum1, randomNum1 + 1);
        int randomNum2 = rand.nextInt(25) + 0;
        String strcharacter2 = strcharacters.substring(randomNum2, randomNum2 + 1);
        int randomNum3 = rand.nextInt(25) + 0;
        String strcharacter3 = strcharacters.substring(randomNum3, randomNum3 + 1);
        int randomNum4 = rand.nextInt(25) + 0;
        String strcharacter4 = strcharacters.substring(randomNum4, randomNum4 + 1);
        int randomNum5 = rand.nextInt(25) + 0;
        String strcharacter5 = strcharacters.substring(randomNum5, randomNum5 + 1);
        int randomNum6 = rand.nextInt(25) + 0;
        String strcharacter6 = strcharacters.substring(randomNum6, randomNum6 + 1);
        int randomNum7 = rand.nextInt(25) + 0;
        String strcharacter7 = strcharacters.substring(randomNum7, randomNum7 + 1);
        int randomNum8 = rand.nextInt(25) + 0;
        String strcharacter8 = strcharacters.substring(randomNum8, randomNum8 + 1);
        //String FirstName = strcharacter1 + strcharacter2 + strcharacter3 + strcharacter4 + strcharacter5 + strcharacter6 + strcharacter7 + strcharacter8;
        int randomNum11 = rand.nextInt(25) + 0;
        String strcharacter11 = strcharacters.substring(randomNum11, randomNum11 + 1);
        int randomNum21 = rand.nextInt(25) + 0;
        String strcharacter21 = strcharacters.substring(randomNum21, randomNum21 + 1);
        int randomNum31 = rand.nextInt(25) + 0;
        String strcharacter31 = strcharacters.substring(randomNum31, randomNum31 + 1);
        int randomNum41 = rand.nextInt(25) + 0;
        String strcharacter41 = strcharacters.substring(randomNum41, randomNum41 + 1);
        int randomNum51 = rand.nextInt(25) + 0;
        String strcharacter51 = strcharacters.substring(randomNum51, randomNum51 + 1);
        int randomNum61 = rand.nextInt(25) + 0;
        String strcharacter61 = strcharacters.substring(randomNum61, randomNum61 + 1);
        int randomNum71 = rand.nextInt(25) + 0;
        String strcharacter71 = strcharacters.substring(randomNum71, randomNum71 + 1);
        int randomNum81 = rand.nextInt(25) + 0;
        String strcharacter81 = strcharacters.substring(randomNum81, randomNum81 + 1);
        //String LastName = strcharacter11 + strcharacter21 + strcharacter31 + strcharacter41 + strcharacter51 + strcharacter61 + strcharacter71 + strcharacter81;
        int randomNum111 = rand.nextInt(25) + 0;
        String strcharacter111 = strcharacters.substring(randomNum111, randomNum111 + 1);
        int randomNum211 = rand.nextInt(25) + 0;
        String strcharacter211 = strcharacters.substring(randomNum211, randomNum211 + 1);
        int randomNum311 = rand.nextInt(25) + 0;
        String strcharacter311 = strcharacters.substring(randomNum311, randomNum311 + 1);
        int randomNum411 = rand.nextInt(25) + 0;
        String strcharacter411 = strcharacters.substring(randomNum411, randomNum411 + 1);
        int randomNum511 = rand.nextInt(25) + 0;
        String strcharacter511 = strcharacters.substring(randomNum511, randomNum511 + 1);
        int randomNum611 = rand.nextInt(25) + 0;
        String strcharacter611 = strcharacters.substring(randomNum611, randomNum611 + 1);
        int randomNum711 = rand.nextInt(25) + 0;
        String strcharacter711 = strcharacters.substring(randomNum711, randomNum711 + 1);
        int randomNum811 = rand.nextInt(25) + 0;
        int randomNum8111 = rand.nextInt(100) + 0;
        String strcharacter811 = strcharacters.substring(randomNum811, randomNum811 + 1);
        String Email = strcharacter111 + strcharacter211 + strcharacter311 + strcharacter411 + strcharacter511 + strcharacter611 + strcharacter711 + strcharacter811 + randomNum8111 + "@HIP.com";
        //String NewEmail = strcharacter111+ strcharacter211+ strcharacter311+ strcharacter411+ strcharacter511+ strcharacter611+ strcharacter711+ strcharacter811+ randomNum8111+ "_Newmail@HIP.com";

        return Email;
    }


}
