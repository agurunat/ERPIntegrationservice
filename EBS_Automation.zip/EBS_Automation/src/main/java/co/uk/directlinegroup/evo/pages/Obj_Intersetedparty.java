package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Obj_Intersetedparty extends AbstractPage {

    public WebElement addPartyYesRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C1__QUE_48BDF1EEA3569326406504']/label[1]/span"));
    }

    public WebElement addPartyNoRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C1__QUE_48BDF1EEA3569326406504']/label[2]/span"));
    }

    public WebElement addPartyNextButton() {
        return waitForUnstableElement(By.id("C1__BUT_55E5AE0A984C2873500530"));
    }
}