package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_Paymentinformation;

import java.util.List;

public class PaymentinformationUtil {

    private CommonUtil commonutil = new CommonUtil();
    private Obj_Paymentinformation paymentinformation = new Obj_Paymentinformation();

    public void cardBelongsTo(List<List<String>> data, String fieldName) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        if (StrVal.equalsIgnoreCase("Yes")) {
            paymentinformation.cardBelongsToYesRadiobutton().click();
        } else {
            paymentinformation.cardBelongsToNoRadiobutton().click();
        }
    }

    public void cardPermission(List<List<String>> data, String fieldName) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        if (StrVal.equalsIgnoreCase("Yes")) {
            paymentinformation.cardPermissionYesRadiobutton().click();
        } else {
            paymentinformation.cardBelongsToNoRadiobutton().click();
        }
    }

    public void billingAddress(List<List<String>> data, String fieldName) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        if (StrVal.equalsIgnoreCase("Yes")) {
            paymentinformation.billingAddressYesRadiobutton().click();
        } else {
            paymentinformation.billingAddressNoRadiobutton().click();
        }
    }
}