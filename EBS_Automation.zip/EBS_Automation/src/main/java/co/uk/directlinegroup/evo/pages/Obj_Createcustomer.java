package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import net.serenitybdd.core.annotations.findby.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.util.concurrent.TimeUnit;

public class Obj_Createcustomer extends AbstractPage {

    public WebElement createNewCustomerButton() {
        return waitForUnstableElement(By.xpath("//button[@id='C2__BUT_57179A1244E6618059413'][@class='btn btn-default pull-right height-34 createnewcustombtn create-contact btn-space-Rht']"));
    }

    public WebElement corporateContact() {
        return waitForElementToBeClickableAndReturnElement(By.cssSelector("[data-target=\"#C2__C1__corporate-details\"]"));
    }

    public WebElement tradeNametextbox() {
        return waitForElementPresent(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217400"));
    }

    public WebElement addressTypeButton() {
        return waitForUnstableElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217412"));
    }

    public WebElement buildingNumberTextbox() {
        return waitForUnstableElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217414"));
    }

    public WebElement countryTextbox() {
        return waitForUnstableElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217416"));
    }

    public WebElement postCodeTextbox() {
        return waitAndFindElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217418"));
    }

    public WebElement findAddressButton() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__C1__BUT_B5F37DDFDCE76BB21217422']"));
    }
    public WebElement selectAddressDropdown() {
        return waitForElementToBeClickableAndReturnElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217420"));
    }



    public WebElement address1Textbox() {
        return waitForUnstableElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217370"));
    }


    public WebElement businessTextbox() {
        return waitForUnstableElement(By.id("QUE_05DBD1E701916C229357499"));
    }

    public WebElement homeBusinessTexbox() {
        return waitForUnstableElement(By.id("QUE_05DBD1E701916C229357501"));
    }

    public WebElement mobileBusinessTextbox() {
        return waitForUnstableElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217446"));
    }

    public WebElement emailBusinessTextbox() {
        return waitAndFindElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217452"));
    }

    public WebElement websiteAddressTextbox() {
        return waitForUnstableElement(By.id("QUE_05DBD1E701916C229357511"));
    }

    public WebElement titleContactDetailsDropdown() {
        return waitForUnstableElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217470"));
    }

    public WebElement firstnameContactDetailsTextbox() {
        return waitForUnstableElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217472"));
    }

    public WebElement middlenameContactDetailsTextbox() {
        return waitForUnstableElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217320"));
    }

    public WebElement lastnameContactDetailstextbox() {
        return waitForUnstableElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217474"));
    }

    public WebElement suffixContactDetailsDropdown() {
        return waitForUnstableElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217324"));
    }

    public WebElement homeTelephoneNumbersTetbox() {
        return waitForUnstableElement(By.id("QUE_05DBD1E701916C229357541"));
    }

    public WebElement marketingPreferenceYesRadiobutton() {
        return waitForUnstableElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217496_0"));
    }

    public WebElement marketingPreferenceNoRadiobutton() {
        return waitForUnstableElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217496_1"));
    }

    public WebElement correspondenceByPostRadiobutton() {
        return waitForUnstableElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217510_0"));
    }

    public WebElement correspondenceByMailRadiobutton() {
        return waitForUnstableElement(By.id("C2__C1__QUE_B5F37DDFDCE76BB21217510_1"));
    }

    public WebElement smsNotificationCheckbox() {
        return waitForUnstableElement(By.id("C2__C1__QUE_AE3BD4516663C76F871083_0"));
    }

    public WebElement saveButtonButton() {
        return waitForUnstableElement(By.cssSelector("button[id='C2__C1__SaveBtn_Create_New_Corporate_Contact']"));
//        return waitAndFindElement(By.id("BUT_05DBD1E701916C229357573"));
    }

    public WebElement cancelButton() {
        return waitForUnstableElement(By.id("C2__C1__CloseBtn_Create_New_Personal_Contact"));
    }

    public WebElement newQuoteButton() {
        return waitForUnstableElement(By.id("C2__BUT_DB4A6646C4C5D63933681"));
    }

    public void pageLoading() {
        waitForElementEnabled(org.openqa.selenium.By.xpath("//*[@id='TXT_FAE554C988A5F3932837']/div/div[2]/div"));
    }

    public void ccPageLoad() {
        waitForElementEnabled(By.xpath("html/body/div[1]"));
    }


    public WebElement saveExitButton() {
        return waitForElementVisible(By.id("C2__BUT_D3E81D5ED026892F942222"));
    }


    public WebElement saveExitButtonPopUp() {
        return waitForElementVisible(By.xpath("//*[@id='C1__BUT_391E4BE220C07767120913'][@class='green-btn']"));

    }

    public WebElement liabilitySaveExitButton() {
        // return waitForElementVisible(By.id("C2__BUT_D3E81D5ED026892F942222"));
        return waitForElementPresent(By.xpath("//div[@id='C3__p4_BUT_D3E81D5ED026892F3370337']//button[@id='C2__BUT_D3E81D5ED026892F942222']"));
    }

    public WebElement peopleSaveExitButtonPopUp() {
        return waitForElementVisible(By.xpath("//*[@id='BUT_8213FC3835F9DD291056861'][@class='green-btn ssc_exit']"));

    }

    public WebElement emailTextBox() {
        return waitForElementVisible(By.id("QUE_879C6A11B52E18631000835"));
    }

    public WebElement confirmEmailTextBox() {
        return waitForElementVisible(By.id("QUE_879C6A11B52E18631000853"));
    }

    public WebElement contactNoTextBox() {
        return waitForElementVisible(By.id("QUE_879C6A11B52E18631000859"));
    }

    public WebElement emailCheckBox() {
        return waitForElementVisible(By.xpath("//*[@id='checkbox_saveQuoteMarketingPreferences']/label[1]"));


    }

    public WebElement saveExitButton2() {
        return waitForElementVisible(By.id("BUT_879C6A11B52E18633458448"));
    }


    public WebElement removeBusinessTools() {
        return waitForElementVisible(By.xpath("//*[@id='C9__BUT_99A2BF20ED976E671699268']/span"));

    }

    public WebElement removeBusinessContents() {
        return waitForElementVisible(By.xpath("//*[@id='C9__BUT_99A2BF20ED976E671699059']/span"));

    }

    public WebElement removeTOTCover() {
        return waitForElementVisible(By.xpath("//*[@id='C2__BUT_24D9276FBA6E19C58823822']/span"));
    }

    public WebElement removeBusinessToolsYesButton() {
        return waitForElementVisible(By.xpath("//*[@id='information']/div[2]/button[1]"));

    }

    public WebElement removeBusinessContentsYesButton() {
        return waitForElementVisible(By.xpath("//*[@id='information']/div[2]/button[1]"));

    }

    public WebElement saveExitButtonTreatmentPage() {
        return waitForElementVisible(By.id("C4__BUT_D3E81D5ED026892F3306326"));
    }

    public WebElement saveExitButtonPopUpTreatmentPage() {
        return waitForElementVisible(By.xpath("//*[@id='BUT_D3E81D5ED026892F1577152'][@class='green-btn']"));

    }

    public WebElement authorisedContactMobile() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C1__QUE_B5F37DDFDCE76BB21217488']"));
    }

    public WebElement authorisedContactEmail() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C1__QUE_B5F37DDFDCE76BB21217490']"));
    }

    public WebElement manageUserAccount() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C1__BUT_E7B607645443AA0846027']"));
    }

    public WebElement createUserAccount() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C1__BUT_9F531346609AC1BF160413']"));
    }

    public WebElement manageUserAccountCancelButton() {
        return waitForElementPresent(By.xpath("//*[@id='C2__C1__BUT_9F531346609AC1BF160409']"));
    }

    public boolean createUserAccountbox() {
        return waitForElementInVisible(By.xpath("//*[@id='FMT_E7B607645443AA0838692']"));
    }

    public WebElement referralSaveExitButton() {
        return waitForElementVisible(By.xpath("//*[@id='C1__BUT_2913A5FDBA5243B93675229']"));

    }

    public WebElement referralSaveExitButtonPopUp() {
        return waitForElementVisible(By.xpath("//*[@id='BUT_879C6A11B52E18633458448']"));

    }
}
