package co.uk.directlinegroup.evo.utils;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Iterator;

public class Reader {
    /*
    public static void main (String[] args) throws Exception {
        Reader rd = new Reader();
        System.out.println(rd.lookUpreference("DLG_PULSE_CONVERSION_TYPE"));

    }*/

    public String lookUpreference(String lookupValue,String Sheetname,int s_column_no,int t_coloum_no) throws Exception {
        String conversionRef = null;
        String filePath = "C:\\Test\\POC Mapping Sheet\\";
        //String fileName = "Test.xlsx";
        String fileName = "POC Mapping values1.2_Cons.xlsx";
        String Type = null;
        File file = new File(filePath + "\\" + fileName);
        InputStream ExcelFileToRead = new FileInputStream(file);

        XSSFWorkbook wb = new XSSFWorkbook(ExcelFileToRead);
        XSSFSheet sheet = wb.getSheet(Sheetname);
        DataFormatter dataFormatter = new DataFormatter();

        for (Row nextRow : sheet) {
            Type = dataFormatter.formatCellValue(nextRow.getCell(s_column_no));
            //vendor_site_code = dataFormatter.formatCellValue(nextRow.getCell(s_column_no));

            if (Type.equals(lookupValue)) {
                conversionRef = dataFormatter.formatCellValue(nextRow.getCell(t_coloum_no));
                break;
            } else if (Type.equals(lookupValue)) {
                conversionRef = dataFormatter.formatCellValue(nextRow.getCell(t_coloum_no));
                break;
            }
            ExcelFileToRead.close();
        }
        return conversionRef;

    }
}
