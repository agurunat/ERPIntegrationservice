package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_BusinessInterruption;
import co.uk.directlinegroup.evo.pages.Obj_BusinessInteruptionThirdParty;
import co.uk.directlinegroup.evo.pages.Obj_Generalinformation;
import com.usmanhussain.habanero.framework.AbstractPage;
import org.junit.Assert;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.NoSuchElementException;

public class BusinessinterruptionUtil extends AbstractPage {

    private CommonUtil commonUtil = new CommonUtil();
    private Obj_BusinessInterruption businessInterruption = new Obj_BusinessInterruption();
    private Obj_BusinessInteruptionThirdParty businessInteruptionThirdParty = new Obj_BusinessInteruptionThirdParty();
    private static Obj_Generalinformation generalinformation = new Obj_Generalinformation();

    public void businessInterruption(List<List<String>> data, String fieldName, WebElement property) throws NoSuchElementException {
        String options = commonUtil.datapicker(data, fieldName);
        if (options.equalsIgnoreCase("$Element should be present$")) {
            Assert.assertTrue("Element present in the page", property.isDisplayed());
        } else if (options.equalsIgnoreCase("$Element should not be present$")) {
            Assert.assertTrue("Element not present in the page", !property.isDisplayed());
        }
    }

    public void grossTurnOverTextbox(List<List<String>> data, String fieldName, WebElement property) throws NoSuchElementException {
        String options = commonUtil.datapicker(data, fieldName);
        waitForPageLoad();
        if (!options.equalsIgnoreCase("")) {
            commonUtil.setValue(data, "GrossTurnOverValue", property);
        } else {
            LOG.error("Field is not Present");
        }
    }

    public void requiredErrorMessageText(List<List<String>> validationContents) {
        String contentFromPage = businessInterruption.requiredErrorMessageText().getText();
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(contentFromPage + "is displayed", validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            } else if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(contentFromPage + "is displayed", !validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            }
        }
    }

    public void validationErrorMessageText(List<List<String>> validationContents) {
        String contentFromPage = businessInterruption.validationErrorMessage().getText();
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(contentFromPage + "is displayed", validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            } else if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(contentFromPage + "is displayed", !validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            }
        }
    }

    public void grossTurnOverTextboxValidation(List<List<String>> validationContents) {
        String contentFromPage = businessInterruption.grossTurnOverText().getText();
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(contentFromPage + "is displayed", validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            } else if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(contentFromPage + "is displayed", !validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            }
        }
    }

    public void fillBIAtThirdPartyScreenDefault() {
        businessInteruptionThirdParty.rentChair().click();
        generalinformation.pageLoading();
        businessInteruptionThirdParty.nameOfSaloon().sendKeys("ABC Salon");
        businessInteruptionThirdParty.postcode().sendKeys("GY1 1AE");
        businessInteruptionThirdParty.addSaloon().click();
        generalinformation.pageLoading();
        businessInteruptionThirdParty.nextbutton().click();
        generalinformation.pageLoading();
    }


}