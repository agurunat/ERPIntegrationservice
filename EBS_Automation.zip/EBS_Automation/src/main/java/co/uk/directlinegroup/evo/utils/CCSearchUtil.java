package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_CC_Search;
import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CCSearchUtil extends AbstractPage {

    private Obj_CC_Search ccSearch = new Obj_CC_Search();
    private boolean flag = false;

    public void setSearchvalue(String policyno, WebElement property) throws Throwable {
        property.sendKeys(policyno);
    }

    public void setFirstNameValue(String firstName, WebElement property) throws Throwable {
        property.sendKeys(firstName);
    }

    public void setLastNameValue(String LastName, WebElement property) throws Throwable {
        property.sendKeys(LastName);
    }

    public void passwordSetEmailSelection() throws Throwable {
        int rowcount = ccSearch.tableRow().size();
        for (int l = 1; l <= rowcount; l++) {
            for (int k = 1; k <= 8; k++) {
                String data = getDriver.findElement(By.xpath("//table[@id='C2__C6__TBL_BD388A52554BC5E72766684']/tbody/tr[" + l + "]/td[" + k + "]")).getText();
                if (data.equalsIgnoreCase("Password set - email")) {
                    getDriver.findElement(By.xpath("//table[@id='C2__C6__TBL_BD388A52554BC5E72766684']/tbody/tr[" + l + "]/td[" + (k + 2) + "]/div/div/div/a")).click();
                    ccSearch.ccPageLoad();
                    for (String winHandle : getDriver.getWindowHandles()) {
                        WebDriver getDriverTitle = getDriver.switchTo().window(winHandle);
                        if (!getDriverTitle.getTitle().equalsIgnoreCase("CustomerDashboard")) {
                            ccSearch.executeScript("arguments[0].click();", ccSearch.logInhereButton());
                            flag = true;
                            break;
                        }
                    }
                }
                if (flag)
                    break;
            }
            if (flag)
                break;
        }
    }
}