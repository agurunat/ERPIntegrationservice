package co.uk.directlinegroup.evo.utils;

import org.joda.time.DateTime;
import org.w3c.dom.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

public class WebServiceFunctionalUtil {

    public static String contactID = null, counter, policynumber;
    public static String dateSelection, date, companyName, PersonName, lossHistory, subsidaries,requestXml,interestedPartiesPolicy,addPIStandard,addSubPremises;
    File f;

    //ENV or env added to profile use accordingly, any questions contact Rao
    //"https://dlg-test.ssp-hosting.com/DLGUAT/TechnologyFrameworksWeb";
    //https://dlg-sit2.ssp-hosting.com/DLGTRCT/TechnologyFrameworksWeb
    private int number;
    private GeneralinformationUtil obj_generalInformationUtil = new GeneralinformationUtil();
    private ServiceUtil serviceUtil = new ServiceUtil();

    // private static int count=0;

    public String currentDate() throws IOException {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        Date c = new Date();
        date = sdf.format(c);
        return date;
    }

    public String backDated() throws IOException {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        Date c = new Date();
        Date backDated = new DateTime(c).minusDays(359).toDate();
        date = sdf.format(backDated);
        return date;
    }

    public String futureDate() throws IOException {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        Date c = new Date();
        Date futureDate = new DateTime(c).plusDays(1).toDate();
        date = sdf.format(futureDate);
        return date;
    }
    public String relativeDate(String dt) throws IOException {

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        Date c = new Date();
        int rel = Integer.parseInt(dt);
        Date futureDate = new DateTime(c).plusDays(rel).toDate();
        date = sdf.format(futureDate);
        return date;
    }

    public int randomNumber() throws IOException {

        Random rand = new Random();
        int pickedNumber = rand.nextInt(400) + 1;
        return pickedNumber;
    }


    public String searchProduct(String role) throws IOException {
        String[] values = role.split("#");
        if (values.length > 1) {
            if (values[1].equalsIgnoreCase("BackDated")) {
                dateSelection = backDated();
            } else if (values[1].equalsIgnoreCase("futuredate")) {
                dateSelection = futureDate();
            }

            else if (values[1].equalsIgnoreCase("Date")) {
                dateSelection = relativeDate(values[2]);
            }
        } else {
            dateSelection = currentDate();
        }
        contactID = values[0];
        File f = new File("src/test/resources/requests/pre-req/search.xml");
        String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);

        return serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/SearchProductWS");
    }

    public String getProductResources(String schemeCode, String prodTreeId, String versionIdentity) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/product-resources.xml");
        String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        soapRequest = soapRequest.replace("${#TestSuite#scheme-code}", schemeCode);
        soapRequest = soapRequest.replace("${#TestSuite#inception-date}", dateSelection);
        soapRequest = soapRequest.replace("${#TestSuite#product-tree-id}", prodTreeId);
        soapRequest = soapRequest.replace("${#TestSuite#product-version-identity}", versionIdentity);
        return serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/RetrieveResourceWS_v2");
    }

    public String getSpecificResources() throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/specific-resources.xml");
        String specificRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        specificRequest = specificRequest.replace("${#TestSuite#inception-date}", dateSelection);
        return serviceUtil.getResponse(specificRequest, System.getProperty("ENV") + "/RetrieveResourceWS_v2");
    }

    public String generalInfoAddCompanyContact() throws IOException, ParseException {
        companyName = "Automation" + randomNumber();
        //Cognos
        CognosReportsUtil.map.put("Business Name", companyName);
        File f = new File("src/test/resources/requests/pre-req/addCompanyContact.xml");
        String addCompanyContactRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addCompanyContactRequest = addCompanyContactRequest.replace("${#TestSuite#company-name}", companyName);
        return serviceUtil.getResponse(addCompanyContactRequest, System.getProperty("ENV") + "/ManageCompanyWS", "ManageCompanyWSService/createCompany");
    }

    public String generalInfoAddPersonalContact(String companyID) throws IOException, ParseException {
        PersonName = "Person" + randomNumber();
        //Cognos
        CognosReportsUtil.map.put("Personal Name", PersonName);
        File f = new File("src/test/resources/requests/pre-req/addPersonalContact.xml");
        String addPersonalContactRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addPersonalContactRequest = addPersonalContactRequest.replace("Person${#TestSuite#contact-counter}", PersonName);
        addPersonalContactRequest = addPersonalContactRequest.replace("${#TestSuite#company-id}", companyID);
        return serviceUtil.getResponse(addPersonalContactRequest, System.getProperty("ENV") + "/ManagePersonWS", "ManagePersonWSService/createPerson");
    }
    public String generalInfoAddPersonalContact(String companyID, String marketingAsked, String marketingSMS, String marketingTelephone, String marketingPost, String marketingEmail, String inputEmail, String inputTelephone, String inputMobile) throws IOException, ParseException {
        PersonName = "Person" + randomNumber();
        //Cognos
        CognosReportsUtil.map.put("Personal Name", PersonName);
        File f = new File("src/test/resources/Cognos_XML/addPersonalContact-MarkettingPreference.xml");
        String addPersonalContactRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addPersonalContactRequest = addPersonalContactRequest.replace("Person${#TestSuite#contact-counter}", PersonName);
        addPersonalContactRequest = addPersonalContactRequest.replace("${#TestSuite#company-id}", companyID);

        addPersonalContactRequest = addPersonalContactRequest.replace("${#TestSuite#optToMarketing}", marketingAsked);
        addPersonalContactRequest = addPersonalContactRequest.replace("${#TestSuite#marketingDateAsked}", LocalDateTime.now()+"Z");
        addPersonalContactRequest = addPersonalContactRequest.replace("${#TestSuite#marketingSMS}", marketingSMS);
        addPersonalContactRequest = addPersonalContactRequest.replace("${#TestSuite#marketingTelephone}", marketingTelephone);
        addPersonalContactRequest = addPersonalContactRequest.replace("${#TestSuite#marketingPost}", marketingPost);
        addPersonalContactRequest = addPersonalContactRequest.replace("${#TestSuite#marketingEmail}", marketingEmail);
/*
<!--emailtelephones>
${#TestSuite#emailtelephones}
<emailtelephones-->

 */
        String emailPhonedetail = "";
        if(inputEmail.equals("yes"))
        {
            emailPhonedetail = emailPhonedetail + "<v11:emails><v11:email><v11:emailType>2</v11:emailType><v11:emailAddress>automation@test.com</v11:emailAddress></v11:email></v11:emails>";
        }

        if(inputMobile.equals("yes") || inputTelephone.equals("yes"))
        {
            emailPhonedetail = emailPhonedetail +"<v11:telephones>";
            if(inputMobile.equals("yes"))
            {
                emailPhonedetail = emailPhonedetail +"<v11:telephone><v11:telephoneType>1</v11:telephoneType><v11:telephoneNumber>700056845</v11:telephoneNumber></v11:telephone>";
            }
            if(inputTelephone.equals("yes"))
            {
                emailPhonedetail = emailPhonedetail +"<v11:telephone><v11:telephoneType>5</v11:telephoneType><v11:telephoneNumber>700056845</v11:telephoneNumber></v11:telephone>";
            }
            emailPhonedetail = emailPhonedetail +"</v11:telephones>";

        }
        addPersonalContactRequest = addPersonalContactRequest.replace("<!--emailtelephones>","");
        addPersonalContactRequest = addPersonalContactRequest.replace("${#TestSuite#emailtelephones}",emailPhonedetail);
        addPersonalContactRequest = addPersonalContactRequest.replace("<emailtelephones-->","");

        return serviceUtil.getResponse(addPersonalContactRequest, System.getProperty("ENV") + "/ManagePersonWS", "ManagePersonWSService/createPerson");
    }

    public String generalInfoRetrieveCompanyContact(String companyID) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/retrieveCompanyContact.xml");
        String retrieveCompanyContactRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        retrieveCompanyContactRequest = retrieveCompanyContactRequest.replace("${#TestSuite#company-id}", companyID);
        return serviceUtil.getResponse(retrieveCompanyContactRequest, System.getProperty("ENV") + "/RetrieveCompanyWS", "RetrieveCompanyWSService/retrieveCompany");
    }

    public String generalInfoUpdateCompanyContact(String companyID) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateCompanyContact.xml");
        String updateCompanyContactRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        updateCompanyContactRequest = updateCompanyContactRequest.replace("${#TestSuite#company-id}", companyID);
        return serviceUtil.getResponse(updateCompanyContactRequest, System.getProperty("ENV") + "/ManageCompanyWS", "ManageCompanyWSService/updateCompany");
    }

    public String generalInfoNewBusiness(String strTrade, String productClass, String schemeCode, String prodTreeId, String companyID, String policyBasis, String completionChannel) throws IOException, ParseException {
        String intermediaryID = "5";
        File f = new File("src/test/resources/requests/pre-req/newBusiness.xml");
        String newBusinessRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        newBusinessRequest = newBusinessRequest.replace("${#TestSuite#company-id}", companyID);
        newBusinessRequest = newBusinessRequest.replace("${#TestSuite#product-class}", productClass);
        newBusinessRequest = newBusinessRequest.replace("${#TestSuite#scheme-code}", schemeCode);
        newBusinessRequest = newBusinessRequest.replace("${#TestSuite#product-tree-id}", prodTreeId);
        newBusinessRequest = newBusinessRequest.replace("${#TestSuite#company-id}", companyID);
        newBusinessRequest = newBusinessRequest.replace("${#TestSuite#intermediary-id}", intermediaryID);
        newBusinessRequest = newBusinessRequest.replace("${#TestSuite#inception-date}", dateSelection);
        newBusinessRequest = newBusinessRequest.replace("${#TestSuite#policy-basis}", policyBasis);
        newBusinessRequest = newBusinessRequest.replace("strCompletionChannel", completionChannel);
        return serviceUtil.getResponse(newBusinessRequest, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/createNewBusiness");
    }

    public String genInfoAddBusinessTrade(String strTrade, String addBusinessInput, String policyIdentity, String PositionIdentity, String variationIdentity, String dlgComponentIdentity) throws IOException, ParseException {
        File f = null;
        String[] businessValue = addBusinessInput.split(",");
        String addBusinessRequest = null;
        if (strTrade.equalsIgnoreCase("H&B")) {
            f = new File("src/test/resources/requests/pre-req/addTheBusinessMainTrade.xml");
            addBusinessRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
            addBusinessRequest = addBusinessRequest.replace("<urn2:isManufactureBeautyProducts>N", "<urn2:isManufactureBeautyProducts>" + String.valueOf(businessValue[17]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:isBusinessStatutoryRegulations>NA", "<urn2:isBusinessStatutoryRegulations>" + String.valueOf(businessValue[18]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:isContracts>NA", "<urn2:isContracts>" + String.valueOf(businessValue[19]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:isOccupiedAsHolidayHomeHostelDorm>NA", "<urn2:isOccupiedAsHolidayHomeHostelDorm>" + String.valueOf(businessValue[20]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:isOvernightOccupation>NA", "<urn2:isOvernightOccupation>" + String.valueOf(businessValue[21]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:haveEmployees>N", "<urn2:haveEmployees>" + String.valueOf(businessValue[22]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:noOfEmployees>0", "<urn2:noOfEmployees>" + String.valueOf(businessValue[23]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:noOfEmployeesAdminOnly>0", "<urn2:noOfEmployeesAdminOnly>" + String.valueOf(businessValue[24]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:noOfPPD>1", "<urn2:noOfPPD>" + String.valueOf(businessValue[25]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:noOfPPDAdminOnly>0", "<urn2:noOfPPDAdminOnly>" + String.valueOf(businessValue[26]).replace("$null$", ""));

        } else if (strTrade.equalsIgnoreCase("B&B")) {

            f = new File("src/test/resources/BB_XML/BB_Business_MainTrade.xml");
            addBusinessRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
            addBusinessRequest = addBusinessRequest.replace("<urn2:isManufactureBeautyProducts>NA", "<urn2:isManufactureBeautyProducts>" + String.valueOf(businessValue[17]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:isBusinessStatutoryRegulations>Y", "<urn2:isBusinessStatutoryRegulations>" + String.valueOf(businessValue[18]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:isContracts>Y", "<urn2:isContracts>" + String.valueOf(businessValue[19]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:isOccupiedAsHolidayHomeHostelDorm>Y", "<urn2:isOccupiedAsHolidayHomeHostelDorm>" + String.valueOf(businessValue[20]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:isOvernightOccupation>Y", "<urn2:isOvernightOccupation>" + String.valueOf(businessValue[21]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:haveEmployees>E", "<urn2:haveEmployees>" + String.valueOf(businessValue[22]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:noOfEmployees>4", "<urn2:noOfEmployees>" + String.valueOf(businessValue[23]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:noOfEmployeesAdminOnly>0", "<urn2:noOfEmployeesAdminOnly>" + String.valueOf(businessValue[24]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:noOfPPD>1", "<urn2:noOfPPD>" + String.valueOf(businessValue[25]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:noOfPPDAdminOnly>0", "<urn2:noOfPPDAdminOnly>" + String.valueOf(businessValue[26]).replace("$null$", ""));
        } else if (strTrade.equalsIgnoreCase("OPR")){
            f = new File("src/test/resources/OPR_XML/OPR_Business_MainTrade.xml");
            addBusinessRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
            addBusinessRequest = addBusinessRequest.replace("<urn2:isManufactureBeautyProducts>N", "<urn2:isManufactureBeautyProducts>" + String.valueOf(businessValue[17]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:isBusinessStatutoryRegulations>NA", "<urn2:isBusinessStatutoryRegulations>" + String.valueOf(businessValue[18]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:isContracts>NA", "<urn2:isContracts>" + String.valueOf(businessValue[19]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:isOccupiedAsHolidayHomeHostelDorm>NA", "<urn2:isOccupiedAsHolidayHomeHostelDorm>" + String.valueOf(businessValue[20]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:isOvernightOccupation>NA", "<urn2:isOvernightOccupation>" + String.valueOf(businessValue[21]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:haveEmployees>N", "<urn2:haveEmployees>" + String.valueOf(businessValue[22]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:noOfEmployees>0", "<urn2:noOfEmployees>" + String.valueOf(businessValue[23]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:noOfEmployeesAdminOnly>0", "<urn2:noOfEmployeesAdminOnly>" + String.valueOf(businessValue[24]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:noOfPPD>1", "<urn2:noOfPPD>" + String.valueOf(businessValue[25]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("<urn2:noOfPPDAdminOnly>0", "<urn2:noOfPPDAdminOnly>" + String.valueOf(businessValue[26]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("strLastTurnOverAmount", String.valueOf(businessValue[34]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("strLastTurnOverBsnd", String.valueOf(businessValue[35]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("strMainSegmentL1", String.valueOf(businessValue[36]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("strMainTradeSeglevelInt", String.valueOf(businessValue[37]).replace("$null$", ""));
            addBusinessRequest = addBusinessRequest.replace("strSecondSegmentL1", String.valueOf(businessValue[38]).replace("$null$", ""));
            if(!businessValue[39].equalsIgnoreCase("")){
                addBusinessRequest = addBusinessRequest.replace("<urn2:mobileFoodTrailer>false", "<urn2:mobileFoodTrailer>"+String.valueOf(businessValue[39]).replace("$null$", ""));
            }
            if(!businessValue[40].equalsIgnoreCase("")){
                addBusinessRequest = addBusinessRequest.replace("<urn2:myShop>false", "<urn2:myShop>"+String.valueOf(businessValue[40]).replace("$null$", ""));
            }
            if(!businessValue[41].equalsIgnoreCase("")){
                addBusinessRequest = addBusinessRequest.replace("<urn2:pop_Ups>false", "<urn2:pop_Ups>"+String.valueOf(businessValue[41]).replace("$null$", ""));
            }
            if(!businessValue[42].equalsIgnoreCase("")){
                addBusinessRequest = addBusinessRequest.replace("<urn2:streetFoodStall>false", "<urn2:streetFoodStall>"+String.valueOf(businessValue[42]).replace("$null$", ""));
            }
            if(!businessValue[43].equalsIgnoreCase("")){
                addBusinessRequest = addBusinessRequest.replace("<urn2:online>false", "<urn2:online>"+String.valueOf(businessValue[43]).replace("$null$", ""));
            }
            if(!businessValue[44].equalsIgnoreCase("")){
                addBusinessRequest = addBusinessRequest.replace("<urn2:marketsFairsAndFestivals>false", "<urn2:marketsFairsAndFestivals>"+String.valueOf(businessValue[44]).replace("$null$", ""));
            }
            if(!businessValue[45].equalsIgnoreCase("")){
                addBusinessRequest = addBusinessRequest.replace("<urn2:provideFoodForEvents>false", "<urn2:provideFoodForEvents>"+String.valueOf(businessValue[45]).replace("$null$", ""));
            }
            if(!businessValue[46].equalsIgnoreCase("")){
                addBusinessRequest = addBusinessRequest.replace("<urn2:visitMyCustomers>false", "<urn2:visitMyCustomers>"+String.valueOf(businessValue[46]).replace("$null$", ""));
            }
            if(!businessValue[47].equalsIgnoreCase("")){
                addBusinessRequest = addBusinessRequest.replace("<urn2:sharedRetailSpace>false", "<urn2:sharedRetailSpace>"+String.valueOf(businessValue[47]).replace("$null$", ""));
            }
            if(!businessValue[48].equalsIgnoreCase("")){
                addBusinessRequest = addBusinessRequest.replace("<urn2:fromOwnOffice>false", "<urn2:fromOwnOffice>"+String.valueOf(businessValue[48]).replace("$null$", ""));
            }
            if(!businessValue[49].equalsIgnoreCase("")){
                addBusinessRequest = addBusinessRequest.replace("<urn2:rentDesk>false", "<urn2:rentDesk>"+String.valueOf(businessValue[49]).replace("$null$", ""));
            }
            if(!businessValue[50].equalsIgnoreCase("") ){
                if(!businessValue[50].equalsIgnoreCase("$null$")){
                    addBusinessRequest = addBusinessRequest.replace("<urn2:fromOtherCommercialPremises>false", "<urn2:fromOtherCommercialPremises>"+String.valueOf(businessValue[50]).replace("$null$", ""));
                }
            }
            addBusinessRequest = addBusinessRequest.replace("strManualWork",String.valueOf(businessValue[51]).replace("$null$", ""));
            if(businessValue[52].equalsIgnoreCase("RN")){
                addBusinessRequest = addBusinessRequest.replace("<urn2:numberOfEmployeesManualOnly>strEmpManual</urn2:numberOfEmployeesManualOnly>", "");
            }else {
                addBusinessRequest = addBusinessRequest.replace("strEmpManual",String.valueOf(businessValue[52]).replace("$null$", ""));
            }
            if(businessValue[53].equalsIgnoreCase("RN")){
                addBusinessRequest = addBusinessRequest.replace("<urn2:noOfPPDManualOnly>strPPDManual</urn2:noOfPPDManualOnly>", "");
            }else {
                addBusinessRequest = addBusinessRequest.replace("strPPDManual",String.valueOf(businessValue[53]).replace("$null$", ""));
            }
        }
        addBusinessRequest = addBusinessRequest.replace("${#TestSuite#policy-id}", policyIdentity);
        addBusinessRequest = addBusinessRequest.replace("${#TestSuite#position-id}", PositionIdentity);
        addBusinessRequest = addBusinessRequest.replace("${#TestSuite#variation-id}", variationIdentity);
        addBusinessRequest = addBusinessRequest.replace("${#TestSuite#DLG-comp-id}", dlgComponentIdentity);
        addBusinessRequest = addBusinessRequest.replace("strTradeName", String.valueOf(businessValue[0]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strAnotherTrade1", String.valueOf(businessValue[2]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("<urn2:isMainTrade>false", "<urn2:isMainTrade>" + String.valueOf(businessValue[3]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strIsMainTradeCheck", String.valueOf(businessValue[1]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strSecondTradeSeglevelInt", String.valueOf(businessValue[4]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strRentChair", String.valueOf(businessValue[5]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strMobile", String.valueOf(businessValue[6]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strSalon", String.valueOf(businessValue[7]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strWorkFromHome", String.valueOf(businessValue[8]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strTransactUX", String.valueOf(businessValue[9]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("<urn2:agreeToStatements>Y", "<urn2:agreeToStatements>" + String.valueOf(businessValue[10]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("<urn2:importantOrRefurbishment>Y", "<urn2:importantOrRefurbishment>" + String.valueOf(businessValue[11]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("<urn2:isRefusedCancelledInsurance>N", "<urn2:isRefusedCancelledInsurance>" + String.valueOf(businessValue[12]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("<urn2:isConviction>N", "<urn2:isConviction>" + String.valueOf(businessValue[13]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("<<urn2:isCcj>N", "<urn2:isCcj>" + String.valueOf(businessValue[14]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("<urn2:isIva>N", "<urn2:isIva>" + String.valueOf(businessValue[15]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("<urn2:isBankrupcy>N", "<urn2:isBankrupcy>" + String.valueOf(businessValue[16]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("<urn2:companyStatus>DL4B_03", "<urn2:companyStatus>" + String.valueOf(businessValue[27]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("<urn2:subsidiaries>N", "<urn2:subsidiaries>" + String.valueOf(businessValue[28]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("<urn2:yearsTradingAtIncep>2", "<urn2:yearsTradingAtIncep>" + String.valueOf(businessValue[29]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("<urn2:workOutsideUK>2", "<urn2:workOutsideUK>" + String.valueOf(businessValue[30]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("<urn2:frequencyOutsideUK>2", "<urn2:frequencyOutsideUK>" + String.valueOf(businessValue[31]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("<urn2:turnoverBand>150000", "<urn2:turnoverBand>" + String.valueOf(businessValue[32]).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("<urn1:amount>0", "<urn1:amount>" + String.valueOf(businessValue[33]).replace("$null$", ""));

        //System.out.println("request--->"+addBusinessRequest);

        return serviceUtil.getResponse(addBusinessRequest, System.getProperty("ENV") + "/ListComponentSaveSME_INSSMEv1", "ListComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String generalInfoAddBusinessMainTrade(String strTrade, String tradeName, String isMainTrade, String strAnotherTrade1, String secondTradeSegLevel, String rentChair, String mobileBusiness, String ownSalon, String workFromHome, String transactViaUX, String policyIdentity, String PositionIdentity, String variationIdentity, String dlgComponentIdentity) throws IOException, ParseException {
        File f = null;
        switch (strTrade) {
            case ("H&B"):
                f = new File("src/test/resources/requests/pre-req/addTheBusinessMainTrade.xml");
                break;

            case ("B&B"):
                f = new File("src/test/resources/BB_XML/BB_Business_MainTrade.xml");
                break;
            case ("OPR"):
                f = new File("src/test/resources/OPR_XML/OPR_Business_MainTrade.xml");
                break;
        }

        String addBusinessRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addBusinessRequest = addBusinessRequest.replace("${#TestSuite#policy-id}", policyIdentity);
        addBusinessRequest = addBusinessRequest.replace("${#TestSuite#position-id}", PositionIdentity);
        addBusinessRequest = addBusinessRequest.replace("${#TestSuite#variation-id}", variationIdentity);
        addBusinessRequest = addBusinessRequest.replace("${#TestSuite#DLG-comp-id}", dlgComponentIdentity);
        addBusinessRequest = addBusinessRequest.replace("strRentChair", String.valueOf(rentChair).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strMobile", String.valueOf(mobileBusiness).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strSalon", String.valueOf(ownSalon).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strWorkFromHome", String.valueOf(workFromHome).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strTradeName", String.valueOf(tradeName).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strIsMainTradeCheck", String.valueOf(isMainTrade).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strAnotherTrade1", String.valueOf(strAnotherTrade1).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strSecondTradeSeglevelInt", String.valueOf(secondTradeSegLevel).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strTransactUX", String.valueOf(transactViaUX).replace("$null$", ""));
        //System.out.println(addBusinessRequest);
        return serviceUtil.getResponse(addBusinessRequest, System.getProperty("ENV") + "/ListComponentSaveSME_INSSMEv1", "ListComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String OPR_generalInfoAddBusinessMainTrade(String strTrade, String tradeName, String isMainTrade, String strAnotherTrade1, String secondTradeSegLevel, String rentChair, String mobileBusiness, String ownSalon, String workFromHome,String strTurnOverAmount,String strTurnOverBsnd,String strLastTurnOverAmount,String strLastTurnOverBsnd,String strTradeYears,String transactViaUX, String policyIdentity, String PositionIdentity, String variationIdentity, String dlgComponentIdentity) throws IOException, ParseException {
        File f = null;
        switch (strTrade) {
            case ("H&B"):
                f = new File("src/test/resources/requests/pre-req/addTheBusinessMainTrade.xml");
                break;

            case ("B&B"):
                f = new File("src/test/resources/BB_XML/BB_Business_MainTrade.xml");
                break;
            case ("OPR"):
                f = new File("src/test/resources/OPR_XML/OPR_Business_MainTrade.xml");
                break;
        }

        String addBusinessRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addBusinessRequest = addBusinessRequest.replace("${#TestSuite#policy-id}", policyIdentity);
        addBusinessRequest = addBusinessRequest.replace("${#TestSuite#position-id}", PositionIdentity);
        addBusinessRequest = addBusinessRequest.replace("${#TestSuite#variation-id}", variationIdentity);
        addBusinessRequest = addBusinessRequest.replace("${#TestSuite#DLG-comp-id}", dlgComponentIdentity);
        addBusinessRequest = addBusinessRequest.replace("strRentChair", String.valueOf(rentChair).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strMobile", String.valueOf(mobileBusiness).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strSalon", String.valueOf(ownSalon).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strWorkFromHome", String.valueOf(workFromHome).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strTradeName", String.valueOf(tradeName).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strIsMainTradeCheck", String.valueOf(isMainTrade).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strAnotherTrade1", String.valueOf(strAnotherTrade1).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strSecondTradeSeglevelInt", String.valueOf(secondTradeSegLevel).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strTransactUX", String.valueOf(transactViaUX).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strTurnOverAmount", String.valueOf(strTurnOverAmount).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strTurnOverBsnd", String.valueOf(strTurnOverBsnd).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strLastTurnOverAmount", String.valueOf(strLastTurnOverAmount).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strLastTurnOverBsnd", String.valueOf(strLastTurnOverBsnd).replace("$null$", ""));
        addBusinessRequest = addBusinessRequest.replace("strTradeYears", String.valueOf(strTradeYears).replace("$null$", ""));
        return serviceUtil.getResponse(addBusinessRequest, System.getProperty("ENV") + "/ListComponentSaveSME_INSSMEv1", "ListComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String generalInfoUpdateBusinessMainTrade(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity) throws IOException, ParseException {
        Integer componentIdentity132, componentIdentityA13, componentIdentity245;
        File f = new File("src/test/resources/requests/pre-req/updateTheBusiness.xml");
        String updateBusinessRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        updateBusinessRequest = updateBusinessRequest.replace("${#TestSuite#policy-id}", policyIdentity);
        updateBusinessRequest = updateBusinessRequest.replace("${#TestSuite#position-id}", PositionIdentity);
        updateBusinessRequest = updateBusinessRequest.replace("${#TestSuite#variation-id}", variationIdentity);
        updateBusinessRequest = updateBusinessRequest.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
        Integer componentIdentity = Integer.parseInt(businessComponentIdentity);
        componentIdentity132 = componentIdentity + 1;
        componentIdentityA13 = componentIdentity + 2;
        componentIdentity245 = componentIdentity + 3;
        updateBusinessRequest = updateBusinessRequest.replace("${#TestSuite#132-comp-id}", componentIdentity132.toString());
        updateBusinessRequest = updateBusinessRequest.replace("${#TestSuite#A13-comp-id}", componentIdentityA13.toString());
        updateBusinessRequest = updateBusinessRequest.replace("${#TestSuite#245-comp-id}", componentIdentity245.toString());
        return serviceUtil.getResponse(updateBusinessRequest, System.getProperty("ENV") + "/ListComponentUpdateSME_INSSMEv1", "ListComponentUpdateSME_INSSMEv1Service/updateExistingListComponentIgnoreWarnings");
    }

    public String generalInfoSaveQuote(String policyIdentity, String PositionIdentity, String variationIdentity) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/saveQuote.xml");
        String saveQuoteRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        saveQuoteRequest = saveQuoteRequest.replace("${#TestSuite#policy-id}", policyIdentity);
        saveQuoteRequest = saveQuoteRequest.replace("${#TestSuite#position-id}", PositionIdentity);
        saveQuoteRequest = saveQuoteRequest.replace("${#TestSuite#variation-id}", variationIdentity);
        saveQuoteRequest = saveQuoteRequest.replace("${#TestSuite#inception-date}", dateSelection);
        return serviceUtil.getResponse(saveQuoteRequest, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/statusUpdate");
    }

    public String peopleUpdateBusiness(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity, String strTrade) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/PeopleUpdateTheBusiness.xml");
        String peopleUpdateBusiness = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        peopleUpdateBusiness = peopleUpdateBusiness.replace("${#TestSuite#policy-id}", policyIdentity);
        peopleUpdateBusiness = peopleUpdateBusiness.replace("${#TestSuite#position-id}", PositionIdentity);
        peopleUpdateBusiness = peopleUpdateBusiness.replace("${#TestSuite#variation-id}", variationIdentity);
        peopleUpdateBusiness = peopleUpdateBusiness.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
        if (strTrade.equalsIgnoreCase("B&B")) {
            peopleUpdateBusiness = peopleUpdateBusiness.replace("strNoOfPPAdminOnly", "");
            peopleUpdateBusiness = peopleUpdateBusiness.replace("strNoOfEmpAdminOnly", "");
        } else {
            peopleUpdateBusiness = peopleUpdateBusiness.replace("strNoOfPPAdminOnly", "0");
            peopleUpdateBusiness = peopleUpdateBusiness.replace("strNoOfEmpAdminOnly", "0");
        }
        return serviceUtil.getResponse(peopleUpdateBusiness, System.getProperty("ENV") + "/ListComponentUpdateSME_INSSMEv1", "ListComponentUpdateSME_INSSMEv1Service/updateExistingListComponentIgnoreWarnings");
    }

    public String plAddPublicProductLiability(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/addPublicAndProductLiability.xml");
        String addPublicProdutLiability = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addPublicProdutLiability = addPublicProdutLiability.replace("${#TestSuite#policy-id}", policyIdentity);
        addPublicProdutLiability = addPublicProdutLiability.replace("${#TestSuite#position-id}", PositionIdentity);
        addPublicProdutLiability = addPublicProdutLiability.replace("${#TestSuite#variation-id}", variationIdentity);
        addPublicProdutLiability = addPublicProdutLiability.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
        return serviceUtil.getResponse(addPublicProdutLiability, System.getProperty("ENV") + "/GroupComponentSaveSME_INSSMEv1", "GroupComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String plAddPublicLiabilityStandard(String policyIdentity, String PositionIdentity, String variationIdentity, String publicLiabilityCompId, String exportsOutsideUK) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/addPublicLiabilityStandard.xml");
        String addPublicLiabilityStandard = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addPublicLiabilityStandard = addPublicLiabilityStandard.replace("${#TestSuite#policy-id}", policyIdentity);
        addPublicLiabilityStandard = addPublicLiabilityStandard.replace("${#TestSuite#position-id}", PositionIdentity);
        addPublicLiabilityStandard = addPublicLiabilityStandard.replace("${#TestSuite#variation-id}", variationIdentity);
        addPublicLiabilityStandard = addPublicLiabilityStandard.replace("${#TestSuite#Public_Liability-comp-id}", publicLiabilityCompId);
        //Format-Add the Covers of 'PPLiability-1,1000000,100#Engineering' with 'nopplValidation'
        String[] ppl = exportsOutsideUK.split(",");
        if (ppl.length >= 2) {
            addPublicLiabilityStandard = addPublicLiabilityStandard.replace("<urn2:limitOfIndemnity>1000000", "<urn2:limitOfIndemnity>" + String.valueOf(ppl[1]).replace("$null$", ""));
            addPublicLiabilityStandard = addPublicLiabilityStandard.replace("<urn2:excess>100", "<urn2:excess>" + String.valueOf(ppl[2]).replace("$null$", ""));
        }
        addPublicLiabilityStandard = addPublicLiabilityStandard.replace("strExportOutsideUK", String.valueOf(ppl[0]).replace("$null$", ""));
        //System.out.println(addPublicLiabilityStandard);
        return serviceUtil.getResponse(addPublicLiabilityStandard, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String plPublicLiabilityTemporaryEmployees(String policyIdentity, String PositionIdentity, String variationIdentity, String publicLiabilityStandardCompId) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/addPublicLiabilityTemporaryEmployees.xml");
        String publicLiabilityTempEmp = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        publicLiabilityTempEmp = publicLiabilityTempEmp.replace("${#TestSuite#policy-id}", policyIdentity);
        publicLiabilityTempEmp = publicLiabilityTempEmp.replace("${#TestSuite#position-id}", PositionIdentity);
        publicLiabilityTempEmp = publicLiabilityTempEmp.replace("${#TestSuite#variation-id}", variationIdentity);
        publicLiabilityTempEmp = publicLiabilityTempEmp.replace("${#TestSuite#Public_Liability-comp-id}", publicLiabilityStandardCompId);
        return serviceUtil.getResponse(publicLiabilityTempEmp, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String plAddBoneFideSubContractors(String policyIdentity, String PositionIdentity, String variationIdentity, String publicLiabilityCompId, String strBFSCValue) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addBonaFideSubContractors.xml");
        String addBoneFideSubContractors = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addBoneFideSubContractors = addBoneFideSubContractors.replace("${#TestSuite#policy-id}", policyIdentity);
        addBoneFideSubContractors = addBoneFideSubContractors.replace("${#TestSuite#position-id}", PositionIdentity);
        addBoneFideSubContractors = addBoneFideSubContractors.replace("${#TestSuite#variation-id}", variationIdentity);
        addBoneFideSubContractors = addBoneFideSubContractors.replace("${#TestSuite#Public_Liability-comp-id}", publicLiabilityCompId);
        addBoneFideSubContractors = addBoneFideSubContractors.replace("strBFSCValue", String.valueOf(strBFSCValue));
        return serviceUtil.getResponse(addBoneFideSubContractors, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String updateBusinessBI(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity, String turnoverInput) throws IOException, ParseException {
        String[] turnoverValue = turnoverInput.split(",");
        File f = new File("src/test/resources/requests/pre-req/UpdateTheBusinessTurnOver.xml");
        String updateBusinessBI = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        updateBusinessBI = updateBusinessBI.replace("${#TestSuite#policy-id}", policyIdentity);
        updateBusinessBI = updateBusinessBI.replace("${#TestSuite#position-id}", PositionIdentity);
        updateBusinessBI = updateBusinessBI.replace("${#TestSuite#variation-id}", variationIdentity);
        updateBusinessBI = updateBusinessBI.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
        updateBusinessBI = updateBusinessBI.replace("strTurnoverBand", String.valueOf(turnoverValue[0]));
        updateBusinessBI = updateBusinessBI.replace("strTurnoverAmount", String.valueOf(turnoverValue[1]));
        return serviceUtil.getResponse(updateBusinessBI, System.getProperty("ENV") + "/ListComponentUpdateSME_INSSMEv1", "ListComponentUpdateSME_INSSMEv1Service/updateExistingListComponentIgnoreWarnings");
    }

    public String addPremises(String strTrade, String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity, HashMap<String, String> premises) throws IOException, ParseException {
        File f = null;
        switch (strTrade) {
            case ("H&B"):

                f = new File("src/test/resources/requests/pre-req/addPremises.xml");
                break;
            case ("B&B"):

                f = new File("src/test/resources/BB_XML/PU_AddPremises.xml");
                break;
        }
        List<String> premisesKeys = new ArrayList<>(premises.keySet());

        String addPremises = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addPremises = addPremises.replace("${#TestSuite#policy-id}", policyIdentity);
        addPremises = addPremises.replace("${#TestSuite#position-id}", PositionIdentity);
        addPremises = addPremises.replace("${#TestSuite#variation-id}", variationIdentity);
        addPremises = addPremises.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);

        for (String strXmlParameterKey : premisesKeys) {

            if (premises.get(strXmlParameterKey).equalsIgnoreCase("Commercial")) {
                addPremises = addPremises.replace(strXmlParameterKey, String.valueOf(premises.get(strXmlParameterKey)).replace("Commercial", "DL4B_PT20"));
            } else if (premises.get(strXmlParameterKey).equalsIgnoreCase("Home")) {
                addPremises = addPremises.replace(strXmlParameterKey, String.valueOf(premises.get(strXmlParameterKey)).replace("Home", "DL4B_PT10"));
            }

            addPremises = addPremises.replace(strXmlParameterKey, String.valueOf(premises.get(strXmlParameterKey)).replace("$null$", ""));

        }
        return serviceUtil.getResponse(addPremises, System.getProperty("ENV") + "/ListComponentSaveSME_INSSMEv1", "ListComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }

    public String addPremisesRenewals(String strTrade, String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity, HashMap<String, String> premises) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addPremisesRenewal.xml");
        List<String> premisesKeys = new ArrayList<>(premises.keySet());
        String addPremises = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addPremises = addPremises.replace("${#TestSuite#policy-id}", policyIdentity);
        addPremises = addPremises.replace("${#TestSuite#position-id}", PositionIdentity);
        addPremises = addPremises.replace("${#TestSuite#variation-id}", variationIdentity);
        addPremises = addPremises.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);

        for (String strXmlParameterKey : premisesKeys) {

            if (premises.get(strXmlParameterKey).equalsIgnoreCase("Commercial")) {
                addPremises = addPremises.replace(strXmlParameterKey, String.valueOf(premises.get(strXmlParameterKey)).replace("Commercial", "DL4B_PT20"));
            } else if (premises.get(strXmlParameterKey).equalsIgnoreCase("Home")) {
                addPremises = addPremises.replace(strXmlParameterKey, String.valueOf(premises.get(strXmlParameterKey)).replace("Home", "DL4B_PT10"));
            }

            addPremises = addPremises.replace(strXmlParameterKey, String.valueOf(premises.get(strXmlParameterKey)).replace("$null$", ""));

        }

        //System.out.println("request =================== " + addPremises);

        return serviceUtil.getResponse(addPremises, System.getProperty("ENV") + "/ListComponentSaveSME_INSSMEv1", "ListComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }
    public String writeAddSubPremsieWallRoofMaterials(String materials,String xml) throws Exception
    //Format - WALL:1#ROOF:1#HEAT:044,003
    {
        if(!materials.equalsIgnoreCase("$null$")) {
            String[] constructionMaterials = materials.split("#");
            DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = domFactory.newDocumentBuilder();
            Document doc = builder.parse(new File(xml));
            for (int t = 0; t < constructionMaterials.length; t++) {

                String[] materialVal = constructionMaterials[t].split(":");
                //Telling that need to write these items between which node, node name is <urn1:component> in xml
                Element dataTag = doc.getDocumentElement();
                Element componentTag = (Element) dataTag.getElementsByTagName("urn1:component").item(0);

                //Creating the <urn1:listElement> node and their attributes, values
                Element listElement = doc.createElement("urn1:listElement");
                Attr attrType = doc.createAttribute("xsi:type");
                attrType.setValue("urn2:ComponentPremiseItem");
                listElement.setAttributeNode(attrType);

                //Creating the <urn2:type> node within listElement node
                Element type = doc.createElement("urn2:type");
                type.setTextContent(String.valueOf(materialVal[0]).replace("$null$", ""));

                switch (materialVal[0]){

                    //here we are using OR condition for same list of items(Wall and Roof)

                    case "WALL":
                    case "ROOF":

                        //Creating the <urn2:typeOfMaterial> node within listElement node
                        Element typeOfMaterial = doc.createElement("urn2:typeOfMaterial");
                        typeOfMaterial.setTextContent(String.valueOf(materialVal[1]).replace("$null$", ""));
                        listElement.appendChild(typeOfMaterial);

                        break;

                    case "HEAT":

                        String[] items = materialVal[1].split("&");
                        //Creating the <urn2:typeOfHeating> node within listElement node
                        Element typeOfHeating = doc.createElement("urn2:typeOfHeating");
                        typeOfHeating.setTextContent(String.valueOf(items[0]).replace("$null$", ""));
                        listElement.appendChild(typeOfHeating);

                        //Creating the <urn2:typeOfFuel> node within listElement node
                        Element typeOfFuel = doc.createElement("urn2:typeOfFuel");
                        typeOfFuel.setTextContent(String.valueOf(items[1]).replace("$null$", ""));
                        listElement.appendChild(typeOfFuel);

                        break;


                }

                listElement.appendChild(type);

                //Appdening all the list items of nodes within componentTag "<urn2:component>"
                componentTag.appendChild(listElement);

            }

            //Writing the above items
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");

            StreamResult result = new StreamResult(new StringWriter());
            DOMSource source = new DOMSource(doc);
            transformer.transform(source, result);

            addSubPremises = result.getWriter().toString();
            //System.out.println(addSubPremises);
        }
        return addSubPremises;

    }

    public  String xmlSelectionHB_BB_OPR(String strTrade){


        switch (strTrade) {
            case ("H&B"):

                f = new File("src/test/resources/requests/pre-req/addSubPremise.xml");
                break;
            case ("B&B"):

                f = new File("src/test/resources/BB_XML/SP_AddSubPremise.xml");
                break;
            case ("OPR"):

                f = new File("src/test/resources/requests/pre-req/OPRSubPremise.xml");
                break;
        }

        return f.toString();
    }

    public String addSubPremises(String strTrade, String policyIdentity, String PositionIdentity, String variationIdentity, String riskAddCompId, HashMap<String, String> subPremises) throws Exception {
        boolean flag = false;

        List<String> keys = new ArrayList<>(subPremises.keySet());

        for (String strXmlParameterKey : keys) {

            if (strXmlParameterKey.equalsIgnoreCase("wallroofheat")) {

                addSubPremises = writeAddSubPremsieWallRoofMaterials(subPremises.get(strXmlParameterKey), xmlSelectionHB_BB_OPR(strTrade));
                flag = true;
                break;
            }

        }

        if (flag) {

            addSubPremises = addSubPremises.replace("${#Project#select-contact-id}", contactID);
            addSubPremises = addSubPremises.replace("${#TestSuite#policy-id}", policyIdentity);
            addSubPremises = addSubPremises.replace("${#TestSuite#position-id}", PositionIdentity);
            addSubPremises = addSubPremises.replace("${#TestSuite#variation-id}", variationIdentity);
            addSubPremises = addSubPremises.replace("${#TestSuite#risk_Add-comp-id}", riskAddCompId);
            for (String strXmlParameterKey : keys) {
                addSubPremises = addSubPremises.replace(strXmlParameterKey, String.valueOf(subPremises.get(strXmlParameterKey)).replace("$null$", ""));
            }

        } else {
            switch (strTrade) {
                case ("H&B"):

                    f = new File("src/test/resources/requests/pre-req/addSubPremise.xml");
                    break;
                case ("B&B"):

                    f = new File("src/test/resources/BB_XML/SP_AddSubPremise.xml");
                    break;

                case ("OPR"):

                    f = new File("src/test/resources/requests/pre-req/OPRSubPremise.xml");
                    break;

            }
            List<String> key = new ArrayList<>(subPremises.keySet());

            //File f = new File("src/test/resources/requests/pre-req/addSubPremise.xml");
            addSubPremises = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
            addSubPremises = addSubPremises.replace("${#TestSuite#policy-id}", policyIdentity);
            addSubPremises = addSubPremises.replace("${#TestSuite#position-id}", PositionIdentity);
            addSubPremises = addSubPremises.replace("${#TestSuite#variation-id}", variationIdentity);
            addSubPremises = addSubPremises.replace("${#TestSuite#risk_Add-comp-id}", riskAddCompId);

            for (String strXmlParameterKey : key) {

                addSubPremises = addSubPremises.replace(strXmlParameterKey, String.valueOf(subPremises.get(strXmlParameterKey)).replace("$null$", ""));

            }
//System.out.println("request =================== " + addSubPremises);
        }
            return serviceUtil.getResponse(addSubPremises, System.getProperty("ENV") + "/ListComponentSaveSME_INSSMEv1", "ListComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }


    public String addBusinessContentsPremises(String strTrade, String policyIdentity, String PositionIdentity, String variationIdentity, String premiseCompId) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addBusinessContentsAtPremises.xml");
        String addBusinessContPremises = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addBusinessContPremises = addBusinessContPremises.replace("${#TestSuite#policy-id}", policyIdentity);
        addBusinessContPremises = addBusinessContPremises.replace("${#TestSuite#position-id}", PositionIdentity);
        addBusinessContPremises = addBusinessContPremises.replace("${#TestSuite#variation-id}", variationIdentity);
        addBusinessContPremises = addBusinessContPremises.replace("${#TestSuite#Premise-comp-id}", premiseCompId);
//System.out.println("request =================== " + addBusinessContPremises);

        return serviceUtil.getResponse(addBusinessContPremises, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }

    public String addBusinessContentsPremisesItem(String strTrade, String policyIdentity, String PositionIdentity, String variationIdentity, String premiseBussContCompId, String bussContContentType, String bussContAmount) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addBusinessContentsAtPremisesItem.xml");
        String addBusinessContPremisesItem = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addBusinessContPremisesItem = addBusinessContPremisesItem.replace("${#TestSuite#policy-id}", policyIdentity);
        addBusinessContPremisesItem = addBusinessContPremisesItem.replace("${#TestSuite#position-id}", PositionIdentity);
        addBusinessContPremisesItem = addBusinessContPremisesItem.replace("${#TestSuite#variation-id}", variationIdentity);
        addBusinessContPremisesItem = addBusinessContPremisesItem.replace("${#TestSuite#Premise_BussCnt-comp-id}", premiseBussContCompId);
        addBusinessContPremisesItem = addBusinessContPremisesItem.replace("strContentsType", String.valueOf(bussContContentType).replace("$null$", ""));
        addBusinessContPremisesItem = addBusinessContPremisesItem.replace("strAmount", String.valueOf(bussContAmount).replace("$null$", ""));

        /*if(strTrade.equalsIgnoreCase("B&B")){
            addBusinessContPremisesItem = addBusinessContPremisesItem.replace("strContentType", "");
        }else{
            addBusinessContPremisesItem = addBusinessContPremisesItem.replace("strContentType", "1");
        }*/
//System.out.println("request =================== " + addBusinessContPremisesItem);
        return serviceUtil.getResponse(addBusinessContPremisesItem, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }

    public String addPremisesSingularCovers(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseCompId) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/premisesSingularCovers.xml");
        String addPremiseSingualrCovers = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addPremiseSingualrCovers = addPremiseSingualrCovers.replace("${#TestSuite#policy-id}", policyIdentity);
        addPremiseSingualrCovers = addPremiseSingualrCovers.replace("${#TestSuite#position-id}", PositionIdentity);
        addPremiseSingualrCovers = addPremiseSingualrCovers.replace("${#TestSuite#variation-id}", variationIdentity);
        addPremiseSingualrCovers = addPremiseSingualrCovers.replace("${#TestSuite#Premise-comp-id}", premiseCompId);
        //  addPremiseSingualrCovers = addPremiseSingualrCovers.replace("strHouseHoldCheckBox", houseHoldCheckBox);
//System.out.println("request =================== " + addPremiseSingualrCovers);

        return serviceUtil.getResponse(addPremiseSingualrCovers, System.getProperty("ENV") + "/GroupComponentSaveSME_INSSMEv1", "GroupComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }

    public String addHouseHoldContents(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseGroupCompId, String amount) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/houseHoldContents.xml");
        String addHouseHoldContents = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addHouseHoldContents = addHouseHoldContents.replace("${#TestSuite#policy-id}", policyIdentity);
        addHouseHoldContents = addHouseHoldContents.replace("${#TestSuite#position-id}", PositionIdentity);
        addHouseHoldContents = addHouseHoldContents.replace("${#TestSuite#variation-id}", variationIdentity);
        addHouseHoldContents = addHouseHoldContents.replace("${#TestSuite#Premise_Group-comp-id}", premiseGroupCompId);
        addHouseHoldContents = addHouseHoldContents.replace("strHouseHoldAmount", amount);
//System.out.println("request =================== " + addHouseHoldContents);

        return serviceUtil.getResponse(addHouseHoldContents, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }

    public String addBuildings(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseGroupCompId, String amount) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addBuilding.xml");
        String addBuildings = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addBuildings = addBuildings.replace("${#TestSuite#policy-id}", policyIdentity);
        addBuildings = addBuildings.replace("${#TestSuite#position-id}", PositionIdentity);
        addBuildings = addBuildings.replace("${#TestSuite#variation-id}", variationIdentity);
        addBuildings = addBuildings.replace("${#TestSuite#Premise_Group-comp-id}", premiseGroupCompId);
        addBuildings = addBuildings.replace("strBuildingAmount", amount);
        //System.out.println("request =================== " + addBuildings);

        return serviceUtil.getResponse(addBuildings, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }


    public String addFrontGlass(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseGroupCompId, String glassAmount) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addBuildingFrontGlass.xml");
        String addFrontGlass = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addFrontGlass = addFrontGlass.replace("${#TestSuite#policy-id}", policyIdentity);
        addFrontGlass = addFrontGlass.replace("${#TestSuite#position-id}", PositionIdentity);
        addFrontGlass = addFrontGlass.replace("${#TestSuite#variation-id}", variationIdentity);
        addFrontGlass = addFrontGlass.replace("${#TestSuite#Premise_Group-comp-id}", premiseGroupCompId);
        addFrontGlass = addFrontGlass.replace("strFrontGlassAmt", glassAmount);
        //System.out.println("request =================== " + addFrontGlass);

        return serviceUtil.getResponse(addFrontGlass, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }

    public String addFixtureFittings(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseGroupCompId, String fixFitAmount) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addFixtureFittings.xml");
        String addFixtureFittings = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addFixtureFittings = addFixtureFittings.replace("${#TestSuite#policy-id}", policyIdentity);
        addFixtureFittings = addFixtureFittings.replace("${#TestSuite#position-id}", PositionIdentity);
        addFixtureFittings = addFixtureFittings.replace("${#TestSuite#variation-id}", variationIdentity);
        addFixtureFittings = addFixtureFittings.replace("${#TestSuite#Premise_Group-comp-id}", premiseGroupCompId);
        addFixtureFittings = addFixtureFittings.replace("strFixFitAmt", fixFitAmount);
        //System.out.println("request =================== " + addFixtureFittings);

        return serviceUtil.getResponse(addFixtureFittings, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }


    public String addStockPremises(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseCompId) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/premisesStock.xml");
        String addStockPremises = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addStockPremises = addStockPremises.replace("${#TestSuite#policy-id}", policyIdentity);
        addStockPremises = addStockPremises.replace("${#TestSuite#position-id}", PositionIdentity);
        addStockPremises = addStockPremises.replace("${#TestSuite#variation-id}", variationIdentity);
        addStockPremises = addStockPremises.replace("${#TestSuite#Premise-comp-id}", premiseCompId);
        //System.out.println("request =================== " + addStockPremises);

        return serviceUtil.getResponse(addStockPremises, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }

    public String addStockPremisesItem(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseStockCompId, String strStockType, String strStockAmount) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/premisesStockItem.xml");
        String addStockPremisesItem = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addStockPremisesItem = addStockPremisesItem.replace("${#TestSuite#policy-id}", policyIdentity);
        addStockPremisesItem = addStockPremisesItem.replace("${#TestSuite#position-id}", PositionIdentity);
        addStockPremisesItem = addStockPremisesItem.replace("${#TestSuite#variation-id}", variationIdentity);
        addStockPremisesItem = addStockPremisesItem.replace("${#TestSuite#Premise_Stock-comp-id}", premiseStockCompId);
        addStockPremisesItem = addStockPremisesItem.replace("strStockAmount", String.valueOf(strStockAmount).replace("$null$", ""));
        addStockPremisesItem = addStockPremisesItem.replace("strStockType", String.valueOf(strStockType).replace("$null$", ""));
       /* if(strTrade.equalsIgnoreCase("B&B")){
            addStockPremisesItem = addStockPremisesItem.replace("strStockType", "");
        }else{
            addStockPremisesItem = addStockPremisesItem.replace("strStockType", "1");
        }*/
        //System.out.println("request =================== " + addStockPremisesItem);
        return serviceUtil.getResponse(addStockPremisesItem, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }

    public String addNamedItemsPremises(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseCompId) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addNamedItemsAtPremises.xml");
        String addNamedItemsPremises = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addNamedItemsPremises = addNamedItemsPremises.replace("${#TestSuite#policy-id}", policyIdentity);
        addNamedItemsPremises = addNamedItemsPremises.replace("${#TestSuite#position-id}", PositionIdentity);
        addNamedItemsPremises = addNamedItemsPremises.replace("${#TestSuite#variation-id}", variationIdentity);
        addNamedItemsPremises = addNamedItemsPremises.replace("${#TestSuite#Premise-comp-id}", premiseCompId);
        //System.out.println("request =================== " + addNamedItemsPremises);
        return serviceUtil.getResponse(addNamedItemsPremises, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }

    public String addNamedItemsPremisesItem(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseNamedItemsCompId, String itemType, String amount, String excess) throws Exception {

        if (itemType.equalsIgnoreCase("$null$")) {
            requestXml = removeNodeElement("src/test/resources/requests/pre-req/addNamedItemsAtPremisesItem.xml", "urn1:component", "urn2:itemType");
        } else {
            File f = new File("src/test/resources/requests/pre-req/addNamedItemsAtPremisesItem.xml");
            requestXml = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("strItemType", String.valueOf(itemType).replace("$null$", ""));
        }
        requestXml = requestXml.replace("${#Project#select-contact-id}", contactID);
        requestXml = requestXml.replace("${#TestSuite#policy-id}", policyIdentity);
        requestXml = requestXml.replace("${#TestSuite#position-id}", PositionIdentity);
        requestXml = requestXml.replace("${#TestSuite#variation-id}", variationIdentity);
        requestXml = requestXml.replace("${#TestSuite#Premise_NamedItems-comp-id}", premiseNamedItemsCompId);
        requestXml = requestXml.replace("strExcess", String.valueOf(excess).replace("$null$", ""));
        requestXml = requestXml.replace("strAmount", String.valueOf(amount).replace("$null$", ""));

        //System.out.println("request =================== " + requestXml);
        return serviceUtil.getResponse(requestXml, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }


    public String addPropertyAway(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity) throws IOException, ParseException {


        File f = new File("src/test/resources/requests/pre-req/addPropertyAway.xml");
        String addPropertyAway = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addPropertyAway = addPropertyAway.replace("${#TestSuite#policy-id}", policyIdentity);
        addPropertyAway = addPropertyAway.replace("${#TestSuite#position-id}", PositionIdentity);
        addPropertyAway = addPropertyAway.replace("${#TestSuite#variation-id}", variationIdentity);
        addPropertyAway = addPropertyAway.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);

        //System.out.println("request =================== " + addPropertyAway);

        return serviceUtil.getResponse(addPropertyAway, System.getProperty("ENV") + "/GroupComponentSaveSME_INSSMEv1", "GroupComponentSaveSME_INSSMEv1Service/saveNewComponent");


    }

    public String addBusinessContAwaySectionLevel(String policyIdentity, String PositionIdentity, String variationIdentity, String propertyAwayCompId) throws IOException, ParseException {


        File f = new File("src/test/resources/requests/pre-req/addBusinessContentAwaySectionLevel.xml");
        String addBusiContAwaySecLevel = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addBusiContAwaySecLevel = addBusiContAwaySecLevel.replace("${#TestSuite#policy-id}", policyIdentity);
        addBusiContAwaySecLevel = addBusiContAwaySecLevel.replace("${#TestSuite#position-id}", PositionIdentity);
        addBusiContAwaySecLevel = addBusiContAwaySecLevel.replace("${#TestSuite#variation-id}", variationIdentity);
        addBusiContAwaySecLevel = addBusiContAwaySecLevel.replace("${#TestSuite#Prop_Away-comp-id}", propertyAwayCompId);

        //System.out.println("request =================== " + addBusiContAwaySecLevel);

        return serviceUtil.getResponse(addBusiContAwaySecLevel, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");


    }

    public String addBusinessContAway(String policyIdentity, String PositionIdentity, String variationIdentity, String busiContPropertyAwayCompId, String businessAwayContType) throws IOException, ParseException {

        String[] businessAwayValues = businessAwayContType.split(",");
        File f = new File("src/test/resources/requests/pre-req/addBusinessContentAway.xml");
        String addBusiContAway = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addBusiContAway = addBusiContAway.replace("${#TestSuite#policy-id}", policyIdentity);
        addBusiContAway = addBusiContAway.replace("${#TestSuite#position-id}", PositionIdentity);
        addBusiContAway = addBusiContAway.replace("${#TestSuite#variation-id}", variationIdentity);
        addBusiContAway = addBusiContAway.replace("${#TestSuite#BussCnt_PAP-comp-id}", busiContPropertyAwayCompId);
        addBusiContAway = addBusiContAway.replace("strContentType", businessAwayValues[0]);
        addBusiContAway = addBusiContAway.replace("strAmount", businessAwayValues[1]);
        addBusiContAway = addBusiContAway.replace("strExcess", businessAwayValues[2]);


        //System.out.println("request =================== " + addBusiContAway);

        return serviceUtil.getResponse(addBusiContAway, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");


    }

    public String addStockAwaySectionLevel(String policyIdentity, String PositionIdentity, String variationIdentity, String propertyAwayCompId) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addStockAwaySectionLevel.xml");
        String addStockAwaySecLevel = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addStockAwaySecLevel = addStockAwaySecLevel.replace("${#TestSuite#policy-id}", policyIdentity);
        addStockAwaySecLevel = addStockAwaySecLevel.replace("${#TestSuite#position-id}", PositionIdentity);
        addStockAwaySecLevel = addStockAwaySecLevel.replace("${#TestSuite#variation-id}", variationIdentity);
        addStockAwaySecLevel = addStockAwaySecLevel.replace("${#TestSuite#Prop_Away-comp-id}", propertyAwayCompId);

        //System.out.println("request =================== " + addStockAwaySecLevel);

        return serviceUtil.getResponse(addStockAwaySecLevel, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");


    }

    public String addStockAway(String policyIdentity, String PositionIdentity, String variationIdentity, String stockPropertyAwayCompId, String stockAwayType, String stockAwayAmount, String methodTransit) throws IOException, ParseException {


        File f = new File("src/test/resources/requests/pre-req/addStockAway.xml");
        String addStockAway = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addStockAway = addStockAway.replace("${#TestSuite#policy-id}", policyIdentity);
        addStockAway = addStockAway.replace("${#TestSuite#position-id}", PositionIdentity);
        addStockAway = addStockAway.replace("${#TestSuite#variation-id}", variationIdentity);
        addStockAway = addStockAway.replace("${#TestSuite#Stock_PAP-comp-id}", stockPropertyAwayCompId);
        addStockAway = addStockAway.replace("strStockType", stockAwayType);
        addStockAway = addStockAway.replace("strStockAmount", stockAwayAmount);
        addStockAway = addStockAway.replace("strMethod", methodTransit);

        //System.out.println("request =================== " + addStockAway);

        return serviceUtil.getResponse(addStockAway, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");


    }

    public String addNamedItemAwaySectionLevel(String policyIdentity, String PositionIdentity, String variationIdentity, String propertyAwayCompId) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addNamedItemsAwaySectionLevel.xml");
        String addNamedItemAwaySecLevel = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addNamedItemAwaySecLevel = addNamedItemAwaySecLevel.replace("${#TestSuite#policy-id}", policyIdentity);
        addNamedItemAwaySecLevel = addNamedItemAwaySecLevel.replace("${#TestSuite#position-id}", PositionIdentity);
        addNamedItemAwaySecLevel = addNamedItemAwaySecLevel.replace("${#TestSuite#variation-id}", variationIdentity);
        addNamedItemAwaySecLevel = addNamedItemAwaySecLevel.replace("${#TestSuite#Prop_Away-comp-id}", propertyAwayCompId);

        //System.out.println("request =================== " + addNamedItemAwaySecLevel);

        return serviceUtil.getResponse(addNamedItemAwaySecLevel, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");


    }

    public String addNamedItemAway(String policyIdentity, String PositionIdentity, String variationIdentity, String namedItemPropertyAwayCompId,String namedItemsValues) throws IOException, ParseException {
        String[] namedItems = namedItemsValues.split("#");
        File f = new File("src/test/resources/requests/pre-req/addNamedItemsAway.xml");
        String addNamedItemAway = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addNamedItemAway = addNamedItemAway.replace("${#TestSuite#policy-id}", policyIdentity);
        addNamedItemAway = addNamedItemAway.replace("${#TestSuite#position-id}", PositionIdentity);
        addNamedItemAway = addNamedItemAway.replace("${#TestSuite#variation-id}", variationIdentity);
            for (int ni = 0; ni < namedItems.length; ni++) {
                String[] namedItemsVal = namedItems[ni].split(",");
                addNamedItemAway = addNamedItemAway.replace("${#TestSuite#NamedItems_PAP-comp-id}", namedItemPropertyAwayCompId);
                addNamedItemAway = addNamedItemAway.replace("strItemGrp", String.valueOf(namedItemsVal[0]).replace("$null$", ""));
                addNamedItemAway = addNamedItemAway.replace("strItemType", String.valueOf(namedItemsVal[1]).replace("$null$", ""));
                addNamedItemAway = addNamedItemAway.replace("strItemAmount", String.valueOf(namedItemsVal[2]).replace("$null$", ""));
                addNamedItemAway = addNamedItemAway.replace("strExcess", String.valueOf(namedItemsVal[3]).replace("$null$", ""));
                addNamedItemAway = addNamedItemAway.replace("strFreeFormat", String.valueOf(namedItemsVal[4]).replace("$null$", ""));
            }
        //System.out.println("request =================== " + addNamedItemAway);
        return serviceUtil.getResponse(addNamedItemAway, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");


    }


    public String addPersonalEffects(String policyIdentity, String PositionIdentity, String variationIdentity, String propertyAwayCompId, String personalEffVal) throws IOException, ParseException {
        String[] personalEff = personalEffVal.split(",");
        File f = new File("src/test/resources/requests/pre-req/addPersonalEffects.xml");
        String addPersonalEffects = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addPersonalEffects = addPersonalEffects.replace("${#TestSuite#policy-id}", policyIdentity);
        addPersonalEffects = addPersonalEffects.replace("${#TestSuite#position-id}", PositionIdentity);
        addPersonalEffects = addPersonalEffects.replace("${#TestSuite#variation-id}", variationIdentity);
        addPersonalEffects = addPersonalEffects.replace("${#TestSuite#Prop_Away-comp-id}", propertyAwayCompId);
        addPersonalEffects = addPersonalEffects.replace("strAmount", String.valueOf(personalEff[0]).replace("$null$", ""));
        addPersonalEffects = addPersonalEffects.replace("strExcess", String.valueOf(personalEff[1]).replace("$null$", ""));
        //System.out.println("request =================== " + addPersonalEffects);
        return serviceUtil.getResponse(addPersonalEffects, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");


    }

    public String addEngineering(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addEngineering.xml");
        String addEngineering = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addEngineering = addEngineering.replace("${#TestSuite#policy-id}", policyIdentity);
        addEngineering = addEngineering.replace("${#TestSuite#position-id}", PositionIdentity);
        addEngineering = addEngineering.replace("${#TestSuite#variation-id}", variationIdentity);
        addEngineering = addEngineering.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
        //System.out.println("request =================== " + addEngineering);
        return serviceUtil.getResponse(addEngineering, System.getProperty("ENV") + "/GroupComponentSaveSME_INSSMEv1", "GroupComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String additionalDetails(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addAdditionalDetails.xml");
        String additionalDetails = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        additionalDetails = additionalDetails.replace("${#TestSuite#policy-id}", policyIdentity);
        additionalDetails = additionalDetails.replace("${#TestSuite#position-id}", PositionIdentity);
        additionalDetails = additionalDetails.replace("${#TestSuite#variation-id}", variationIdentity);
        additionalDetails = additionalDetails.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
        //System.out.println("request =================== " + additionalDetails);
        return serviceUtil.getResponse(additionalDetails, System.getProperty("ENV") + "/GroupComponentSaveSME_INSSMEv1", "GroupComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String writeListOfLossHistItems(String[] historyItems) throws Exception {
        int f=0;
        Element lossDate = null;
        DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = domFactory.newDocumentBuilder();
        Document doc = builder.parse(new File("src/test/resources/requests/pre-req/addLossHistory.xml"));
        for (int ad = 0; ad < historyItems.length; ad++) {

            String[] additionalCoverVal = historyItems[ad].split(",");
            //Telling that need to write these items between which node, node name is <urn1:component> in xml
            Element dataTag = doc.getDocumentElement();
            Element componentTag = (Element) dataTag.getElementsByTagName("urn1:component").item(0);
            //Creating the <urn1:listElement> node and their attributes, values
            Element listElement = doc.createElement("urn1:listElement");
            Attr attrType = doc.createAttribute("xsi:type");
            attrType.setValue("urn2:ComponentLoss_HistoryItem");
            listElement.setAttributeNode(attrType);

            //Creating the <urn2:lossAmount> node
            Element lossAmount = doc.createElement("urn2:lossAmount");
            //Creating the <urn1:amount> node within lossAmount node
            Element amount = doc.createElement("urn1:amount");
            amount.setTextContent(String.valueOf(additionalCoverVal[0]).replace("$null$", ""));
            Element currency = doc.createElement("urn1:currency");
            currency.setTextContent("GBP");
            //Appdening these amount and currency nodes as a childnode to lossAmount Node
            lossAmount.appendChild(currency);
            lossAmount.appendChild(amount);
            //Creating the <urn2:lossCause> node within listElement node
            Element lossCause = doc.createElement("urn2:lossCause");
            lossCause.setTextContent(String.valueOf(additionalCoverVal[1]).replace("$null$", ""));
            //Creating the <urn2:lossDate> node within listElement node
            if (!additionalCoverVal[2].equalsIgnoreCase("$null$")) {
                lossDate = doc.createElement("urn2:lossDate");
                additionalCoverVal[2] = additionalCoverVal[2].replace(":", "-");
                lossDate.setTextContent(String.valueOf(additionalCoverVal[2]).replace("$null$", ""));
                f=1;
            }
            //Creating the <urn2:statusOfClaim> node within listElement node
            Element statusOfClaim = doc.createElement("urn2:statusOfClaim");
            statusOfClaim.setTextContent(String.valueOf(additionalCoverVal[3]).replace("$null$", ""));
            //Creating the <urn2:contactAddress> node and set their attributes,values
            Element contactAddress = doc.createElement("urn1:contactAddress");
            Attr attrType1 = doc.createAttribute("xsi:nil");
            attrType1.setValue("true");
            contactAddress.setAttributeNode(attrType1);
            //Appdening these lossAmount,lossCause,lossDate,statusOfClaim and contactAddress nodes as a childnode to listElement Node
            listElement.appendChild(lossAmount);
            listElement.appendChild(lossCause);
            if(f==1) {
                listElement.appendChild(lossDate);
            }
            listElement.appendChild(statusOfClaim);
            listElement.appendChild(contactAddress);
            //Appdening all the list items of nodes within componentTag "<urn1:component>"
            componentTag.appendChild(listElement);
        }

        //Writing the above items
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");

        StreamResult result = new StreamResult(new StringWriter());
        DOMSource source = new DOMSource(doc);
        transformer.transform(source, result);

        lossHistory = result.getWriter().toString();
        //System.out.println(lossHistory);

        return lossHistory;

    }

    public String lossHistory(String policyIdentity, String PositionIdentity, String variationIdentity, String additionalDetailsCompId, String[] historyItems) throws Exception {

        //Calling the method for appending the list of loss history items into exisiting xml
        lossHistory = writeListOfLossHistItems(historyItems);
        lossHistory = lossHistory.replace("${#Project#select-contact-id}", contactID);
        lossHistory = lossHistory.replace("${#TestSuite#policy-id}", policyIdentity);
        lossHistory = lossHistory.replace("${#TestSuite#position-id}", PositionIdentity);
        lossHistory = lossHistory.replace("${#TestSuite#variation-id}", variationIdentity);
        lossHistory = lossHistory.replace("${#TestSuite#Additional_details-comp-id}", additionalDetailsCompId);
        //System.out.println("request =================== " + lossHistory);
        return serviceUtil.getResponse(lossHistory, System.getProperty("ENV") + "/ListComponentSaveSME_INSSMEv1", "ListComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }


    public String writeListOfSubsidariesItems(String[] subsidiariesItems) throws Exception {

        DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = domFactory.newDocumentBuilder();
        Document doc = builder.parse(new File("src/test/resources/requests/pre-req/addSubsidiaries.xml"));
        for (int ad = 0; ad < subsidiariesItems.length; ad++) {

            String[] subsidiariesItemsVal = subsidiariesItems[ad].split(",");
            //Telling that need to write these items between which node, node name is <urn1:component> in xml
            Element dataTag = doc.getDocumentElement();
            Element componentTag = (Element) dataTag.getElementsByTagName("urn1:component").item(0);
            //Creating the <urn1:listElement> node and their attributes, values
            Element listElement = doc.createElement("urn1:listElement");
            Attr attrType = doc.createAttribute("xsi:type");
            attrType.setValue("urn2:ComponentSubsidiariesItem");
            listElement.setAttributeNode(attrType);

            Element name = doc.createElement("urn2:name");
            name.setTextContent(String.valueOf(subsidiariesItemsVal[0]).replace("$null$", ""));


            Element registeredOffice = doc.createElement("urn2:registeredOfficeAddress");

            String[] nodes= {"singleLineAddress","line1","line2","city","postCode","state","country","format"};

            for(int s =0; s < nodes.length; s++){

                Element urnNode = doc.createElement("urn1:"+nodes[s]);
                urnNode.setTextContent(String.valueOf(subsidiariesItemsVal[s+1]).replace("$null$", ""));
                registeredOffice.appendChild(urnNode);
            }
            listElement.appendChild(registeredOffice);

            Element ernExempt = doc.createElement("urn2:ernExempt");
            ernExempt.setTextContent(String.valueOf(subsidiariesItemsVal[9]).replace("$null$", ""));


            Element ern = doc.createElement("urn2:ern");
            ern.setTextContent(String.valueOf(subsidiariesItemsVal[10]).replace("$null$", ""));


            Element includeInInsurance = doc.createElement("urn2:includeInInsurance");
            includeInInsurance.setTextContent(String.valueOf(subsidiariesItemsVal[11]).replace("$null$", ""));

            listElement.appendChild(name);
            listElement.appendChild(ernExempt);
            listElement.appendChild(ern);
            listElement.appendChild(includeInInsurance);
            componentTag.appendChild(listElement);

        }

        //Writing the above items
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");

        StreamResult result = new StreamResult(new StringWriter());
        DOMSource source = new DOMSource(doc);
        transformer.transform(source, result);

        subsidaries = result.getWriter().toString();
        //System.out.println(subsidaries);

        return subsidaries;

    }


    public String subsidaries(String policyIdentity, String PositionIdentity, String variationIdentity, String additionalDetailsCompId, String[] subsidiariesItems) throws Exception {

        //Calling the method for appending the list of subsidiaries Items  into exisiting xml
        subsidaries = writeListOfSubsidariesItems(subsidiariesItems);
        subsidaries = subsidaries.replace("${#Project#select-contact-id}", contactID);
        subsidaries = subsidaries.replace("${#TestSuite#policy-id}", policyIdentity);
        subsidaries = subsidaries.replace("${#TestSuite#position-id}", PositionIdentity);
        subsidaries = subsidaries.replace("${#TestSuite#variation-id}", variationIdentity);
        subsidaries = subsidaries.replace("${#TestSuite#Additional_details-comp-id}", additionalDetailsCompId);
        //System.out.println("request =================== " + subsidaries);
        return serviceUtil.getResponse(subsidaries, System.getProperty("ENV") + "/ListComponentSaveSME_INSSMEv1", "ListComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String addTreatment(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addTreatments.xml");
        String addTreatment = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addTreatment = addTreatment.replace("${#TestSuite#policy-id}", policyIdentity);
        addTreatment = addTreatment.replace("${#TestSuite#position-id}", PositionIdentity);
        addTreatment = addTreatment.replace("${#TestSuite#variation-id}", variationIdentity);
        addTreatment = addTreatment.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
        //System.out.println("request =================== " + addTreatment);
        return serviceUtil.getResponse(addTreatment, System.getProperty("ENV") + "/GroupComponentSaveSME_INSSMEv1", "GroupComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public static String removeNodeElement(String xmlPath, String parentTagName, String nodeElements) throws Exception {

        String nodeEle[] = nodeElements.split("#");
        DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = domFactory.newDocumentBuilder();
        Document doc = builder.parse(new File(xmlPath));

        // Get the component element by tag name directly
        Node component = doc.getElementsByTagName(parentTagName).item(0);
        NodeList list = component.getChildNodes();

        for (int i = 0; i < nodeEle.length; i++) {

            for (int j = 0; j < list.getLength(); j++) {

                Node node = list.item(j);

                //remove NoOfOperatAdditional

                if (nodeEle[i].equals(node.getNodeName())) {
                    component.removeChild(node);
                }

            }
        }

        //Writing the above items
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");

        StreamResult result = new StreamResult(new StringWriter());
        DOMSource source = new DOMSource(doc);
        transformer.transform(source, result);

        requestXml = result.getWriter().toString();
        //System.out.println(requestXml);

        return requestXml;


    }

    public String standardTreatment(String policyIdentity, String PositionIdentity, String variationIdentity, String pulTreatmentCompId, String standardTreatmentVal) throws Exception {
        String[] standTreatmentValues = standardTreatmentVal.split(",");
        File f = new File("src/test/resources/requests/pre-req/addStandardTreatment.xml");
        if (standTreatmentValues[1].equalsIgnoreCase("$null$")) {
            requestXml = removeNodeElement("src/test/resources/requests/pre-req/addStandardTreatment.xml", "urn1:component", "urn2:noOfOperativesAdditional");
        } else {
            requestXml = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("strNoOfOperatAddition", String.valueOf(standTreatmentValues[1]).replace("$null$", ""));
        }

        requestXml = requestXml.replace("${#Project#select-contact-id}", contactID);
        requestXml = requestXml.replace("${#TestSuite#policy-id}", policyIdentity);
        requestXml = requestXml.replace("${#TestSuite#position-id}", PositionIdentity);
        requestXml = requestXml.replace("${#TestSuite#variation-id}", variationIdentity);
        requestXml = requestXml.replace("${#TestSuite#Pul_Treatment-comp-id}", pulTreatmentCompId);
        requestXml = requestXml.replace("strMeetMinProExp", String.valueOf(standTreatmentValues[0]).replace("$null$", ""));
        //System.out.println("request =================== " + requestXml);
        return serviceUtil.getResponse(requestXml, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String additionalTreatment(String policyIdentity, String PositionIdentity, String variationIdentity, String pulTreatmentCompId, String treatmentName, String noOfOperativesAdditional, String limtCover) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addAdditionalTreatment.xml");
        String additionalTreatment = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        additionalTreatment = additionalTreatment.replace("${#TestSuite#policy-id}", policyIdentity);
        additionalTreatment = additionalTreatment.replace("${#TestSuite#position-id}", PositionIdentity);
        additionalTreatment = additionalTreatment.replace("${#TestSuite#variation-id}", variationIdentity);
        additionalTreatment = additionalTreatment.replace("${#TestSuite#Pul_Treatment-comp-id}", pulTreatmentCompId);
        additionalTreatment = additionalTreatment.replace("strTreatmentName", String.valueOf(treatmentName).replace("$null$", ""));
        additionalTreatment = additionalTreatment.replace("strNoOfOperatAddition", String.valueOf(noOfOperativesAdditional).replace("$null$", ""));
        additionalTreatment = additionalTreatment.replace("strLimitCover", String.valueOf(limtCover).replace("$null$", ""));
        //System.out.println("request =================== " + additionalTreatment);
        return serviceUtil.getResponse(additionalTreatment, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }


    public String pladdLossOfBusinessMoney(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addLossOfBusinessMoney.xml");
        String addLossOfBusinessMoney = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addLossOfBusinessMoney = addLossOfBusinessMoney.replace("${#TestSuite#policy-id}", policyIdentity);
        addLossOfBusinessMoney = addLossOfBusinessMoney.replace("${#TestSuite#position-id}", PositionIdentity);
        addLossOfBusinessMoney = addLossOfBusinessMoney.replace("${#TestSuite#variation-id}", variationIdentity);
        addLossOfBusinessMoney = addLossOfBusinessMoney.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
        //System.out.println("request =================== " + addLossOfBusinessMoney);
        return serviceUtil.getResponse(addLossOfBusinessMoney, System.getProperty("ENV") + "/GroupComponentSaveSME_INSSMEv1", "GroupComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String pladdLossOfBusinessMoneyStandard(String policyIdentity, String PositionIdentity, String variationIdentity, String businessMoneyCompId, String Coverage) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addLossOfBusinessMoneyStandard.xml");
        String addLossOfBusinessMoneyStandard = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addLossOfBusinessMoneyStandard = addLossOfBusinessMoneyStandard.replace("${#TestSuite#policy-id}", policyIdentity);
        addLossOfBusinessMoneyStandard = addLossOfBusinessMoneyStandard.replace("${#TestSuite#position-id}", PositionIdentity);
        addLossOfBusinessMoneyStandard = addLossOfBusinessMoneyStandard.replace("${#TestSuite#variation-id}", variationIdentity);
        addLossOfBusinessMoneyStandard = addLossOfBusinessMoneyStandard.replace("${#TestSuite#Business_Money-comp-id}", businessMoneyCompId);
        String[] ToT = Coverage.split(",");
        addLossOfBusinessMoneyStandard = addLossOfBusinessMoneyStandard.replace("strinBankNightSafe", String.valueOf(ToT[0]).replace("$null$", ""));
        addLossOfBusinessMoneyStandard = addLossOfBusinessMoneyStandard.replace("strinTransit", String.valueOf(ToT[1]).replace("$null$", ""));
        addLossOfBusinessMoneyStandard = addLossOfBusinessMoneyStandard.replace("strinThePremisesWhilstAttended", String.valueOf(ToT[2]).replace("$null$", ""));
        addLossOfBusinessMoneyStandard = addLossOfBusinessMoneyStandard.replace("strinThePremisesWhilstUnattendedAndInSafe", String.valueOf(ToT[3]).replace("$null$", ""));
        //System.out.println("request =================== " + addLossOfBusinessMoneyStandard);
        return serviceUtil.getResponse(addLossOfBusinessMoneyStandard, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String interestedPartiesContact1() throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addInterestedPartyContact1.xml");
        String interestedPartiesContact1 = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        interestedPartiesContact1 = interestedPartiesContact1.replace("${#TestSuite#contact-counter}", companyName);
        //System.out.println("request =================== " + interestedPartiesContact1);
        return serviceUtil.getResponse(interestedPartiesContact1, System.getProperty("ENV") + "/ManageCompanyWS", "ManageCompanyWSService/createCompany");
    }

    public String writeListOfInterestedPartiesItems(String interestedItems, String interestPartyContactID,String personIdentity) throws Exception {
        int f = 0;
        Element lossDate = null;
        DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = domFactory.newDocumentBuilder();
        Document doc = builder.parse(new File("src/test/resources/requests/pre-req/addInterestedParties.xml"));
        String IPItems[] = interestedItems.split("&");
        String[] contactIds = {interestPartyContactID,personIdentity};
        for (int ad = 0; ad < IPItems.length; ad++) {

            String[] interestedPartyItems = IPItems[ad].split(",");
            //Telling that need to write these items between which node, node name is <urn1:component> in xml
            Element dataTag = doc.getDocumentElement();
            Element componentTag = (Element) dataTag.getElementsByTagName("urn1:component").item(0);
            //Creating the <urn1:listElement> node and their attributes, values
            Element listElement = doc.createElement("urn1:listElement");
            Attr attrType = doc.createAttribute("xsi:type");
            attrType.setValue("urn2:Component087Item");
            listElement.setAttributeNode(attrType);

            //Creating the <urn2:interestedParty> node
            Element interestedParty = doc.createElement("urn2:interestedParty");
            //Creating the <urn1:objectIdentity> node
            Element objIdentity = doc.createElement("urn1:objectIdentity");
            objIdentity.setTextContent(contactIds[ad]);
            //Creating the <urn1:roleType> node
            Element roleType = doc.createElement("urn1:roleType");
            roleType.setTextContent("interestedParty");
            //Creating the <urn1:contactTypeName> node
            Element contactType = doc.createElement("urn1:contactTypeName");
            contactType.setTextContent("Company");
            //Appending child nodes with parent nodes
            interestedParty.appendChild(objIdentity);
            interestedParty.appendChild(roleType);
            interestedParty.appendChild(contactType);
            //Creating the <urn2:typeOfInterest> node
            Element typeOfInterest = doc.createElement("urn2:typeOfInterest");
            typeOfInterest.setTextContent(interestedPartyItems[0]);
            //Creating the <urn2:comments> node
            Element comment = doc.createElement("urn2:comments");
            comment.setTextContent(interestedPartyItems[1]);
            //Appending child nodes with parent nodes
            listElement.appendChild(typeOfInterest);
            listElement.appendChild(comment);
            listElement.appendChild(interestedParty);
            //Appending child nodes with parent nodes
            componentTag.appendChild(listElement);
        }

        //Writing the above items
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");

        StreamResult result = new StreamResult(new StringWriter());
        DOMSource source = new DOMSource(doc);
        transformer.transform(source, result);

        interestedPartiesPolicy = result.getWriter().toString();
        //System.out.println(interestedPartiesPolicy);

        return interestedPartiesPolicy;

    }


    public String interestedPartiesPolicy(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity, String interestPartyContactID,String personIdentity, String interestedPartiesValues) throws Exception {
        interestedPartiesPolicy = writeListOfInterestedPartiesItems(interestedPartiesValues, interestPartyContactID,personIdentity);
        interestedPartiesPolicy = interestedPartiesPolicy.replace("${#Project#select-contact-id}", contactID);
        interestedPartiesPolicy = interestedPartiesPolicy.replace("${#TestSuite#policy-id}", policyIdentity);
        interestedPartiesPolicy = interestedPartiesPolicy.replace("${#TestSuite#position-id}", PositionIdentity);
        interestedPartiesPolicy = interestedPartiesPolicy.replace("${#TestSuite#variation-id}", variationIdentity);
        interestedPartiesPolicy = interestedPartiesPolicy.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
        //System.out.println("request =================== " + interestedPartiesPolicy);
        return serviceUtil.getResponse(interestedPartiesPolicy, System.getProperty("ENV") + "/ListComponentSaveSME_INSSMEv1", "ListComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String addBusinessInterruption(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addBusinessInterruption.xml");
        String addBusinessInterruption = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addBusinessInterruption = addBusinessInterruption.replace("${#TestSuite#policy-id}", policyIdentity);
        addBusinessInterruption = addBusinessInterruption.replace("${#TestSuite#position-id}", PositionIdentity);
        addBusinessInterruption = addBusinessInterruption.replace("${#TestSuite#variation-id}", variationIdentity);
        addBusinessInterruption = addBusinessInterruption.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
        //System.out.println("request =================== " + addBusinessInterruption);
        return serviceUtil.getResponse(addBusinessInterruption, System.getProperty("ENV") + "/GroupComponentSaveSME_INSSMEv1", "GroupComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String bIOwnPremise(String policyIdentity, String PositionIdentity, String variationIdentity, String publicLiabilityCompId, String indemnityPeriodNumberOfMonths) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addBusinessInterrupInOwnPremises.xml");
        String addBIOwnPremise = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addBIOwnPremise = addBIOwnPremise.replace("${#TestSuite#policy-id}", policyIdentity);
        addBIOwnPremise = addBIOwnPremise.replace("${#TestSuite#position-id}", PositionIdentity);
        addBIOwnPremise = addBIOwnPremise.replace("${#TestSuite#variation-id}", variationIdentity);
        addBIOwnPremise = addBIOwnPremise.replace("${#TestSuite#Business_Int-comp-id}", publicLiabilityCompId);
        addBIOwnPremise = addBIOwnPremise.replace("strNoOfmonths", String.valueOf(indemnityPeriodNumberOfMonths).replace("$null$", ""));
        //System.out.println("request =================== " + addBIOwnPremise);
        return serviceUtil.getResponse(addBIOwnPremise, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }


    public String saveDetailsCreatePersonContact(String companyId) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/saveDetailsCreatePersonContact.xml");
        String saveDetailsCreatePersonContact = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        number = randomNumber();
        counter = "" + number;
        saveDetailsCreatePersonContact = saveDetailsCreatePersonContact.replace("${#TestSuite#contact-counter}", counter);
        saveDetailsCreatePersonContact = saveDetailsCreatePersonContact.replace("${#TestSuite#company-id}", companyId);
        //System.out.println("request =================== " + saveDetailsCreatePersonContact);
        return serviceUtil.getResponse(saveDetailsCreatePersonContact, System.getProperty("ENV") + "/ManagePersonWS", "ManagePersonWSService/createPerson");
    }

    public String saveDetailsRetrievePerson(String personId) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/saveDetailsRetrievePerson.xml");
        String saveDetailsRetrievePerson = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        saveDetailsRetrievePerson = saveDetailsRetrievePerson.replace("${#TestSuite#person-id}", personId);
        //System.out.println("request =================== " + saveDetailsRetrievePerson);
        return serviceUtil.getResponse(saveDetailsRetrievePerson, System.getProperty("ENV") + "/RetrievePersonWS", "RetrievePersonWSService/retrievePerson");
    }


    public String saveDetailsUpdatePersonContact(String personId) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/saveDetailsUpdatePersonContact.xml");
        String saveDetailsUpdatePersonContact = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        saveDetailsUpdatePersonContact = saveDetailsUpdatePersonContact.replace("${#TestSuite#person-id}", personId);
        saveDetailsUpdatePersonContact = saveDetailsUpdatePersonContact.replace("${#TestSuite#contact-counter}", counter);
        //System.out.println("request =================== " + saveDetailsUpdatePersonContact);
        return serviceUtil.getResponse(saveDetailsUpdatePersonContact, System.getProperty("ENV") + "/ManagePersonWS", "ManagePersonWSService/updatePerson");
    }


    public String saveDetailsRegisterSelfService(String personUrn, String policyUrn) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/saveDetailsRegisterAndSelfService.xml");
        String saveDetailsRegisterSelfService = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        saveDetailsRegisterSelfService = saveDetailsRegisterSelfService.replace("${#TestSuite#person-urn}", personUrn);
        saveDetailsRegisterSelfService = saveDetailsRegisterSelfService.replace("${#TestSuite#policy-urn}", policyUrn);
        //System.out.println("request =================== " + saveDetailsRegisterSelfService);
        return serviceUtil.getResponse(saveDetailsRegisterSelfService, System.getProperty("ENV") + "/RegisterUserWS", "RegisterUserWSService/register");
    }

    public String saveDetailsUpdateCompanyContact(String companyId) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/saveDetailsUpdateCompanyContact.xml");
        String saveDetailsUpdateCompanyContact = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        saveDetailsUpdateCompanyContact = saveDetailsUpdateCompanyContact.replace("${#TestSuite#company-id}", companyId);
        saveDetailsUpdateCompanyContact = saveDetailsUpdateCompanyContact.replace("${#TestSuite#today}", currentDate());
        //System.out.println("request =================== " + saveDetailsUpdateCompanyContact);
        return serviceUtil.getResponse(saveDetailsUpdateCompanyContact, System.getProperty("ENV") + "/ManageCompanyWS", "ManageCompanyWSService/updateCompany");
    }


    public String importantStmtUpdateTheBusiness(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity, String agreeToStmt, String impRefurbis) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/importStmtUpdateTheBusiness.xml");
        String importantStmtUpdateTheBusiness = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        importantStmtUpdateTheBusiness = importantStmtUpdateTheBusiness.replace("${#TestSuite#policy-id}", policyIdentity);
        importantStmtUpdateTheBusiness = importantStmtUpdateTheBusiness.replace("${#TestSuite#position-id}", PositionIdentity);
        importantStmtUpdateTheBusiness = importantStmtUpdateTheBusiness.replace("${#TestSuite#variation-id}", variationIdentity);
        importantStmtUpdateTheBusiness = importantStmtUpdateTheBusiness.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
        importantStmtUpdateTheBusiness = importantStmtUpdateTheBusiness.replace("strAgreeStmt", agreeToStmt);
        importantStmtUpdateTheBusiness = importantStmtUpdateTheBusiness.replace("strImpRefurbishment", impRefurbis);
      /*  importantStmtUpdateTheBusiness = importantStmtUpdateTheBusiness.replace("strIsRefusedCancel", isRefusedCancel);
        importantStmtUpdateTheBusiness = importantStmtUpdateTheBusiness.replace("strIsConviction", isConviction);
        importantStmtUpdateTheBusiness = importantStmtUpdateTheBusiness.replace("strIsCcj", isCcj);
        importantStmtUpdateTheBusiness = importantStmtUpdateTheBusiness.replace("strIsIva", isIva);
        importantStmtUpdateTheBusiness = importantStmtUpdateTheBusiness.replace("strIsBankrupcy", isBankrupcy);
        importantStmtUpdateTheBusiness = importantStmtUpdateTheBusiness.replace("strIsManufacBeautyPrd", isManufBeautyPrd);
        importantStmtUpdateTheBusiness = importantStmtUpdateTheBusiness.replace("strIsBusiStatRegulations", isBussReg);
        importantStmtUpdateTheBusiness = importantStmtUpdateTheBusiness.replace("strIsContracts", isContracts);
        importantStmtUpdateTheBusiness = importantStmtUpdateTheBusiness.replace("strIsOccupHolidayHome", isOccuHoliday);
        importantStmtUpdateTheBusiness = importantStmtUpdateTheBusiness.replace("strIsOvernightOccup", isOvernightOccup);*/


        //System.out.println("request =================== " + importantStmtUpdateTheBusiness);
        return serviceUtil.getResponse(importantStmtUpdateTheBusiness, System.getProperty("ENV") + "/ListComponentUpdateSME_INSSMEv1", "ListComponentUpdateSME_INSSMEv1Service/updateExistingListComponentIgnoreWarnings");
    }


    public String addSSIClaimCoverage(String policyIdentity, String PositionIdentity, String variationIdentity, String dlgCompId) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addSSIClaimCoverage.xml");
        String addSSIClaimCoverage = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addSSIClaimCoverage = addSSIClaimCoverage.replace("${#TestSuite#policy-id}", policyIdentity);
        addSSIClaimCoverage = addSSIClaimCoverage.replace("${#TestSuite#position-id}", PositionIdentity);
        addSSIClaimCoverage = addSSIClaimCoverage.replace("${#TestSuite#variation-id}", variationIdentity);
        addSSIClaimCoverage = addSSIClaimCoverage.replace("${#TestSuite#DLG-comp-id}", dlgCompId);
        //System.out.println("request =================== " + addSSIClaimCoverage);
        return serviceUtil.getResponse(addSSIClaimCoverage, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String addNeedAnalyser(String policyIdentity, String PositionIdentity, String variationIdentity, String dlgCompId) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addNeedsAnalyser.xml");
        String addNeedAnalyser = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addNeedAnalyser = addNeedAnalyser.replace("${#TestSuite#policy-id}", policyIdentity);
        addNeedAnalyser = addNeedAnalyser.replace("${#TestSuite#position-id}", PositionIdentity);
        addNeedAnalyser = addNeedAnalyser.replace("${#TestSuite#variation-id}", variationIdentity);
        addNeedAnalyser = addNeedAnalyser.replace("${#TestSuite#DLG-comp-id}", dlgCompId);
        //System.out.println("request =================== " + addNeedAnalyser);
        return serviceUtil.getResponse(addNeedAnalyser, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String addVerify(String policyIdentity, String PositionIdentity, String variationIdentity, String dlgCompId) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/addVerifyWatchList.xml");
        String addVerify = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addVerify = addVerify.replace("${#TestSuite#policy-id}", policyIdentity);
        addVerify = addVerify.replace("${#TestSuite#position-id}", PositionIdentity);
        addVerify = addVerify.replace("${#TestSuite#variation-id}", variationIdentity);
        addVerify = addVerify.replace("${#TestSuite#DLG-comp-id}", dlgCompId);
        //System.out.println("request =================== " + addVerify);
        return serviceUtil.getResponse(addVerify, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }

    public String evaluateTreeValidation(String policyIdentity, String PositionIdentity, String variationIdentity, String productClass, String schemeCode, String prodTreeId) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/evaluateTreeValidation.xml");
        String evaluateTreeValidation = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        evaluateTreeValidation = evaluateTreeValidation.replace("${#TestSuite#policy-id}", policyIdentity);
        evaluateTreeValidation = evaluateTreeValidation.replace("${#TestSuite#position-id}", PositionIdentity);
        evaluateTreeValidation = evaluateTreeValidation.replace("${#TestSuite#variation-id}", variationIdentity);
        evaluateTreeValidation = evaluateTreeValidation.replace("${#TestSuite#product-class}", productClass);
        evaluateTreeValidation = evaluateTreeValidation.replace("${#TestSuite#scheme-code}", schemeCode);
        evaluateTreeValidation = evaluateTreeValidation.replace("${#TestSuite#product-tree-id}", prodTreeId);
        //System.out.println("request =================== " + evaluateTreeValidation);
        return serviceUtil.getResponse(evaluateTreeValidation, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/evaluateTreeValidation");
    }

    public String calculatePremium(String policyIdentity, String PositionIdentity, String variationIdentity, String productClass, String schemeCode, String prodTreeId) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/calculatePremium.xml");
        String calculatePremium = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        calculatePremium = calculatePremium.replace("${#TestSuite#policy-id}", policyIdentity);
        calculatePremium = calculatePremium.replace("${#TestSuite#position-id}", PositionIdentity);
        calculatePremium = calculatePremium.replace("${#TestSuite#variation-id}", variationIdentity);
        calculatePremium = calculatePremium.replace("${#TestSuite#product-class}", productClass);
        calculatePremium = calculatePremium.replace("${#TestSuite#scheme-code}", schemeCode);
        calculatePremium = calculatePremium.replace("${#TestSuite#product-tree-id}", prodTreeId);
        //System.out.println("request =================== " + calculatePremium);
        String calculatePremiumResponse = serviceUtil.getResponse(calculatePremium, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/calculatePolicyPremium");
        //System.out.println(calculatePremiumResponse);
//        policynumber = serviceUtil.getNodeValue(calculatePremiumResponse, "v1_1:internalPolicyReference");
        //System.out.println("policy =================== " + policynumber);
        return calculatePremiumResponse;
    }

    public String searchReferral(String policyIdentity, String PositionIdentity, String variationIdentity) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/Ref_SearchReferrals.xml");
        String searchReferral = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        searchReferral = searchReferral.replace("${#TestSuite#policy-id}", policyIdentity);
        searchReferral = searchReferral.replace("${#TestSuite#position-id}", PositionIdentity);
        searchReferral = searchReferral.replace("${#TestSuite#variation-id}", variationIdentity);
        searchReferral = searchReferral.replace("${#TestSuite#inception-date}", dateSelection);

        //System.out.println("request =================== " + searchReferral);
        return serviceUtil.getResponse(searchReferral, System.getProperty("ENV") + "/SearchReferralWS", "SearchReferralWSService/searchReferral");
    }

    public String PPSR(String policyIdentity, String PositionIdentity, String variationIdentity) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/PPSR.xml");
        String PPSR = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        PPSR = PPSR.replace("${#TestSuite#policy-id}", policyIdentity);
        PPSR = PPSR.replace("${#TestSuite#position-id}", PositionIdentity);
        PPSR = PPSR.replace("${#TestSuite#variation-id}", variationIdentity);

        //System.out.println("request =================== " + PPSR);
        return serviceUtil.getResponse(PPSR, System.getProperty("ENV") + "/PolicyPositionSummaryRetrieveSME_INSSMEv1", "PolicyPositionSummaryRetrieveSME_INSSMEv1Service/retrievePolicyPositionSummary");
    }


    public String authorizeReferral(String policyIdentity, String PositionIdentity, String variationIdentity) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/authorizeReferral.xml");
        String authorizeReferral = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        authorizeReferral = authorizeReferral.replace("${#TestSuite#policy-id}", policyIdentity);
        authorizeReferral = authorizeReferral.replace("${#TestSuite#position-id}", PositionIdentity);
        authorizeReferral = authorizeReferral.replace("${#TestSuite#variation-id}", variationIdentity);
        authorizeReferral = authorizeReferral.replace("${#TestSuite#inception-date}", dateSelection);
        //authorizeReferral = authorizeReferral.replace("${#TestSuite#underwriter-id}", underWriterId);


        //System.out.println("request =================== " + authorizeReferral);
        return serviceUtil.getResponse(authorizeReferral, System.getProperty("ENV") + "/ManageReferralWS", "ManageReferralWSService/createARNAndValidateReferrals");
    }

    public String paymnentcard(String companyID) throws IOException {


        File f = new File("src/test/resources/requests/pre-req/updatecompanycontact-AccountingAddress.xml");
        String paymnentCard = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        paymnentCard = paymnentCard.replace("${#TestSuite#company-id}", companyID);
        paymnentCard = paymnentCard.replace("${#TestSuite#contact-counter}", "1074");
        return serviceUtil.getResponse(paymnentCard, System.getProperty("ENV") + "/ManageCompanyWS", "ManageCompanyWSService/updateCompany");

    }

    public String cardDetails(String cardExpiryDate, String cardAccRefNumber, String companyID) throws IOException {
        File f = new File("src/test/resources/requests/pre-req/updatecompanycontact-carddetails.xml");
        String cardDetails = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        cardDetails = cardDetails.replace("${#TestSuite#company-id}", companyID);
        cardDetails = cardDetails.replace("CardholderName${#TestSuite#contact-counter}", obj_generalInformationUtil.randomFirstName());
        cardDetails = cardDetails.replace("strCardExpiryDate", cardExpiryDate);
        cardDetails = cardDetails.replace("strCardAccRefNumber", cardAccRefNumber);
        return serviceUtil.getResponse(cardDetails, System.getProperty("ENV") + "/ManageCompanyWS", "ManageCompanyWSService/updateCompany");

    }

    public String worldPay(String policyIdentity, String PositionIdentity, String variationIdentity, String productClass, String schemeCode, String cardAccountIdentity, String prodTreeId, String isAutoReview, String isAutoRenew, String isBlockRenewal) throws IOException {
        return worldPay( policyIdentity,  PositionIdentity,  variationIdentity,  productClass,  schemeCode,  cardAccountIdentity,  prodTreeId,  isAutoReview,  isAutoRenew,  isBlockRenewal,  "Self-Service",  "Self-Service");
    }


    public String worldPay(String policyIdentity, String PositionIdentity, String variationIdentity, String productClass, String schemeCode, String cardAccountIdentity, String prodTreeId, String isAutoReview, String isAutoRenew, String isBlockRenewal, String orgChannel, String endChannel) throws IOException {
        File f = new File("src/test/resources/requests/pre-req/UpdatePolicyPaymentPlan.xml");
        String UpdatePolicyPaymentPlan = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        UpdatePolicyPaymentPlan = UpdatePolicyPaymentPlan.replace("${#TestSuite#policy-id}", policyIdentity);
        UpdatePolicyPaymentPlan = UpdatePolicyPaymentPlan.replace("${#TestSuite#position-id}", PositionIdentity);
        UpdatePolicyPaymentPlan = UpdatePolicyPaymentPlan.replace("${#TestSuite#variation-id}", variationIdentity);
        UpdatePolicyPaymentPlan = UpdatePolicyPaymentPlan.replace("${#TestSuite#product-class}", productClass);
        UpdatePolicyPaymentPlan = UpdatePolicyPaymentPlan.replace("${#TestSuite#scheme-code}", schemeCode);
        UpdatePolicyPaymentPlan = UpdatePolicyPaymentPlan.replace("${#TestSuite#inception-date}", dateSelection);
        UpdatePolicyPaymentPlan = UpdatePolicyPaymentPlan.replace("strIsAutoReview", isAutoReview);
        UpdatePolicyPaymentPlan = UpdatePolicyPaymentPlan.replace("strIsAutoRenew", isAutoRenew);
        UpdatePolicyPaymentPlan = UpdatePolicyPaymentPlan.replace("strIsBlockRenewal", isBlockRenewal);
        UpdatePolicyPaymentPlan = UpdatePolicyPaymentPlan.replace("${#TestSuite#annual-plan-id}", "2");
        UpdatePolicyPaymentPlan = UpdatePolicyPaymentPlan.replace("${#TestSuite#card-account-id}", cardAccountIdentity);
        UpdatePolicyPaymentPlan = UpdatePolicyPaymentPlan.replace("${#TestSuite#product-tree-id}", prodTreeId);
        //System.out.println("Request--->"+UpdatePolicyPaymentPlan);
        return serviceUtil.getResponse(UpdatePolicyPaymentPlan, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/updateNewBusiness");
    }

    public String acceptPolicy(String policyIdentity, String PositionIdentity, String variationIdentity, String productClass, String schemeCode, String prodTreeId) throws IOException, Exception

    {
        File f = new File("src/test/resources/requests/pre-req/acceptNewBusiness.xml");
        String acceptNewBusiness = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        acceptNewBusiness = acceptNewBusiness.replace("${#TestSuite#policy-id}", policyIdentity);
        acceptNewBusiness = acceptNewBusiness.replace("${#TestSuite#position-id}", PositionIdentity);
        acceptNewBusiness = acceptNewBusiness.replace("${#TestSuite#variation-id}", variationIdentity);
        acceptNewBusiness = acceptNewBusiness.replace("${#TestSuite#product-class}", productClass);
        acceptNewBusiness = acceptNewBusiness.replace("${#TestSuite#scheme-code}", schemeCode);
        acceptNewBusiness = acceptNewBusiness.replace("${#TestSuite#product-tree-id}", prodTreeId);
        //System.out.println("Request--->"+acceptNewBusiness);
        String newbusinessResponse = serviceUtil.getResponse(acceptNewBusiness, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/completeNewBusiness");
        //System.out.println(newbusinessResponse);
        policynumber = serviceUtil.getNodeValue(newbusinessResponse, "v1_1:internalPolicyReference");
        return newbusinessResponse;
    }

    public String quotedPolicy(String policyIdentity, String PositionIdentity, String variationIdentity, String productClass, String schemeCode, String prodTreeId) throws IOException, Exception

    {
        File f = new File("src/test/resources/requests/pre-req/policyQuoted.xml");
        String quotedPolicy = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        quotedPolicy = quotedPolicy.replace("${#TestSuite#policy-id}", policyIdentity);
        quotedPolicy = quotedPolicy.replace("${#TestSuite#position-id}", PositionIdentity);
        quotedPolicy = quotedPolicy.replace("${#TestSuite#variation-id}", variationIdentity);
        quotedPolicy = quotedPolicy.replace("${#TestSuite#product-class}", productClass);
        quotedPolicy = quotedPolicy.replace("${#TestSuite#scheme-code}", schemeCode);
        quotedPolicy = quotedPolicy.replace("${#TestSuite#inception-date}", dateSelection);
        //System.out.println("Request--->"+quotedPolicy);
        String newBusinessQuote = serviceUtil.getResponse(quotedPolicy, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/statusUpdate");
        //System.out.println(newBusinessQuote);

        return newBusinessQuote;

    }


    public String createReceipt(String policyIdentity, String PositionIdentity, String productClass, String schemeCode, String cardAccountIdentity, String totalDue, String[] receiptValues) throws IOException {
        File f = new File("src/test/resources/requests/pre-req/CreateReceipt.xml");
        String createReceipt = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        createReceipt = createReceipt.replace("${#TestSuite#policy-id}", policyIdentity);
        createReceipt = createReceipt.replace("${#TestSuite#position-id}", PositionIdentity);
        createReceipt = createReceipt.replace("${#TestSuite#product-class}", productClass);
        createReceipt = createReceipt.replace("${#TestSuite#scheme-code}", schemeCode);
        createReceipt = createReceipt.replace("${#TestSuite#card-account-id}", cardAccountIdentity);
        createReceipt = createReceipt.replace("${#TestSuite#payment-amount}", totalDue);
        createReceipt = createReceipt.replace("strVisa", receiptValues[0]);
        createReceipt = createReceipt.replace("strCardNumber", receiptValues[1]);
        createReceipt = createReceipt.replace("strCardExpiry", receiptValues[2]);
        //System.out.println("Request--->"+createReceipt);
        return serviceUtil.getResponse(createReceipt, System.getProperty("ENV") + "/CreateReceiptWS", "CreateReceiptWSService/createPaymentHubReceipt");
        // String receiptid = serviceUtil.getNodeValue(receiptResponce, "v1_1:transactionNumber");

    }

    public String paymentTop(String companyID) throws IOException {

        //String companyName = "Company01";
        File f = new File("src/test/resources/requests/pre-req/updateCompanyContactBankDetails.xml");
        String updateBankDetails = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        updateBankDetails = updateBankDetails.replace("${#TestSuite#company-name}", companyName);
        updateBankDetails = updateBankDetails.replace("${#TestSuite#company-id}", companyID);
        //System.out.println("Request--->"+updateBankDetails);
        return serviceUtil.getResponse(updateBankDetails, System.getProperty("ENV") + "/ManageCompanyWS", "ManageCompanyWSService/updateCompany");

    }


    public String updatePolicy(String policyIdentity, String PositionIdentity, String variationIdentity, String productClass, String schemeCode, String prodTreeId, String bankAccountIdentity, String isAutoReview, String isAutoRenew, String isBlockRenewal) throws IOException {
        return  updatePolicy( policyIdentity,  PositionIdentity,  variationIdentity,  productClass,  schemeCode,  prodTreeId,  bankAccountIdentity,  isAutoReview,  isAutoRenew,  isBlockRenewal,  "Self-Service", "Self-Service");
    }

    public String updatePolicy(String policyIdentity, String PositionIdentity, String variationIdentity, String productClass, String schemeCode, String prodTreeId, String bankAccountIdentity, String isAutoReview, String isAutoRenew, String isBlockRenewal, String strStartChannel, String strEndChannnel) throws IOException {

        File f = new File("src/test/resources/requests/pre-req/updatePolicy.xml");
        String updatePolicy = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        updatePolicy = updatePolicy.replace("${#TestSuite#policy-id}", policyIdentity);
        updatePolicy = updatePolicy.replace("${#TestSuite#position-id}", PositionIdentity);
        updatePolicy = updatePolicy.replace("${#TestSuite#variation-id}", variationIdentity);
        updatePolicy = updatePolicy.replace("${#TestSuite#product-class}", productClass);
        updatePolicy = updatePolicy.replace("${#TestSuite#scheme-code}", schemeCode);
        updatePolicy = updatePolicy.replace("${#TestSuite#product-tree-id}", prodTreeId);
        updatePolicy = updatePolicy.replace("${#TestSuite#inception-date}", dateSelection);
        updatePolicy = updatePolicy.replace("strIsAutoReview", isAutoReview);
        updatePolicy = updatePolicy.replace("strIsAutoRenew", isAutoRenew);
        updatePolicy = updatePolicy.replace("strIsBlockRenewal", isBlockRenewal);
        updatePolicy = updatePolicy.replace("${#TestSuite#monthly-plan-id}", "4");
        updatePolicy = updatePolicy.replace("${#TestSuite#bank-account-id}", bankAccountIdentity);
        //System.out.println("Request--->"+updatePolicy);
        return serviceUtil.getResponse(updatePolicy, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/updateNewBusiness");

    }

    public String retriveSchedule(String policyIdentity, String PositionIdentity, String variationIdentity, String productClass, String schemeCode, String prodTreeId) throws IOException {
        File f = new File("src/test/resources/requests/pre-req/retriveSchedule.xml");
        String retriveSchedule = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        retriveSchedule = retriveSchedule.replace("${#TestSuite#policy-id}", policyIdentity);
        retriveSchedule = retriveSchedule.replace("${#TestSuite#position-id}", PositionIdentity);
        retriveSchedule = retriveSchedule.replace("${#TestSuite#variation-id}", variationIdentity);
        retriveSchedule = retriveSchedule.replace("${#TestSuite#product-class}", productClass);
        retriveSchedule = retriveSchedule.replace("${#TestSuite#scheme-code}", schemeCode);
        retriveSchedule = retriveSchedule.replace("${#TestSuite#product-tree-id}", prodTreeId);
        //System.out.println(retriveSchedule);
        return serviceUtil.getResponse(retriveSchedule, System.getProperty("ENV") + "/ManagePolicyBillingWS", "ManagePolicyBillingWSService/retrievePolicySchedule");


    }

    public String businessERN(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity,String values) throws IOException {
        String ernVal[] = values.split("#");
        File f = new File("src/test/resources/requests/pre-req/businessERN.xml");
        String updateERN = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        updateERN = updateERN.replace("${#TestSuite#policy-id}", policyIdentity);
        updateERN = updateERN.replace("${#TestSuite#position-id}", PositionIdentity);
        updateERN = updateERN.replace("${#TestSuite#variation-id}", variationIdentity);
        updateERN = updateERN.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
        updateERN = updateERN.replace("strErnExempt",String.valueOf(ernVal[0]).replace("$null$", ""));
        updateERN = updateERN.replace("ernValue", String.valueOf(ernVal[1]).replace("$null$", ""));
        return serviceUtil.getResponse(updateERN, System.getProperty("ENV") + "/ListComponentUpdateSME_INSSMEv1", "ListComponentUpdateSME_INSSMEv1Service/updateExistingListComponent");

    }

    public String partners(String partnerValues) throws IOException {
//        String[] partnerVal = partnerValues.split(",");
        File f = new File("src/test/resources/requests/pre-req/partners.xml");
        String partners = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        partners = partners.replace("${#TestSuite#contact-counter}", companyName);
//        partners = partners.replace("strForeName", partnerVal[0]);
//        partners = partners.replace("strCountry", partnerVal[1]);
        //System.out.println("REQUEST"+partners);
        return serviceUtil.getResponse(partners, System.getProperty("ENV") + "/ManagePersonWS", "ManagePersonWSService/createPerson");

    }

    public String addSubsidence(String policyIdentity, String PositionIdentity, String variationIdentity, String riskAddCompId, String subsidenceValues) throws IOException {
        String[] subsidenceVal = subsidenceValues.split(",");
        File f = new File("src/test/resources/requests/pre-req/addSubsidence.xml");
        String addSubsidence = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addSubsidence = addSubsidence.replace("${#TestSuite#policy-id}", policyIdentity);
        addSubsidence = addSubsidence.replace("${#TestSuite#position-id}", PositionIdentity);
        addSubsidence = addSubsidence.replace("${#TestSuite#variation-id}", variationIdentity);
        addSubsidence = addSubsidence.replace("${#TestSuite#risk_Add-comp-id}", riskAddCompId);
        addSubsidence = addSubsidence.replace("strSubsidenceHist", String.valueOf(subsidenceVal[0]).replace("$null$", ""));
        addSubsidence = addSubsidence.replace("strProximityRivBank", String.valueOf(subsidenceVal[1]).replace("$null$", ""));
        //System.out.println("Request---->"+addSubsidence);
        return serviceUtil.getResponse(addSubsidence, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }

    public String addLegalExpenses(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity) throws IOException {
        File f = new File("src/test/resources/requests/pre-req/addLegalExpenses.xml");
        String addLegalExpenses = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addLegalExpenses = addLegalExpenses.replace("${#TestSuite#policy-id}", policyIdentity);
        addLegalExpenses = addLegalExpenses.replace("${#TestSuite#position-id}", PositionIdentity);
        addLegalExpenses = addLegalExpenses.replace("${#TestSuite#variation-id}", variationIdentity);
        addLegalExpenses = addLegalExpenses.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
        //System.out.println("Request---->"+addLegalExpenses);
        return serviceUtil.getResponse(addLegalExpenses, System.getProperty("ENV") + "/GroupComponentSaveSME_INSSMEv1", "GroupComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }

    public String addLegalExpensesStandard(String policyIdentity, String PositionIdentity, String variationIdentity, String legalExpenseCompId, String coverLimit) throws IOException {
        File f = new File("src/test/resources/requests/pre-req/addLegalExpensesStandard.xml");
        String addLegalExpensesStandard = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addLegalExpensesStandard = addLegalExpensesStandard.replace("${#TestSuite#policy-id}", policyIdentity);
        addLegalExpensesStandard = addLegalExpensesStandard.replace("${#TestSuite#position-id}", PositionIdentity);
        addLegalExpensesStandard = addLegalExpensesStandard.replace("${#TestSuite#variation-id}", variationIdentity);
        addLegalExpensesStandard = addLegalExpensesStandard.replace("${#TestSuite#Legal_Expense-comp-id}", legalExpenseCompId);
        addLegalExpensesStandard = addLegalExpensesStandard.replace("strCoverLimit", String.valueOf(coverLimit).replace("$null$", ""));
        //System.out.println("Request---->"+addLegalExpensesStandard);
        return serviceUtil.getResponse(addLegalExpensesStandard, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }

    public String loadsAndDiscounts(String policyIdentity, String PositionIdentity, String variationIdentity, String dlgComponentIdentity, String loadsDiscountValues) throws IOException {
        String[] loadDiscountVal = loadsDiscountValues.split(",");
        File f = new File("src/test/resources/requests/pre-req/addLoadsAndDiscounts.xml");
        String loadsAndDiscounts = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        loadsAndDiscounts = loadsAndDiscounts.replace("${#TestSuite#policy-id}", policyIdentity);
        loadsAndDiscounts = loadsAndDiscounts.replace("${#TestSuite#position-id}", PositionIdentity);
        loadsAndDiscounts = loadsAndDiscounts.replace("${#TestSuite#variation-id}", variationIdentity);
        loadsAndDiscounts = loadsAndDiscounts.replace("${#TestSuite#DLG-comp-id}", dlgComponentIdentity);
        loadsAndDiscounts = loadsAndDiscounts.replace("strAmount", String.valueOf(loadDiscountVal[0]).replace("$null$", ""));
        loadsAndDiscounts = loadsAndDiscounts.replace("strReasonCode", String.valueOf(loadDiscountVal[1]).replace("$null$", ""));
        loadsAndDiscounts = loadsAndDiscounts.replace("strPercentage", String.valueOf(loadDiscountVal[2]).replace("$null$", ""));
        loadsAndDiscounts = loadsAndDiscounts.replace("strFreeFormat", String.valueOf(loadDiscountVal[3]).replace("$null$", ""));
        //System.out.println("Request---->"+loadsAndDiscounts);
        return serviceUtil.getResponse(loadsAndDiscounts, System.getProperty("ENV") + "/ListComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }


    public String addEmployersLiability(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity) throws IOException {

        File f = new File("src/test/resources/requests/pre-req/addEmployersLiability.xml");
        String addEmployersLiability = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addEmployersLiability = addEmployersLiability.replace("${#TestSuite#policy-id}", policyIdentity);
        addEmployersLiability = addEmployersLiability.replace("${#TestSuite#position-id}", PositionIdentity);
        addEmployersLiability = addEmployersLiability.replace("${#TestSuite#variation-id}", variationIdentity);
        addEmployersLiability = addEmployersLiability.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
        //System.out.println("Request---->"+addEmployersLiability);
        return serviceUtil.getResponse(addEmployersLiability, System.getProperty("ENV") + "/GroupComponentSaveSME_INSSMEv1", "GroupComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }


    public String addEmpLiabilityStandard(String policyIdentity, String PositionIdentity, String variationIdentity, String employersLiabilityCompId) throws IOException {

        File f = new File("src/test/resources/requests/pre-req/addEmployersLiabilityStandard.xml");
        String addEmpLiabilityStandard = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addEmpLiabilityStandard = addEmpLiabilityStandard.replace("${#TestSuite#policy-id}", policyIdentity);
        addEmpLiabilityStandard = addEmpLiabilityStandard.replace("${#TestSuite#position-id}", PositionIdentity);
        addEmpLiabilityStandard = addEmpLiabilityStandard.replace("${#TestSuite#variation-id}", variationIdentity);
        addEmpLiabilityStandard = addEmpLiabilityStandard.replace("${#TestSuite#Employ_Liability-comp-id}", employersLiabilityCompId);
        //System.out.println("Request---->"+addEmpLiabilityStandard);
        return serviceUtil.getResponse(addEmpLiabilityStandard, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }

    public String piAddProfessionalIndemnity(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/addProfessionalIndemnity.xml");
        String addProfessionalIndemnity = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addProfessionalIndemnity = addProfessionalIndemnity.replace("${#TestSuite#policy-id}", policyIdentity);
        addProfessionalIndemnity = addProfessionalIndemnity.replace("${#TestSuite#position-id}", PositionIdentity);
        addProfessionalIndemnity = addProfessionalIndemnity.replace("${#TestSuite#variation-id}", variationIdentity);
        addProfessionalIndemnity = addProfessionalIndemnity.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
        return serviceUtil.getResponse(addProfessionalIndemnity, System.getProperty("ENV") + "/GroupComponentSaveSME_INSSMEv1", "GroupComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }

    public String pIStandard(String policyIdentity, String PositionIdentity, String variationIdentity, String pICompId,  HashMap<String, String> professionalIndemnity) throws Exception {
        List<String> PIKeys = new ArrayList<>(professionalIndemnity.keySet());
        File f=null;
        f = new File("src/test/resources/requests/pre-req/addProfessionalIndemnityStandard.xml");
        addPIStandard = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addPIStandard = addPIStandard.replace("${#TestSuite#policy-id}", policyIdentity);
        addPIStandard = addPIStandard.replace("${#TestSuite#position-id}", PositionIdentity);
        addPIStandard = addPIStandard.replace("${#TestSuite#variation-id}", variationIdentity);
        addPIStandard = addPIStandard.replace("${#TestSuite#Prof_Indemnity-comp-id}", pICompId);

        for (String strXmlParameterKey : PIKeys) {
            if(professionalIndemnity.get(strXmlParameterKey).equalsIgnoreCase("RN")){
                addPIStandard = addPIStandard.replace("<urn2:retroactiveDate>strdate</urn2:retroactiveDate>","");
            }else if(professionalIndemnity.get(strXmlParameterKey).contains(":")){
                addPIStandard = addPIStandard.replace(strXmlParameterKey, String.valueOf(professionalIndemnity.get(strXmlParameterKey)).replace(":","-"));
            }
            addPIStandard = addPIStandard.replace(strXmlParameterKey, String.valueOf(professionalIndemnity.get(strXmlParameterKey)).replace("$null$",""));
        }
        //System.out.println(addPIStandard);

        return serviceUtil.getResponse(addPIStandard, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");
    }




    public String addEmpLiabilityTemp(String policyIdentity, String PositionIdentity, String variationIdentity, String employersLiabilityCompId) throws IOException {

        File f = new File("src/test/resources/requests/pre-req/addEmployersLiabilityStandard.xml");
        String addEmpLiabilityTemp = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addEmpLiabilityTemp = addEmpLiabilityTemp.replace("${#TestSuite#policy-id}", policyIdentity);
        addEmpLiabilityTemp = addEmpLiabilityTemp.replace("${#TestSuite#position-id}", PositionIdentity);
        addEmpLiabilityTemp = addEmpLiabilityTemp.replace("${#TestSuite#variation-id}", variationIdentity);
        addEmpLiabilityTemp = addEmpLiabilityTemp.replace("${#TestSuite#Employ_Liability-comp-id}", employersLiabilityCompId);
        //System.out.println("Request---->"+addEmpLiabilityTemp);
        return serviceUtil.getResponse(addEmpLiabilityTemp, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }

    public String addWorkingPartners(String policyIdentity, String PositionIdentity, String variationIdentity, String employersLiabilityCompId) throws IOException {

        File f = new File("src/test/resources/requests/pre-req/addEmployersLiabilityStandard.xml");
        String addWorkingPartners = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        addWorkingPartners = addWorkingPartners.replace("${#TestSuite#policy-id}", policyIdentity);
        addWorkingPartners = addWorkingPartners.replace("${#TestSuite#position-id}", PositionIdentity);
        addWorkingPartners = addWorkingPartners.replace("${#TestSuite#variation-id}", variationIdentity);
        addWorkingPartners = addWorkingPartners.replace("${#TestSuite#Employ_Liability-comp-id}", employersLiabilityCompId);
        //System.out.println("Request---->"+addWorkingPartners);
        return serviceUtil.getResponse(addWorkingPartners, System.getProperty("ENV") + "/ComponentSaveSME_INSSMEv1", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");

    }


    public String contacts() throws IOException {

        File f = new File("src/test/resources/requests/pre-req/partners.xml");
        String contacts = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        contacts = contacts.replace("{#TestSuite#contact-counter}", "1104");
        String contactsResponce = serviceUtil.getResponse(contacts, System.getProperty("ENV") + "/ManagePersonWS", "ManagePersonWSService/createPerson");
        return contactsResponce;
    }

    //MTA Implementation
    public String createMTA(String policyIdentity, String PositionIdentity, String productClass, String schemeCode, int intDate) throws IOException {
        String responce = "";

        File f = new File("src/test/resources/Cognos_XML/CreateMTA.xml");
        String request = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        request = request.replace("${#TestSuite#policy-id}", policyIdentity);
        request = request.replace("${#TestSuite#position-id}", PositionIdentity);
        request = request.replace("${#TestSuite#product-code}", productClass);
        request = request.replace("${#TestSuite#scheme-code}", schemeCode);

        Calendar date = Calendar.getInstance(TimeZone.getTimeZone("Europe/London"));
        date.add(Calendar.DATE, intDate);
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd'T'HH:MM:SS").format(date.getTime());
        request = request.replace("${#TestCase#mta-inception-date}", timeStamp);

        responce = serviceUtil.getResponse(request, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/createAdjustment");

        return  responce;


    }
    public String updateMTADetails(String policyIdentity, String PositionIdentity,String variationIdentity,  String productClass, String schemeCode, String prodTreeId) throws IOException {
        String responce = "";

        File f = new File("src/test/resources/Cognos_XML/UpdateMTAPolicyDetail.xml");
        String request = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        request = request.replace("${#TestSuite#policy-id}", policyIdentity);
        request = request.replace("${#TestCase#position-id}", PositionIdentity);
        request = request.replace("${#TestCase#position-id}", PositionIdentity);
        request = request.replace("${#TestCase#variation-id}", variationIdentity);

        request = request.replace("${#TestSuite#product-code}", productClass);
        request = request.replace("${#TestSuite#scheme-code}", schemeCode);
        request = request.replace("${#TestSuite#product-tree-id}", prodTreeId);


        responce = serviceUtil.getResponse(request, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/updateNewBusiness");

        return  responce;


    }

    public String reCalculatePremium(String policyIdentity, String PositionIdentity, String variationIdentity, String productClass, String schemeCode) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/RecalculatePremium.xml");
        String calculatePremium = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        calculatePremium = calculatePremium.replace("${#TestSuite#policy-id}", policyIdentity);
        calculatePremium = calculatePremium.replace("${#TestCase#position-id}", PositionIdentity);
        calculatePremium = calculatePremium.replace("${#TestCase#position-id}", PositionIdentity);
        calculatePremium = calculatePremium.replace("${#TestCase#variation-id}", variationIdentity);
        calculatePremium = calculatePremium.replace("${#TestSuite#product-class}", productClass);
        calculatePremium = calculatePremium.replace("${#TestSuite#scheme-code}", schemeCode);

        return serviceUtil.getResponse(calculatePremium, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/calculatePolicyPremium");
    }

    public String acceptMTA(String policyIdentity, String PositionIdentity,String variationIdentity, String productClass, String schemeCode) throws IOException {
        String responce = "";

        File f = new File("src/test/resources/Cognos_XML/AcceptMTA.xml");
        String request = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        request = request.replace("${#TestCase#policy-id}", policyIdentity);
        request = request.replace("${#TestCase#position-id}", PositionIdentity);
        request = request.replace("${#TestCase#position-id}", PositionIdentity);
        request = request.replace("${#TestCase#variation-id}", variationIdentity);

        request = request.replace("${#TestSuite#product-code}", productClass);
        request = request.replace("${#TestSuite#scheme-code}", schemeCode);



        responce = serviceUtil.getResponse(request, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/completeAdjustment");

        return  responce;


    }

    public String searchPolicy() throws IOException {
        File f = new File("src/test/resources/requests/pre-req/SearchPolicy.xml");
        String searchpolicy = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        searchpolicy = searchpolicy.replace("${#TestSuite#policy-urn}", policynumber);
        //System.out.println(searchpolicy);
        return serviceUtil.getResponse(searchpolicy, System.getProperty("ENV") + "/SearchPolicyWS", "SearchPolicyWSService/searchPolicies");
    }

    public String searchTheCompany(String compName) throws IOException {

//        compName = FunctionalUtil.strBusinessName;
        File f = new File("src/test/resources/requests/pre-req/searchCompany.xml");
        String request = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
//        request = request.replace("strCompanyName", compName);
        request = request.replace("strURNName", compName);
        return serviceUtil.getResponse(request, System.getProperty("ENV") + "/SearchCompanyWS", "SearchCompanyWSService/searchCompany");

    }


    public String retrieveDetails(String policyId,String positionId) throws IOException {
        File f = new File("src/test/resources/requests/pre-req/policyPositionSummaryRetrieve.xml");
        String retrieveDetails = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        retrieveDetails = retrieveDetails.replace("strPolicyId", policyId);
        retrieveDetails = retrieveDetails.replace("strPolicyPosId", positionId);
        //System.out.println(retrieveDetails);
        return serviceUtil.getResponse(retrieveDetails,System.getProperty("ENV") + "/PolicyPositionSummaryRetrieveSME_INSSMEv1", "PolicyPositionSummaryRetrieveSME_INSSMEv1Service/retrievePolicyPositionSummary");
    }

    public String searchThePolicy(String policyNo) throws IOException {
        File f = new File("src/test/resources/requests/pre-req/SearchPolicy.xml");
        String request = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        request = request.replace("${#TestSuite#policy-urn}", policyNo);
        return serviceUtil.getResponse(request, System.getProperty("ENV") + "/SearchPolicyWS", "SearchPolicyWSService/searchPolicies");
    }

    public String searchTheCompanyID(String companyID) throws IOException {
        File f = new File("src/test/resources/requests/pre-req/SearchPolicyWithCompanyID.xml");
        String request = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        request = request.replace("strCompid", companyID);
        return serviceUtil.getResponse(request, System.getProperty("ENV") + "/SearchPolicyWS", "SearchPolicyWSService/searchPolicies");
    }

    public String searchTheCompanyDetails(String companyName) throws IOException {
        companyName = FunctionalUtil.strBusinessName;
        File f = new File("src/test/resources/requests/pre-req/searchCompany.xml");
        String request = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        request = request.replace("strCompanyName", companyName);
        return serviceUtil.getResponse(request, System.getProperty("ENV") + "/SearchCompanyWS", "SearchCompanyWSService/searchCompany");

    }


    public String removeCovItemGen(String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity) throws IOException, ParseException {

        File f = new File("src/test/resources/requests/pre-req/deleteBusinessContentsItem.xml");
        String removeBusinessContentsPremisesItem = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", contactID);
        removeBusinessContentsPremisesItem = removeBusinessContentsPremisesItem.replace("${#TestSuite#policy-id}", policyIdentity);
        removeBusinessContentsPremisesItem = removeBusinessContentsPremisesItem.replace("${#TestSuite#position-id}", PositionIdentity);
        removeBusinessContentsPremisesItem = removeBusinessContentsPremisesItem.replace("${#TestSuite#variation-id}", variationIdentity);
        removeBusinessContentsPremisesItem = removeBusinessContentsPremisesItem.replace("${#TestSuite#Prm_BusCont-comp-id}", businessComponentIdentity);
        //System.out.println("request =================== " + removeBusinessContentsPremisesItem);

        return serviceUtil.getResponse(removeBusinessContentsPremisesItem, System.getProperty("ENV") + "/ComponentDelete", "ComponentDeleteService/deleteComponent");

    }

}


