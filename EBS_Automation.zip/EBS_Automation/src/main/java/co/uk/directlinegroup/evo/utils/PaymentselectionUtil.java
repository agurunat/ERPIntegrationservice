package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_Paymentselection;

import java.util.List;

public class PaymentselectionUtil {

    private CommonUtil commonutil = new CommonUtil();
    private Obj_Paymentselection paymentselection = new Obj_Paymentselection();

    public void paymentMethod(List<List<String>> data, String fieldName) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        if (StrVal.equalsIgnoreCase("Monthly")) {
            paymentselection.monthlyLink().click();
        } else if (StrVal.equalsIgnoreCase("Annual")) {
            paymentselection.annualLink().click();
        }
    }
}