package co.uk.directlinegroup.evo.utils;

import java.util.ArrayList;

public class CognosExcelLogUtil extends ReportUtil {

    public static boolean testStatus = true;
    public static boolean flag = false;
    public static String reportPushText = "";
    ArrayList<String> expected = new ArrayList<String>();
    ArrayList<String> actualVal = new ArrayList<String>();
    ArrayList<String> reference = new ArrayList<String>();
    public static String tempRefer = "";
    public void logBooleanResult(String Expected, String Actual, boolean result, String strReference) {

        strReference = strReference + tempRefer;
        tempRefer="";
        if (!result) {
            expected.add(Expected);
            actualVal.add(Actual);
            reference.add(strReference);
            reportPushText = reportPushText + "<tr><td>" + Expected + "</td><td>" + Actual + "</td><td>" + strReference + "</td></tr>";
        }
    }

    public void logBooleanResult2(String Expected, String Actual, boolean result, String strReference,String Key) {

        strReference = strReference + tempRefer;
        tempRefer="";
        if (!result) {
            expected.add(Expected);
            actualVal.add(Actual);
            reference.add(strReference);
            reportPushText = reportPushText + "<tr><td>" + Expected + "</td><td>" + Actual + "</td><td>" + strReference + "</td></tr>";
        }
    }

}
