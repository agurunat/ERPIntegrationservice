package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import net.serenitybdd.core.annotations.findby.By;
import org.openqa.selenium.WebElement;

import java.util.List;


public class Obj_BusinessInterruption extends AbstractPage {

    public WebElement grossTurnOverDropDown() {
        return waitForUnstableElement(By.xpath(".//*[@id='C8__estimatedGrossTurnover']"));
    }

    public WebElement grossTurnOverText() {
        return waitForUnstableElement(By.xpath(".//*[@id='C8__p1_QUE_006AB5B0B0C7206C621574']/div/label"));
    }

    public WebElement grossTurnOverTextbox() {
        return waitForUnstableElement(By.xpath(".//*[@id='C8__QUE_006AB5B0B0C7206C621574']"));
    }

    public WebElement monthOfCoverDropDown() {
        return waitForUnstableElement(By.xpath(".//*[@id='C8__maxNoOfMonths']"));
    }

    public WebElement validationErrorMessage() {
        return waitForUnstableElement(By.xpath(".//*[@id='p4_QUE_F87629A96841D9F44136942_R1']/div"));
    }

    public WebElement requiredErrorMessageText() {
        return waitForUnstableElement(By.xpath("//*[@id='C8__QUE_006AB5B0B0C7206C621574_ERRORMESSAGE']"));
    }

    public WebElement businessInterruptionNextButton() {
        return waitForUnstableElement(By.xpath(".//*[@id='C8__BUT_006AB5B0B0C7206C622756']"));
    }

    public WebElement accordionBI() {
        return waitForUnstableElement(By.id("step-BI"));
    }

    public WebElement addSalon() {
        return waitForElementPresent(By.id("C8__BUT_150E2AD778D3C2DE272983"));
    }

    public WebElement thirdPartyNameBI() {
        return waitForUnstableElement(By.id("C8__QUE_006AB5B0B0C7206C624273"));
    }

    public WebElement thirdPartyPostCodeBI() {
        return waitForUnstableElement(By.id("C8__QUE_72934B4CEE6D3139317179"));
    }

    public WebElement addBIatThirdParty() {
        return waitForElementPresent(By.id("C8__BUT_006AB5B0B0C7206C648375"));
    }

    public WebElement nextBIThirdParty() {
        return waitForUnstableElement(By.id("C8__BUT_006AB5B0B0C7206C624835"));
    }

    public WebElement TurnOverQuestionText()
    {
        return waitAndFindElement(By.xpath("//*[@id='C8__p1_estimatedGrossTurnover']/div/label"));
    }

    public WebElement TurnOverPleaseTellText()
    {
        return waitAndFindElement(By.xpath("//*[@id='C8__p1_QUE_006AB5B0B0C7206C621574']/div/label"));
    }

    public WebElement nxtBtnBI()
    {
        return waitAndFindElement(By.id("C8__BUT_006AB5B0B0C7206C622756"));
    }


    public WebElement biErrorValidNumber_HB_BB()
    {
        return waitAndFindElement(By.id("C8__QUE_006AB5B0B0C7206C621574_ERRORMESSAGE"));
    }

    public WebElement biErrorMsgGreaterThan1Mill_HB_BB()
    {
        return waitAndFindElement(By.xpath("//*[@id='p4_QUE_F87629A96841D9F44136942_R1']/div"));
    }

    public WebElement noOFMonthstext()
    {
        return waitAndFindElement(By.xpath("//*[@id='C8__p1_maxNoOfMonths']/div/label"));
    }


    public WebElement binButtonBI()
    {
        return waitForElementPresent(By.id("C8__BUT_E51B872E5D2AA440704822"));
    }
    public List<WebElement> eleAccordionBI() {
        return findElements(By.xpath("//*[@id='step-BI']"));
    }

    public WebElement moreOptionBI() {
        return waitForElementPresent(By.xpath("//*[@id='C5__QUE_965BD2C07905F7002825070']/p"));
    }
    public WebElement validationPopUp(){
        return waitForElementPresent(By.id("C8__HEAD_523D3ECD008FAE54669865"));
    }
    public WebElement validationPopUpYesButton(){
        return waitForElementPresent(By.id("C8__BUT_523D3ECD008FAE54670027"));
    }
    public WebElement validationPopUpNoButton(){
        return waitForElementPresent(By.id("C8__BUT_523D3ECD008FAE54670032"));
    }
    public WebElement moreOptionAddBIGrossTurnover() {
        return waitForElementPresent(By.xpath("//*[@id='C5__C1__QUE_965BD2C07905F7002825186']"));
    }
    public WebElement moreOptionAddBIMonths() {
        return waitForElementPresent(By.xpath("//*[@id='C5__C1__QUE_965BD2C07905F7002825190']"));
    }
    public WebElement moreOptionAddBIAddToQuote() {
        return waitForElementPresent(By.xpath("//*[@id='C5__C1__BUT_965BD2C07905F7002825194']"));
    }
    public WebElement moreOptionAddBI() {
        return waitForElementPresent(By.xpath("//*[@id='C5__BUT_0D396F41AB6AB8C2544911']/span"));
    }

    public WebElement removeBI() {
        return waitForElementPresent(By.xpath("//*[@id='C5__BUT_965BD2C07905F7003509104']"));
    }

}
