package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_Createcustomer;

import java.util.List;

public class CreatecustomerUtil {

    private CommonUtil commonutil = new CommonUtil();
    private Obj_Createcustomer createcustomer = new Obj_Createcustomer();

    public void marketingPreferences(List<List<String>> data, String fieldName) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        if (StrVal.equalsIgnoreCase("Yes")) {
            createcustomer.executeScript("arguments[0].click();", createcustomer.marketingPreferenceYesRadiobutton());
        } else {
            createcustomer.executeScript("arguments[0].click();", createcustomer.marketingPreferenceNoRadiobutton());
        }
    }

    public void communicationPreferences(List<List<String>> data, String fieldName) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        if (StrVal.equalsIgnoreCase("Correspondence by email")) {
            createcustomer.executeScript("arguments[0].click();", createcustomer.correspondenceByMailRadiobutton());
        } else {
            createcustomer.executeScript("arguments[0].click();", createcustomer.correspondenceByPostRadiobutton());
        }
    }
}