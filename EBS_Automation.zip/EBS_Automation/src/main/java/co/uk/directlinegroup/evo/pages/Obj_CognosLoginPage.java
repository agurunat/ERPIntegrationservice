package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 * Created by 323996 on 9/5/2017.
 */
public class Obj_CognosLoginPage extends AbstractPage {

    public WebElement userNameTextbox() {
        return waitForUnstableElement(By.id("CAMUsername"));
    }

    public WebElement passwordTextbox() {
        return waitForUnstableElement(By.id("CAMPassword"));
    }

    public WebElement okButton() {
        return waitForUnstableElement(By.id("cmdOK"));
    }

}
