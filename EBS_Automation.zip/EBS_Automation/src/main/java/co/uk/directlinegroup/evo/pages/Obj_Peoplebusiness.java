package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class Obj_Peoplebusiness extends AbstractPage {

    public WebElement peopleScreenHeader() {
        return waitForUnstableElement(By.id("step-2"));
    }

    public WebElement toldUsQuestion() {
        return waitAndFindElement(By.xpath("//*[@id='C2__p1_QUE_5847B0D83AF0F962230497']/div/label"));
    }

    public WebElement toldUsBuisnessDropdownbox() {
        return waitAndFindElement(By.xpath("//*[@id='C2__QUE_5847B0D83AF0F962230497']"));
    }

    public WebElement toldUsQuestionHT() {
        return waitForElementPresent(By.xpath("//*[@id='C2__p4_QUE_5847B0D83AF0F962230497']/div/div[1]/div"));
    }

    public List<WebElement> moreThan50DaysContent(){
        return findElements(By.xpath("//*[@id='C2__p1_HEAD_5847B0D83AF0F962230538']/div/div"));
    }
    public List<WebElement> moreThan50DaysQuest(){
        return findElements(By.xpath("//*[@id='C2__p1_QUE_5847B0D83AF0F962230511']/div/label"));
    }

    public WebElement selfEmployedPeople(String YorN) {
        String value = "No";
        if (YorN.equalsIgnoreCase("Yes")) {
            value = "Yes";
        }
        String cssSelector = "input[name='C2__DIRECTLINE[1].YOURBUSINESS[1].PEOPLEPAGE[1].PREMISESUSEDBYSELF-EMPLOY'][value=" + value + "]";
        return waitForUnstableElement(By.cssSelector(cssSelector));
    }
    public List<WebElement> selfEmployedQuestion(){
        return findElements(By.id("C2__row_QUE_5847B0D83AF0F962230540"));
    }
    public List<WebElement> noOfSelfEmployedQuestion()
    {
        return findElements(By.id("C2__row_QUE_5847B0D83AF0F962230543"));
    }
    public WebElement employerLiabilityYesRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C2__QUE_5847B0D83AF0F962230499']/label[1]/span"));
    }

    public WebElement employerLiabilityNoRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C2__QUE_5847B0D83AF0F962230499']/label[2]/span"));
    }

    public WebElement tempMorethanDaysYesRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C2__QUE_5847B0D83AF0F962230511']/label[1]/span"));
    }

    public WebElement tempMorethanDaysNoRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C2__QUE_5847B0D83AF0F962230511']/label[2]/span"));
    }

    public WebElement empWorkBusinessTextbox() {
        return waitForUnstableElement(By.id("C2__QUE_5847B0D83AF0F962230522"));
    }

    public WebElement empWorkBusinessText() {
        return waitForUnstableElement(By.id("C2__QUE_5847B0D83AF0F962230522"));
    }

    public WebElement peopleBusinessTextbox() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__p1_QUE_5847B0D83AF0F962230522']/div/label"));
    }

    public WebElement empAdminWorkTextbox() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__QUE_5847B0D83AF0F962230532']"));
    }

    public WebElement moreThanDaysQuestionMark() {
        return waitAndFindElement(By.xpath("//*[@id='C2__p1_QUE_5847B0D83AF0F962230511']/div/label"));
    }

    public WebElement liabilityCoverQues() {
        return waitForUnstableElement(By.id("C3__QUE_5847B0D83AF0F962260731"));

    }

    public WebElement liabilityCoverQuesText() {
        return waitForUnstableElement(By.xpath("//*[@id='C3__p4_QUE_5847B0D83AF0F962260731']/div/div[1]/div"));

    }

    public WebElement gradeQues() {
        return waitForUnstableElement(By.id("C5__QUE_487C210376DC00A33351725_R1"));

    }

    public WebElement gradeQuesHelpText() {
        return waitForUnstableElement(By.xpath("//*[@id='C5__p4_QUE_487C210376DC00A33351725_R1']/div/div[1]/div"));

    }

    public WebElement yourBuildingQues() {
        return waitForUnstableElement(By.xpath("//*[@id='C5__p1_QUE_B477726732A860C1416209_R1']/div/label"));

    }

    public WebElement yourBuildingQuesText() {
        return waitForUnstableElement(By.xpath("//*[@id='C5__p4_QUE_B477726732A860C1416209_R1']/div/div/div"));

    }

    public WebElement directorBusinessTextbox() {
        return waitForUnstableElement(By.id("C2__QUE_5847B0D83AF0F962230504"));
    }

    public WebElement businessQuestions() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__p1_QUE_5847B0D83AF0F962230522'or @id='C2__p1_QUE_5847B0D83AF0F962230504'or @id='C2__p1_QUE_5847B0D83AF0F962230506'or @id='C2__p1_QUE_5847B0D83AF0F962230514'or @id='C2__p1_QUE_5847B0D83AF0F962230526']/div/label"));
    }



    public WebElement questionsTextbox() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__p4_QUE_5847B0D83AF0F962230522'or @id='C2__QUE_5847B0D83AF0F962230504' or@id='C2__QUE_5847B0D83AF0F962230506'or @id='C2__QUE_5847B0D83AF0F962230514'or @id='C2__QUE_5847B0D83AF0F962230526']"));
    }

    public WebElement questionsDisplayedText() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__p1_QUE_5847B0D83AF0F962230522'or @id='C2__p1_QUE_5847B0D83AF0F962230504'or @id='C2__p1_QUE_5847B0D83AF0F962230506'or @id='C2__p1_QUE_5847B0D83AF0F962230514'or @id='C2__p1_QUE_5847B0D83AF0F962230526']/div/label"));
    }

    public WebElement directorAdminTextbox() {
        return waitForUnstableElement(By.id("C2__QUE_5847B0D83AF0F962230506"));
    }

    public List<WebElement> adminDirectorOrPartnerQuestion(){
        return findElements(By.xpath("//*[@id='C2__p1_QUE_5847B0D83AF0F962230506']/div/label"));
    }

    public List<WebElement>  employeeExcludeDirectorsQuestion(){
        return findElements(By.xpath("//*[@id='C2__p1_QUE_5847B0D83AF0F962230514']/div/label"));
    }


    public List<WebElement> employeeExcludeAdminDirectorsQuestion(){
        return findElements(By.xpath("//*[@id='C2__p1_QUE_5847B0D83AF0F962230526']/div/label"));
    }


    public List<WebElement> empAdminQuestion(){
        return findElements(By.xpath("//*[@id='C2__p1_QUE_5847B0D83AF0F962230532']/div/label"));
    }


    public WebElement employeeExcludeDirectorsTextbox() {
        return waitForUnstableElement(By.id("C2__QUE_5847B0D83AF0F962230514"));
    }

    public WebElement employeeExcludeDirectorsAdminTextbox() {
        return waitForUnstableElement(By.id("C2__QUE_5847B0D83AF0F962230526"));
    }

    public WebElement peopleBusinessNextbutton() {
        return waitForUnstableElement(By.id("C2__BUT_5847B0D83AF0F962230553"));
    }

    public WebElement peopleBusinessSaveExitbutton() {
        return waitForUnstableElement(By.id(".//div[@id='C2__p4_BUT_D3E81D5ED026892F942222']/div/button"));
    }

    public List<WebElement> directorBusinessTextboxSize() {
        return findElements(By.id("C2__QUE_5847B0D83AF0F962230504"));
    }

    public List<WebElement> directorAdminTextboxSize() {
        return findElements(By.id("C2__QUE_5847B0D83AF0F962230506"));
    }

    public List<WebElement> employeeExcludeDirectorsTextboxSize() {
        return findElements(By.id("C2__QUE_5847B0D83AF0F962230514"));
    }

    public List<WebElement> employeeExcludeDirectorsAdminTextboxSize() {
        return findElements(By.id("C2__QUE_5847B0D83AF0F962230526"));
    }

    public List<WebElement> selfEmployeeYesRadiobuttonSize() {
        return findElements(By.xpath(".//*[@id='radio_C2__QUE_5847B0D83AF0F962230540']/label[1]/span"));
    }

    public WebElement selfEmployeeText() {
        return waitForUnstableElement(By.xpath(".//*[@id='C2__p1_QUE_5847B0D83AF0F962230540']/div/label)"));
    }

    public WebElement selfEmployeeYesRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C2__QUE_5847B0D83AF0F962230540']/label[1]/span"));
    }

    public WebElement selfEmployeeNoRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C2__QUE_5847B0D83AF0F962230540']/label[2]/span"));
    }

    public WebElement selfEmployeeValueTextbox() {
        return waitForUnstableElement(By.id("C2__QUE_5847B0D83AF0F962230543"));
    }

    public WebElement tempEmp50Days(String YorN) {
        String value = "No";
        if (YorN.equalsIgnoreCase("Yes")) {
            value = "Yes";
        }
        String cssSelector = "input[name='C2__DIRECTLINE[1].YOURBUSINESS[1].PEOPLEPAGE[1].TEMPEMPLOYEES'][value=" + value + "]";
        return waitForUnstableElement(By.cssSelector(cssSelector));
    }

    public WebElement coverInjuriesYesRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C2__QUE_5847B0D83AF0F962230508']/label[1]/span"));
    }

    public WebElement coverInjuriesNoRadiobutton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C2__QUE_5847B0D83AF0F962230508']/label[2]/span"));
    }

    public WebElement tempEmployeeText() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__p1_QUE_5847B0D83AF0F962230511']/div/label"));
    }

    public WebElement expandLiabilityText() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__p1_HEAD_5847B0D83AF0F962230538']/div/div"));
    }

    public WebElement LiabilityQuestionText() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__p1_QUE_5847B0D83AF0F962230499'or @id='C2__p1_QUE_5847B0D83AF0F962230511'or @id='C2__p1_QUE_5847B0D83AF0F962230508']/div/label"));
    }

    public WebElement liabilityButton() {
        return waitForUnstableElement(By.xpath(".//*[@id='radio_C2__QUE_5847B0D83AF0F962230499'or @id='radio_C2__QUE_5847B0D83AF0F962230511'or @id='radio_C2__QUE_5847B0D83AF0F962230508']/label[1]/span"));
    }

    public WebElement empELCoverErrorValidation() {
        return waitForUnstableElement(By.xpath(".//*[@id='C2__TXT_5847B0D83AF0F962230502']/div/div"));
    }

    public WebElement employeeHelpText() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__p4_QUE_5847B0D83AF0F962230522']/div/div[1]"));
    }

    public WebElement toldUsYourBusinessQuestionMark() {
        return waitAndFindElement(By.xpath(".//*[@id='C2__p4_QUE_5847B0D83AF0F962230497']/div/div[1]"));
    }

    public WebElement toldUsYourBusinessHelpText() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__p4_QUE_5847B0D83AF0F962230497']/div/div[1]/div"));
    }

    public WebElement employersLiabilityQuestionMark() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__p4_QUE_5847B0D83AF0F962230499']/div/div[1]"));
    }

    public WebElement employersLiabilityHelpText() {
        return waitForUnstableElement(By.xpath(".//*[@id='C2__p4_QUE_5847B0D83AF0F962230499']/div/div[1]/div"));
    }

    public WebElement employeeWorkBusinessQuestionMark() {
        return waitForUnstableElement(By.xpath(".//*[@id='C2__p4_QUE_5847B0D83AF0F962230522']/div/div[1]"));
    }

    public WebElement employeeWorkBusinessHelpText() {
        return waitForUnstableElement(By.xpath(".//*[@id='C2__p4_QUE_5847B0D83AF0F962230522']/div/div[1]/div"));
    }

    public WebElement employeeDoAdminQuestionMark() {
        return waitForUnstableElement(By.xpath(".//*[@id='C2__p4_QUE_5847B0D83AF0F962230532']/div/div[1]"));
    }

    public WebElement employeeDoAdminHelpText() {
        return waitForUnstableElement(By.xpath(".//*[@id='C2__p4_QUE_5847B0D83AF0F962230532']/div/div[1]/div"));
    }

    public WebElement employeeDoAdminQuestionMarkExcludingDirectors() {
        return waitForUnstableElement(By.xpath(".//*[@id='C2__p4_QUE_5847B0D83AF0F962230526']/div/div[1]"));
    }

    public WebElement employeeDoAdminHelpTextExcludingDirectors() {
        return waitForUnstableElement(By.xpath(".//*[@id='C2__p4_QUE_5847B0D83AF0F962230526']/div/div[1]/div"));
    }

    public WebElement employeeExcludingQuestionMark() {
        return waitForUnstableElement(By.xpath(".//*[@id='C2__p4_QUE_5847B0D83AF0F962230514']/div/div[1]"));
    }

    public WebElement employeeExcludingHelpText() {
        return waitForUnstableElement(By.xpath(".//*[@id='C2__p4_QUE_5847B0D83AF0F962230514']/div/div[1]/div"));
    }

    public WebElement employeeHelpTextSymbol() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__p4_QUE_5847B0D83AF0F962230522']/div/div[1]"));
    }

    public WebElement EmpWorkBusinessQuestion() {
        return waitForUnstableElement(By.xpath(".//*[@id='C2__p4_QUE_5847B0D83AF0F962230499'or @id='C2__p4_QUE_5847B0D83AF0F962230522'or @id='C2__p4_QUE_5847B0D83AF0F962230532']/div/div[1]"));
    }

    public WebElement saveAndExitPeoplePL() {
        return waitForUnstableElement(By.id("C2__BUT_D3E81D5ED026892F942222"));
    }

    public WebElement saveAndExitPopUpPeoplePL() {
        return waitForUnstableElement(By.id("BUT_D3E81D5ED026892F1577152"));
    }

    public WebElement saveExitButtonPopUp() {
//    return waitForElementVisible(By.xpath("//*[@id='C1__BUT_391E4BE220C07767120913'][@class='green-btn']"));
        return waitForElementVisible(By.xpath("//*[@id='BUT_D3E81D5ED026892F1577152'][@class='green-btn']"));
    }

    public WebElement moreThanDaysHelpText() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__p4_QUE_5847B0D83AF0F962230511']/div/div[1]/div"));
    }

    public WebElement selfEmployedPeopleHelpText() {
        return waitForUnstableElement(By.xpath("//*[@id='C2__p4_QUE_5847B0D83AF0F962230540']/div/div[1]/div"));

    }
    public WebElement requiredMsg(){
        return waitForUnstableElement(By.xpath("//label[contains(text(),'Required')]"));
    }

    public WebElement assumptionRequired(){
        return  waitForUnstableElement(By.cssSelector("span[id='C6__QUE_081B7A67BC5B17F91541469_ERRORMESSAGE_R1']"));
    }
    public WebElement validationMessage(){
        return waitForUnstableElement(By.id("C2__p1_TBL_818CB4BDAC15FD54572930"));
    }
//    Need to update property once it got displayed in application
    public WebElement employeeManualWorkHelpText()
    {
        return waitForUnstableElement(By.xpath("//*[@id='C2__p4_QUE_95CA52D4EB4CD7F61659143']/div/div[1]"));
    }
    public WebElement employeeManualWork()
    {
        return waitForElementPresent(By.id("C2__QUE_95CA52D4EB4CD7F61659143"));
    }
    public List<WebElement> employeeManualWorkQuestion(){
        return findElements(By.xpath("//*[@id='C2__p1_QUE_95CA52D4EB4CD7F61659143']/div/label"));}
    public WebElement partnerDirectorManualWorkHelpText(){
        return waitForUnstableElement(By.xpath("//*[@id='C2__p4_QUE_95CA52D4EB4CD7F61659148']/div/div[1]"));}
    public WebElement partnerDirectorManualWork(){
        return waitForElementPresent(By.id("C2__QUE_95CA52D4EB4CD7F61659148"));}
    public List<WebElement> partnerDirectorManualWorkQuestion(){
        return findElements(By.xpath("//*[@id='C2__p1_QUE_95CA52D4EB4CD7F61659148']/div/label"));}
    public List<WebElement> empManualWorkValidaiton(){
        return findElements(By.id("C2__QUE_95CA52D4EB4CD7F61659143_ERRORMESSAGE"));}
    public List<WebElement> empDirManualWorkValidaiton(){
        return findElements(By.id("C2__QUE_95CA52D4EB4CD7F61659153_ERRORMESSAGE"));}
    public List<WebElement> partnerDirectorManualWorkValidation(){
        return findElements(By.id("C2__QUE_95CA52D4EB4CD7F61659148_ERRORMESSAGE"));}
    public WebElement employeeExDirManualWorkHelpText(){
        return waitForUnstableElement(By.xpath("//*[@id='C2__p4_QUE_95CA52D4EB4CD7F61659153']/div/div[1]"));}
    public WebElement employeeExDirManualWork(){
        return waitForElementPresent(By.id("C2__QUE_95CA52D4EB4CD7F61659153"));}
    public List<WebElement> employeeExDirManualWorkQuestion(){
        return findElements(By.xpath("//*[@id='C2__p1_QUE_95CA52D4EB4CD7F61659153']/div/label"));}
    public WebElement elHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C2__p4_QUE_5847B0D83AF0F962230499']/div/div[1]"));
    }
    public WebElement noOfEmpHelpText() {
        return waitForElementPresent(By.xpath("//*[@id='C2__p4_QUE_5847B0D83AF0F962230514']/div/div[1]"));
    }
    public WebElement empManualRequiredMsg(){
        return waitForUnstableElement(By.id("C2__QUE_95CA52D4EB4CD7F61659143_ERRORMESSAGE"));
    }
    public WebElement partnerOrDirectorManualRequiredMsg(){
        return waitForUnstableElement(By.id("C2__QUE_95CA52D4EB4CD7F61659148_ERRORMESSAGE"));
    }
    public WebElement excluDirectorManualRequiredMsg(){
        return waitForUnstableElement(By.id("C2__QUE_95CA52D4EB4CD7F61659153_ERRORMESSAGE"));
    }
}