package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_Businesspremises;
import co.uk.directlinegroup.evo.pages.Obj_Propertyaway;
import com.usmanhussain.habanero.framework.AbstractPage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;
import java.util.NoSuchElementException;

public class BusinesspremisesUtil extends AbstractPage {

    private CommonUtil commonutil = new CommonUtil();
    private Obj_Businesspremises businesspremises = new Obj_Businesspremises();
    private Obj_Businesspremises obj_businessPremises = new Obj_Businesspremises();
    private Obj_Propertyaway obj_propertyAway = new Obj_Propertyaway();
    private PeoplebusinessUtil peoplebusinesutil = new PeoplebusinessUtil();

/*    public void businesspremisesHome(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                businesspremises.premisesOccupiedYesRadiobutton(i).click();
            } else if (strVal.equalsIgnoreCase("No")) {
                businesspremises.premisesOccupiedNoRadiobutton(i).click();
            }
        }
    }*/

    public void alcoholLicense(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase(null)) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.alcoholYesButton(i));
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.alcoholNoButton(i));
            }
        }
    }

    public void businesspremisesCommercial(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.commercialpremisesOccupiedYesRadiobutton(i));
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.commercialpremisesOccupiedNoRadiobutton(i));
            }
        }
    }

    public void premisetype(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("home business")) {
                commonutil.selectElement(columnValue, columnName, "PremisesType", businesspremises.selectPremisesTypeDropdown(i));
                commonutil.waitForPageLoad();
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.premisesOccupiedYesRadiobutton(i));
                //businesspremisesHome(columnValue, columnName, "SoleOccupancy", i);
            } else if (strVal.equalsIgnoreCase("commercial premises")) {
                commonutil.selectElement(columnValue, columnName, "PremisesType", businesspremises.selectPremisesTypeDropdown(i));
                commonutil.waitForPageLoad();
                //businesspremisesCommercial(columnValue, columnName, "SoleOccupancy", i);
            }
        }
    }

    public void riskAddress(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.riskAddressYesRadioButton(i));
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.riskAddressNoRadioButton(i));
            }
        }
    }

    public void accomodation(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.accomodationYesRadiobutton(i));
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.accomodationNoRadiobutton(i));
            }
        }
    }

    public void commercialSoleOccupancy(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.commercialSoleOccupancyYesButton(k));
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.commercialSoleOccupancyNoButton(k));
            }
        }
    }

    public void homeSoleOccupancy(List<List<String>> data, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(data, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.homeSoleOccupancyYesButton(k));
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.homeSoleOccupancyNoButton(k));
            }
        }
    }

    public void applyToBusiness(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (strVal.equalsIgnoreCase("I haven’t started trading at the premises yet.")) {
            obj_businessPremises.executeScript("arguments[0].click();", businesspremises.haventStartedTradeRadiobutton(i));
        } else if (strVal.equalsIgnoreCase("The premises are currently unoccupied")) {
            obj_businessPremises.executeScript("arguments[0].click();", businesspremises.premiseCurrentlyUnoccupiedRadiobutton(i));
        } else if (strVal.equalsIgnoreCase("During the year, the premises will be unoccupied for more than 30 consecutive days")) {
            obj_businessPremises.executeScript("arguments[0].click();", businesspremises.premiseUnoccupied30daysRadiobutton(i));
        } else if (strVal.equalsIgnoreCase("None")) {
            obj_businessPremises.executeScript("arguments[0].click();", businesspremises.noneOftheAboveRadiobutton(i));
        }
    }

    public void outBuilding(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.anyOutBuildingYesRadiobutton(i));
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.anyOutBuildingNoRadiobutton(i));
            }
        }
    }

    public void buildingUsage(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            obj_businessPremises.executeScript("arguments[0].click();", businesspremises.buildingUsageDropDown());
        }
    }

    public void PleaseTellUsBuildingUsedFor(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            commonutil.setValue(columnValue, columnName, "PleaseTellUsBuildingUsedFor", businesspremises.PleaseTellUsBuildingUsedFor(i));
        }
    }

    public void mainYourBuilding(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (businesspremises.yourBuildingValueTextbox(i).isDisplayed()) {
            commonutil.waitForPageLoad();
            commonutil.setValue(columnValue, columnName, "MainBuilding_YourBuilding", businesspremises.yourBuildingValueTextbox(i));
        } else {
            if (!strVal.equalsIgnoreCase("")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.yourBuildingAddCoverLink(i));
                businesspremises.pageLoading();
                commonutil.setValue(columnValue, columnName, "MainBuilding_YourBuilding", businesspremises.yourBuildingValueTextbox(i));
                commonutil.tabKeypress();
                businesspremises.pageLoading();
            }
        }
    }

    public void mainBuildingShopFitting(List<List<String>> data, String fieldName, WebElement property, int i) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        if (property.isDisplayed()) {
            commonutil.setValue(data, "MainBuilding_BuildingShopFitting", businesspremises.yourBuildingValueTextbox(i));
        } else {
            if (!StrVal.equalsIgnoreCase("")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.yourBuildingAddCoverLink(i));
                businesspremises.pageLoading();
                commonutil.setValue(data, "MainBuilding_BuildingShopFitting", businesspremises.yourBuildingValueTextbox(i));
                commonutil.tabKeypress();
                businesspremises.pageLoading();
                commonutil.waitForPageLoad();
            }
        }
    }

    public void mainBuildingShop(List<List<String>> data, String fieldName, WebElement property, int i) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        if (property.isDisplayed()) {
            commonutil.setValue(data, "MainBuilding_BuildingShopFitting", businesspremises.buildingShopValueTextbox(i));
        } else {
            if (!StrVal.equalsIgnoreCase("")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.buildingShopAddCoverLink(i));
                businesspremises.pageLoading();
                commonutil.setValue(data, "MainBuilding_BuildingShopFitting", businesspremises.buildingShopValueTextbox(i));
                commonutil.tabKeypress();
                businesspremises.pageLoading();
                commonutil.waitForPageLoad();
            }
        }
    }

    public void mainBuildingFitting(List<List<String>> data, String fieldName, WebElement property, int i) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        if (property.isDisplayed()) {
            commonutil.setValue(data, "MainBuilding_BuildingShopFitting", businesspremises.buildingfittingValueTextbox(i));
        } else {
            if (!StrVal.equalsIgnoreCase("")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.buildingfittingAddCoverLink(i));
                businesspremises.pageLoading();
                commonutil.setValue(data, "MainBuilding_BuildingShopFitting", businesspremises.buildingfittingValueTextbox(i));
                commonutil.tabKeypress();
                businesspremises.pageLoading();
                commonutil.waitForPageLoad();
            }
        }
    }

    public void mainBusinessContent(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (businesspremises.businessContentValueTextbox(i).isDisplayed()) {
                commonutil.setValue(columnValue, columnName, "MainBuilding_BusinessContentValue", businesspremises.businessContentValueTextbox(i));
                commonutil.tabKeypress();
                businesspremises.pageLoading();
            } else {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.businessContentAddCoverLink(i));
                businesspremises.pageLoading();
                commonutil.setValue(columnValue, columnName, "MainBuilding_BusinessContentValue", businesspremises.businessContentValueTextbox(i));
                commonutil.tabKeypress();
                businesspremises.pageLoading();
            }
        }
    }

    public void WinesSpiritMain(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (businesspremises.stockValueSpiritTextbox(i).isDisplayed() && (!strVal.equalsIgnoreCase(""))) {
            commonutil.setValue(columnValue, columnName, "MainBuilding_StockWSValue", businesspremises.stockValueSpiritTextbox(i));
            commonutil.tabKeypress();
            businesspremises.pageLoading();
        } else {
            if (!strVal.equalsIgnoreCase("")) {
                if (businesspremises.stockAddCoverLink(i).isDisplayed()) {
                    obj_businessPremises.executeScript("arguments[0].click();", businesspremises.stockAddCoverLink(i));
                    businesspremises.pageLoading();
                }
                commonutil.setValue(columnValue, columnName, "MainBuilding_StockWSValue", businesspremises.stockValueSpiritTextbox(i));
                commonutil.tabKeypress();
                businesspremises.pageLoading();
            } else {
                int size = getDriver.findElements(By.id("C5__BUT_130910B8F1739FAC1055243_R" + i)).size();
                if (size == 1) {
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.wineSpiritRemoveCover(i));
                }
            }
        }
    }

    public void WinesSpiritOut(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (businesspremises.outStockWinesSpiritTextBox(i).isDisplayed() && (!strVal.equalsIgnoreCase(""))) {
            commonutil.setValue(columnValue, columnName, fieldName, businesspremises.outStockWinesSpiritTextBox(i));
            commonutil.tabKeypress();
        } else {
            if (!strVal.equalsIgnoreCase("")) {
                if (businesspremises.outbuildingStockWSAddCoverLink(i).isDisplayed()) {
                    businesspremises.outbuildingStockWSAddCoverLink(i).click();
                    businesspremises.pageLoading();
                }
                commonutil.setValue(columnValue, columnName, "OutBuilding_StockWSValue", businesspremises.outbuildingStockValueSpiritTextbox(i));
                commonutil.tabKeypress();
                businesspremises.pageLoading();
            } else {
                int size = getDriver.findElements(By.id("C5__BUT_130910B8F1739FAC1055243_R" + i)).size();
                if (size == 1) {
                    obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outBuildingStockWSRemoveButton(i));
                }
            }
        }
    }

    public void mainStock(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (!businesspremises.stockValueTextbox(i).isDisplayed()) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.stockAddCoverLink(i));
                businesspremises.pageLoading();
                commonutil.setValue(columnValue, columnName, "MainBuilding_StockValue", businesspremises.stockValueTextbox(i));
                commonutil.tabKeypress();
                businesspremises.pageLoading();
            } else {
                commonutil.setValue(columnValue, columnName, "MainBuilding_StockValue", businesspremises.stockValueTextbox(i));
                commonutil.tabKeypress();
                businesspremises.pageLoading();
            }
        }
    }

    public void requiredMessageFreeFormatMain(List<List<String>> validationContents, int k) {
        String requiredMsg = businesspremises.requiredTextFreeFormatMain(k).getText();
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(requiredMsg + " is displayed", validationContents.get(i).get(0).equalsIgnoreCase(requiredMsg));

            } else if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue("Element is not displayed", !validationContents.get(i).get(0).equalsIgnoreCase(requiredMsg));
            }
        }
    }

    public void requiredMessageFreeFormatOut(List<List<String>> validationContents, int k) {
        String requiredMsg = businesspremises.requiredTextFreeFormatOut(k).getText();
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(requiredMsg + " is displayed", validationContents.get(i).get(0).equalsIgnoreCase(requiredMsg));

            } else if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue("Element is not displayed", !validationContents.get(i).get(0).equalsIgnoreCase(requiredMsg));
            }
        }
    }

    public void mainHousehold(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if ((businesspremises.householdContentValueTextbox(i).isDisplayed()) && !(strVal.equalsIgnoreCase(""))) {
            commonutil.setValue(columnValue, columnName, "MainBuilding_HouseholdContent", businesspremises.householdContentValueTextbox(i));
            commonutil.tabKeypress();
            businesspremises.pageLoading();
            businesspremises.executeScript("arguments[0].click();", obj_businessPremises.householdContentNoValue());
            businesspremises.pageLoading();
        } else if (!strVal.equalsIgnoreCase("")) {
            obj_businessPremises.executeScript("arguments[0].click();", businesspremises.householdContentAddCoverLink(i));
            businesspremises.pageLoading();
            commonutil.setValue(columnValue, columnName, "MainBuilding_HouseholdContent", businesspremises.householdContentValueTextbox(i));
            commonutil.tabKeypress();
            businesspremises.pageLoading();
            businesspremises.executeScript("arguments[0].click();", obj_businessPremises.householdContentNoValue());
            businesspremises.pageLoading();
        } else if (strVal.equalsIgnoreCase("")) {
            businesspremises.executeScript("arguments[0].click();", obj_businessPremises.householdremovecover(i));
            businesspremises.pageLoading();
        }
    }

    public void outYourBuilding(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (businesspremises.outBuildingTextBox(k).isDisplayed()) {
            commonutil.waitForPageLoad();
            commonutil.setValue(columnValue, columnName, "OutBuilding_YourBuilding", businesspremises.outBuildingTextBox(k));
            commonutil.tabKeypress();
            businesspremises.pageLoading();
        } else {
            if (!strVal.equalsIgnoreCase("")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.outbuildingAddCover(k));
                businesspremises.pageLoading();
                commonutil.setValue(columnValue, columnName, "OutBuilding_YourBuilding", businesspremises.outBuildingTextBox(k));
                commonutil.tabKeypress();
                businesspremises.pageLoading();
                commonutil.waitForPageLoad();
            }
        }
    }

    public void outBusinessContent(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (businesspremises.outBusinessContentTextBox(k).isDisplayed()) {
                commonutil.setValue(columnValue, columnName, "OutBuilding_BusinessContentValue", businesspremises.outBusinessContentTextBox(k));
                commonutil.tabKeypress();
                businesspremises.pageLoading();
            } else {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.outBusninessContentAddCover(k));
                businesspremises.pageLoading();
                commonutil.setValue(columnValue, columnName, "OutBuilding_BusinessContentValue", businesspremises.outBusinessContentTextBox(k));
                commonutil.tabKeypress();
                businesspremises.pageLoading();
            }
        }
    }

    public void outStock(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (businesspremises.outBusinessStockTextBox(k).isDisplayed()) {
            if (strVal.equalsIgnoreCase("null")) {
                businesspremises.executeScript("arguments[0].click();", businesspremises.outBuildingStockRemoveButton(k));
            } else {
                commonutil.setValue(columnValue, columnName, "OutBuilding_StockValue", businesspremises.outBusinessStockTextBox(k));
                commonutil.tabKeypress();
                businesspremises.pageLoading();
            }
        } else {
            if (!strVal.equalsIgnoreCase("")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.outStockAddCover(k));
                businesspremises.pageLoading();
                commonutil.setValue(columnValue, columnName, "OutBuilding_StockValue", businesspremises.outBusinessStockTextBox(k));
                commonutil.tabKeypress();
                businesspremises.pageLoading();
            }
        }
    }

    public void outHousehold(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (businesspremises.outHouseholdContentTextBox(k).isDisplayed()) {
            commonutil.setValue(columnValue, columnName, "OutBuilding_HouseholdContent", businesspremises.outHouseholdContentTextBox(k));
            commonutil.tabKeypress();
        } else {
            if (!strVal.equalsIgnoreCase("")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.outHouseholdContentAddCover(k));
                businesspremises.pageLoading();
                commonutil.setValue(columnValue, columnName, "OutBuilding_HouseholdContent", businesspremises.outHouseholdContentTextBox(k));
                commonutil.tabKeypress();
            }
        }
    }

    public void premiseGrade(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.premiseGradeYesRadiobutton(i));
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.premiseGradeNoRadiobutton(i));
            }
        }
    }

    public void NamedItem(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.wallMaterialYesRadiobutton(i));
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.wallMaterialNoRadiobutton(i));
            }
        }
    }

    public void wallMaterial(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.wallMaterialYesRadiobutton(i));
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.wallMaterialNoRadiobutton(i));
            }
        }
    }

    public void roofMaterial(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.roofMaterialYesRadiobutton(i));
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.roofMaterialNoRadiobutton(i));
            }
        }
    }

    public void commWallMaterial(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Exception {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.wallMaterialYesRadiobutton(i));
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.wallMaterialNoRadiobutton(i));
            }
        }
    }

    public void commRoofMaterial(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                businesspremises.executeScript("arguments[0].click();", businesspremises.roofMaterialYesRadiobutton(i));
            } else if (strVal.equalsIgnoreCase("No")) {
                businesspremises.executeScript("arguments[0].click();", businesspremises.roofMaterialNoRadiobutton(i));
            }
        }
    }

    public void storageHeating(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                commonutil.executeScript("arguments[0].click();", businesspremises.storageHeatingYesRadiobutton(k));
                businesspremises.pageLoading();
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.storageHeatingNoRadiobutton(k));
                businesspremises.pageLoading();
            } else if (strVal.equalsIgnoreCase("Not heated")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.storageHeatingNotHeatedRadiobutton(k));
                businesspremises.pageLoading();
            }
        }
    }

    public void firePlace(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                businesspremises.pageLoading();
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.openFirePlacesYesRadiobutton(i));
                businesspremises.pageLoading();
            } else if (strVal.equalsIgnoreCase("No")) {
                businesspremises.pageLoading();
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.openFirePlacesNoRadiobutton(i));
                businesspremises.pageLoading();
            } else if (strVal.equalsIgnoreCase("Not heated")) {
                businesspremises.pageLoading();
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.openFirePlacesNotheatedRadiobutton(i));
                businesspremises.pageLoading();
            }
        }
    }

    public void heating(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.openFirePlacesYesRadiobutton(i));
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.openFirePlacesNoRadiobutton(i));
            } else if (strVal.equalsIgnoreCase("Not heated")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.openFirePlacesNotheatedRadiobutton(i));
            }
        }
    }

    public void subsidenceCover(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.subsidenceCoverYesRadiobutton(k));
                businesspremises.pageLoading();
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.propertyDamageNoRadioButton());
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.propertyAwayNoRadioButton());
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.subsidenceCoverNoRadiobutton(k));
            }
        }
    }

    public void addAnotherPremises(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.pageLoading();
                businesspremises.executeScript("arguments[0].click();", businesspremises.addAnotherPremise());
            }
        }
    }

    public void validateAccomodationQuestion(List<List<String>> data) {
        String accomodationQuestion = businesspremises.accomodationQuestion().getText();
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(accomodationQuestion + "is displayed", data.get(i).get(0).equalsIgnoreCase(accomodationQuestion));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(accomodationQuestion + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(accomodationQuestion));
            }
        }
    }

    public void validateBBAccomodationPremiseHelpText(List<List<String>> data) throws Throwable {
        businesspremises.accomodationHelpTextRadiobutton().click();
        String strText = businesspremises.accomodationHelpText().getText();
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(strText + "is displayed", data.get(i).get(0).equalsIgnoreCase(strText));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(strText + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(strText));
            }
        }
    }

    public void requiredAccErrorMessageText(List<List<String>> data, int k) {
        String errorMessage = businesspremises.requiredErrorMessageText(k).getText();
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(errorMessage + "is displayed", data.get(i).get(0).equalsIgnoreCase(errorMessage));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(errorMessage + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(errorMessage));
            }
        }
    }

    public void hbOutBuilding(List<List<String>> validationContents) throws Throwable {
        String contentFromPage = businesspremises.outbuildingQuestionText().getText();
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(contentFromPage + "is displayed", validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            }
        }
    }

    public void bbOutBuildingHelpText(List<List<String>> validationContents, int k) throws Throwable {
        for (int i = 1; i < validationContents.size(); i++) {
            String script = "return arguments[0].innerText";
            String strText = (String) getDriver.executeScript(script, businesspremises.outbuildingHelpText(k));
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(strText.replace(" ", "").replace("\n", "") + "is displayed", validationContents.get(i).get(0).replace(" ", "").replace("\n", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "")));
            } else if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(strText.replace(" ", "").replace("\n", "") + "is not displayed", validationContents.get(i).get(0).replace(" ", "").replace("\n", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "")));
            }
        }
    }

    public void bbOutBuilding(List<List<String>> validationContents) throws Throwable {
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                String contentFromPage = businesspremises.outbuildingQuestionText().getText();
                Assert.assertTrue(contentFromPage + "is displayed", validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            } else if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                String contentFromPage = businesspremises.outbuildingQuestionText().getText();
                Assert.assertTrue(contentFromPage + "is not displayed", !validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            }
        }
    }

    public void OutBuildingStatement(List<List<String>> validationContents) throws Throwable {
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                String contentFromPage = businesspremises.bbOutbuildingContent().getText();
                Assert.assertTrue(contentFromPage + "is displayed", validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            } else if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                String contentFromPage = businesspremises.bbOutbuildingContent().getText();
                Assert.assertTrue(contentFromPage + "is not displayed", !validationContents.get(i).get(0).equalsIgnoreCase(contentFromPage));
            }
        }
    }

    public void hbOutBuildingHelpText(List<List<String>> validationContents, int k) throws Throwable {
        for (int i = 1; i < validationContents.size(); i++) {
            String script = "return arguments[0].innerText";
            String strText = (String) getDriver.executeScript(script, businesspremises.outbuildingHelpText(k));
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(strText.replace(" ", "").replace("\n", "") + "is displayed", validationContents.get(i).get(0).replace(" ", "").replace("\n", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "")));
            } else if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(strText.replace(" ", "").replace("\n", "") + "is not displayed", validationContents.get(i).get(0).replace(" ", "").replace("\n", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "")));
            }
        }
    }

    public void validateHelpTextMain(List<List<String>> data) throws Throwable {
        for (int i = 1; i < data.size(); i++) {
            String script = "return arguments[0].innerText";
            String strText = (String) getDriver.executeScript(script, businesspremises.bedRommHelpTextSymbolMain());
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(strText.replace(" ", "").replace("\n", "") + "is displayed", data.get(i).get(0).replace(" ", "").replace("\n", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "")));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(strText.replace(" ", "").replace("\n", "") + "is not displayed", data.get(i).get(0).replace(" ", "").replace("\n", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "")));
            }
        }
    }

    public void validateHelpTextOut(List<List<String>> data) throws Throwable {
        for (int i = 1; i < data.size(); i++) {
            String script = "return arguments[0].innerText";
            String strText = (String) getDriver.executeScript(script, businesspremises.bedRommHelpTextSymbolMain());
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(strText.replace(" ", "").replace("\n", "") + "is displayed", data.get(i).get(0).replace(" ", "").replace("\n", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "")));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(strText.replace(" ", "").replace("\n", "") + "is not displayed", data.get(i).get(0).replace(" ", "").replace("\n", "").equalsIgnoreCase(strText.replace(" ", "").replace("\n", "")));
            }
        }
    }

    public void validationMessage(List<List<String>> validationContents) {
        String validationText = businesspremises.validationText().getText();
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(validationText + " is displayed", validationContents.get(i).get(0).equalsIgnoreCase(validationText));
            } else if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue("Element is not displayed", !validationContents.get(i).get(0).equalsIgnoreCase(validationText));
            }
        }
    }

    public void requiredMessageMain(List<List<String>> validationContents) {
        String requiredMsg = businesspremises.requiredTextMain().getText();
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(requiredMsg + " is displayed", validationContents.get(i).get(0).equalsIgnoreCase(requiredMsg));
            } else if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue("Element is not displayed", !validationContents.get(i).get(0).equalsIgnoreCase(requiredMsg));
            }
        }
    }

    public void requiredMessageOut(List<List<String>> validationContents) {
        String requiredMsg = businesspremises.requiredTextOut().getText();
        for (int i = 1; i < validationContents.size(); i++) {
            if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(requiredMsg + " is displayed", validationContents.get(i).get(0).equalsIgnoreCase(requiredMsg));
            } else if (validationContents.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue("Element is not displayed", !validationContents.get(i).get(0).equalsIgnoreCase(requiredMsg));
            }
        }
    }

    public void bedroomQuestionddlValuesMain(List<List<String>> data, WebElement property) throws Throwable {
        List<WebElement> dropDownList = new Select(property).getOptions();
        for (WebElement suggestion : dropDownList) {
            String dropDownValues = suggestion.getText();
            for (int i = 1; i < data.size(); i++) {
                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    if (data.get(i).get(0).equalsIgnoreCase((dropDownValues).trim())) {
                        Assert.assertTrue(dropDownValues + "is displayed", data.get(i).get(0).equalsIgnoreCase((dropDownValues).trim()));
                    }
                }
            }
        }
    }

    public void bedroomQuestionddlValuesOut(List<List<String>> data, WebElement property) throws Throwable {
        List<WebElement> dropDownList = new Select(property).getOptions();
        for (WebElement suggestion : dropDownList) {
            String dropDownValues = suggestion.getText();
            for (int i = 1; i < data.size(); i++) {
                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    if (data.get(i).get(0).equalsIgnoreCase((dropDownValues).trim())) {
                        Assert.assertTrue(dropDownValues + "is displayed", data.get(i).get(0).equalsIgnoreCase((dropDownValues).trim()));
                    }
                }
            }
        }
    }

    public void bedRoomNumberMain(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.trim().equalsIgnoreCase("")) {
            commonutil.setValue(columnValue, columnName, "MainBuilding_BedRoomNumber", businesspremises.bedRoomFreeFormatMain(i));
        }
    }

    public void bedRoomNumberOut(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.trim().equalsIgnoreCase("")) {
            commonutil.setValue(columnValue, columnName, "OutBuilding_BedRoomNumber", businesspremises.bedRoomFreeFormatOut(k));
        }
    }

    public void bedRoomMain(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            commonutil.waitForPageLoad();
            commonutil.selectElement(columnValue, columnName, "MainBuilding_BedRoom", businesspremises.selectBedRoomDropdownMain(k));
        }
    }

    public void bedRoomOut(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            commonutil.selectElement(columnValue, columnName, "MainBuilding_BedRoom", businesspremises.selectBedRoomDropdownOut(k));
        }
    }

    public void validateBedRoomddlMain(List<List<String>> data) throws Throwable {
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                String bedroomquestnmain = businesspremises.selectBedRoomDropdownMainLbl().getText();
                Assert.assertTrue(bedroomquestnmain + "is displayed", data.get(i).get(0).equalsIgnoreCase(bedroomquestnmain));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(bedRoomQuestionNotDisplayed());
            }
        }
    }

    public boolean bedRoomQuestionNotDisplayed() throws Throwable {
        try {
            return false;
        } catch (WebDriverException e) {
            return true;
        }
        }

    public void validateBedRoomddlOut(List<List<String>> data) throws Throwable {
        String bedroomquestnout = businesspremises.selectBedRoomDropdownOutLbl().getText();
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(bedroomquestnout + "is displayed", data.get(i).get(0).equalsIgnoreCase(bedroomquestnout));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(bedRoomQuestionNotDisplayed());
            }
        }
    }

    public void validateBedRoomFreeFormatMain(List<List<String>> data, int k) throws Throwable {
        String bedroomquestnfreefrmtmain = businesspremises.bedRoomFreeFormatMainLbl().getText();
        String bedroomfreeformat = businesspremises.bedRoomFreeFormatMain(k).getText();
        if ((!bedroomquestnfreefrmtmain.equalsIgnoreCase("")) && (bedroomfreeformat.equalsIgnoreCase(""))) {
            for (int i = 1; i < data.size(); i++) {
                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(bedroomquestnfreefrmtmain + "is displayed", data.get(i).get(0).equalsIgnoreCase(bedroomquestnfreefrmtmain));
                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue(bedroomquestnfreefrmtmain + "is displayed", !data.get(i).get(0).equalsIgnoreCase(bedroomquestnfreefrmtmain));
                }
            }
        }
    }

    public void validateBedRoomFreeFormatOut(List<List<String>> data, int k) throws Throwable {
        String bedroomquestnfreefrmtout = businesspremises.bedRoomFreeFormatOutLbl().getText();
        String bedroomfreeformat = businesspremises.bedRoomFreeFormatMain(k).getText();
        if ((!bedroomquestnfreefrmtout.equalsIgnoreCase("")) && (bedroomfreeformat.equalsIgnoreCase(""))) {
            for (int i = 1; i < data.size(); i++) {
                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    Assert.assertTrue(bedroomquestnfreefrmtout + "is displayed", data.get(i).get(0).equalsIgnoreCase(bedroomquestnfreefrmtout));
                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue(bedroomquestnfreefrmtout + "is displayed", !data.get(i).get(0).equalsIgnoreCase(bedroomquestnfreefrmtout));
                }
            }
        }
    }

    public void firePlaceout(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {

        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                businesspremises.pageLoading();
                businesspremises.executeScript("arguments[0].click();", obj_businessPremises.fireplaceOutYesRadiobutton(k));
                businesspremises.pageLoading();
            } else if (strVal.equalsIgnoreCase("No")) {
                businesspremises.pageLoading();
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.fireplaceOutNoRadiobutton(k));
                businesspremises.pageLoading();
            } else if (strVal.equalsIgnoreCase("Not Heated")) {
                businesspremises.pageLoading();
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.fireplaceOutNotheatedRadiobutton(k));
                businesspremises.pageLoading();
            }
        }
    }

    public void electricheaterout(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.electricheaterOutRadiobutton(strVal, k));
            businesspremises.pageLoading();
        }
    }

    public void selfCateringQuestionValidation(List<List<String>> data) throws Throwable {
        int size = businesspremises.selfCateringQuestionLabelHB().size();
        if (size == 1) {
            Assert.assertTrue(businesspremises.selfCateringQuestionLabelHB().size() == 1);
        } else {
            Assert.assertFalse(false);
        }
    }

    public void selfCateringQuestionValidationBB(List<List<String>> data) throws Throwable {
        String strValue = businesspremises.selfCateringQuestionLabel().getText();
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(strValue + "is displayed", data.get(i).get(0).equalsIgnoreCase(strValue));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(strValue + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(strValue));
            }
        }
    }

    public void selfCateringHelpTextValidation(List<List<String>> data) throws Throwable {
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                String expectedText = data.get(i).get(0);
                peoplebusinesutil.validateHelpTextPresent(expectedText, businesspremises.selfCateringHelpTextValue());
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                String expectedText = data.get(i).get(0);
                Assert.assertTrue(expectedText + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(expectedText));
            }
        }
    }

    public void commMainBuildingUsage(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            commonutil.selectElement(columnValue, columnName, "Mainbuilding_BuildingUsage", businesspremises.mainBuildingUsageDDL(i));
            commonutil.waitForPageLoad();
        }
    }

    public void commOutBuildingUsage(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            commonutil.selectElement(columnValue, columnName, "Outbuilding_BuildingUsage", businesspremises.commOutBuildingUsageDropDown(i));
            commonutil.waitForPageLoad();
        }
    }

    public void premiseTypeDropDownValidation(List<List<String>> data) throws Throwable {
        String strValue = businesspremises.riskAddressQuestion().getText();
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(strValue + "is displayed", data.get(i).get(0).equalsIgnoreCase(strValue));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(strValue + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(strValue));
            }
        }
    }

    public void selfCateringMain(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                commonutil.clickbyJS(businesspremises.mainSelfCateringQuestionYesRadioButton(i));
            } else if (strVal.equalsIgnoreCase("No")) {
                commonutil.clickbyJS(businesspremises.mainSelfCateringQuestionNoRadioButton(i));
            }
        }
    }

    public void selfCateringOut(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                commonutil.clickbyJS(businesspremises.outSelfCateringQuestionYesRadioButton(i));
            } else if (strVal.equalsIgnoreCase("No")) {
                commonutil.clickbyJS(businesspremises.outSelfCateringQuestionNoRadioButton(i));
            }
        }
    }

    public void mainBuildingUsage(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            commonutil.selectElement(columnValue, columnName, "Mainbuilding_BuildingUsage", businesspremises.mainBuildingUsageDropDown(i));
        }
    }

    public void mainBuildingFreeFormat(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            commonutil.setValue(columnValue, columnName, "PleaseTellUsBuildingUsedFor", businesspremises.buiildingUsageFreeformattext(i));
        }
    }

    public void outBuildingUsage(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            commonutil.selectElement(columnValue, columnName, "Outbuilding_BuildingUsage", businesspremises.outBuildingUsageDropDown(i));
        }
    }

    public void riskAddressRelatedQuestionVerification(List<List<String>> data) throws Throwable {
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                if (data.get(i).get(1).equalsIgnoreCase("Your household contents")) {
                    String strValue = businesspremises.houseHoldContentLable().getText();
                    Assert.assertTrue(strValue + "is displayed", data.get(i).get(0).equalsIgnoreCase(strValue));
                } else if (data.get(i).get(1).equalsIgnoreCase("Building type")) {
                    String strValue = businesspremises.buildingTypeLable().getText();
                    Assert.assertTrue(strValue + "is displayed", data.get(i).get(0).equalsIgnoreCase(strValue));
                } else if (data.get(i).get(1).equalsIgnoreCase("Do your premises have an ATM?")) {
                    String strValue = businesspremises.lableATM().getText();
                    Assert.assertTrue(strValue + "is displayed", data.get(i).get(0).equalsIgnoreCase(strValue));
                }
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                String strValue = businesspremises.riskAddressQuestion().getText();
                Assert.assertTrue(strValue + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(strValue));
            }
        }
    }

    public void riskAddressQuestionChecked(List<List<String>> data, int k) throws Throwable {
        String verifyChecked = businesspremises.checkedPremisesType(k).getAttribute("checked");
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element is checked by default$")) {
                Assert.assertTrue(verifyChecked + "is defaulted", data.get(i).get(0).equalsIgnoreCase(verifyChecked));
            } else if (data.get(i).get(1).equalsIgnoreCase("Element is not checked by default$")) {
                Assert.assertTrue(verifyChecked + "is not defaulted", !data.get(i).get(0).equalsIgnoreCase(verifyChecked));
            }
        }
    }

    public void validateGrade1Listed(List<List<String>> data) {
        String premiseGrade1Listed = businesspremises.premiseGrade1ListedLbl().getText();
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(premiseGrade1Listed + "is displayed", data.get(i).get(0).equalsIgnoreCase(premiseGrade1Listed));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(premiseGrade1Listed + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(premiseGrade1Listed));
            }
        }
    }

    public void validateOutGrade1Listed(List<List<String>> data) {
        String outGrade1Listed = businesspremises.outPremiseGrade1ListedLbl().getText();
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(outGrade1Listed + "is displayed", data.get(i).get(0).equalsIgnoreCase(outGrade1Listed));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(outGrade1Listed + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(outGrade1Listed));
            }
        }
    }

    public void shareOccupancyHome(List<List<String>> data) {
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                List<WebElement> ele = getDriver.findElements(By.xpath(businesspremises.homeSharedOccupancyLbl()));
                String[] linkText = new String[ele.size()];
                int xsi = ele.size();
                if (xsi == 1) {
                    linkText[0] = getDriver.findElement(By.xpath(businesspremises.homeSharedOccupancyLbl())).getText();
                    Assert.assertTrue(linkText[0] + "is displayed", data.get(i).get(0).equalsIgnoreCase(linkText[0]));
                } else if (xsi == 0) {
                    Assert.assertTrue(linkText[0] + "is not displayed", data.get(i).get(0).equalsIgnoreCase(linkText[0]));
                }
            }
        }
    }

    public void shareOccupancyCommercial(List<List<String>> data) {
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                List<WebElement> ele = getDriver.findElements(By.xpath(businesspremises.salonSharedOccupancyLbl()));
                String[] linkText = new String[ele.size()];
                int xsi = ele.size();
                if (xsi == 1) {
                    linkText[0] = getDriver.findElement(By.xpath(businesspremises.salonSharedOccupancyLbl())).getText();
                    Assert.assertTrue(linkText[0] + "is displayed", data.get(i).get(0).equalsIgnoreCase(linkText[0]));
                } else if (xsi == 0) {
                    Assert.assertTrue(linkText[0] + "is not displayed", data.get(i).get(0).equalsIgnoreCase(linkText[0]));
                }
            }
        }
    }

    public void occupancyTypes(List<List<String>> data) {
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                if (data.get(i).get(0).equalsIgnoreCase("flats")) {
                    String strFlats = businesspremises.flatsOption().getText();
                    Assert.assertTrue(strFlats + "is displayed", data.get(i).get(0).equalsIgnoreCase(strFlats));
                } else if (data.get(i).get(0).equalsIgnoreCase("offices")) {
                    String strOffices = businesspremises.officesOption().getText();
                    Assert.assertTrue(strOffices + "is displayed", data.get(i).get(0).equalsIgnoreCase(strOffices));
                } else if (data.get(i).get(0).equalsIgnoreCase("Food take-aways, pubs, restaurants, coffee shops, bars")) {
                    String strFoodtakeaway = businesspremises.foodTakeAwayOption().getText();
                    Assert.assertTrue(strFoodtakeaway + "is displayed", data.get(i).get(0).equalsIgnoreCase(strFoodtakeaway));
                } else if (data.get(i).get(0).equalsIgnoreCase("Other type of retail units")) {
                    String strRetail = businesspremises.retailOption().getText();
                    Assert.assertTrue(strRetail + "is displayed", data.get(i).get(0).equalsIgnoreCase(strRetail));
                } else if (data.get(i).get(0).equalsIgnoreCase("Vacant commercial units")) {
                    String strVacant = businesspremises.vacantOption().getText();
                    Assert.assertTrue(strVacant + "is displayed", data.get(i).get(0).equalsIgnoreCase(strVacant));
                } else if (data.get(i).get(0).equalsIgnoreCase("Other types of commercial units")) {
                    String strCommercial = businesspremises.commercialOption().getText();
                    Assert.assertTrue(strCommercial + "is displayed", data.get(i).get(0).equalsIgnoreCase(strCommercial));
                }
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                if (data.get(i).get(0).equalsIgnoreCase("flats")) {
                    String strFlats = businesspremises.flatsOption().getText();
                    Assert.assertTrue(strFlats + "is displayed", !data.get(i).get(0).equalsIgnoreCase(strFlats));
                } else if (data.get(i).get(0).equalsIgnoreCase("offices")) {
                    String strOffices = businesspremises.officesOption().getText();
                    Assert.assertTrue(strOffices + "is displayed", !data.get(i).get(0).equalsIgnoreCase(strOffices));
                } else if (data.get(i).get(0).equalsIgnoreCase("Food take-aways, pubs, restaurants, coffee shops, bars")) {
                    String strFoodtakeaway = businesspremises.foodTakeAwayOption().getText();
                    Assert.assertTrue(strFoodtakeaway + "is displayed", !data.get(i).get(0).equalsIgnoreCase(strFoodtakeaway));
                } else if (data.get(i).get(0).equalsIgnoreCase("Other type of retail units")) {
                    String strRetail = businesspremises.retailOption().getText();
                    Assert.assertTrue(strRetail + "is displayed", !data.get(i).get(0).equalsIgnoreCase(strRetail));
                } else if (data.get(i).get(0).equalsIgnoreCase("Vacant commercial units")) {
                    String strVacant = businesspremises.vacantOption().getText();
                    Assert.assertTrue(strVacant + "is displayed", !data.get(i).get(0).equalsIgnoreCase(strVacant));
                } else if (data.get(i).get(0).equalsIgnoreCase("Other types of commercial units")) {
                    String strCommercial = businesspremises.commercialOption().getText();
                    Assert.assertTrue(strCommercial + "is displayed", !data.get(i).get(0).equalsIgnoreCase(strCommercial));
                }
            }
        }
    }

    public void occupancyType(List<List<String>> data, String fieldName) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        if (!StrVal.equalsIgnoreCase("")) {
            String[] type = StrVal.split(",");
            for (String occupancyTypes : type) {
                if (occupancyTypes.equalsIgnoreCase("flats")) {
                    commonutil.clickbyJS(businesspremises.flatsOption());
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                } else if (occupancyTypes.equalsIgnoreCase("offices")) {
                    obj_businessPremises.executeScript("arguments[0].click();", businesspremises.officesOption());
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                } else if (occupancyTypes.equalsIgnoreCase("Food take-aways, pubs, restaurants, coffee shops, bars")) {
                    obj_businessPremises.executeScript("arguments[0].click();", businesspremises.foodTakeAwayOption());
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                } else if (occupancyTypes.equalsIgnoreCase("Other type of retail units")) {
                    obj_businessPremises.executeScript("arguments[0].click();", businesspremises.retailOption());
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                } else if (occupancyTypes.equalsIgnoreCase("Vacant commercial units")) {
                    obj_businessPremises.executeScript("arguments[0].click();", businesspremises.vacantOption());
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                } else if (occupancyTypes.equalsIgnoreCase("Other types of commercial units")) {
                    obj_businessPremises.executeScript("arguments[0].click();", businesspremises.commercialOption());
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                }
            }
        }
    }

    public void soleControl(List<List<String>> data, String fieldName, int k) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        if (!StrVal.equalsIgnoreCase("")) {
            if (StrVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.soleControlYesButton(k));
            } else if (StrVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.soleControlNoButton(k));
            }
        }
    }

    public void outPremiseGrade(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.outPremiseGradeYesRadiobutton(k));
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", obj_businessPremises.outPremiseGradeNoRadiobutton(k));
            }
        }
    }

    public void outWallMaterial(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                commonutil.clickbyJS(businesspremises.outWallMaterialYesRadiobutton(k));
            } else if (strVal.equalsIgnoreCase("No")) {
                commonutil.clickbyJS(businesspremises.outWallMaterialNoRadiobutton(k));
            }
        }
    }

    public void outWallMaterialTimber(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                commonutil.clickbyJS(businesspremises.outWallMaterialTimberYesRadiobutton(k));
            } else if (strVal.equalsIgnoreCase("No")) {
                commonutil.clickbyJS(businesspremises.outWallMaterialTimberNoRadiobutton(k));
            }
        }
    }

    public void outRoofMaterial(List<String> columnValue, List<String> columnName, String fieldName, int k) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.outRoofMaterialYesRadiobutton(k));
            } else if (strVal.equalsIgnoreCase("No")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.outRoofMaterialNoRadiobutton(k));
            }
        }
    }

    public void buildingUsageDropDown(List<List<String>> data, WebElement property) throws Throwable {
        List<WebElement> dropDownList = new Select(property).getOptions();
        for (WebElement suggestion : dropDownList) {
            String dropDownValues = suggestion.getText();
            for (int i = 1; i < data.size(); i++) {
                if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                    if (data.get(i).get(0).equalsIgnoreCase((dropDownValues).trim())) {
                        Assert.assertTrue(dropDownValues + "is displayed", data.get(i).get(0).equalsIgnoreCase((dropDownValues).trim()));
                    }
                } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue(dropDownValues + "is not displayed", !data.get(i).get(0).equalsIgnoreCase((dropDownValues).trim()));
                }
            }
        }
    }

    public void buildingUsageHelpText(List<List<String>> data) throws Throwable {
        obj_businessPremises.executeScript("arguments[0].click();", businesspremises.buildingUsageHelpTextQuestionMark());
        String helpText = businesspremises.buildingUsageHelpText().getText();
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(helpText + "is displayed", data.get(i).get(0).equalsIgnoreCase(helpText));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(helpText + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(helpText));
            }
        }
    }

    public void premiseQuestionValidation(List<List<String>> data) throws Throwable {
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                if (data.get(i).get(0).equalsIgnoreCase("how many bedrooms are there in this building?")) {
                    String strValue = businesspremises.selectBedRoomDropdownMainLbl().getText();
                    Assert.assertTrue(strValue + "is displayed", data.get(i).get(0).equalsIgnoreCase(strValue));
                } else if (data.get(i).get(0).equalsIgnoreCase("Please enter the number of bedrooms")) {
                    String strValue = businesspremises.bedRoomFreeFormatMainLbl().getText();
                    Assert.assertTrue(strValue + "is displayed", data.get(i).get(0).equalsIgnoreCase(strValue));
                } else if (data.get(i).get(0).equalsIgnoreCase("What is this building used for?")) {
                    String strValue = businesspremises.mainBuildingUsageDropDownLbl().getText();
                    Assert.assertTrue(strValue + "is displayed", data.get(i).get(0).equalsIgnoreCase(strValue));
                } else if (data.get(i).get(0).equalsIgnoreCase("Please tell us what this building is used for")) {
                    String strValue = businesspremises.buildingUsageFreeFormatlbl().getText();
                    Assert.assertTrue(strValue + "is displayed", data.get(i).get(0).equalsIgnoreCase(strValue));
                }
            }
        }
    }

    public void buildingUsageValidationMessage(List<List<String>> data, WebElement property) throws Throwable {
        String validationMessage = property.getText();
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                Assert.assertTrue(validationMessage + "is displayed", data.get(i).get(0).equalsIgnoreCase(validationMessage));
            } else if (data.get(i).get(1).equalsIgnoreCase("$Element should not be present$")) {
                Assert.assertTrue(validationMessage + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(validationMessage));
            }
        }
    }

    public void homeSecurityFeatureValidation(List<List<String>> data) {
        for (int j = 0; j < data.size(); j++) {
            String features = businesspremises.homeFeaturesList().getText();
            String strFeatures[] = features.split("\n");
            for (String securityFeatures : strFeatures) {
                if (data.get(j).get(1).equalsIgnoreCase("$Element should be present$")) {
                    if (data.get(j).get(0).equals(securityFeatures)) {
                        Assert.assertTrue(securityFeatures + "is displayed", data.get(j).get(0).equals(securityFeatures));
                    }
                } else if (data.get(j).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue(securityFeatures + "is not displayed", !data.get(j).get(0).equals(securityFeatures));
                }
            }
        }
    }

    public void outHomeSecurityFeatureValidation(List<List<String>> data) {
        for (int j = 0; j < data.size(); j++) {
            String features = businesspremises.outHomeFeaturesList().getText();
            String strFeatures[] = features.split("\n");
            for (String securityFeatures : strFeatures) {
                if (data.get(j).get(1).equalsIgnoreCase("$Element should be present$")) {
                    if (data.get(j).get(0).equals(securityFeatures)) {
                        Assert.assertTrue(securityFeatures + "is displayed", data.get(j).get(0).equals(securityFeatures));
                    }
                } else if (data.get(j).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue(securityFeatures + "is not displayed", !data.get(j).get(0).equals(securityFeatures));
                }
            }
        }
    }

    public void commercialSecurityFeatureValidation(List<List<String>> data) {
        for (int j = 0; j < data.size(); j++) {
            String features = businesspremises.salonFeaturesList().getText();
            String strFeatures[] = features.split("\n");
            for (String securityFeatures : strFeatures) {
                if (data.get(j).get(1).equalsIgnoreCase("$Element should be present$")) {
                    if (data.get(j).get(0).equals(securityFeatures)) {
                        Assert.assertTrue(securityFeatures + "is displayed", data.get(j).get(0).equals(securityFeatures));
                    }
                } else if (data.get(j).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue(securityFeatures + "is not displayed", !data.get(j).get(0).equals(securityFeatures));
                }
            }
        }
    }

    public void outCommercialSecurityFeatureValidation(List<List<String>> data) {
        for (int j = 0; j < data.size(); j++) {
            String features = businesspremises.outSalonFeaturesList().getText();
            String strFeatures[] = features.split("\n");
            for (String securityFeatures : strFeatures) {
                if (data.get(j).get(1).equalsIgnoreCase("$Element should be present$")) {
                    if (data.get(j).get(0).equals(securityFeatures)) {
                        Assert.assertTrue(securityFeatures + "is displayed", data.get(j).get(0).equals(securityFeatures));
                    }
                } else if (data.get(j).get(1).equalsIgnoreCase("$Element should not be present$")) {
                    Assert.assertTrue(securityFeatures + "is not displayed", !data.get(j).get(0).equals(securityFeatures));
                }
            }
        }
    }

    public void burglarAlamQuestion(List<List<String>> data) {
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                if (data.get(i).get(0).equalsIgnoreCase("Please select your type of burglar alarm?")) {
                    String strAlarmType = businesspremises.typeOfBuglarAlarmLbl().getText();
                    Assert.assertTrue(strAlarmType + "is displayed", data.get(i).get(0).equalsIgnoreCase(strAlarmType));
                } else if (data.get(i).get(0).equalsIgnoreCase("Is the alarm under your business' sole control?")) {
                    String strAlarmSoleControl = businesspremises.alarmSoleControlLbl().getText();
                    Assert.assertTrue(strAlarmSoleControl + "is displayed", data.get(i).get(0).equalsIgnoreCase(strAlarmSoleControl));
                } else if (data.get(i).get(0).equalsIgnoreCase("Does your alarm have police response?")) {
                    String strPoliceResponse = businesspremises.alarmPoliceResponseLbl().getText();
                    Assert.assertTrue(strPoliceResponse + "is displayed", data.get(i).get(0).equalsIgnoreCase(strPoliceResponse));
                } else if (data.get(i).get(0).equalsIgnoreCase("Who maintains the alarm?")) {
                    String strAlarmMaintain = businesspremises.alarmMaintainLbl().getText();
                    Assert.assertTrue(strAlarmMaintain + "is displayed", data.get(i).get(0).equalsIgnoreCase(strAlarmMaintain));
                }
            } else if (data.get(i).get(0).equalsIgnoreCase("Please select your type of burglar alarm?")) {
                String strAlarmType = businesspremises.typeOfBuglarAlarmLbl().getText();
                Assert.assertTrue(strAlarmType + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(strAlarmType));
            } else if (data.get(i).get(0).equalsIgnoreCase("Is the alarm under your business' sole control?")) {
                String strAlarmSoleControl = businesspremises.alarmSoleControlLbl().getText();
                Assert.assertTrue(strAlarmSoleControl + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(strAlarmSoleControl));
            } else if (data.get(i).get(0).equalsIgnoreCase("Does your alarm have police response?")) {
                String strPoliceResponse = businesspremises.alarmPoliceResponseLbl().getText();
                Assert.assertTrue(strPoliceResponse + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(strPoliceResponse));
            } else if (data.get(i).get(0).equalsIgnoreCase("Who maintains the alarm?")) {
                String strAlarmMaintain = businesspremises.alarmMaintainLbl().getText();
                Assert.assertTrue(strAlarmMaintain + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(strAlarmMaintain));
            }
        }
    }

    public void outBurglarAlamQuestion(List<List<String>> data) {
        for (int i = 1; i < data.size(); i++) {
            if (data.get(i).get(1).equalsIgnoreCase("$Element should be present$")) {
                if (data.get(i).get(0).equalsIgnoreCase("Please select your type of burglar alarm?")) {
                    String strAlarmType = businesspremises.outTypeOfBuglarAlarmLbl().getText();
                    Assert.assertTrue(strAlarmType + "is displayed", data.get(i).get(0).equalsIgnoreCase(strAlarmType));
                } else if (data.get(i).get(0).equalsIgnoreCase("Is the alarm under your business' sole control?")) {
                    String strAlarmSoleControl = businesspremises.outAlarmSoleControlLbl().getText();
                    Assert.assertTrue(strAlarmSoleControl + "is displayed", data.get(i).get(0).equalsIgnoreCase(strAlarmSoleControl));
                } else if (data.get(i).get(0).equalsIgnoreCase("Does your alarm have police response?")) {
                    String strPoliceResponse = businesspremises.outAlarmPoliceResponseLbl().getText();
                    Assert.assertTrue(strPoliceResponse + "is displayed", data.get(i).get(0).equalsIgnoreCase(strPoliceResponse));
                } else if (data.get(i).get(0).equalsIgnoreCase("Who maintains the alarm?")) {
                    String strAlarmMaintain = businesspremises.outAlarmMaintainLbl().getText();
                    Assert.assertTrue(strAlarmMaintain + "is displayed", data.get(i).get(0).equalsIgnoreCase(strAlarmMaintain));
                }
            } else if (data.get(i).get(0).equalsIgnoreCase("Please select your type of burglar alarm?")) {
                String strAlarmType = businesspremises.outTypeOfBuglarAlarmLbl().getText();
                Assert.assertTrue(strAlarmType + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(strAlarmType));
            } else if (data.get(i).get(0).equalsIgnoreCase("Is the alarm under your business' sole control?")) {
                String strAlarmSoleControl = businesspremises.outAlarmSoleControlLbl().getText();
                Assert.assertTrue(strAlarmSoleControl + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(strAlarmSoleControl));
            } else if (data.get(i).get(0).equalsIgnoreCase("Does your alarm have police response?")) {
                String strPoliceResponse = businesspremises.outAlarmPoliceResponseLbl().getText();
                Assert.assertTrue(strPoliceResponse + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(strPoliceResponse));
            } else if (data.get(i).get(0).equalsIgnoreCase("Who maintains the alarm?")) {
                String strAlarmMaintain = businesspremises.outAlarmMaintainLbl().getText();
                Assert.assertTrue(strAlarmMaintain + "is not displayed", !data.get(i).get(0).equalsIgnoreCase(strAlarmMaintain));
            }
        }
    }

    public void homeSecurityFeature(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            String[] type = strVal.split(",");
            for (String securityTypes : type) {
                if (securityTypes.equalsIgnoreCase("CCTV with 24 hour recording")) {
                    commonutil.clickbyJS(businesspremises.homeCctvOption(i));
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                } else if (securityTypes.equalsIgnoreCase("Burglar alarm")) {
                    commonutil.clickbyJS(businesspremises.homeBurglarOption(i));
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                } else if (securityTypes.equalsIgnoreCase("None of the above")) {
                    commonutil.clickbyJS(businesspremises.homeNoneOption(i));
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                }
            }
        }
    }

    public void policeResponse(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            commonutil.selectElement(columnValue, columnName, "PoliceResponse", businesspremises.policeResponse(i));
            commonutil.waitForPageLoad();
        }
    }

    public void maintenance(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            commonutil.selectElement(columnValue, columnName, "Maintenance", businesspremises.alarmMaintenance(i));
            commonutil.waitForPageLoad();
        }
    }

    public void underControl(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.underControlYes(i));
                commonutil.waitForPageLoad();
            } else if (strVal.equalsIgnoreCase("No"))
                commonutil.selectElement(columnValue, columnName, "UnderControl", businesspremises.underControlNo(i));
            commonutil.waitForPageLoad();
        }
    }

    public void burglarType(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            commonutil.selectElement(columnValue, columnName, "BurglarType", businesspremises.alarmType(i));
            commonutil.waitForPageLoad();
        }
    }

    public void commercialSecurityFeature(List<String> columnValue, List<String> columnName, String fieldName, int i) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            String[] type = strVal.split(";");
            for (String securityTypes : type) {
                if (securityTypes.equalsIgnoreCase("CCTV with 24 hour recording")) {
                    commonutil.clickbyJS(businesspremises.saloncctvOption(i));
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                } else if (securityTypes.equalsIgnoreCase("Burglar alarm")) {
                    commonutil.clickbyJS(businesspremises.salonBurglarOption(i));
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                } else if (securityTypes.equalsIgnoreCase("None of the above")) {
                    commonutil.clickbyJS(businesspremises.salonNoneOption(i));
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                } else if (securityTypes.equalsIgnoreCase("Bars and grilles")) {
                    commonutil.clickbyJS(businesspremises.salonBars(i));
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                } else if (securityTypes.equalsIgnoreCase("Steel-lined external doors")) {
                    commonutil.clickbyJS(businesspremises.salonSteel(i));
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                } else if (securityTypes.equalsIgnoreCase("Metal roller shutter")) {
                    commonutil.clickbyJS(businesspremises.salonMetal(i));
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                } else if (securityTypes.equalsIgnoreCase("Enclosed within a shopping centre")) {
                    commonutil.clickbyJS(businesspremises.salonShopping(i));
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                } else if (securityTypes.equalsIgnoreCase("You, members of your family or your employees live above the premises")) {
                    commonutil.clickbyJS(businesspremises.salonFamily(i));
                    commonutil.waitForPageLoad();
                    businesspremises.pageLoading();
                }
            }
        }
    }

    public void next(List<String> columnValue, List<String> columnName, String fieldName) throws Throwable {
        String strVal = commonutil.datapicker(columnValue, columnName, fieldName);
        if (!strVal.equalsIgnoreCase("")) {
            if (strVal.equalsIgnoreCase("Yes")) {
                obj_businessPremises.executeScript("arguments[0].click();", businesspremises.nextButton());
                Thread.sleep(3000);
                obj_propertyAway.businessToolsEquipmentYesRadiobutton();
            }
        }
    }

    public void removeCoverBtnTextBoxEnableCheck(WebElement removerCoverBtn,WebElement txtBox) throws Throwable{

       // String buttonText = (String) ((JavascriptExecutor) getDriver).executeScript("return arguments[0].value;",removerCoverBtn);
        String buttonText = removerCoverBtn.getAttribute("value");
        Assert.assertTrue("Remove Cover button is displayed",buttonText.equalsIgnoreCase("Remove cover"));
        Assert.assertTrue("TextBox is Enabled",txtBox.isEnabled());

    }

    public void addCoverBtnCheck(WebElement addCoverBtn) throws Throwable{

        String buttonText = addCoverBtn.getAttribute("value");
        Assert.assertTrue("Add Cover button is displayed",buttonText.equalsIgnoreCase("Add cover"));

    }

}