package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_Claims;

import java.util.List;

public class ClaimsUtil {

    private Obj_Claims claims = new Obj_Claims();
    private CommonUtil commonutil = new CommonUtil();

    public void previous_Losses(List<List<String>> data, String fieldName) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        if (StrVal.equalsIgnoreCase("Yes")) {
            claims.executeScript("arguments[0].click();", claims.previousLossesYesRadiobutton());
        } else {
            claims.executeScript("arguments[0].click();", claims.previousLossesNoRadiobutton());
        }
    }
}
