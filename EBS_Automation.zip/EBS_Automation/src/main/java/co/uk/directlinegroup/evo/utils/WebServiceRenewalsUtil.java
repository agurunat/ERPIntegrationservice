package co.uk.directlinegroup.evo.utils;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * Created by 257783 on 10/10/2017.
 */
public class WebServiceRenewalsUtil {

    public String updateTheBusiness, updateLossHistory;
    public ArrayList<String> lossHistoryCompentityId;
    int f = 0;

    private ServiceUtil serviceUtil = new ServiceUtil();

    public String searchPolicy() throws IOException {

        File f = new File("src/test/resources/requests/pre-req/SearchPolicy.xml");
        String searchpolicy = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        searchpolicy = searchpolicy.replace("${#TestSuite#policy-id}", WebServiceFunctionalUtil.policynumber);
        return serviceUtil.getResponse(searchpolicy, System.getProperty("ENV") + "/SearchPolicyWS", "SearchPolicyWSService/searchPolicies");

    }

    public String inviteRenewal(String policyIdentity, String PositionIdentity, String schemeCode, String productClass) throws IOException {

        File f = new File("src/test/resources/requests/pre-req/InviteRenewal.xml");
        String inviteRenewal = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        inviteRenewal = inviteRenewal.replace("${#TestSuite#policy-id}", policyIdentity);
        inviteRenewal = inviteRenewal.replace("${#TestSuite#position-id}", PositionIdentity);
        inviteRenewal = inviteRenewal.replace("${#TestSuite#product-class}", productClass);
        inviteRenewal = inviteRenewal.replace("${#TestSuite#scheme-code}", schemeCode);
        return serviceUtil.getResponse(inviteRenewal, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/createRenewal");

    }

    public String recalculatePremium(String policyIdentity, String renewalPositionIdentity, String renewalVariationIdentity, String schemeCode, String productClass) throws IOException {
        File f = new File("src/test/resources/requests/pre-req/RecalculatePremium.xml");
        String recalculatePremium = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        recalculatePremium = recalculatePremium.replace("${#TestSuite#policy-id}", policyIdentity);
        recalculatePremium = recalculatePremium.replace("${#TestCase#position-id}", renewalPositionIdentity);
        recalculatePremium = recalculatePremium.replace("${#TestCase#variation-id}", renewalVariationIdentity);
        //recalculatePremium = recalculatePremium.replace("${#TestSuite#variation-id}", variationIdentity);
        recalculatePremium = recalculatePremium.replace("${#TestSuite#product-class}", productClass);
        recalculatePremium = recalculatePremium.replace("${#TestSuite#scheme-code}", schemeCode);
        return serviceUtil.getResponse(recalculatePremium, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/calculatePolicyPremium");

    }


    public String saveAsAccepted(String policyIdentity, String renewalPositionIdentity, String renewalVariationIdentity, String schemeCode, String productClass) throws IOException {

        File f = new File("src/test/resources/requests/pre-req/RenewalSaveAsAccepted.xml");
        String completeRenewal = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        completeRenewal = completeRenewal.replace("${#TestSuite#policy-id}", policyIdentity);
        completeRenewal = completeRenewal.replace("${#TestCase#position-id}", renewalPositionIdentity);
        completeRenewal = completeRenewal.replace("${#TestCase#variation-id}", renewalVariationIdentity);
        //completeRenewal = completeRenewal.replace("${#TestSuite#policy-id}", policyIdentity);
        //completeRenewal = completeRenewal.replace("${#TestSuite#position-id}", PositionIdentity);
        //completeRenewal = completeRenewal.replace("${#TestSuite#variation-id}", variationIdentity);
        completeRenewal = completeRenewal.replace("${#TestSuite#product-class}", productClass);
        completeRenewal = completeRenewal.replace("${#TestSuite#scheme-code}", schemeCode);
        return serviceUtil.getResponse(completeRenewal, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/completeRenewal");


    }


    public String writeNumberOfTrades(String noOfTrades, ArrayList<String> objectIdentity) throws Exception {


        if (!noOfTrades.equalsIgnoreCase("$null$")) {
            String[] trades = noOfTrades.split("#");
            Element lossDate = null;
            DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = domFactory.newDocumentBuilder();
            Document doc = builder.parse(new File("src/test/resources/requests/pre-req/updateTheBusiness.xml"));
            for (int t = 0; t < trades.length; t++) {

                String[] tradesVal = trades[t].split(":");
                //Telling that need to write these items between which node, node name is <urn1:component> in xml
                Element dataTag = doc.getDocumentElement();
                Element componentTag = (Element) dataTag.getElementsByTagName("urn1:component").item(0);
                //Creating the <urn1:listElement> node and their attributes, values
                Element listElement = doc.createElement("urn1:listElement");
                Attr attrType = doc.createAttribute("xsi:type");
                attrType.setValue("urn2:ComponentUpdateThe_BusinessItem");
                listElement.setAttributeNode(attrType);

                Element trade = doc.createElement("urn1:objectIdentity");
                trade.setTextContent(String.valueOf(objectIdentity.get(t+2)).replace("$null$", ""));

                //Creating the <urn2:trade> node within listElement node
                Element object = doc.createElement("urn2:trade");
                object.setTextContent(String.valueOf(tradesVal[0]).replace("$null$", ""));
                //Creating the <urn2:isMainTrade> node within listElement node
                Element isMainTrade = doc.createElement("urn2:isMainTrade");
                isMainTrade.setTextContent(String.valueOf(tradesVal[1]).replace("$null$", ""));
                //Creating the <urn2:segmentL1> node within listElement node
                Element segmentL1 = doc.createElement("urn2:segmentL1");
                segmentL1.setTextContent(String.valueOf(tradesVal[2]).replace("$null$", ""));
                //Creating the <urn2:segmentL2> node within listElement node
                Element segmentL2 = doc.createElement("urn2:segmentL2");
                segmentL2.setTextContent(String.valueOf(tradesVal[3]).replace("$null$", ""));
                //Creating the <urn2:tradeSegmentLevel1Int> node within listElement node
                Element tradeSegmentLevel1Int = doc.createElement("urn2:tradeSegmentLevel1Int");
                tradeSegmentLevel1Int.setTextContent(String.valueOf(tradesVal[4]).replace("$null$", ""));

                //Appdening these trade,trade,segmentL1,segmentL2 and tradeSegmentLevel1Int nodes as a childnode to listElement Node
                listElement.appendChild(object);
                listElement.appendChild(trade);
                listElement.appendChild(isMainTrade);
                listElement.appendChild(segmentL1);
                listElement.appendChild(segmentL2);
                listElement.appendChild(tradeSegmentLevel1Int);
                //Appdening all the list items of nodes within componentTag "<urn2:component>"
                componentTag.appendChild(listElement);
                f = 1;
            }


            //Writing the above items
            Transformer transformer = TransformerFactory.newInstance().newTransformer();
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");

            StreamResult result = new StreamResult(new StringWriter());
            DOMSource source = new DOMSource(doc);
            transformer.transform(source, result);

            updateTheBusiness = result.getWriter().toString();
        }
        return updateTheBusiness;
    }

    public String updateTheBusiness(HashMap<String, String> business, String policyIdentity, String PositionIdentity, String variationIdentity, String businessComponentIdentity, String dlgComponentIdentity, ArrayList<String> businessObjectIdentity) throws Exception {
        //Trades format like -132:true:1:1:1#A13:false:1:1:1
        List<String> businessKeys = new ArrayList<>(business.keySet());
        for (String strXmlParameterKey : businessKeys) {
            if (strXmlParameterKey.equalsIgnoreCase("strTradeLists")) {
                updateTheBusiness = writeNumberOfTrades(business.get(strXmlParameterKey),businessObjectIdentity);
                break;
            }
        }
        if (f == 0) {
            File f = new File("src/test/resources/requests/pre-req/updateTheBusiness.xml");
            updateTheBusiness = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
            updateTheBusiness = updateTheBusiness.replace("${#TestSuite#policy-id}", policyIdentity);
            updateTheBusiness = updateTheBusiness.replace("${#TestSuite#position-id}", PositionIdentity);
            updateTheBusiness = updateTheBusiness.replace("${#TestSuite#variation-id}", variationIdentity);
            updateTheBusiness = updateTheBusiness.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
            updateTheBusiness = updateTheBusiness.replace("${#TestSuite#DLG-comp-id}", dlgComponentIdentity);
            for (String strXmlParameterKey2 : businessKeys) {
                if (strXmlParameterKey2.equalsIgnoreCase("strTradeLists")) {
                    updateTheBusiness.replace(strXmlParameterKey2, "");
                } else {
                    updateTheBusiness = updateTheBusiness.replace(strXmlParameterKey2, String.valueOf(business.get(strXmlParameterKey2)).replace("$null$", ""));
                }
            }
        } else {
            updateTheBusiness = updateTheBusiness.replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
            updateTheBusiness = updateTheBusiness.replace("${#TestSuite#policy-id}", policyIdentity);
            updateTheBusiness = updateTheBusiness.replace("${#TestSuite#position-id}", PositionIdentity);
            updateTheBusiness = updateTheBusiness.replace("${#TestSuite#variation-id}", variationIdentity);
            updateTheBusiness = updateTheBusiness.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);
            updateTheBusiness = updateTheBusiness.replace("${#TestSuite#DLG-comp-id}", dlgComponentIdentity);
            for (String strXmlParameterKey1 : businessKeys) {
                if (strXmlParameterKey1.equalsIgnoreCase("strTradeLists")) {
                    updateTheBusiness.replace(strXmlParameterKey1, "");
                } else {
                    updateTheBusiness = updateTheBusiness.replace(strXmlParameterKey1, String.valueOf(business.get(strXmlParameterKey1)).replace("$null$", ""));
                }
            }
        }
        //System.out.println(updateTheBusiness);
        return serviceUtil.getResponse(updateTheBusiness, System.getProperty("ENV") + "/ListComponentUpdateSME_INSSMEv1", "ListComponentUpdateSME_INSSMEv1Service/updateExistingListComponent");
    }

    public String updatePremises(String policyIdentity, String PositionIdentity, String variationIdentity, String riskAddCompId, String businessComponentIdentity, HashMap<String, String> premises) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updatePremises.xml");
        List<String> premisesKeys = new ArrayList<>(premises.keySet());
        String updatePremises = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updatePremises = updatePremises.replace("${#TestSuite#policy-id}", policyIdentity);
        updatePremises = updatePremises.replace("${#TestSuite#position-id}", PositionIdentity);
        updatePremises = updatePremises.replace("${#TestSuite#variation-id}", variationIdentity);
        updatePremises = updatePremises.replace("${#TestSuite#risk_Add-comp-id}", riskAddCompId);
        updatePremises = updatePremises.replace("${#TestSuite#The_Business-comp-id}", businessComponentIdentity);

        for (String strXmlParameterKey : premisesKeys) {

            if (premises.get(strXmlParameterKey).equalsIgnoreCase("Commercial")) {
                updatePremises = updatePremises.replace(strXmlParameterKey, String.valueOf(premises.get(strXmlParameterKey)).replace("Commercial", "DL4B_PT20"));
            } else if (premises.get(strXmlParameterKey).equalsIgnoreCase("Home")) {
                updatePremises = updatePremises.replace(strXmlParameterKey, String.valueOf(premises.get(strXmlParameterKey)).replace("Home", "DL4B_PT10"));
            }
            updatePremises = updatePremises.replace(strXmlParameterKey, String.valueOf(premises.get(strXmlParameterKey)).replace("$null$", ""));
        }
        //System.out.println(updatePremises);
        return serviceUtil.getResponse(updatePremises, System.getProperty("ENV") + "/ListComponentUpdateSME_INSSMEv1", "ListComponentUpdateSME_INSSMEv1Service/updateExistingListComponent");
    }

    public String updateSubPremises(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseCompId, HashMap<String, String> subPremises) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateSubPremises.xml");
        List<String> keys = new ArrayList<>(subPremises.keySet());
        String updateSubPremises = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateSubPremises = updateSubPremises.replace("${#TestSuite#policy-id}", policyIdentity);
        updateSubPremises = updateSubPremises.replace("${#TestSuite#position-id}", PositionIdentity);
        updateSubPremises = updateSubPremises.replace("${#TestSuite#variation-id}", variationIdentity);
        updateSubPremises = updateSubPremises.replace("${#TestSuite#Premise-comp-id}", premiseCompId);
        for (String strXmlParameterKey : keys) {
            updateSubPremises = updateSubPremises.replace(strXmlParameterKey, String.valueOf(subPremises.get(strXmlParameterKey)).replace("$null$", ""));
        }
        //System.out.println(updateSubPremises);
        return serviceUtil.getResponse(updateSubPremises, System.getProperty("ENV") + "/ListComponentUpdateSME_INSSMEv1", "ListComponentUpdateSME_INSSMEv1Service/updateExistingListComponent");
    }

    public String updateBusinessContentsPremises(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseBussContCompId, String premiseCompId) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateBusinessContentsAtPremises.xml");
        String updateBusinessContentsPremises = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateBusinessContentsPremises = updateBusinessContentsPremises.replace("${#TestSuite#policy-id}", policyIdentity);
        updateBusinessContentsPremises = updateBusinessContentsPremises.replace("${#TestSuite#position-id}", PositionIdentity);
        updateBusinessContentsPremises = updateBusinessContentsPremises.replace("${#TestSuite#variation-id}", variationIdentity);
        updateBusinessContentsPremises = updateBusinessContentsPremises.replace("${#TestSuite#Premise_BussCnt-comp-id}", premiseBussContCompId);
        updateBusinessContentsPremises = updateBusinessContentsPremises.replace("${#TestSuite#Premise-comp-id}", premiseCompId);
        return serviceUtil.getResponse(updateBusinessContentsPremises, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateBusinessContentsPremisesItem(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseBussContCompIdFromItem, String premiseBussContCompId, String bussContContentType, String bussContAmount) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateBusinessContentsAtPremisesItem.xml");
        String updateBusinessContentsPremisesItem = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateBusinessContentsPremisesItem = updateBusinessContentsPremisesItem.replace("${#TestSuite#policy-id}", policyIdentity);
        updateBusinessContentsPremisesItem = updateBusinessContentsPremisesItem.replace("${#TestSuite#position-id}", PositionIdentity);
        updateBusinessContentsPremisesItem = updateBusinessContentsPremisesItem.replace("${#TestSuite#variation-id}", variationIdentity);
        updateBusinessContentsPremisesItem = updateBusinessContentsPremisesItem.replace("${#TestSuite#Prm_BusCont-comp-id}", premiseBussContCompIdFromItem);
        updateBusinessContentsPremisesItem = updateBusinessContentsPremisesItem.replace("${#TestSuite#Premise_BussCnt-comp-id}", premiseBussContCompId);
        updateBusinessContentsPremisesItem = updateBusinessContentsPremisesItem.replace("strContentsType", String.valueOf(bussContContentType).replace("$null$", ""));
        updateBusinessContentsPremisesItem = updateBusinessContentsPremisesItem.replace("strAmount", String.valueOf(bussContAmount).replace("$null$", ""));
        return serviceUtil.getResponse(updateBusinessContentsPremisesItem, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateStockPremises(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseStockCompId, String premiseCompId) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updatePremisesStock.xml");
        String updateStockPremises = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateStockPremises = updateStockPremises.replace("${#TestSuite#policy-id}", policyIdentity);
        updateStockPremises = updateStockPremises.replace("${#TestSuite#position-id}", PositionIdentity);
        updateStockPremises = updateStockPremises.replace("${#TestSuite#variation-id}", variationIdentity);
        updateStockPremises = updateStockPremises.replace("${#TestSuite#Premise_Stock-comp-id}", premiseStockCompId);
        updateStockPremises = updateStockPremises.replace("${#TestSuite#Premise-comp-id}", premiseCompId);
        return serviceUtil.getResponse(updateStockPremises, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateStockPremisesItem(String policyIdentity, String PositionIdentity, String variationIdentity, String prmStockCompIdFromItem, String premiseStockCompId, String strStockType, String strStockAmount) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updatePremisesStockItem.xml");
        String updateStockPremisesItem = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateStockPremisesItem = updateStockPremisesItem.replace("${#TestSuite#policy-id}", policyIdentity);
        updateStockPremisesItem = updateStockPremisesItem.replace("${#TestSuite#position-id}", PositionIdentity);
        updateStockPremisesItem = updateStockPremisesItem.replace("${#TestSuite#variation-id}", variationIdentity);
        updateStockPremisesItem = updateStockPremisesItem.replace("${#TestSuite#Premise_Stock-comp-id}", premiseStockCompId);
        updateStockPremisesItem = updateStockPremisesItem.replace("${#TestSuite#Prm_Stock-comp-id}", prmStockCompIdFromItem);
        updateStockPremisesItem = updateStockPremisesItem.replace("strStockAmount", String.valueOf(strStockAmount).replace("$null$", ""));
        updateStockPremisesItem = updateStockPremisesItem.replace("strStockType", String.valueOf(strStockType).replace("$null$", ""));
        return serviceUtil.getResponse(updateStockPremisesItem, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateSubsidence(String policyIdentity, String PositionIdentity, String variationIdentity, String subsidenceObjectIdentity, String riskAddCompId, String subsidenceValues) throws IOException {
        String[] subsidenceVal = subsidenceValues.split(",");
        File f = new File("src/test/resources/requests/pre-req/updateSubsidence.xml");
        String updateSubsidence = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateSubsidence = updateSubsidence.replace("${#TestSuite#policy-id}", policyIdentity);
        updateSubsidence = updateSubsidence.replace("${#TestSuite#position-id}", PositionIdentity);
        updateSubsidence = updateSubsidence.replace("${#TestSuite#variation-id}", variationIdentity);
        updateSubsidence = updateSubsidence.replace("SubsidenceObjectIdentity", subsidenceObjectIdentity);
        updateSubsidence = updateSubsidence.replace("${#TestSuite#risk_Add-comp-id}", riskAddCompId);
        updateSubsidence = updateSubsidence.replace("strSubsidenceHist", String.valueOf(subsidenceVal[0]).replace("$null$", ""));
        updateSubsidence = updateSubsidence.replace("strProximityRivBank", String.valueOf(subsidenceVal[1]).replace("$null$", ""));
        return serviceUtil.getResponse(updateSubsidence, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateHouseHoldContents(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseGroupCompId, String prmHouseCompId, String amount) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateHouseHoldContents.xml");
        String updateHouseHoldContents = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateHouseHoldContents = updateHouseHoldContents.replace("${#TestSuite#policy-id}", policyIdentity);
        updateHouseHoldContents = updateHouseHoldContents.replace("${#TestSuite#position-id}", PositionIdentity);
        updateHouseHoldContents = updateHouseHoldContents.replace("${#TestSuite#variation-id}", variationIdentity);
        updateHouseHoldContents = updateHouseHoldContents.replace("${#TestSuite#Premise_Group-comp-id}", premiseGroupCompId);
        updateHouseHoldContents = updateHouseHoldContents.replace("HouseHoldObjectIdentity", prmHouseCompId);
        updateHouseHoldContents = updateHouseHoldContents.replace("strHouseHoldAmount", amount);
        return serviceUtil.getResponse(updateHouseHoldContents, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateBuildings(String policyIdentity, String PositionIdentity, String variationIdentity, String prmBuildCompId, String premiseGroupCompId, String amount) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateBuilding.xml");
        String updateBuildings = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateBuildings = updateBuildings.replace("${#TestSuite#policy-id}", policyIdentity);
        updateBuildings = updateBuildings.replace("${#TestSuite#position-id}", PositionIdentity);
        updateBuildings = updateBuildings.replace("${#TestSuite#variation-id}", variationIdentity);
        updateBuildings = updateBuildings.replace("BuildingPrmBuildCompId", prmBuildCompId);
        updateBuildings = updateBuildings.replace("${#TestSuite#Premise_Group-comp-id}", premiseGroupCompId);
        updateBuildings = updateBuildings.replace("strBuildingAmount", amount);
        return serviceUtil.getResponse(updateBuildings, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateFrontGlass(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseGroupCompId, String prmFrtGlassCompId, String glassAmount) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateBuildingFrontGlass.xml");
        String updateFrontGlass = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateFrontGlass = updateFrontGlass.replace("${#TestSuite#policy-id}", policyIdentity);
        updateFrontGlass = updateFrontGlass.replace("${#TestSuite#position-id}", PositionIdentity);
        updateFrontGlass = updateFrontGlass.replace("${#TestSuite#variation-id}", variationIdentity);
        updateFrontGlass = updateFrontGlass.replace("BuildingPrmFrtGlassCompId", prmFrtGlassCompId);
        updateFrontGlass = updateFrontGlass.replace("${#TestSuite#Premise_Group-comp-id}", premiseGroupCompId);
        updateFrontGlass = updateFrontGlass.replace("strFrontGlassAmt", glassAmount);
        return serviceUtil.getResponse(updateFrontGlass, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateFixtureFittings(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseGroupCompId, String prmFixFitCompId, String fixFitAmount) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateFixtureFittings.xml");
        String updateFixtureFittings = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateFixtureFittings = updateFixtureFittings.replace("${#TestSuite#policy-id}", policyIdentity);
        updateFixtureFittings = updateFixtureFittings.replace("${#TestSuite#position-id}", PositionIdentity);
        updateFixtureFittings = updateFixtureFittings.replace("${#TestSuite#variation-id}", variationIdentity);
        updateFixtureFittings = updateFixtureFittings.replace("${#TestSuite#Premise_Group-comp-id}", premiseGroupCompId);
        updateFixtureFittings = updateFixtureFittings.replace("BuildingPrmFixFitCompId", prmFixFitCompId);
        updateFixtureFittings = updateFixtureFittings.replace("strFixFitAmt", fixFitAmount);
        return serviceUtil.getResponse(updateFixtureFittings, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateNamedItemsPremises(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseCompId, String premiseNamedItemsCompId) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateNamedItemsAtPremises.xml");
        String updateNamedItemsPremises = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateNamedItemsPremises = updateNamedItemsPremises.replace("${#TestSuite#policy-id}", policyIdentity);
        updateNamedItemsPremises = updateNamedItemsPremises.replace("${#TestSuite#position-id}", PositionIdentity);
        updateNamedItemsPremises = updateNamedItemsPremises.replace("${#TestSuite#variation-id}", variationIdentity);
        updateNamedItemsPremises = updateNamedItemsPremises.replace("${#TestSuite#Premise-comp-id}", premiseCompId);
        updateNamedItemsPremises = updateNamedItemsPremises.replace("premiseNamedItemsCompId", premiseNamedItemsCompId);
        return serviceUtil.getResponse(updateNamedItemsPremises, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateNamedItemsPremisesItem(String policyIdentity, String PositionIdentity, String variationIdentity, String premiseNamedItemsCompId, String prmSpcItmCompId, String itemType, String amount) throws Exception {
        File f = new File("src/test/resources/requests/pre-req/updateNamedItemsAtPremisesItem.xml");
        String updateNamedItemsPremisesItem = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateNamedItemsPremisesItem = updateNamedItemsPremisesItem.replace("${#TestSuite#policy-id}", policyIdentity);
        updateNamedItemsPremisesItem = updateNamedItemsPremisesItem.replace("${#TestSuite#position-id}", PositionIdentity);
        updateNamedItemsPremisesItem = updateNamedItemsPremisesItem.replace("${#TestSuite#variation-id}", variationIdentity);
        updateNamedItemsPremisesItem = updateNamedItemsPremisesItem.replace("NamedItemsPrmSpcItmCompId", prmSpcItmCompId);
        updateNamedItemsPremisesItem = updateNamedItemsPremisesItem.replace("${#TestSuite#Premise_NamedItems-comp-id}", premiseNamedItemsCompId);
        updateNamedItemsPremisesItem = updateNamedItemsPremisesItem.replace("strItemType", String.valueOf(itemType).replace("$null$", ""));
        updateNamedItemsPremisesItem = updateNamedItemsPremisesItem.replace("strAmount", String.valueOf(amount).replace("$null$", ""));
        return serviceUtil.getResponse(updateNamedItemsPremisesItem, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateBusinessContAwaySectionLevel(String policyIdentity, String PositionIdentity, String variationIdentity, String propertyAwayCompId, String busiContPropertyAwayCompId) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateBusinessContentAwaySectionLevel.xml");
        String updateBusiContAwaySecLevel = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateBusiContAwaySecLevel = updateBusiContAwaySecLevel.replace("${#TestSuite#policy-id}", policyIdentity);
        updateBusiContAwaySecLevel = updateBusiContAwaySecLevel.replace("${#TestSuite#position-id}", PositionIdentity);
        updateBusiContAwaySecLevel = updateBusiContAwaySecLevel.replace("${#TestSuite#variation-id}", variationIdentity);
        updateBusiContAwaySecLevel = updateBusiContAwaySecLevel.replace("${#TestSuite#Prop_Away-comp-id}", propertyAwayCompId);
        updateBusiContAwaySecLevel = updateBusiContAwaySecLevel.replace("${#TestSuite#BussCnt_PAP-comp-id}", busiContPropertyAwayCompId);
        return serviceUtil.getResponse(updateBusiContAwaySecLevel, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateBusinessContAway(String policyIdentity, String PositionIdentity, String variationIdentity, String busiContPropertyAwayCompId, String businessContPropertyAwayCompId, String businessAwayContType, String businessAwayAmount) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateBusinessContentAway.xml");
        String updateBusiContAway = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateBusiContAway = updateBusiContAway.replace("${#TestSuite#policy-id}", policyIdentity);
        updateBusiContAway = updateBusiContAway.replace("${#TestSuite#position-id}", PositionIdentity);
        updateBusiContAway = updateBusiContAway.replace("${#TestSuite#variation-id}", variationIdentity);
        updateBusiContAway = updateBusiContAway.replace("${#TestSuite#BusCont_PAP-comp-id}", businessContPropertyAwayCompId);
        updateBusiContAway = updateBusiContAway.replace("${#TestSuite#BussCnt_PAP-comp-id}", busiContPropertyAwayCompId);
        updateBusiContAway = updateBusiContAway.replace("strContentType", businessAwayContType);
        updateBusiContAway = updateBusiContAway.replace("strAmount", businessAwayAmount);
        return serviceUtil.getResponse(updateBusiContAway, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateStockAwaySectionLevel(String policyIdentity, String PositionIdentity, String variationIdentity, String propertyAwayCompId, String stockPropertyAwayCompId) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateStockAwaySectionLevel.xml");
        String udpateStockAwaySecLevel = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        udpateStockAwaySecLevel = udpateStockAwaySecLevel.replace("${#TestSuite#policy-id}", policyIdentity);
        udpateStockAwaySecLevel = udpateStockAwaySecLevel.replace("${#TestSuite#position-id}", PositionIdentity);
        udpateStockAwaySecLevel = udpateStockAwaySecLevel.replace("${#TestSuite#variation-id}", variationIdentity);
        udpateStockAwaySecLevel = udpateStockAwaySecLevel.replace("${#TestSuite#Prop_Away-comp-id}", propertyAwayCompId);
        udpateStockAwaySecLevel = udpateStockAwaySecLevel.replace("${#TestSuite#Prop_Stock-comp-id}", stockPropertyAwayCompId);
        return serviceUtil.getResponse(udpateStockAwaySecLevel, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateStockAway(String policyIdentity, String PositionIdentity, String variationIdentity, String stockPropertyAwayCompId, String PropertyAwayObjectId, String stockAwayType, String stockAwayAmount, String methodTransit) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateStockAway.xml");
        String updateStockAway = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateStockAway = updateStockAway.replace("${#TestSuite#policy-id}", policyIdentity);
        updateStockAway = updateStockAway.replace("${#TestSuite#position-id}", PositionIdentity);
        updateStockAway = updateStockAway.replace("${#TestSuite#variation-id}", variationIdentity);
        updateStockAway = updateStockAway.replace("${#TestSuite#Stock_PAP-comp-id}", stockPropertyAwayCompId);
        updateStockAway = updateStockAway.replace("PAP_ObjectID", PropertyAwayObjectId);
        updateStockAway = updateStockAway.replace("strStockType", stockAwayType);
        updateStockAway = updateStockAway.replace("strStockAmount", stockAwayAmount);
        updateStockAway = updateStockAway.replace("strMethod", methodTransit);
        return serviceUtil.getResponse(updateStockAway, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateNamedItemAwaySectionLevel(String policyIdentity, String PositionIdentity, String variationIdentity, String propertyAwayCompId, String namedItemPropertyAwayCompId) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateNamedItemsAwaySectionLevel.xml");
        String updateNamedItemAwaySecLevel = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateNamedItemAwaySecLevel = updateNamedItemAwaySecLevel.replace("${#TestSuite#policy-id}", policyIdentity);
        updateNamedItemAwaySecLevel = updateNamedItemAwaySecLevel.replace("${#TestSuite#position-id}", PositionIdentity);
        updateNamedItemAwaySecLevel = updateNamedItemAwaySecLevel.replace("${#TestSuite#variation-id}", variationIdentity);
        updateNamedItemAwaySecLevel = updateNamedItemAwaySecLevel.replace("${#TestSuite#Prop_Away-comp-id}", propertyAwayCompId);
        updateNamedItemAwaySecLevel = updateNamedItemAwaySecLevel.replace("NamedItemPropertyAwayObjId", namedItemPropertyAwayCompId);
        return serviceUtil.getResponse(updateNamedItemAwaySecLevel, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateNamedItemAway(String policyIdentity, String PositionIdentity, String variationIdentity, String namedItemPropertyAwayCompId, String namedItemPropertyAwayObjId, String namedItemGroup, String namedItemAwayType, String namedItemAwayAmount, String freeFormat) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateNamedItemsAway.xml");
        String updateNamedItemAway = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateNamedItemAway = updateNamedItemAway.replace("${#TestSuite#policy-id}", policyIdentity);
        updateNamedItemAway = updateNamedItemAway.replace("${#TestSuite#position-id}", PositionIdentity);
        updateNamedItemAway = updateNamedItemAway.replace("${#TestSuite#variation-id}", variationIdentity);
        updateNamedItemAway = updateNamedItemAway.replace("${#TestSuite#NamedItems_PAP-comp-id}", namedItemPropertyAwayCompId);
        updateNamedItemAway = updateNamedItemAway.replace("NamedItemsPAPObjId", namedItemPropertyAwayObjId);
        updateNamedItemAway = updateNamedItemAway.replace("strItemGrp", String.valueOf(namedItemGroup).replace("$null$", ""));
        updateNamedItemAway = updateNamedItemAway.replace("strItemType", String.valueOf(namedItemAwayType).replace("$null$", ""));
        updateNamedItemAway = updateNamedItemAway.replace("strItemAmount", String.valueOf(namedItemAwayAmount).replace("$null$", ""));
        updateNamedItemAway = updateNamedItemAway.replace("strFreeFormat", String.valueOf(freeFormat).replace("$null$", ""));
        return serviceUtil.getResponse(updateNamedItemAway, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updatePersonalEffects(String policyIdentity, String PositionIdentity, String variationIdentity, String propertyAwayCompId, String personalEffectsObjId, String amount) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updatePersonalEffects.xml");
        String updatePersonalEffects = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updatePersonalEffects = updatePersonalEffects.replace("${#TestSuite#policy-id}", policyIdentity);
        updatePersonalEffects = updatePersonalEffects.replace("${#TestSuite#position-id}", PositionIdentity);
        updatePersonalEffects = updatePersonalEffects.replace("${#TestSuite#variation-id}", variationIdentity);
        updatePersonalEffects = updatePersonalEffects.replace("${#TestSuite#Prop_Away-comp-id}", propertyAwayCompId);
        updatePersonalEffects = updatePersonalEffects.replace("PropertyAwayObjID", personalEffectsObjId);
        updatePersonalEffects = updatePersonalEffects.replace("strAmount", String.valueOf(amount).replace("$null$", ""));
        return serviceUtil.getResponse(updatePersonalEffects, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String plUpdatePublicLiabilityStandard(String policyIdentity, String PositionIdentity, String variationIdentity, String publicLiabilityStandardCompId, String exportsOutsideUK) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updatePublicLiabilityStandard.xml");
        String updatePublicLiabilityStandard = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updatePublicLiabilityStandard = updatePublicLiabilityStandard.replace("${#TestSuite#policy-id}", policyIdentity);
        updatePublicLiabilityStandard = updatePublicLiabilityStandard.replace("${#TestSuite#position-id}", PositionIdentity);
        updatePublicLiabilityStandard = updatePublicLiabilityStandard.replace("${#TestSuite#variation-id}", variationIdentity);
        updatePublicLiabilityStandard = updatePublicLiabilityStandard.replace("${#TestSuite#PuL_Std-comp-id}", publicLiabilityStandardCompId);
        //Format-Add the Covers of 'PPLiability-1,1000000,100#Engineering' with 'nopplValidation'
        String[] ppl = exportsOutsideUK.split(",");
        if (ppl.length >= 2) {
            updatePublicLiabilityStandard = updatePublicLiabilityStandard.replace("<urn2:limitOfIndemnity>1000000", "<urn2:limitOfIndemnity>" + String.valueOf(ppl[1]).replace("$null$", ""));
            updatePublicLiabilityStandard = updatePublicLiabilityStandard.replace("<urn2:excess>100", "<urn2:excess>" + String.valueOf(ppl[2]).replace("$null$", ""));
        }
        updatePublicLiabilityStandard = updatePublicLiabilityStandard.replace("strExportOutsideUK", String.valueOf(ppl[0]).replace("$null$", ""));
        return serviceUtil.getResponse(updatePublicLiabilityStandard, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String plUpdatePublicLiabilityTemporaryEmployees(String policyIdentity, String PositionIdentity, String variationIdentity, String publicLiabilityTempObjectId) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updatePublicLiabilityTemporaryEmployees.xml");
        String updatePublicLiabilityTempEmp = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updatePublicLiabilityTempEmp = updatePublicLiabilityTempEmp.replace("${#TestSuite#policy-id}", policyIdentity);
        updatePublicLiabilityTempEmp = updatePublicLiabilityTempEmp.replace("${#TestSuite#position-id}", PositionIdentity);
        updatePublicLiabilityTempEmp = updatePublicLiabilityTempEmp.replace("${#TestSuite#variation-id}", variationIdentity);
        updatePublicLiabilityTempEmp = updatePublicLiabilityTempEmp.replace("TempEmpObjectIdentity", publicLiabilityTempObjectId);
        return serviceUtil.getResponse(updatePublicLiabilityTempEmp, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String plupdateBoneFideSubContractors(String policyIdentity, String PositionIdentity, String variationIdentity, String boneFideSubContractorsObjectId, String strBFSCValue) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateBonaFideSubContractors.xml");
        String updateBoneFideSubContractors = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateBoneFideSubContractors = updateBoneFideSubContractors.replace("${#TestSuite#policy-id}", policyIdentity);
        updateBoneFideSubContractors = updateBoneFideSubContractors.replace("${#TestSuite#position-id}", PositionIdentity);
        updateBoneFideSubContractors = updateBoneFideSubContractors.replace("${#TestSuite#variation-id}", variationIdentity);
        updateBoneFideSubContractors = updateBoneFideSubContractors.replace("BonaFideSubObjectIdentity", boneFideSubContractorsObjectId);
        updateBoneFideSubContractors = updateBoneFideSubContractors.replace("strBFSCValue", String.valueOf(strBFSCValue));
        return serviceUtil.getResponse(updateBoneFideSubContractors, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateStandardTreatment(String policyIdentity, String PositionIdentity, String variationIdentity, String pulStdTreatmentCompId, String standardTreatmentVal) throws Exception {
        String[] standTreatmentValues = standardTreatmentVal.split(",");
        String updateStandardTreatment;
        File f = new File("src/test/resources/requests/pre-req/updateStandardTreatment.xml");
        if (standTreatmentValues[1].equalsIgnoreCase("$null$")) {
            updateStandardTreatment = WebServiceFunctionalUtil.removeNodeElement("src/test/resources/requests/pre-req/updateStandardTreatment.xml", "urn1:component", "urn2:noOfOperativesAdditional");
        } else {
            updateStandardTreatment = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("strNoOfOperatAddition", String.valueOf(standTreatmentValues[1]).replace("$null$", ""));
        }

        updateStandardTreatment = updateStandardTreatment.replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateStandardTreatment = updateStandardTreatment.replace("${#TestSuite#policy-id}", policyIdentity);
        updateStandardTreatment = updateStandardTreatment.replace("${#TestSuite#position-id}", PositionIdentity);
        updateStandardTreatment = updateStandardTreatment.replace("${#TestSuite#variation-id}", variationIdentity);
        updateStandardTreatment = updateStandardTreatment.replace("${#TestSuite#PuL_Std_Treatment-comp-id}", pulStdTreatmentCompId);
        updateStandardTreatment = updateStandardTreatment.replace("strMeetMinProExp", String.valueOf(standTreatmentValues[0]).replace("$null$", ""));
        return serviceUtil.getResponse(updateStandardTreatment, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateAdditionalTreatment(String policyIdentity, String PositionIdentity, String variationIdentity, String pulAddTreatmentCompId, String treatmentName, String noOfOperativesAdditional, String limtCover) throws Exception {
        String updateAdditionalTreatment;
        File f = new File("src/test/resources/requests/pre-req/updateAdditionalTreatment.xml");
        if (noOfOperativesAdditional.equalsIgnoreCase("$null$")) {
            updateAdditionalTreatment = WebServiceFunctionalUtil.removeNodeElement("src/test/resources/requests/pre-req/updateAdditionalTreatment.xml", "urn1:component", "urn2:noOfOperativesAdditional");
        } else {
            updateAdditionalTreatment = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("strNoOfOperatAddition", String.valueOf(noOfOperativesAdditional).replace("$null$", ""));
        }
        updateAdditionalTreatment = updateAdditionalTreatment.replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateAdditionalTreatment = updateAdditionalTreatment.replace("${#TestSuite#policy-id}", policyIdentity);
        updateAdditionalTreatment = updateAdditionalTreatment.replace("${#TestSuite#position-id}", PositionIdentity);
        updateAdditionalTreatment = updateAdditionalTreatment.replace("${#TestSuite#variation-id}", variationIdentity);
        updateAdditionalTreatment = updateAdditionalTreatment.replace("PULAddTreatmentCompId", pulAddTreatmentCompId);
        updateAdditionalTreatment = updateAdditionalTreatment.replace("strTreatmentName", String.valueOf(treatmentName).replace("$null$", ""));
        updateAdditionalTreatment = updateAdditionalTreatment.replace("strLimitCover", String.valueOf(limtCover).replace("$null$", ""));
        return serviceUtil.getResponse(updateAdditionalTreatment, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateListOfLossHistItems(String[] historyItems) throws Exception {
        int f = 0;
        Element lossDate = null;
        DocumentBuilderFactory domFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = domFactory.newDocumentBuilder();
        Document doc = builder.parse(new File("src/test/resources/requests/pre-req/updateLossHistory.xml"));
        for (int ad = 0; ad < historyItems.length; ad++) {
            String[] additionalCoverVal = historyItems[ad].split(",");
            //Telling that need to write these items between which node, node name is <urn1:component> in xml
            Element dataTag = doc.getDocumentElement();
            Element componentTag = (Element) dataTag.getElementsByTagName("urn1:component").item(0);
            //Creating the <urn1:listElement> node and their attributes, values
            Element listElement = doc.createElement("urn1:listElement");
            Attr attrType = doc.createAttribute("xsi:type");
            attrType.setValue("urn2:ComponentUpdateLoss_HistoryItem");
            listElement.setAttributeNode(attrType);
            //Creating the <urn1:objectIdentity> nodeg
            Element objectIdentity = doc.createElement("urn1:objectIdentity");
            objectIdentity.setTextContent(String.valueOf(lossHistoryCompentityId.get(ad + 1)).replace("$null$", ""));

            //Creating the <urn2:lossAmount> node
            Element lossAmount = doc.createElement("urn2:lossAmount");
            //Creating the <urn1:amount> node within lossAmount node
            Element amount = doc.createElement("urn1:amount");
            amount.setTextContent(String.valueOf(additionalCoverVal[0]).replace("$null$", ""));
            Element currency = doc.createElement("urn1:currency");
            currency.setTextContent("GBP");
            //Appdening these amount and currency nodes as a childnode to lossAmount Node
            lossAmount.appendChild(currency);
            lossAmount.appendChild(amount);
            //Creating the <urn2:lossCause> node within listElement node
            Element lossCause = doc.createElement("urn2:lossCause");
            lossCause.setTextContent(String.valueOf(additionalCoverVal[1]).replace("$null$", ""));
            //Creating the <urn2:lossDate> node within listElement node
            if (!additionalCoverVal[2].equalsIgnoreCase("$null$")) {
                lossDate = doc.createElement("urn2:lossDate");
                additionalCoverVal[2] = additionalCoverVal[2].replace(":", "-");
                lossDate.setTextContent(String.valueOf(additionalCoverVal[2]).replace("$null$", ""));
                f = 1;
            }
            //Creating the <urn2:statusOfClaim> node within listElement node
            Element statusOfClaim = doc.createElement("urn2:statusOfClaim");
            statusOfClaim.setTextContent(String.valueOf(additionalCoverVal[3]).replace("$null$", ""));
            //Creating the <urn2:contactAddress> node and set their attributes,values
            /*Element contactAddress = doc.createElement("urn1:contactAddress");
            Attr attrType1 = doc.createAttribute("xsi:nil");
            attrType1.setValue("true");
            contactAddress.setAttributeNode(attrType1);*/
            //Appdening these lossAmount,lossCause,lossDate,statusOfClaim and contactAddress nodes as a childnode to listElement Node
            listElement.appendChild(objectIdentity);
            listElement.appendChild(lossAmount);
            listElement.appendChild(lossCause);
            if (f == 1) {
                listElement.appendChild(lossDate);
            }
            listElement.appendChild(statusOfClaim);
            //   listElement.appendChild(contactAddress);
            //Appdening all the list items of nodes within componentTag "<urn1:component>"
            componentTag.appendChild(listElement);
        }

        //Writing the above items
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");
        StreamResult result = new StreamResult(new StringWriter());
        DOMSource source = new DOMSource(doc);
        transformer.transform(source, result);
        updateLossHistory = result.getWriter().toString();
        return updateLossHistory;
    }

    public String updateLossHistory(String policyIdentity, String PositionIdentity, String variationIdentity, ArrayList<String> lossHistoryCompId, String[] historyItems) throws Exception {
        for (int i = 0; i < lossHistoryCompId.size(); i++) {
            if (lossHistoryCompId.get(i).equals("")) {
                lossHistoryCompId.remove(i);
            }
        }
        lossHistoryCompentityId = lossHistoryCompId;
        updateLossHistory = updateListOfLossHistItems(historyItems);
        updateLossHistory = updateLossHistory.replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateLossHistory = updateLossHistory.replace("${#TestSuite#policy-id}", policyIdentity);
        updateLossHistory = updateLossHistory.replace("${#TestSuite#position-id}", PositionIdentity);
        updateLossHistory = updateLossHistory.replace("${#TestSuite#variation-id}", variationIdentity);
        updateLossHistory = updateLossHistory.replace("${#TestSuite#Loss_History-comp-id}", lossHistoryCompentityId.get(0));
        return serviceUtil.getResponse(updateLossHistory, System.getProperty("ENV") + "/ListComponentUpdateSME_INSSMEv1", "ListComponentUpdateSME_INSSMEv1Service/updateExistingListComponent");
    }

    public String updateBIOwnPremise(String policyIdentity, String PositionIdentity, String variationIdentity, String biOwnPremiseObjectID, String indemnityPeriodNumberOfMonths) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateBIOwnPremises.xml");
        String updateBIOwnPremise = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateBIOwnPremise = updateBIOwnPremise.replace("${#TestSuite#policy-id}", policyIdentity);
        updateBIOwnPremise = updateBIOwnPremise.replace("${#TestSuite#position-id}", PositionIdentity);
        updateBIOwnPremise = updateBIOwnPremise.replace("${#TestSuite#variation-id}", variationIdentity);
        updateBIOwnPremise = updateBIOwnPremise.replace("BIOwnPremisesObjectID", biOwnPremiseObjectID);
        updateBIOwnPremise = updateBIOwnPremise.replace("strNoOfmonths", String.valueOf(indemnityPeriodNumberOfMonths).replace("$null$", ""));
        return serviceUtil.getResponse(updateBIOwnPremise, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1Service/updateExistingComponent");
    }

    public String updateLossOfBusinessMoneyStandard(String policyIdentity, String PositionIdentity, String variationIdentity, String businessMoneyStdCompId, String Coverage) throws IOException, ParseException {
        File f = new File("src/test/resources/requests/pre-req/updateLossOfBusinessMoneyStd.xml");
        String updateLossOfBusinessMoneyStandard = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateLossOfBusinessMoneyStandard = updateLossOfBusinessMoneyStandard.replace("${#TestSuite#policy-id}", policyIdentity);
        updateLossOfBusinessMoneyStandard = updateLossOfBusinessMoneyStandard.replace("${#TestSuite#position-id}", PositionIdentity);
        updateLossOfBusinessMoneyStandard = updateLossOfBusinessMoneyStandard.replace("${#TestSuite#variation-id}", variationIdentity);
        updateLossOfBusinessMoneyStandard = updateLossOfBusinessMoneyStandard.replace("${#TestSuite#Lbm_Std-comp-id}", businessMoneyStdCompId);
        String[] ToT = Coverage.split(",");
        updateLossOfBusinessMoneyStandard = updateLossOfBusinessMoneyStandard.replace("strinBankNightSafe", String.valueOf(ToT[0]).replace("$null$", ""));
        updateLossOfBusinessMoneyStandard = updateLossOfBusinessMoneyStandard.replace("strinTransit", String.valueOf(ToT[1]).replace("$null$", ""));
        updateLossOfBusinessMoneyStandard = updateLossOfBusinessMoneyStandard.replace("strinThePremisesWhilstAttended", String.valueOf(ToT[2]).replace("$null$", ""));
        updateLossOfBusinessMoneyStandard = updateLossOfBusinessMoneyStandard.replace("strinThePremisesWhilstUnattendedAndInSafe", String.valueOf(ToT[3]).replace("$null$", ""));
        return serviceUtil.getResponse(updateLossOfBusinessMoneyStandard, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1/updateExistingComponent");
    }

    public String updateLegalExpensesStandard(String policyIdentity, String PositionIdentity, String variationIdentity, String legalExpenseStdCompId, String coverLimit) throws IOException {
        File f = new File("src/test/resources/requests/pre-req/updateLegalExpensesStandard.xml");
        String updateLegalExpensesStandard = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateLegalExpensesStandard = updateLegalExpensesStandard.replace("${#TestSuite#policy-id}", policyIdentity);
        updateLegalExpensesStandard = updateLegalExpensesStandard.replace("${#TestSuite#position-id}", PositionIdentity);
        updateLegalExpensesStandard = updateLegalExpensesStandard.replace("${#TestSuite#variation-id}", variationIdentity);
        updateLegalExpensesStandard = updateLegalExpensesStandard.replace("${#TestSuite#LEx_Std-comp-id}", legalExpenseStdCompId);
        updateLegalExpensesStandard = updateLegalExpensesStandard.replace("strCoverLimit", String.valueOf(coverLimit).replace("$null$", ""));
        return serviceUtil.getResponse(updateLegalExpensesStandard, System.getProperty("ENV") + "/ComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1/updateExistingComponent");
    }

    public String updateLoadsAndDiscounts(String policyIdentity, String PositionIdentity, String variationIdentity, String loadsAndDiscountCompId, String loadsDiscountValues) throws IOException {
        String[] updateLoadDiscountVal = loadsDiscountValues.split(",");
        File f = new File("src/test/resources/requests/pre-req/updateLoadsAndDiscounts.xml");
        String updateLoadsAndDiscounts = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", WebServiceFunctionalUtil.contactID);
        updateLoadsAndDiscounts = updateLoadsAndDiscounts.replace("${#TestSuite#policy-id}", policyIdentity);
        updateLoadsAndDiscounts = updateLoadsAndDiscounts.replace("${#TestSuite#position-id}", PositionIdentity);
        updateLoadsAndDiscounts = updateLoadsAndDiscounts.replace("${#TestSuite#variation-id}", variationIdentity);
        updateLoadsAndDiscounts = updateLoadsAndDiscounts.replace("${#TestSuite#LnD-comp-id}", loadsAndDiscountCompId);
        updateLoadsAndDiscounts = updateLoadsAndDiscounts.replace("strAmount", String.valueOf(updateLoadDiscountVal[0]).replace("$null$", ""));
        updateLoadsAndDiscounts = updateLoadsAndDiscounts.replace("strReasonCode", String.valueOf(updateLoadDiscountVal[1]).replace("$null$", ""));
        updateLoadsAndDiscounts = updateLoadsAndDiscounts.replace("strPercentage", String.valueOf(updateLoadDiscountVal[2]).replace("$null$", ""));
        updateLoadsAndDiscounts = updateLoadsAndDiscounts.replace("strFreeFormat", String.valueOf(updateLoadDiscountVal[3]).replace("$null$", ""));
        return serviceUtil.getResponse(updateLoadsAndDiscounts, System.getProperty("ENV") + "/ListComponentUpdateSME_INSSMEv1", "ComponentUpdateSME_INSSMEv1/updateExistingComponent");
    }
}