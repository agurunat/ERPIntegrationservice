package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class Obj_Partners extends AbstractPage {

    public WebElement addPartner() {
        return waitForElementToBeClickableAndReturnElement(By.id("C1__BUT_D304421B4A30AE94573230"));
    }

    public WebElement title() {
        return waitForElementPresent(By.id("C1__QUE_48BDF1EEA3569326405358"));
    }

    public WebElement firstName() {
        return waitForElementToBeClickableAndReturnElement(By.id("C1__QUE_48BDF1EEA3569326405361"));
    }

    public WebElement lastName() {
        return waitForElementToBeClickableAndReturnElement(By.id("C1__QUE_EFE281AF6E39A131169832"));
    }

    public WebElement addbutton() {
        return waitForElementToBeClickableAndReturnElement(By.id("C1__BUT_E9B4CF71BABEB218517288"));
    }

    public WebElement nextbutton() {
        return waitForElementPresent(By.id("C1__BUT_55E5AE0A984C2873500525"));
    }

    public WebElement anotherPartners() {
        return waitForElementPresent(By.id("C1__BUT_D304421B4A30AE94573853"));
    }


}