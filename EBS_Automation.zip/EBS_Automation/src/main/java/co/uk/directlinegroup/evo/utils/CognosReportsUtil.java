package co.uk.directlinegroup.evo.utils;

import co.uk.directlinegroup.evo.pages.Obj_CognosReportCommon;
import com.usmanhussain.habanero.framework.AbstractPage;
import org.apache.commons.lang.math.NumberUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathFactory;
import java.awt.*;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by 323996 on 9/5/2017.
 */
public class CognosReportsUtil extends AbstractPage {
    //    private Obj_CognosMarketingPreferenceReport cognosMarketingPreferenceReport = new Obj_CognosMarketingPreferenceReport();
    private GeneralinformationUtil obj_generalInformationUtil = new GeneralinformationUtil();
    private CommonUtil obj_commonUtil = new CommonUtil();
    private Obj_CognosReportCommon obj_CognosReportCommon = new Obj_CognosReportCommon();
    private WebServiceFunctionalUtil functionalUtil = new WebServiceFunctionalUtil();
    public static CognosExcelLogUtil excelLog = new CognosExcelLogUtil();
    public static String strSaveFileLocation = "";
    public static String currentTableLid = "List";
    public static String currentTab = "";
    public static int currentExcelSheet = 1;
    public static int currentExcelStartRow = 8;
    public static int currentExcelEndRowCorretion = 1;
    public static int drillEndCol;
    public static List<String> userLastNames = new ArrayList<>();
    public static Map<String, String> map = new HashMap<String, String>();
    public static Map<String, String> errorLog = new HashMap<String, String>();
    public static String rndText = "";
    public static int errorLogCtr = 1;
    public static boolean hvWaitFlag = false;
    public static List<ValueAndRowspanCounter> colCtrFinal = new ArrayList<>();


    private ServiceUtil serviceUtil = new ServiceUtil();


    public void logError(String log) {
        errorLog.put("errorLog" + errorLogCtr++, log);

    }

    public void setCurrsheet(int sheet) {
        currentExcelSheet = sheet;
    }

    public void stringValidation(String strActual, String strExpected) throws IOException {

        excelLog.logBooleanResult(strExpected, strActual, strExpected.equals(strActual), "");

    }

    public void mapReport() {
        for (Map.Entry<String, String> entry : map.entrySet()) {
            String key = entry.getKey();
            String value = entry.getValue();

            excelLog.logBooleanResult(key, value, false, "Map");
        }

    }

    public void stringValidation(String strActual, String strExpected, String strReference) throws IOException {

        excelLog.logBooleanResult(strExpected, strActual, strExpected.equals(strActual), strReference);

    }

    public void stringContainsValidation(String strExpected, String strActual, String strReference) throws IOException {

        excelLog.logBooleanResult(strExpected + ": contains text : ", strActual, strExpected.contains(strActual), strReference);

    }


    public String getElementStringByJS(WebElement element) {
        String script = "return arguments[0].innerText";
        String strText = (String) ((JavascriptExecutor) getDriver).executeScript(script, element);
        return strText;
    }

    public void intSumValidation(String strValue1, String strValue2, String strExpected) throws IOException {
        strValue1 = strValue1.replaceAll(",", "");
        strValue2 = strValue2.replaceAll(",", "");
        strExpected = strExpected.replaceAll(",", "");
        Float intActual = Float.parseFloat(strValue1) + Float.parseFloat(strValue2);
//        DecimalFormat df = new DecimalFormat("###.##");

        String strActual = String.format("%.2f", intActual);
        excelLog.logBooleanResult(strValue1 + "+" + strValue2 + "=" + strExpected, strActual, strExpected.equals(strActual), "");

    }

    public void intSumValidation(String strValue1, String strValue2, String strExpected, String strReference) throws IOException {
        strValue1 = strValue1.replaceAll(",", "");
        strValue2 = strValue2.replaceAll(",", "");
        strExpected = strExpected.replaceAll(",", "");
        Float intActual = Float.parseFloat(strValue1) + Float.parseFloat(strValue2);
//        DecimalFormat df = new DecimalFormat("###.##");
        String strActual = String.format("%.2f", intActual);
//        if (!strExpected.equals(strActual)) {
//            int i = 0;
//            i++;
//        }

        excelLog.logBooleanResult(strValue1 + "+" + strValue2 + "=" + strExpected, strActual, strExpected.equals(strActual), strReference);

    }

    public String sumOfAllElementsValues(List<WebElement> listEle) {
        Float sum = Float.parseFloat("0");
//        DecimalFormat df = new DecimalFormat("###.##");
        for (WebElement e : listEle) {
            sum = sum + Float.parseFloat(getElementStringByJS(e).replaceAll(",", ""));
        }
        return String.format("%.2f", sum);
    }

    public boolean validateTableHeader(String strExpectedHeader) {

        String[] strExptHeaderList = strExpectedHeader.split("(?<!#)#");
        List<WebElement> headers = obj_CognosReportCommon.reportTableHeaderRow().findElements(By.xpath("td/span"));
//        int it = headers.size();
//        it = strExptHeaderList.length;
        Assert.assertTrue(headers.size() == strExptHeaderList.length);

        for (int i = 0; i < strExptHeaderList.length; i++) {
            if (!strExptHeaderList[i].trim().equals(headers.get(i).getText().trim())) {
                excelLog.logBooleanResult(strExptHeaderList[i], headers.get(i).getText().trim(), false, "Table Header : " + (i + 1));
                return false;
            }


        }

        return true;
    }

    public boolean validateEvsUEPTableHeader(String strExpectedHeader) {

        String[] strExptHeaderList = strExpectedHeader.split("#");
        List<WebElement> headers = obj_CognosReportCommon.reportTableHeaderRow().findElements(By.xpath("td/span"));

        Assert.assertTrue(headers.size() == strExptHeaderList.length + 1);

        for (int i = 0; i < strExptHeaderList.length; i++) {
            if (!strExptHeaderList[i].equals(headers.get(i + 1).getText())) {
                return false;
            }


        }

        return true;
    }


    public int findColumnIndex(String strColumnName) {
        String columns = "";

        int intCount = obj_CognosReportCommon.reportTableHeaderRow().findElements(By.xpath("td/span")).size();
        for (int i = 0; i < intCount; i++) {
            columns = columns + obj_CognosReportCommon
                    .reportTableHeaderRow()
                    .findElements(By.xpath("td/span"))
                    .get(i).getText().trim() + ", ";
            if (obj_CognosReportCommon
                    .reportTableHeaderRow()
                    .findElements(By.xpath("td/span"))
                    .get(i).getText().trim().equals(strColumnName)) {


                //excelLog.logBooleanResult(strColumnName,columns,false,"Debug Logging");

                return i + 1;

            }

        }
        excelLog.logBooleanResult(strColumnName, columns, false, "Column was not found in list of columns");
        Assert.assertTrue(false);
        return 0;
    }

    public int findPageAndRow(String strValue, int intColumnIndex) throws InterruptedException {
        int intRowCount;
        if (findElements(By.xpath("//td/a")).size() == 2) {
            Assert.assertTrue(findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom"));
        }
        do {
            Assert.assertTrue(waitForElementInVisible(By.id("CVWaitindicator_NS_")));
            intRowCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr")).size();
            for (int i = 1; i <= intRowCount; i++) {
                if (findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + i + "]"))
                        .findElement(By.xpath("td[" + intColumnIndex + "]/span"))
                        .getText().equals(strValue)) {
                    findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + i + "]")).click();

                    return i;
                }
            }
            if (findElements(By.xpath("(//td/a)[last()]")).size() > 0) {
                if (findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom")) {
                    obj_CognosReportCommon.reportTablePageDownLink().click();
                }
            } else {
                break;
            }
        } while (findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom"));
//        Assert.assertTrue(false);
        return 0;
    }

    public int findPageAndRow(String strValue) throws InterruptedException {
        int intRowCount;
        if (findElements(By.xpath("//td/a")).size() == 2) {
            Assert.assertTrue(findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom"));
        }
        do {
            Assert.assertTrue(waitForElementInVisible(By.id("CVWaitindicator_NS_")));
            intRowCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr")).size();
            for (int i = 1; i <= intRowCount; i++) {
                List<WebElement> cells = findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + i + "]"))
                        .findElements(By.xpath("td/span"));
                for (WebElement cell : cells) {
                    if (cell.getText().equals(strValue)) {
                        findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + i + "]")).click();

                        return i;
                    }
                }
            }
            if (findElements(By.xpath("(//td/a)[last()]")).size() > 0) {
                if (findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom")) {
                    obj_CognosReportCommon.reportTablePageDownLink().click();
                }
            } else {
                break;
            }

        } while (findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom"));

//        Assert.assertTrue(false);
        return 0;
    }

    public void clickTopNavLink() {
        if (findElements(By.xpath("//td/a")).size() == 2) {
            Assert.assertTrue(findElement(By.xpath("(//td/a)[1]")).getText().equals("Top"));
            findElement(By.xpath("(//td/a)[1]")).click();
            cognosDateLodaingComplete();
        }
    }
    public int findPageAndRowByArrayOfValues(String[] strValueArr, Integer[] intColumnIndexArr) throws InterruptedException {

        if(getDriver.findElements(By.xpath("//*[@rowspan]")).size()==0) {
            return findPageAndRowByArrayOfValuesReg(strValueArr, intColumnIndexArr);
        }
        else
//            Assert.assertTrue("Called regular table find row function for an irreguar table",false);
//            return 0;
        {
            findPageAndRowByArrayOfValuesIrReg(strValueArr, intColumnIndexArr);

            CognosReportsUtil.map.put("AutoComposedRowKey", "");

        }
        return 0;
    }
    public int findPageAndRowByArrayOfValuesReg(String[] strValueArr, Integer[] intColumnIndexArr) throws InterruptedException {
        int intRowCount, ctr=2;
        if (findElements(By.xpath("//td/a")).size() == 2) {
            obj_CognosReportCommon.reportTableBottomLink().click();
        }
        cognosDateLodaingComplete();
        Assert.assertTrue(strValueArr.length == intColumnIndexArr.length);
        if (findElements(By.xpath("//td/a")).size() == 2) {
            Assert.assertTrue(findElement(By.xpath("(//td/a)[1]")).getText().equals("Top"));
        }
        do {
            Assert.assertTrue(waitForElementInVisible(By.id("CVWaitindicator_NS_")));
            intRowCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr")).size();
            for (int i = 1; i <= intRowCount; i++) {
                boolean status = true;
                int k = 0;
                for (String strValue : strValueArr) {
                    int intColumnIndex = intColumnIndexArr[k++];
                    if (findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + i + "]"))
                            .findElement(By.xpath("td[" + intColumnIndex + "]/span"))
                            .getText().equals(strValue)) {
                        findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + i + "]")).click();
                        status = status && true;
                    } else {
                        status = false;
                    }
                }
                if (status) {
                    return i;
                }

            }
            if (findElements(By.xpath("(//td/a)[last()]")).size() > 0) {
                if (findElement(By.xpath("(//td/a)[1]")).getText().equals("Top")) {
                    obj_CognosReportCommon.reportTablePageUpLink().click();
                    cognosDateLodaingComplete();
                }
            } else {
                ctr--;
                break;
            }
        } while (ctr>0);

//        Assert.assertTrue(false);
        CognosReportsUtil.errorLog.put("Row not found values", strValueArr.toString());
        CognosReportsUtil.errorLog.put("Row not found cols index", intColumnIndexArr.toString());

        return 0;
    }

    public int findPageAndRowByArrayOfValuesIrReg(String[] strValueArr, Integer[] intColumnIndexArr) throws InterruptedException {
        int intRowCount, ctr=2;
        if (findElements(By.xpath("//td/a")).size() == 2) {
            obj_CognosReportCommon.reportTableBottomLink().click();
        }
        cognosDateLodaingComplete();
        Assert.assertTrue(strValueArr.length == intColumnIndexArr.length);
        if (findElements(By.xpath("//td/a")).size() == 2) {
            Assert.assertTrue(findElement(By.xpath("(//td/a)[1]")).getText().equals("Top"));
        }
        do {
            Assert.assertTrue(waitForElementInVisible(By.id("CVWaitindicator_NS_")));
            intRowCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr")).size();
            WebElement rowele = findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[1]"));
            List<ValueAndRowspanCounter> colCtr = new ArrayList<>();
            if(getDriver.findElements(By.xpath("//*[@rowspan]")).size()==0)
            {

                List<WebElement> td = rowele.findElements(By.xpath("td"));
                for(WebElement tdEle : td)
                {
                    colCtr.add(new ValueAndRowspanCounter(tdEle));
                }
            }
            for (int i = 1; i <= intRowCount; i++) {
                boolean status = true;
                int k = 0;
                for (String strValue : strValueArr) {
                    int intColumnIndex = intColumnIndexArr[k++];

                    if (colCtr.get(intColumnIndex-1).value.equals(strValue)) {
                        findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + i + "]")).click();
                        status = status && true;
                    } else {
                        status = false;
                    }
                }
                if (status) {
                    colCtrFinal = colCtr;
                    return 0;
                }
                List<WebElement> td = findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + i + "]")).findElements(By.xpath("td"));
                int tdctr=0;
                for(WebElement tdEle : td)
                {
                    if(colCtr.get(tdctr).rowSpn==1)
                    {
                        colCtr.set(tdctr,new ValueAndRowspanCounter(tdEle));
                    }
                    else
                    {
                        colCtr.set(tdctr,new ValueAndRowspanCounter(colCtr.get(tdctr).rowSpn--,colCtr.get(tdctr).value));
                    }

                    colCtr.add(new ValueAndRowspanCounter(tdEle));
                }

            }
            if (findElements(By.xpath("(//td/a)[last()]")).size() > 0) {
                if (findElement(By.xpath("(//td/a)[1]")).getText().equals("Top")) {
                    obj_CognosReportCommon.reportTablePageUpLink().click();
                    cognosDateLodaingComplete();
                }
            } else {
                ctr--;
                break;
            }
        } while (ctr!=0);

//        Assert.assertTrue(false);
        CognosReportsUtil.errorLog.put("Row not found values", strValueArr.toString());
        CognosReportsUtil.errorLog.put("Row not found cols index", intColumnIndexArr.toString());

        return 0;
    }



    public int findPageAndRowByArrayOfValues(String[] strValueArr) throws InterruptedException {
        int intRowCount;
        String search = "";
        for (String s : strValueArr) {
            search = search + "#'" + s + "'";
        }

        if (findElements(By.xpath("//td/a")).size() == 2) {
            Assert.assertTrue(findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom"));
        }
        do {
            Assert.assertTrue(waitForElementInVisible(By.id("CVWaitindicator_NS_")));
            intRowCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr")).size();
            for (int i = 1; i <= intRowCount; i++) {
                boolean status = true, match = true;
                int k = 0;
                for (String strValue : strValueArr) {
                    List<WebElement> cells = findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + i + "]"))
                            .findElements(By.xpath("td/span"));
//                    int intColumnIndex = intColumnIndexArr[k++];
                    for (WebElement cell : cells) {
                        if (cell.getText().equals(strValue)) {
                            findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + i + "]")).click();
                            match = true;
                            break;
                        } else {
                            match = false;
                        }
                    }
                    status = status && match;
                }
                if (status) {
                    return i;
                }

            }
            if (findElements(By.xpath("(//td/a)[last()]")).size() > 0) {
                if (findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom")) {
                    obj_CognosReportCommon.reportTablePageDownLink().click();
                }
            } else {
                break;
            }
        } while (findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom"));

//        Assert.assertTrue(false);
        return 0;
    }
    public void validateReportRow(List<List<String>> data, int rowIndex) throws IOException, SAXException, ParserConfigurationException {
        if(getDriver.findElements(By.xpath("//*[@rowspan]")).size()==0) {
            validateReportRowRegular(data, rowIndex);
        }
        else if( CognosReportsUtil.map.containsKey("AutoComposedRowKey"))
        {
            validateReportRowIrRegular(data, rowIndex);
        }
        else
        {
            Assert.assertTrue("Recheck the input", false);
        }
    }

    public void validateReportRowRegular(List<List<String>> data, int rowIndex) throws ParserConfigurationException, SAXException, IOException {
        int count = data.get(0).size(), intValColumn;
        String strExpected = "", strActual = "";

        WebElement eleValue;
        for (int i = 0; i < count; i++) {

            //System.out.println(data.get(0).get(i) + " : " + data.get(1).get(i));
            intValColumn = findColumnIndex(data.get(0).get(i).trim());
            //System.out.println(intValColumn);
            strExpected = data.get(1).get(i);
            if (strExpected.contains("#")) {
                strExpected = valueAction(strExpected);
            }
            eleValue = waitForElementPresent(
                    By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + rowIndex + "]/td[" + intValColumn + "]/span"));
//            eleValue.click();
            strActual = eleValue.getText().trim() + "";
//            Assert.assertTrue(strExpected.equals(strActual));
            if (strExpected.contains("@") && strExpected.contains(".co")) {
                excelLog.logBooleanResult(strExpected, strActual, strExpected.equalsIgnoreCase(strActual), "");
            } else {
                excelLog.logBooleanResult(strExpected, strActual, strExpected.equals(strActual), "");
            }
        }
        if (data.size() > 2) {
            count = data.get(2).size();
//    strExpected = "", strActual = "";
//
//    eleValue;
            for (int i = 0; i < count; i++) {

                //System.out.println(data.get(0).get(i) + " : " + data.get(1).get(i));
                intValColumn = findColumnIndex(data.get(2).get(i).trim());
                //System.out.println(intValColumn);
                strExpected = data.get(3).get(i);
                if (strExpected.contains("#")) {
                    strExpected = valueAction(strExpected);
                }
                eleValue = waitForElementPresent(
                        By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + rowIndex + "]/td[" + intValColumn + "]/span"));
//            eleValue.click();
                strActual = eleValue.getText().trim() + "";
//            Assert.assertTrue(strExpected.equals(strActual));
                if (strExpected.contains("@") && strExpected.contains(".co")) {
                    excelLog.logBooleanResult(strExpected, strActual, strExpected.equalsIgnoreCase(strActual), "");
                } else {
                    excelLog.logBooleanResult(strExpected, strActual, strExpected.equals(strActual), "");
                }
            }
        }

    }

    public void validateReportRowIrRegular(List<List<String>> data, int rowIndex) throws ParserConfigurationException, SAXException, IOException {
        int count = data.get(0).size(), intValColumn;
        String strExpected = "", strActual = "";

        WebElement eleValue;
        for (int i = 0; i < count; i++) {

            //System.out.println(data.get(0).get(i) + " : " + data.get(1).get(i));
            intValColumn = findColumnIndex(data.get(0).get(i).trim());
            //System.out.println(intValColumn);
            strExpected = data.get(1).get(i);
            if (strExpected.contains("#")) {
                strExpected = valueAction(strExpected);
            }

            strActual = colCtrFinal.get(intValColumn).value.trim() + "";
//            Assert.assertTrue(strExpected.equals(strActual));
            if (strExpected.contains("@") && strExpected.contains(".co")) {
                excelLog.logBooleanResult(strExpected, strActual, strExpected.equalsIgnoreCase(strActual), "");
            } else {
                excelLog.logBooleanResult(strExpected, strActual, strExpected.equals(strActual), "");
            }
        }
        if (data.size() > 2) {
            count = data.get(2).size();
//    strExpected = "", strActual = "";
//
//    eleValue;
            for (int i = 0; i < count; i++) {

                //System.out.println(data.get(0).get(i) + " : " + data.get(1).get(i));
                intValColumn = findColumnIndex(data.get(2).get(i).trim());
                //System.out.println(intValColumn);
                strExpected = data.get(3).get(i);
                if (strExpected.contains("#")) {
                    strExpected = valueAction(strExpected);
                }
                strActual = colCtrFinal.get(intValColumn).value.trim() + "";
//            Assert.assertTrue(strExpected.equals(strActual));
                if (strExpected.contains("@") && strExpected.contains(".co")) {
                    excelLog.logBooleanResult(strExpected, strActual, strExpected.equalsIgnoreCase(strActual), "");
                } else {
                    excelLog.logBooleanResult(strExpected, strActual, strExpected.equals(strActual), "");
                }
            }
        }

    }

    public void validateReportWholeTable(List<List<String>> data, int rowIndex) throws ParserConfigurationException, SAXException, IOException {
        int count = data.get(0).size(), intValColumn;
        String strExpected = "", strActual = "";
        WebElement eleValue;
        for (int i = 0; i < count; i++) {

            //System.out.println(data.get(0).get(i) + " : " + data.get(1).get(i));
            intValColumn = findColumnIndex(data.get(0).get(i).trim());
            //System.out.println(intValColumn);
            strExpected = data.get(rowIndex - 1).get(i);
            if (strExpected.contains("#")) {
                strExpected = valueAction(strExpected);
            }
            eleValue = waitForElementPresent(
                    By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + rowIndex + "]/td[" + intValColumn + "]/span"));
//            eleValue.click();
            strActual = eleValue.getText().trim() + "";
//            Assert.assertTrue(strExpected.equals(strActual));
            excelLog.logBooleanResult(strExpected, strActual, strExpected.equals(strActual), "");

        }

    }

    public String valueAction(String value) throws IOException, SAXException, ParserConfigurationException {
        String action = value.split("#")[1];
        value = value.split("#")[0];
        ArrayList<String> listCov = new ArrayList<>();
        switch (action) {
            case "Date":
                value = returnDate(Integer.parseInt(value));
                break;

            case "NB-TotalPrem":
                value = "£"+CognosReportsUtil.map.get("PPSR");
                break;

            case "MTA-TotalPrem":
                value = "£"+CognosReportsUtil.map.get("mtaPPSR");
                break;

            case "CAN-TotalPrem":
                value = "£"+CognosReportsUtil.map.get("CanPPSR");
                break;

            case "REN-TotalPrem":
                value = "£"+CognosReportsUtil.map.get("renewalPPSR");
                break;

            case "NB-CovPrem":
               listCov = getListOfCoveragesWithNon0Premium(CognosReportsUtil.map.get("PPSR"));
                value =  "£"+returnCovpremiumFromPPSR(listCov,value);
                break;
            case "MTA-CovPrem":
                listCov = getListOfCoveragesWithNon0Premium(CognosReportsUtil.map.get("mtaPPSR"));
                value =  "£"+returnCovpremiumFromPPSR(listCov,value);
                break;
            case "CAN-CovPrem":
                listCov = getListOfCoveragesWithNon0Premium(CognosReportsUtil.map.get("CanPPSR"));
                value =  "£"+returnCovpremiumFromPPSR(listCov,value);
                break;
            case "REN-CovPrem":
                listCov = getListOfCoveragesWithNon0Premium(CognosReportsUtil.map.get("renewalPPSR"));
                value =  "£"+returnCovpremiumFromPPSR(listCov,value);
                break;

        }

        return value;
    }

    public Float returnCovpremiumFromPPSR(ArrayList<String> listCov,String value)
    {
        Float premiumCov = Float.parseFloat("0.0");

        for(String covDet : listCov)
        {
            if(covDet.startsWith(value))
            {
                premiumCov = premiumCov + Float.parseFloat(covDet.split("#")[1]);

            }
        }
        return premiumCov;
    }
    public WebElement drillColLinkValidattion(String columnName) {
        int columnIndex = findColumnIndex(columnName.trim());
        String actual = obj_CognosReportCommon.reportTable().findElement(By.xpath("tbody/tr[1]/td[" + columnIndex + "]/span[@dttargets]/span")).getText();
        excelLog.logBooleanResult(columnName, actual, columnName.equals(actual), "Drill down column validation");
        return obj_CognosReportCommon.reportTable().findElement(By.xpath("tbody/tr[1]/td[" + columnIndex + "]/span[@dttargets]/span"));

    }

    public void validateFilterHeader(String columnDrillHeaderName) {
        String expectedFilterHeader = obj_CognosReportCommon.reportFilterHeaderLabel().getText();
        excelLog.logBooleanResult(expectedFilterHeader, columnDrillHeaderName, columnDrillHeaderName.equals(expectedFilterHeader), "Filter Header");

    }

    public void validateReportTableDrilDowncolmuns(List<List<String>> data) throws IOException, InterruptedException {
        cognosDateLodaingComplete();
        Thread.sleep(15000);
        int count = data.size(), columnIndex;
        String columnName = "", columnDrillHeaderName = "", reportHeaderName = "";
        for (int i = 1; i < count; i++) {
            columnName = data.get(i).get(0);
            columnDrillHeaderName = data.get(i).get(1);
            reportHeaderName = data.get(i).get(2);
//            columnIndex = findColumnIndex(columnName.split("#", 2)[0]);
            drillColLinkValidattion(columnName.split("#", 2)[0]).click();
            switchToLastOpenWindow();
            Thread.sleep(15000);
            cognosDateLodaingComplete();
            String expectedFilterHeader = obj_CognosReportCommon.reportFilterHeaderLabel().getText();
            CognosExcelLogUtil.tempRefer = "Drill Down Filter Header";
            excelLog.logBooleanResult(columnDrillHeaderName, expectedFilterHeader, columnDrillHeaderName.equals(expectedFilterHeader), "Filter Header");
            stringValidation(obj_CognosReportCommon.reportTitle().getText(), reportHeaderName);
            int arg1 = Integer.parseInt(data.get(i).get(3));
            reportClickTab(arg1);
            if (data.get(i).get(4).length() > 0 && !data.get(i).get(4).isEmpty() && !(data.get(i).get(4) == null)) {
                int arg2 = Integer.parseInt(data.get(i).get(4));
                currentTab = arg2 + "";
            }
            for (int j = 1; j < columnName.split("#").length; j++) {
                drillColLinkValidattion(columnName.split("#")[j]);
            }

        }

    }

    public void validateReportIrregularTableValues(List<List<String>> data) throws ParseException, InterruptedException, IOException {
        Thread.sleep(15000);

        List<List<String>> expectedRows = new ArrayList<>();
        List<List<Integer>> expectedRowSpaned = new ArrayList<>();
        List<String> expected = new ArrayList<>();
        List<Integer> rowSpan = new ArrayList<>();

        int intRowCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr")).size();
        int intColCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[1]/td")).size();
        String strTemp = "";
        for (int j = 1; j <= intColCount; j++) {
            strTemp =
                    findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[1]"))
                            .findElement(By.xpath("td[" + j + "]/span"))
                            .getText();
            expected.add(strTemp);
            rowSpan.add(0);


        }
        expectedRows.add(expected);
        expectedRowSpaned.add(rowSpan);

        expected = new ArrayList<>();
        rowSpan = new ArrayList<>();

        if (findElements(By.xpath("//td/a")).size() == 2) {
            Assert.assertTrue(findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom"));
        }

        do {

            Assert.assertTrue(waitForElementInVisible(By.id("CVWaitindicator_NS_")));


            intRowCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr")).size();

            for (int i = 2; i <= intRowCount; i++) {
                intColCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + i + "]/td")).size();
                for (int j = 1; j <= intColCount; j++) {
//                    //System.out.println("//table[starts-with(@lid,'"+currentTableLid+"" + currentTab + "')]/tbody/tr[" + i + "]/td[" + j + "]/span");
                    WebElement ele = findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + i + "]"))
                            .findElement(By.xpath("td[" + j + "]"));

                    expected.add(ele.getText());

                    boolean attrPresent = isAttribtuePresent(ele, "rowspan");
                    if (attrPresent) {
                        rowSpan.add(Integer.parseInt(ele.getAttribute("rowspan")));
                    } else {
                        rowSpan.add(0);
                    }


                }
                expectedRows.add(expected);
                expectedRowSpaned.add(rowSpan);
                expected = new ArrayList<>();
                rowSpan = new ArrayList<>();
            }
            if (findElements(By.xpath("(//td/a)[last()]")).size() > 0) {
                if (findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom")) {
                    obj_CognosReportCommon.reportTablePageDownLink().click();
                }
            } else {
                break;
            }
        } while (findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom"));


        for (int i = 0; i < expectedRowSpaned.size(); i++) {
            rowSpan = expectedRowSpaned.get(i);
            expected = expectedRows.get(i);
            for (int j = 0; j < rowSpan.size(); j++) {
                if (rowSpan.get(j) > 0) {
                    String addString = expected.get(j);

                    for (int k = 1; k < rowSpan.get(j); k++) {
                        String pre = expectedRows.get(i + k).toString();
                        expectedRows.get(i + k).add(j, addString);
                        expectedRowSpaned.get(i + k).add(j, 0);
                        String post = expectedRows.get(i + k).toString();

                    }


                }

            }
            if (!(expectedRows.get(i).size() == expectedRows.get(0).size())) {
                excelLog.logBooleanResult(expectedRows.get(i).size() + "", expectedRows.get(i).toString(), false, "HTML Table regular to irregular Conversion Missed for iteration : " + i);

            }
        }

        expectedRowSpaned.clear();
        for (int i = 0; i < expectedRows.size(); i++) {
            if (!(expectedRows.get(i).size() == expectedRows.get(0).size())) {
                excelLog.logBooleanResult(expectedRows.get(i).size() + "", expectedRows.get(i).toString(), false, "HTML Table regular to irregular Conversion Missed for iteration : " + i);
            }
        }
//        mfsalmfds
        int count = data.size(), columnIndex;
        String columnName = "", strCompare = "";

        intRowCount = expectedRows.size();
        for (int jtr = 1; jtr < intRowCount; jtr++) {
//

            for (int itr = 0; itr < count; itr++) {
                columnName = data.get(itr).get(0);
                boolean flag = true;
                if (columnName.equals("Stored validation")) {

//                    Policy Number#Transaction Type:700024329#NewBusiness;Average Incepted#Average Incepted (excluding override):£191.95#£191.95 |
                    String key = data.get(itr).get(1).split(";")[0];
                    if (key.equals("Stored key")) {
                        key = map.get("ComposedRowKey");
                    }
                    String[] cols = key.split(";")[0].split(":")[0].split("#");
                    String[] vals = key.split(";")[0].split(":")[1].split("#");
                    int valsCtr = 0;
                    ArrayList<Integer> colsIndex = new ArrayList<>();
                    for (String col : cols) {
                        colsIndex.add(findColumnIndex(col));
                    }
                    Assert.assertTrue(colsIndex.size() == cols.length);
                    for (int colIndex : colsIndex) {
                        if (!expectedRows.get(jtr).get(colIndex - 1).equals(vals[valsCtr++])) {
                            flag = false;
                            break;
                        }
                        flag = true;

                    }
                    if (flag) {
                        String s = data.get(itr).get(1).split(";")[1];
                        if (s.equals("Stored value")) {
                            s = map.get("ComposedRowValue");
                        }
                        tableRowValidation(expectedRows.get(jtr), s);
                    }

                } else if (!columnName.equals("Multi-Column validation")) {
                    columnIndex = findColumnIndex(columnName);
                    strCompare = expectedRows.get(jtr).get(columnIndex - 1);
                    tableCellValidation(data, strCompare, itr);
//                excelLog.logBooleanResult(columnName+" : "+columnIndex, strCompare+" : "+expectedRows.get(jtr),false,jtr+" : Debug");
                } else {

                    String comparesOperation = data.get(itr).get(1).split("#")[0];
                    String[] comparesColumn = data.get(itr).get(1).split("#", 2)[1].split("#");
                    List<Integer> ColumnIndexList = new ArrayList<>();
                    List<String> ColumnActualList = new ArrayList<>();
                    for (String s : comparesColumn) {
                        ColumnIndexList.add(findColumnIndex(s));
                    }
                    for (int ctr : ColumnIndexList) {
                        ColumnActualList.add(expectedRows.get(jtr).get(ctr - 1));
                    }
                    validateColumnRelation(comparesOperation, ColumnActualList);
                }

            }
        }


        expectedRows.clear();

    }

    public void tableRowValidation(List<String> strings, String s) {
        String[] cols = s.split(":")[0].split("#");
        String[] vals = s.split(":")[1].split("#");
        int valsCtr = 0;
        ArrayList<Integer> colsIndex = new ArrayList<>();
        for (String col : cols) {
            colsIndex.add(findColumnIndex(col));
        }
        Assert.assertTrue(colsIndex.size() == cols.length);

        for (int colIndex : colsIndex) {
            excelLog.logBooleanResult(strings.get(colIndex - 1),
                    vals[valsCtr], strings.get(colIndex - 1).equals(vals[valsCtr++]), "Table data validation");


        }

    }


    public void validateReportTableValues(List<List<String>> data) throws ParseException, IOException {
        int count = data.size(), columnIndex;
        String columnName = "", strCompare = "";
//
        int intRowCount;
        if (findElements(By.xpath("//td/a")).size() == 2) {
            Assert.assertTrue(findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom"));
        }
        do {
            Assert.assertTrue(waitForElementInVisible(By.id("CVWaitindicator_NS_")));
            intRowCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr")).size();
            for (int j = 2; j <= intRowCount; j++) {
//
                int rowspan = 0;
                for (int i = 0; i < count; i++) {
                    columnName = data.get(i).get(0);


//                    try {
//                        rowspan = Integer.parseInt(obj_CognosReportCommon.reportTable().findElement(By.xpath("tbody/tr[" + currentRow + "]/td[" + columnIndex + "]")).getAttribute("rowspan")) - 1;
//                    } catch (Exception e)
//                    {
//
//                    }
                    int currentRow = j;
                    if (!columnName.equals("Multi-Column validation")) {
                        columnIndex = findColumnIndex(columnName);

                        strCompare = obj_CognosReportCommon.reportTable().findElement(By.xpath("tbody/tr[" + currentRow + "]/td[" + columnIndex + "]/span")).getText();
                        tableCellValidation(data, strCompare, i);


                    } else {
                        String comparesOperation = data.get(i).get(1).split("#")[0];
                        String[] comparesColumn = data.get(i).get(1).split("#", 2)[1].split("#");
                        List<Integer> ColumnIndexList = new ArrayList<>();
                        List<String> ColumnActualList = new ArrayList<>();
                        for (String s : comparesColumn) {
                            ColumnIndexList.add(findColumnIndex(s));
                        }
                        for (int ctr : ColumnIndexList) {
//                            ColumnActualList.add(expectedRows.get(jtr).get(ctr - 1));
                            ColumnActualList.add(obj_CognosReportCommon.
                                    reportTable().
                                    findElement(By.xpath("tbody/tr[" + currentRow + "]/td[" + ctr + "]/span")).
                                    getText());
                        }
                        validateColumnRelation(comparesOperation, ColumnActualList);
                    }


//input here


                    //System.out.println(strCompare + " : " + data.get(i).get(1));


                }
//
                j = j + rowspan;

            }
            if (findElements(By.xpath("(//td/a)[last()]")).size() == 1) {
                if (findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom")) {
                    obj_CognosReportCommon.reportTablePageDownLink().click();

                }
            } else {
                break;
            }

        } while (findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom"));
//
    }

    public void validateColumnRelation(String comparesOperation, List<String> columnActualList) throws IOException, ParseException {
        switch (comparesOperation) {
            case "Equals":
                excelLog.logBooleanResult(columnActualList.get(0) + " = " + columnActualList.get(1), "Not Equal", columnActualList.get(0) == columnActualList.get(1), "");
                break;
            case "Greater than(Integer)":
                excelLog.logBooleanResult(columnActualList.get(0) + " > " + columnActualList.get(1), "Not Greater than", Integer.parseInt(columnActualList.get(0)) > Integer.parseInt(columnActualList.get(1)), "");
                break;
            case "Greater than(Decimal)":
                excelLog.logBooleanResult(columnActualList.get(0) + " > " + columnActualList.get(1), "Not Greater than", Float.parseFloat(columnActualList.get(0)) > Float.parseFloat(columnActualList.get(1)), "");
                break;
            case "Greater than(Percentage)":
                excelLog.logBooleanResult(columnActualList.get(0) + " > " + columnActualList.get(1), "Not Greater than", Float.parseFloat(columnActualList.get(0).replace("%", "")) > Float.parseFloat(columnActualList.get(1).replace("%", "")), "");
                break;
            case "Ratio calculation":
                Float rate;
                if (Float.parseFloat(columnActualList.get(2)) > 0) {
                    rate = Float.parseFloat(columnActualList.get(1)) / Float.parseFloat(columnActualList.get(2)) * 100;
                } else {
                    rate = Float.parseFloat("0");
                }
                DecimalFormat df = new DecimalFormat("###.##");
                String strActual = String.format("%.2f", rate) + "%";

                excelLog.logBooleanResult("Ratio : " + columnActualList.get(0) + " = " + columnActualList.get(1) + " / " + columnActualList.get(2), "Not Equal : " + strActual,
                        columnActualList.get(0).equals(strActual), "");
                break;

            case "Ratio calculation(Currency)":
                if (!(columnActualList.get(1).contains("(") || columnActualList.get(1).contains(")") || columnActualList.get(1).contains("(") || columnActualList.get(2).contains("(") || columnActualList.get(2).contains(")"))) {
                    Float rate2;
                    if (Float.parseFloat(columnActualList.get(2).replace("£", "").replace(",", "")) > 0) {
                        rate2 = Float.parseFloat(columnActualList.get(1).replace("£", "").replace(",", "")) / Float.parseFloat(columnActualList.get(2).replace("£", "").replace(",", "")) * 100;
                    } else {
                        rate2 = Float.parseFloat("0");
                    }
                    DecimalFormat df2 = new DecimalFormat("###.##");
                    String strActual2 = String.format("%.2f", rate2) + "%";

                    excelLog.logBooleanResult("Ratio : " + columnActualList.get(0) + " = " + columnActualList.get(1) + " / " + columnActualList.get(2), "Not Equal : " + strActual2,
                            columnActualList.get(0).equals(strActual2), "");
                } else {
                    excelLog.logBooleanResult("Ratio : " + columnActualList.get(0) + " = " + columnActualList.get(1) + " / " + columnActualList.get(2), "contains brackets, ( or ), in one of the comparison values",
                            false, "");

                }
                break;

            case "Greater than or equal to(Integer)":
                excelLog.logBooleanResult(columnActualList.get(0) + " >= " + columnActualList.get(1), "Not Greater than", Integer.parseInt(columnActualList.get(0)) >= Integer.parseInt(columnActualList.get(1)), "");
                break;
            case "Greater than or equal to(Decimal)":
                excelLog.logBooleanResult(columnActualList.get(0) + " >= " + columnActualList.get(1), "Not Greater than", Float.parseFloat(columnActualList.get(0)) >= Float.parseFloat(columnActualList.get(1)), "");
                break;
            case "Greater than or equal to(Percentage)":
                excelLog.logBooleanResult(columnActualList.get(0) + " >= " + columnActualList.get(1), "Not Greater than", Float.parseFloat(columnActualList.get(0).replace("%", "")) >= Float.parseFloat(columnActualList.get(1).replace("%", "")), "");
                break;

            case "Greater than or equal to(Currency)":
                if (!(columnActualList.get(1).contains("(") || columnActualList.get(1).contains(")") || columnActualList.get(1).contains("(") || columnActualList.get(0).contains("(") || columnActualList.get(0).contains(")"))) {

                    excelLog.logBooleanResult(columnActualList.get(0) + " >= " + columnActualList.get(1), "Not Greater than", Float.parseFloat(columnActualList.get(0).replace("£", "").replace(",", "")) >= Float.parseFloat(columnActualList.get(1).replace("£", "").replace(",", "")), "");
                } else {
                    excelLog.logBooleanResult("Greater than or equal to(Currency) : " + columnActualList.get(0) + " >= " + columnActualList.get(1), "contains brackets, ( or ), in one of the comparison values",
                            false, "");

                }
                break;
            case "Calculation-Tax(12%or0%)":

                String strColumnTax = columnActualList.get(0).replace(",", "").replace("£", "");
                String strColumnPremium = columnActualList.get(1).replace(",", "").replace("£", "");
                DecimalFormat df1 = new DecimalFormat("###.##");
                try {
                    String strActualTax = String.format("%.2f", Float.parseFloat(df1.format(Float.parseFloat(strColumnPremium) * Float.parseFloat("12.0") / 100)));
                    excelLog.logBooleanResult("Tax either 0% or 12% of " + strColumnPremium + " = " + strColumnTax, strActualTax, strActualTax.equals(strColumnTax) || strActualTax.equals("0.00"), "");
                } catch (NumberFormatException e) {
                    excelLog.logBooleanResult("Tax either 0% or 12% of " + strColumnPremium + " = " + strColumnTax, "Format issue", false, "");

                }
                break;

            case "Calculation-Tax(10%)":

                String strColumnTax10 = columnActualList.get(0).replace(",", "").replace("£", "");
                String strColumnPremium10 = columnActualList.get(1).replace(",", "").replace("£", "");
                DecimalFormat df10 = new DecimalFormat("###.##");
                String strActualTax10 = String.format("%.2f", Float.parseFloat(df10.format(Float.parseFloat(strColumnPremium10) * Float.parseFloat("10.0") / 100)));


                excelLog.logBooleanResult("Tax 10% of " + strColumnPremium10 + " = " + strColumnTax10, strActualTax10, strActualTax10.equals(strColumnTax10), "");
                break;

            case "Summation(Currency)":
                String expSum = columnActualList.get(0).replace(",", "").replace("£", "");
                Float actSum = Float.valueOf(0);
                try {
                    for (int itr = 1; itr < columnActualList.size(); itr++) {
                        actSum = actSum + Float.parseFloat(columnActualList.get(itr).replace(",", "").replace("£", ""));
                    }


                    excelLog.logBooleanResult("Sum of values : " + expSum, actSum + "", expSum.equals(String.format("%.2f", actSum) + ""), "");
                } catch (NumberFormatException e) {
                    excelLog.logBooleanResult("Sum of values : " + expSum, actSum + " : Format issue", false, "");

                }
                break;

            case "Last Name to URN":
                validateLastNametoUrn(columnActualList.get(0), Integer.parseInt(columnActualList.get(1)));
                break;
            case "UACStatusVsTD":

                switch (columnActualList.get(0)) {
                    case "Authorised":
                        excelLog.logBooleanResult("Termination column should be blank", columnActualList.get(1), columnActualList.get(1).isEmpty() || columnActualList.get(9).equals(""), "");

                        break;

                    case "No Access":
                        excelLog.logBooleanResult("Termination column should not be blank", columnActualList.get(1), !(columnActualList.get(1).isEmpty() || columnActualList.get(9).equals("")), "");


                        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM d, yyyy");
                        dateFormat.setLenient(false);
                        try {
                            dateFormat.parse(columnActualList.get(9).trim());
                        } catch (ParseException pe) {
                            excelLog.logBooleanResult("Terminate Date, Valid date format", columnActualList.get(9), false, "usrId");

                        }


                        break;

                    default:

                        excelLog.logBooleanResult("Status unknown", columnActualList.get(6), false, "");
                }
                break;
            case "UAC":
                String usrId = columnActualList.get(0);
                excelLog.logBooleanResult("Racf ID is equal to User Id",
                        "Not Equal",
                        usrId.equals(columnActualList.get(1)), "UAC Report validation : " + usrId);
                List<String> expectedlist = getActualUAC_RowValues(usrId);
                int ctrExp = 2;
                for (String expected : expectedlist) {
                    excelLog.logBooleanResult(expected.trim(), columnActualList.get(ctrExp), expected.trim().equals(columnActualList.get(ctrExp)), usrId);
                    ctrExp++;

                }

                switch (columnActualList.get(6)) {
                    case "Authorised":
                        excelLog.logBooleanResult("Termination column should be blank", columnActualList.get(9), columnActualList.get(9).isEmpty() || columnActualList.get(9).equals(""), usrId);

                        break;

                    case "No Access":
                        excelLog.logBooleanResult("Termination column should not be blank", columnActualList.get(9), !(columnActualList.get(9).isEmpty() || columnActualList.get(9).equals("")), usrId);


                        SimpleDateFormat dateFormat1 = new SimpleDateFormat("MMM d, yyyy");
                        dateFormat1.setLenient(false);
                        try {
                            dateFormat1.parse(columnActualList.get(9).trim());
                        } catch (ParseException pe) {
                            excelLog.logBooleanResult("Terminate Date, Valid date format", columnActualList.get(9), false, "usrId");

                        }

                        break;

                    default:

                        excelLog.logBooleanResult("Status unknown", columnActualList.get(6), false, usrId);
                }


                break;

        }

    }

    public void tableCellValidation(List<List<String>> data, String strCompare, int i) throws ParseException, IOException {
        boolean flag = true;
        strCompare = strCompare.trim();
        switch (data.get(i).get(1).split("#")[0]) {

            case "Date":

                SimpleDateFormat dateFormat = new SimpleDateFormat("MMM d, yyyy");
                dateFormat.setLenient(false);
                try {
                    dateFormat.parse(strCompare.trim());
                } catch (ParseException pe) {
                    excelLog.logBooleanResult("Valid date format", strCompare, false, "");

                }


                break;


            case "Date Range":
                String sDate1 = strCompare;
                String sDate2 = data.get(i).get(1).split("#")[1];
                String sDate3 = data.get(i).get(1).split("#")[2];
                Date date1 = new SimpleDateFormat("MMM d, yyyy").parse(sDate1);
                if (NumberUtils.isNumber(sDate2)) {

                    sDate2 = returnDate(Integer.parseInt(sDate2));
                }
                if (NumberUtils.isNumber((sDate3))) {
                    sDate3 = returnDate(Integer.parseInt(sDate3));
                }
                Date date2 = new SimpleDateFormat("MMM d, yyyy").parse(sDate2);
                Date date3 = new SimpleDateFormat("MMM d, yyyy").parse(sDate3);
                isWithinRange(date1, date2, date3, "Date Range");
                break;
            case "Date Range(dd-MM-yy)":
                String sDate1f = strCompare;
                String sDate2f = data.get(i).get(1).split("#")[1];
                String sDate3f = data.get(i).get(1).split("#")[2];
                Date date1f = new SimpleDateFormat("dd-MM-yy").parse(sDate1f);
                if (NumberUtils.isNumber(sDate2f)) {

                    sDate2f = returnDate(Integer.parseInt(sDate2f));
                }
                if (NumberUtils.isNumber((sDate3f))) {
                    sDate3f = returnDate(Integer.parseInt(sDate3f));
                }
                Date date2f = new SimpleDateFormat("MMM d, yyyy").parse(sDate2f);
                Date date3f = new SimpleDateFormat("MMM d, yyyy").parse(sDate3f);
                isWithinRange(date1f, date2f, date3f, "Date Range");
                break;

            case "Month Range":
                String sMonth1 = strCompare;
                String sMonth2 = data.get(i).get(1).split("#")[1];
                String sMonth3 = data.get(i).get(1).split("#")[2];
                if (NumberUtils.isNumber(sMonth2)) {

                    sMonth2 = returnMonth(Integer.parseInt(sMonth2));
                }
                if (NumberUtils.isNumber((sMonth3))) {
                    sMonth3 = returnMonth(Integer.parseInt(sMonth3));
                }
                HashMap<String, Integer> hm = new HashMap<String, Integer>();
                hm.put("January", 1);
                hm.put("Febraury", 2);
                hm.put("March", 3);
                hm.put("April", 4);
                hm.put("May", 5);
                hm.put("June", 6);
                hm.put("July", 7);
                hm.put("August", 8);
                hm.put("September", 9);
                hm.put("October", 10);
                hm.put("November", 11);
                hm.put("December", 12);

                int cmprInt = hm.get(sMonth1);
                int strInt = hm.get(sMonth2);
                int endInt = hm.get(sMonth3);
                excelLog.logBooleanResult(sMonth2 + " - " + sMonth3, sMonth1,
                        (strInt <= cmprInt && endInt >= cmprInt), "Month Comparison");


                break;

            case "Value Set":
//                            Assert.assertTrue(data.get(i).get(1).split("#", 2)[1].contains("'" + strCompare + "'"));
                excelLog.logBooleanResult("Is one of theses values: " + data.get(i).get(1).split("#", 2)[1],
                        "'" + strCompare + "'",
                        data.get(i).get(1).split("#", 2)[1].contains("'" + strCompare + "'"),
                        "");
                break;
            case "Policy Number":
                Pattern p = Pattern.compile("^(7){1}\\d{8}$");
                Matcher m = p.matcher(strCompare);

//                            Assert.assertTrue(m.find());
                excelLog.logBooleanResult("Policy Number is 9 digit number, starts with 7 ",
                        strCompare, m.find(), "");
                break;

            case "Blanks":
                excelLog.logBooleanResult("Blanks", strCompare, strCompare.equals(""), "");
                break;
            case "Blanks or Numbers":
                Pattern p1 = Pattern.compile("^\\d+$");
                Matcher m1 = p1.matcher(strCompare);
                excelLog.logBooleanResult("Blanks or Numbers", strCompare, strCompare.equals("") || m1.find(), "");
                break;

            case "Numbers":
                Pattern p2 = Pattern.compile("^\\d+$");
                Matcher m2 = p2.matcher(strCompare);
                excelLog.logBooleanResult("Numbers", strCompare, m2.find(), "");
                break;

            case "Blanks or Currency":
                Pattern p1c = Pattern.compile("^(£){1}\\d+(\\.){1}\\d{2}$");
                Matcher m1c = p1c.matcher(strCompare.replace(",", "").replace("-", ""));
                excelLog.logBooleanResult("Blanks or Currencies", strCompare, strCompare.equals("") || m1c.find(), "");
                break;

            case "Currency":
                Pattern pc = Pattern.compile("^(£){1}\\d+(\\.){1}\\d{2}$");
                Matcher mc = pc.matcher(strCompare.replace(",", "").replace("-", ""));
                excelLog.logBooleanResult("Currencies", strCompare, mc.find(), "");
                break;
            case "PercentageWith1Or2DecimalPoint":
                Pattern pct = Pattern.compile("(^\\d+(\\.){1}\\d{2}%{1}$)|(^\\d+(\\.){1}\\d{1}%{1}$)");
                Matcher mct = pct.matcher(strCompare.replace(",", "").replace("-", ""));
                excelLog.logBooleanResult("PercentageWith1Or2DecimalPoint", strCompare, mct.find(), "");
                break;
            case "NumberWith1Or2DecimalPoint":
                Pattern pnum = Pattern.compile("(^\\d+(\\.){1}\\d{2}$)|(^\\d+(\\.){1}\\d{1}$)");
                Matcher mnum = pnum.matcher(strCompare.replace(",", "").replace("-", ""));
                excelLog.logBooleanResult("NumberWith1Or2DecimalPoint", strCompare, mnum.find(), "");
                break;
            case "CurrencyWith1Or2DecimalPoint":
                Pattern pcur = Pattern.compile("(^£\\d+(\\.){1}\\d{2}$)|(^£\\d+(\\.){1}\\d{1}$)");
                Matcher mcur = pcur.matcher(strCompare.replace(",", "").replace("-", ""));
                excelLog.logBooleanResult("CurrencyWith1Or2DecimalPoint", strCompare, mcur.find(), "");
                break;

            case "PercentageWith0OrNonZeroWith1Or2DecimalPoint":
                Pattern pct0 = Pattern.compile("(^\\d+(\\.){1}\\d{2}%{1}$)|(^\\d+(\\.){1}\\d{1}%{1}|^0{1}%{1}$)");
                Matcher mct0 = pct0.matcher(strCompare.replace(",", "").replace("-", ""));
                excelLog.logBooleanResult("PercentageWith1Or2DecimalPoint", strCompare, mct0.find(), "");
                break;
            case "NumberWith0OrNonZeroWith1Or2DecimalPoint":
                Pattern pnum0 = Pattern.compile("(^\\d+(\\.){1}\\d{2}$)|(^\\d+(\\.){1}\\d{1}|^0{1}%{1}$)");
                Matcher mnum0 = pnum0.matcher(strCompare.replace(",", "").replace("-", ""));
                excelLog.logBooleanResult("NumberWith1Or2DecimalPoint", strCompare, mnum0.find(), "");
                break;
            case "CurrencyWith0OrNonZeroWith1Or2DecimalPoint":
                Pattern pcur0 = Pattern.compile("(^£\\d+(\\.){1}\\d{2}$)|(^£\\d+(\\.){1}\\d{1}|^0{1}%{1}$)");
                Matcher mcur0 = pcur0.matcher(strCompare.replace(",", "").replace("-", ""));
                excelLog.logBooleanResult("CurrencyWith1Or2DecimalPoint", strCompare, mcur0.find(), "");
                break;



            case "Starts-with":
                String[] start = data.get(i).get(1).split("#", 2)[1].split("#");
                flag = false;
                for (String s : start) {
                    if (strCompare.startsWith(s)) {
                        flag = true;
                    }
                }
                excelLog.logBooleanResult("Starts with " + data.get(i).get(1).split("#", 2)[1], strCompare, flag, "");
                break;
            case "Ends-with":
                String[] end = data.get(i).get(1).split("#", 2)[1].split("#");
                flag = false;
                for (String s : end) {
                    if (strCompare.endsWith(s)) {
                        flag = true;
                    }
                }
                excelLog.logBooleanResult("Ends with " + data.get(i).get(1).split("#", 2)[1], strCompare, flag, "");
                break;
            case "User Name":
                validateLastName(strCompare);
//                WebServiceFunctionalUtil functionalUtil = new WebServiceFunctionalUtil();
//                String searchProductResponse = functionalUtil.searchProduct(strCompare);
//                excelLog.logBooleanResult("Valid User Name",strCompare,!searchProductResponse.contains("<message>Unauthorized to execute request. Please login first.</message>"),"");
                break;
            case "System User Name":
                validateSystemUserLastName(strCompare);
                break;

            case "Not Empty":
                excelLog.logBooleanResult("Not Empty", strCompare, !(strCompare.isEmpty() || strCompare.equals("")), "");
                break;


            default:
                Assert.assertTrue(false);


        }
    }


    public void validateTaxReportTaxCalculations() throws ParseException {

//
        int intRowCount;
        int columnIndexTaxRate = findColumnIndex("Tax Rate");
        int columnIndexTaxAmount = findColumnIndex("Tax Amount");
        int columnIndexGPW = findColumnIndex("Gross Premium Written Amount Excluding IPT (Per Coverage)");
        if (findElements(By.xpath("//td/a")).size() == 2) {
            Assert.assertTrue(findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom"));
        }
        do {
            Assert.assertTrue(waitForElementInVisible(By.id("CVWaitindicator_NS_")));
            intRowCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr")).size();
            for (int j = 1; j <= intRowCount; j++) {
                String strColumnIndexTaxRate = obj_CognosReportCommon.reportTable().findElement(By.xpath("tbody/tr[2]/td[" + columnIndexTaxRate + "]/span")).getText();
                String strColumnIndexTaxAmount = obj_CognosReportCommon.reportTable().findElement(By.xpath("tbody/tr[2]/td[" + columnIndexTaxAmount + "]/span")).getText();
                String strColumnIndexGPW = obj_CognosReportCommon.reportTable().findElement(By.xpath("tbody/tr[2]/td[" + columnIndexGPW + "]/span")).getText();
                strColumnIndexTaxRate = strColumnIndexTaxRate.split("%")[0];
                DecimalFormat df = new DecimalFormat("###.##");
                String strActualTax = String.format("%.2f", Float.parseFloat(df.format(Float.parseFloat(strColumnIndexTaxRate) * Float.parseFloat(strColumnIndexGPW) / 100)));
                Assert.assertTrue(strColumnIndexTaxAmount.equals(strActualTax));


            }
            if (findElements(By.xpath("(//td/a)[last()]")).size() > 0) {
                if (findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom")) {
                    obj_CognosReportCommon.reportTablePageDownLink().click();

                }
            } else {
                break;
            }

        } while (findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom"));
//
    }


    public void validateReportRowNotPresent(List<List<String>> data, int rowIndex) {
        int count = data.get(0).size(), intValColumn;
        String strExpected = "", strActual = "";
        WebElement eleValue;
        for (int i = 0; i < count; i++) {

            //System.out.println(data.get(0).get(i) + " : " + data.get(1).get(i));
            intValColumn = findColumnIndex(data.get(0).get(i).trim());
            //System.out.println(intValColumn);
            strExpected = data.get(1).get(i);
            eleValue = waitForElementPresent(
                    By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + rowIndex + "]/td[" + intValColumn + "]/span"));
//            eleValue.click();
            strActual = eleValue.getText().trim() + "";
            Assert.assertTrue(!strExpected.equals(strActual));

        }

    }

    public String returnDate(int intDate) {
        Calendar date = Calendar.getInstance();
        date.add(Calendar.DATE, intDate);
        String timeStamp = new SimpleDateFormat("MMM d, yyyy").format(date.getTime());
        return timeStamp;
    }

    public String returnDate(int intDate, String format) {
        Calendar date = Calendar.getInstance();
        date.add(Calendar.DATE, intDate);
        String timeStamp = new SimpleDateFormat(format).format(date.getTime());
        return timeStamp;
    }

    public String returnMonth(int intDate) {
        Calendar date = Calendar.getInstance();
        date.add(Calendar.DATE, intDate);
        String timeStamp = new SimpleDateFormat("MMMM").format(date.getTime());
        return timeStamp;
    }

    public String returnYear(int intDate) {
        Calendar date = Calendar.getInstance();
        date.add(Calendar.DATE, intDate);
        String timeStamp = new SimpleDateFormat("yyyy").format(date.getTime());
        return timeStamp;
    }


    public Boolean waitForElementInVisible(By by) {
        if (hvWaitFlag) {
            Wait<WebDriver> wait = new WebDriverWait(getDriver, 7200L);
            return (Boolean) wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
        } else {
            Wait<WebDriver> wait = new WebDriverWait(getDriver, 1200L);
            return (Boolean) wait.until(ExpectedConditions.invisibilityOfElementLocated(by));
        }
    }
public String saveDownloadFile() throws AWTException, InterruptedException, IOException
{
    return saveDownloadFile(".xlsx");
}
    public String saveDownloadFile(String fileExt) throws AWTException, InterruptedException, IOException {
        Robot robot = new Robot();
        Thread.sleep(15000);

        File excelFile = new File("target/" + obj_generalInformationUtil.randomFirstName() + fileExt);

        strSaveFileLocation = excelFile.getCanonicalPath();;
        StringSelection stringSelection = new StringSelection(strSaveFileLocation);
        Clipboard clpbrd = Toolkit.getDefaultToolkit().getSystemClipboard();
        clpbrd.setContents(stringSelection, null);
        robot.keyPress(KeyEvent.VK_CONTROL);
        robot.keyPress(KeyEvent.VK_V);
        robot.keyRelease(KeyEvent.VK_CONTROL);
        robot.keyRelease(KeyEvent.VK_V);
        robot.keyPress(KeyEvent.VK_ENTER);
        robot.keyRelease(KeyEvent.VK_ENTER);
        return strSaveFileLocation;
    }

    public void saveReportASExcel2007Data() {
        obj_CognosReportCommon.viewReportAsButton().click();
        obj_CognosReportCommon.viewReportAsExcelButton().click();
        obj_CognosReportCommon.viewReportAsExcel2007DataButton().click();
    }

    public void saveReportASExcel2007Format() {
        obj_CognosReportCommon.viewReportAsButton().click();
        obj_CognosReportCommon.viewReportAsExcelButton().click();
        obj_CognosReportCommon.viewReportAsExcel2007FormatButton().click();
    }

    public void saveReportASExcel2002Format() {
        obj_CognosReportCommon.viewReportAsButton().click();
        obj_CognosReportCommon.viewReportAsExcelButton().click();
        obj_CognosReportCommon.viewReportAsExcel2002FormatButton().click();
    }

   

    private boolean isAttribtuePresent(WebElement element, String attribute) {
        Boolean result = false;
        try {
            String value = element.getAttribute(attribute);
            if (value != null) {
                result = true;
            }
        } catch (Exception e) {
        }

        return result;
    }

    public void validateExcelFile2(String strColumns, String strCurrencies, String strFloats, String strRates, String strNumbers) throws InterruptedException, IOException {
        Thread.sleep(15000);

        List<List<String>> expectedRows = new ArrayList<>();
        List<List<Integer>> expectedRowSpaned = new ArrayList<>();
        List<String> expected = new ArrayList<>();
        List<Integer> rowSpan = new ArrayList<>();

        int intRowCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr")).size();
        int intColCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[1]/td")).size();
        String strTemp = "";
        for (int j = 1; j <= intColCount; j++) {
            strTemp =
                    findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[1]"))
                            .findElement(By.xpath("td[" + j + "]/span"))
                            .getText();
            expected.add(strTemp);
            rowSpan.add(0);


        }
        expectedRows.add(expected);
        expectedRowSpaned.add(rowSpan);

        expected = new ArrayList<>();
        rowSpan = new ArrayList<>();

        if (findElements(By.xpath("//td/a")).size() == 2) {
            Assert.assertTrue(findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom"));
        }

        do {

            Assert.assertTrue(waitForElementInVisible(By.id("CVWaitindicator_NS_")));


            intRowCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr")).size();

            for (int i = 2; i <= intRowCount; i++) {
                intColCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + i + "]/td")).size();
                for (int j = 1; j <= intColCount; j++) {
//                    //System.out.println("//table[starts-with(@lid,'"+currentTableLid+"" + currentTab + "')]/tbody/tr[" + i + "]/td[" + j + "]/span");
                    WebElement ele = findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + i + "]"))
                            .findElement(By.xpath("td[" + j + "]"));

                    expected.add(ele.getText());

                    boolean attrPresent = isAttribtuePresent(ele, "rowspan");
                    if (attrPresent) {
                        rowSpan.add(Integer.parseInt(ele.getAttribute("rowspan")));
                    } else {
                        rowSpan.add(0);
                    }


                }
                expectedRows.add(expected);
                expectedRowSpaned.add(rowSpan);
                expected = new ArrayList<>();
                rowSpan = new ArrayList<>();
            }
            if (findElements(By.xpath("(//td/a)[last()]")).size() > 0) {
                if (findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom")) {
                    obj_CognosReportCommon.reportTablePageDownLink().click();
                }
            } else {
                break;
            }
        } while (findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom"));


        for (int i = 0; i < expectedRowSpaned.size(); i++) {
            rowSpan = expectedRowSpaned.get(i);
            expected = expectedRows.get(i);
            for (int j = 0; j < rowSpan.size(); j++) {
                if (rowSpan.get(j) > 0) {
                    String addString = expected.get(j);

                    for (int k = 1; k < rowSpan.get(j); k++) {
//                        String pre = expectedRows.get(i + k).toString();
                        expectedRows.get(i + k).add(j, addString);
                        expectedRowSpaned.get(i + k).add(j, 0);
//                        String post = expectedRows.get(i + k).toString();

                    }


                }

            }

        }
        expectedRowSpaned.clear();
        for (int i = 0; i < expectedRows.size(); i++) {
            excelLog.logBooleanResult(expectedRows.get(i).size() + "", expectedRows.get(i).toString(), expectedRows.get(i).size() == expectedRows.get(0).size(), "HTML Table regular to irregular Conversion Missed for iteration : " + i);
        }


        FileInputStream download = new FileInputStream(strSaveFileLocation);
        XSSFWorkbook wb = new XSSFWorkbook(download);
        XSSFSheet sheet = wb.getSheetAt(currentExcelSheet - 1);
//         strIndCol,  strDepCol;

        int sheetMergeCount = sheet.getNumMergedRegions();
        for (int i = 0; i < sheetMergeCount; i++) {
            CellRangeAddress ca = sheet.getMergedRegion(i);

            int firstColumn = ca.getFirstColumn();
            int lastColumn = ca.getLastColumn();
            int firstRow = ca.getFirstRow();
            int lastRow = ca.getLastRow();

            XSSFRow xssfFirstRow = sheet.getRow(firstRow);
            XSSFCell firstCell = xssfFirstRow.getCell(firstColumn);
            for (int j = firstRow; j <= lastRow; j++) {
                for (int k = firstColumn; k <= lastColumn; k++) {
                    XSSFRow xssfCurrentRow = sheet.getRow(j);
                    XSSFCell currentCell = xssfCurrentRow.getCell(k);
                    currentCell.setCellStyle(firstCell.getCellStyle());
                    currentCell.setCellType(firstCell.getCellType());
                    switch (firstCell.getCellType()) {
                        case Cell.CELL_TYPE_BLANK:
                            currentCell.setCellValue(firstCell.getStringCellValue());
                            continue;
                        case Cell.CELL_TYPE_BOOLEAN:
                            currentCell.setCellValue(firstCell.getBooleanCellValue());
                            continue;
                        case Cell.CELL_TYPE_ERROR:
                            currentCell.setCellErrorValue(firstCell.getErrorCellValue());
                            continue;
                        case Cell.CELL_TYPE_FORMULA:
                            currentCell.setCellFormula(firstCell.getCellFormula());
                            continue;
                        case Cell.CELL_TYPE_NUMERIC:
                            currentCell.setCellValue(firstCell.getNumericCellValue());
                            continue;
                        case Cell.CELL_TYPE_STRING:
                            currentCell.setCellValue(firstCell.getRichStringCellValue());
                            continue;
                    }


                }
            }


        }
        FileOutputStream out = new FileOutputStream(strSaveFileLocation);
        wb.write(out);
//
        sheet = wb.getSheetAt(currentExcelSheet - 1);
        List<String> expectedConv = new ArrayList<String>();
        for (int itr = 0; itr < expectedRows.size(); itr++) {
            expectedConv.addAll(expectedRows.get(itr));

        }
        expectedRows.clear();

        List<String> actual = new ArrayList<String>();
        //System.out.println(sheet.getPhysicalNumberOfRows()-currentExcelEndRowCorretion);
        boolean dateFlag = false;
        for (int k = currentExcelStartRow - 1; k < (sheet.getPhysicalNumberOfRows() - currentExcelEndRowCorretion); k++) {
            //System.out.println("K : " + k);
            XSSFRow row = sheet.getRow(k);
            for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
                actual.add(excelConv(strColumns, strCurrencies, strFloats, strRates, strNumbers, row, i, k));

            }
            //System.out.println(k);
        }


        boolean flag = true;
        if (expectedConv.size() == actual.size()) {
            for (int i = 0; i < expectedConv.size(); i++) {
                if (!expectedConv.get(i).equals(actual.get(i))) {
//                    flag = false;
                    excelLog.logBooleanResult(expectedConv.get(i), actual.get(i), false, i + "");
//
                }

            }
//            Assert.assertTrue(flag);
        } else {
            flag = false;
            excelLog.logBooleanResult(expectedConv.size() + "", actual.size() + "", false, "Record mismatch between Excel and HTML Table");
            Assert.assertTrue(flag);
        }
        expectedConv.clear();


    }

    public void validateExcel2002FileFirstHeaderRowAlone()  throws IOException, InterruptedException
    {
        Thread.sleep(15000);
        FileInputStream download = new FileInputStream(strSaveFileLocation);
        HSSFWorkbook wb = new HSSFWorkbook(download);
        HSSFSheet sheet = wb.getSheetAt(currentExcelSheet - 1);

        HSSFRow row = sheet.getRow( currentExcelStartRow - 1);


        int intColCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[1]/td")).size();
        String strTemp = "";
        List<String> expected = new ArrayList<String>(), actual = new ArrayList<String>();
        for (int i = 0; i < row.getPhysicalNumberOfCells(); i++)
        {
            HSSFCell cell = row.getCell(i);
            cell.setCellType(Cell.CELL_TYPE_STRING);
            actual.add(cell.getStringCellValue());
        }
        for (int j = 1; j <= intColCount; j++) {
            strTemp =
                    findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[1]"))
                            .findElement(By.xpath("td[" + j + "]/span"))
                            .getText();
            expected.add(strTemp);


        }
        boolean flag = true;
        if (expected.size() == actual.size()) {
            for (int i = 0; i < expected.size(); i++) {
                if (!expected.get(i).equals(actual.get(i).split("\n")[0])) {

                    excelLog.logBooleanResult(expected.get(i), actual.get(i), false, i + "");

                }

            }

        } else {
            flag = false;
            excelLog.logBooleanResult(expected.size() + "", actual.size() + "", false, "Record mismatch between Excel and HTML Table");
            Assert.assertTrue(flag);
        }

    }



    public void validateExcelFileFirstHeaderRowAlone()  throws IOException, InterruptedException
    {
        Thread.sleep(15000);
        FileInputStream download = new FileInputStream(strSaveFileLocation);
        XSSFWorkbook wb = new XSSFWorkbook(download);
        XSSFSheet sheet = wb.getSheetAt(currentExcelSheet - 1);

        XSSFRow row = sheet.getRow( currentExcelStartRow - 1);


        int intColCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[1]/td")).size();
        String strTemp = "";
        List<String> expected = new ArrayList<String>(), actual = new ArrayList<String>();
//        Cell cell;
        for (int i = 0; i < row.getPhysicalNumberOfCells(); i++)

        {

            XSSFCell cell = row.getCell(i);
            cell.setCellType(Cell.CELL_TYPE_STRING);
            String val = cell.getRawValue();
            actual.add(cell.getStringCellValue());

        }
        for (int j = 1; j <= intColCount; j++) {
            strTemp =
                    findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[1]"))
                            .findElement(By.xpath("td[" + j + "]/span"))
                            .getText();
            expected.add(strTemp);


        }
        boolean flag = true;
        if (expected.size() == actual.size()) {
            for (int i = 0; i < expected.size(); i++) {
                if (!expected.get(i).equals(actual.get(i).split("\n")[0])) {

                    excelLog.logBooleanResult(expected.get(i), actual.get(i), false, i + "");

                }

            }

        } else {
            flag = false;
            excelLog.logBooleanResult(expected.size() + "", actual.size() + "", false, "Record mismatch between Excel and HTML Table");
            Assert.assertTrue(flag);
        }

    }

    public void validateExcelFile(String strColumns, String strCurrencies, String strFloats, String strRates, String strNumbers) throws IOException, InterruptedException {
        Thread.sleep(15000);
        FileInputStream download = new FileInputStream(strSaveFileLocation);
        XSSFWorkbook wb = new XSSFWorkbook(download);
        XSSFSheet sheet = wb.getSheetAt(currentExcelSheet - 1);
        String[] strColumnList = strColumns.split("#");
//        List<String> wordList = Arrays.asList(strColumnList);


        int ctr = 1;
        List<String> expected = new ArrayList<String>();
        List<String> actual = new ArrayList<String>();
        //System.out.println(sheet.getPhysicalNumberOfRows()-currentExcelEndRowCorretion);
        boolean dateFlag = false;
        for (int k = currentExcelStartRow - 1; k < (sheet.getPhysicalNumberOfRows() - currentExcelEndRowCorretion); k++) {
            //System.out.println("K : " + k);
            XSSFRow row = sheet.getRow(k);
            for (int i = 0; i < row.getPhysicalNumberOfCells(); i++) {
                actual.add(excelConv(strColumns, strCurrencies, strFloats, strRates, strNumbers, row, i, k));

            }
            //System.out.println(k);
        }
        int intRowCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr")).size();
        int intColCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[1]/td")).size();
        String strTemp = "";
        for (int j = 1; j <= intColCount; j++) {
            strTemp =
                    findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[1]"))
                            .findElement(By.xpath("td[" + j + "]/span"))
                            .getText();
            expected.add(strTemp);
            //System.out.println("Expected Header: " + strTemp);
        }

        if (findElements(By.xpath("//td/a")).size() == 2) {
            Assert.assertTrue(findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom"));
        }

        do {

            Assert.assertTrue(waitForElementInVisible(By.id("CVWaitindicator_NS_")));


            intRowCount = findElements(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr")).size();

            for (int i = 2; i <= intRowCount; i++) {
                for (int j = 1; j <= intColCount; j++) {
//                    //System.out.println("//table[starts-with(@lid,'"+currentTableLid+"" + currentTab + "')]/tbody/tr[" + i + "]/td[" + j + "]/span");

                    expected.add(
                            findElement(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]/tbody/tr[" + i + "]"))
                                    .findElement(By.xpath("td[" + j + "]/span"))
                                    .getText()
                    );
                }
            }
            if (findElements(By.xpath("(//td/a)[last()]")).size() > 0) {
                if (findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom")) {
                    obj_CognosReportCommon.reportTablePageDownLink().click();
                }
            } else {
                break;
            }
        } while (findElement(By.xpath("(//td/a)[last()]")).getText().equals("Bottom"));
        boolean flag = true;
        if (expected.size() == actual.size()) {
            for (int i = 0; i < expected.size(); i++) {
                if (!expected.get(i).equals(actual.get(i).split("\n")[0])) {
//                    flag = false;
                    excelLog.logBooleanResult(expected.get(i), actual.get(i), false, i + "");
//                    System.out.println(i + 1 + " : " + expected.get(i));
//                    System.out.println(i + 1 + " : " + actual.get(i));
                }

            }
//            Assert.assertTrue(flag);
        } else {
            flag = false;
            excelLog.logBooleanResult(expected.size() + "", actual.size() + "", false, "Record mismatch between Excel and HTML Table");
            Assert.assertTrue(flag);
        }

    }


    public String excelConv(String strColumns, String strCurrencies, String strFloats, String strRates, String strNumbers, XSSFRow row, int iCell, int kRow) throws IOException, InterruptedException {
        XSSFCell cell = row.getCell(iCell);
        int intValue = iCell + 1;
        String actual = "";
        if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC && !strColumns.equals("none") && strColumns.contains("#" + intValue + "#")) {

            String timeStamp = new SimpleDateFormat("MMM d, yyyy").format(cell.getDateCellValue());
            actual = (timeStamp);
            //System.out.println(i + " : " + timeStamp);
//                    }
        } else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC && !strCurrencies.equals("none") && strCurrencies.contains("#" + intValue + "#")) {
            //System.out.println("Rawvalue:" + cell.getRawValue());
            double pounds = cell.getNumericCellValue();
            if (pounds != 0) {
//                    String poundsFormatted = "£" + String.format("%.02f", pounds);//gets two decimal point even if it ends with 0 after decimal point

                double amount = Double.parseDouble(pounds + "");
                if (amount < 1 && amount >= 0) {
                    DecimalFormat formatter = new DecimalFormat("#,###.00");
                    actual = ("£0" + formatter.format(amount));
                } else if (amount < 0) {
                    DecimalFormat formatter = new DecimalFormat("#,###.00");
                    actual = ("-£" + formatter.format(amount).split("-")[1]);
                } else {
                    DecimalFormat formatter = new DecimalFormat("#,###.00");
                    actual = ("£" + formatter.format(amount));
                }

            } else {
                actual = ("£0.00");
            }


        } else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC && !strFloats.equals("none") && strFloats.contains("#" + intValue + "#")) {
            //System.out.println("Rawvalue:" + cell.getRawValue());
            double pounds = cell.getNumericCellValue();
            String poundsFormatted = String.format("%.02f", pounds);//gets two decimal point even if it ends with 0 after decimal point
            actual = (poundsFormatted);

            String rate = actual;
            if (!rate.equals("0.00")) {
                double amount = Double.parseDouble(rate + "");
                if (amount < 1 && amount >= 0) {
                    DecimalFormat formatter = new DecimalFormat("#,###.00");
                    actual = ("0" + formatter.format(amount));
                } else if (amount < 0) {
                    DecimalFormat formatter = new DecimalFormat("#,###.00");
                    actual = ("-" + formatter.format(amount).split("-")[1]);
                    if (actual.startsWith("-.")) {
                        actual = actual.replace("-.", "-0.");
                    }
                } else {
                    DecimalFormat formatter = new DecimalFormat("#,###.00");
                    actual = ("" + formatter.format(amount));
                }

            } else {
                actual = (rate);
            }


            //System.out.println(i + " : " + poundsFormatted);
        } else if (!(kRow == currentExcelStartRow - 1) && !strRates.equals("none") && strRates.contains("#" + intValue + "#")) {
            //System.out.println("Rawvalue:" + cell.getRawValue());
            cell.setCellType(Cell.CELL_TYPE_STRING);
            String rate = cell.getStringCellValue();
            if (!rate.equals("0.00%")) {

                rate = String.format("%.02f", (Float.parseFloat(rate) * 100)) + "%";
                actual = (rate);
            } else {
                actual = (rate);
            }
            //System.out.println(i + " : " + rate);

        } else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC && !strNumbers.equals("none") && strNumbers.contains("#" + intValue + "#")) {
            //System.out.println("Rawvalue:" + cell.getRawValue());
            String number = (cell.getNumericCellValue() + "");
//            double vl = cell.getNumericCellValue();

            //System.out.println(formatter.format(amount));
            number = number.substring(0, number.length() - 2);
            actual = NumberFormat.getNumberInstance(Locale.US).format(Long.parseLong(number));
            //System.out.println(i + " : " + poundsFormatted);
        } else if (cell.getCellType() == Cell.CELL_TYPE_NUMERIC) {
            Double number = cell.getNumericCellValue();
            int convertedNumber = number.intValue();
            actual = convertedNumber + "";
            /*
            String number = (cell.getNumericCellValue() + "");
//7.00010509E8
            //System.out.println(formatter.format(amount));
            if (number.endsWith("E8")) { //Policy number get picked as exponent format of double
                number = number.replac cell.setCellType(Cell.CELL_TYPE_STRING);
            String val = cell.getRawValue();
            actual = (cell.getStringCellValue());e(".", "");
                actual = number.substring(0, number.length() - 2);
                if(actual.length()==8)
                {
                    actual=actual+"0";
                }
            }
            else {
                actual = number.substring(0, number.length() - 2);
            }
            */

        } else {
            cell.setCellType(Cell.CELL_TYPE_STRING);


            //System.out.println(i + " : " + cell.getStringCellValue());
        }

        return actual;

    }


    public void reportTableInvisibleCheck() {

        cognosLodaingComplete();
        Assert.assertTrue(waitForElementInVisible(By.xpath("//table[starts-with(@lid,'" + currentTableLid + "" + currentTab + "')]")));

    }

    public void reportClickTab(int tabIndex) {

        cognosLodaingComplete();
        obj_CognosReportCommon.reportTabs().get(tabIndex - 1).click();
        cognosLodaingComplete();
//        currentTab=tabIndex;

    }


    public void cognosLodaingComplete() {
//        hvWaitFlag = false;
        Assert.assertTrue(waitForElementInVisible(By.id("CVWaitindicator_NS_")));
    }

    public void cognosHVLoadingComplete() {
        hvWaitFlag = true;
        Assert.assertTrue(waitForElementInVisible(By.id("CVWaitindicator_NS_")));
    }

    public void cognosDateLodaingComplete() {
//        hvWaitFlag = false;
        Assert.assertTrue(waitForElementInVisible(By.id("CVWaitindicator_NS_")));
        Assert.assertTrue(waitForElementInVisible(By.name("progress")));

    }

    public void cognosHVDateLodaingComplete() {
        hvWaitFlag = true;
        Assert.assertTrue(waitForElementInVisible(By.id("CVWaitindicator_NS_")));
        Assert.assertTrue(waitForElementInVisible(By.name("progress")));

    }


    public void isWithinRange(Date testDate, Date startDate, Date endDate, String strRefer) {

        boolean resulCon1 = testDate.before(startDate);
        boolean resulCon2 = testDate.after(endDate);
        boolean resulCon3 = !(testDate.before(startDate) || testDate.after(endDate));

        excelLog.logBooleanResult("Is on or between : " + startDate + " and  " + endDate, testDate.toString(),
                !(testDate.before(startDate) || testDate.after(endDate)),
                strRefer);

    }

    public void drillDownValidation(int startRow, int endRow, int startCol, int endCol) throws InterruptedException {
        if (startCol == endCol) {
            Assert.assertTrue(false);
        }
        cognosDateLodaingComplete();
        //System.out.println( "startRow,  endRow,  startCol,  endCol");
        //System.out.println( startRow+",  "+endRow+",  "+startCol+",  "+endCol);
        int baseDrillDowns = obj_CognosReportCommon.reportTable().findElements(By.xpath("tbody/tr[position() >= " + startRow + " and position() <= " + endRow + "]/td[" + startCol + "][img][span/span]")).size();
        if (baseDrillDowns > 0) {
            for (int i = 1; i <= baseDrillDowns; i++) {
                Thread.sleep(1000);
                WebElement elementDrillDown
                        = obj_CognosReportCommon
                        .reportTable()
                        .findElements(By.xpath("tbody/tr[position() >= " + startRow + " and position() <= " + endRow + "]/td[" + startCol + "][img][span/span]/img")).get(i - 1);
                String ddStr = elementDrillDown.findElement(By.xpath("following-sibling::span/span")).getText();
                Assert.assertTrue("Plus Img not found for " + ddStr, elementDrillDown.getAttribute("src").endsWith("plus.gif"));
                elementDrillDown.click();
                Thread.sleep(1000);
                elementDrillDown = obj_CognosReportCommon.reportTable().findElements(By.xpath("tbody/tr[position() >= " + startRow + " and position() <= " + endRow + "]/td[" + startCol + "][img][span/span]/img")).get(i - 1);
                Assert.assertTrue("Minus Img not found for " + ddStr, elementDrillDown.getAttribute("src").endsWith("minus.gif"));
                elementDrillDown = obj_CognosReportCommon.reportTable().findElements(By.xpath("tbody/tr[position() >= " + startRow + " and position() <= " + endRow + "]/td[" + startCol + "][img][span/span]/..")).get(i - 1);
                Assert.assertTrue("Multiple Img found for " + ddStr, elementDrillDown.findElements(By.xpath("td[span][img]")).size() == 1);

            }
//            int totalrows = endRow - startRow + 1;
            List<Integer> drillRows = new ArrayList<Integer>();
            drillRows.add(startRow);
//            String drillRows="startRow";
            int progress = 1;
            for (int j = startRow + 1; j <= endRow; j++) {
                if (progress == baseDrillDowns) {
                    break;
                }
                int drillDownCount = obj_CognosReportCommon
                        .reportTable()
                        .findElement(By.xpath("tbody/tr[" + j + "]/td[" + startCol + "]"))
                        .findElements(By.xpath("img"))
                        .size();
                if (drillDownCount == 1) {
                    drillRows.add(j);
                    progress++;
                }

            }
            int itrLastRow = endRow;
            int itr = drillRows.size() - 1;
            do {
                drillDownValidation(drillRows.get(itr) + 1, itrLastRow, startCol + 1, endCol);
                itrLastRow = drillRows.get(itr--) - 1;
            } while (itr >= 0);

        } else {
            drillEndCol = startCol;
            List<WebElement> listElements = obj_CognosReportCommon.reportTable().findElements(By.xpath("tbody/tr[position() >= " + startRow + " and position() <= " + endRow + "]/td[position() >= " + startCol + "]"));
            boolean flag = true;

            for (int l = 0; l < listElements.size(); l++) {
//                listElements.get(l).click();
                if (listElements.get(l).getText().isEmpty()) {
                    flag = false;
                }

            }
            Assert.assertTrue(flag);
        }
    }

    public void clickFilterOptions(List<List<String>> data) {
        int filterIndex = 0;
        String FilterOption = "";
        for (int i = 1; i < data.size(); i++) {
            filterIndex = Integer.parseInt(data.get(i).get(0));
            FilterOption = data.get(i).get(1);
            obj_CognosReportCommon.reportFilterInputOptionDivisions().get(filterIndex - 1).findElement(By.xpath("div/div/label[contains(text(),'" + FilterOption + "')]/..//input")).click();
        }
        obj_CognosReportCommon.reportFilterApplyButton().click();
        cognosDateLodaingComplete();
    }

    public void validateSystemUserLastName(String sName) throws IOException, ParseException {

        String response = validateLastName(sName);
        if (response.equals("0")) {
            excelLog.logBooleanResult(sName + " is a valid System user name", sName + "  is not a valid System user name", false, "Last Name Webservice validation");
        } else {

            File f = new File("src/test/resources/Cognos_XML/RetrieveUserProfileWS-PersonIdentity.xml");
            String node;
            boolean flag = true;
            try {


                node = serviceUtil.getNodeValue(response, "v1_1:personIdentity");
            } catch (NullPointerException e) {
                node = "";
            }
            if (!(node.isEmpty() || node == null || node.equals(""))) {
                String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "DL4B Background User");
                soapRequest = soapRequest.replace("${#PersonIdentity}", node);

//        soapRequest = soapRequest.replace("${#TestSuite#inception-date}", dateSelection);
                response = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/RetrieveUserProfileWS", "RetrieveUserProfileWSService/retrieveProfile");
                node = serviceUtil.getNodeValue(response, "v1_2:name");
                excelLog.logBooleanResult(sName + " is a valid System user name", "User not found", !node.equals("Read Only"), "Last Name Webservice validation");
            } else {
                excelLog.logBooleanResult(sName + " is a valid System user name", node, false, "Last Name Webservice validation");

            }

        }
    }

    public void webserviceFlatCancel() throws ParserConfigurationException, SAXException, ParseException, IOException {
        webserviceCancel(0);
    }

    public void webserviceCancel(int intDate) throws IOException, ParseException, ParserConfigurationException, SAXException {
        File f = new File("src/test/resources/Cognos_XML/CreateCancellation.xml");
        String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "DL4B Background User");
        soapRequest = soapRequest.replace("${#TestSuite#policy-id}", map.get("policyIdentity"));
        soapRequest = soapRequest.replace("${#TestSuite#position-id}", map.get("PositionIdentity"));
        soapRequest = soapRequest.replace("${#TestSuite#product-code}", map.get("productClass"));
        soapRequest = soapRequest.replace("${#TestSuite#scheme-code}", map.get("schemeCode"));

//        Calendar date = Calendar.getInstance(TimeZone.getTimeZone("GMT+1"));
        Calendar date = Calendar.getInstance(TimeZone.getTimeZone("Europe/London"));
        date.add(Calendar.DATE, intDate);
        String timeStamp = new SimpleDateFormat("yyyy-MM-dd'T'HH:MM:SS").format(date.getTime());

        soapRequest = soapRequest.replace("${#TestCase#cnl-inception-date}", timeStamp);
        soapRequest = soapRequest.replace("${#TestCase#cnl-reason}", "5");
        soapRequest = soapRequest.replace("${#TestCase#cnl-type}", "timeOnRisk");
        soapRequest = soapRequest.replace("${#TestCase#cnl-action}", "noFurtherAction");
//        soapRequest = soapRequest.replace("${#Owner}", user);
        String response = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/createCancelPolicy");
        String node = serviceUtil.getNodeValue(response, "v1_1:policyPositionId");
        map.put("CanPositionIdentity", node);
//        node = serviceUtil.getNodeValue(response, "v1_1:quoteVariationId");
//        map.put("CanVariationIdentity",node);

        f = new File("src/test/resources/Cognos_XML/AcceptCancellation.xml");
        soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "DL4B Background User");
        soapRequest = soapRequest.replace("${#TestCase#policy-id}", map.get("policyIdentity"));
        soapRequest = soapRequest.replace("${#TestCase#position-id}", map.get("CanPositionIdentity"));
        soapRequest = soapRequest.replace("${#TestSuite#product-code}", map.get("productClass"));
        soapRequest = soapRequest.replace("${#TestSuite#scheme-code}", map.get("schemeCode"));
        response = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/ManagePolicyWS", "ManagePolicyWSService/completeCancelPolicy");

        String policyIdentity = map.get("policyIdentity"),
                PositionIdentity = map.get("CanPositionIdentity"),
                variationIdentity = map.get("variationIdentity");
        String canPPSR = functionalUtil.PPSR(policyIdentity, PositionIdentity, variationIdentity);
        map.put("CanPPSR", canPPSR);
        CognosReportsUtil.map.put("canEffDate", serviceUtil.getNodeValue(canPPSR, "stn_1:effectiveFrom"));
        CognosReportsUtil.map.put("canCharge", serviceUtil.getNodeValue(canPPSR, "stn_1:charge").trim().split("\n")[0]);
        map.put("NonZeroCoveragePremTax-Can", getListOfCoveragesWithNon0PremiumCan(map.get("CanPPSR")).toString());
    }

    public void createsAManagePoliciesWorkbasketFor(String user, String choice) throws IOException {
        File f = new File("src/test/resources/Cognos_XML/WorkItem-Workbasket.xml");
        String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "DL4B Background User");
        soapRequest = soapRequest.replace("${#Owner}", user);
        soapRequest = soapRequest.replace("${#OwnerName}", user);
        String description = randomString();
        soapRequest = soapRequest.replace("${#description}", description);
//        <urn1:releaseDate>${#ReleaseDate}</urn1:releaseDate>
//         <!--urn1:releaseDate>${#ReleaseDate}13/10/2017 11:10</urn1:releaseDate-->
        soapRequest = soapRequest.replace("${#ReleaseDate}", returnDate(0, "dd/MM/yyy HH:mm"));
//        <workItemActivityDefinitionName>Manage Policies</workItemActivityDefinitionName>
//		<definitionFileName>trading/ManagePolicies486.xml</definitionFileName>
//		<definitionUniqueReference>486</definitionUniqueReference>
//		<category>Policy Administration</category>

        switch (choice) {
            case "Manage Policies":
                soapRequest = soapRequest.replace("${#Activity}", "Manage Policies");
                soapRequest = soapRequest.replace("${#FileName}", "trading/ManagePolicies486.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "486");
                soapRequest = soapRequest.replace("${#Category}", "Policy Administration");

                break;

            case "Set Finance Parameters":
                soapRequest = soapRequest.replace("${#Activity}", "Set Finance Parameters");
                soapRequest = soapRequest.replace("${#FileName}", "trading/SetParameters535.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "535");
                soapRequest = soapRequest.replace("${#Category}", "Finance Administration");

                break;
            case "Allocate Journals":
                soapRequest = soapRequest.replace("${#Activity}", "Allocate Journals");
                soapRequest = soapRequest.replace("${#FileName}", "claims/AllocateJournal3079.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "3079");
                soapRequest = soapRequest.replace("${#Category}", "Claims");
                break;
            case "Allocate Recoveries":
                soapRequest = soapRequest.replace("${#Activity}", "Allocate Recoveries");
                soapRequest = soapRequest.replace("${#FileName}", "claims/AllocateRecovery522.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "522");
                soapRequest = soapRequest.replace("${#Category}", "Claims");
                break;
            case "Manage Bulk Claim Payments":
                soapRequest = soapRequest.replace("${#Activity}", "Manage Bulk Claim Payments");
                soapRequest = soapRequest.replace("${#FileName}", "claims/ManageBulkClaimPayments4261.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "4261");
                soapRequest = soapRequest.replace("${#Category}", "Claims");
                break;
            case "Manage Claims":
                soapRequest = soapRequest.replace("${#Activity}", "Manage Claims");
                soapRequest = soapRequest.replace("${#FileName}", "claims/ManageClaims511.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "511");
                soapRequest = soapRequest.replace("${#Category}", "Claims");
                break;
            case "Manage Incidents":
                soapRequest = soapRequest.replace("${#Activity}", "Manage Incidents");
                soapRequest = soapRequest.replace("${#FileName}", "claims/ManageIncidents521.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "521");
                soapRequest = soapRequest.replace("${#Category}", "Claims");
                break;
            case "Review Estimates":
                soapRequest = soapRequest.replace("${#Activity}", "Review Estimates");
                soapRequest = soapRequest.replace("${#FileName}", "claims/ReviewEstimates524.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "524");
                soapRequest = soapRequest.replace("${#Category}", "Claims");
                break;
            case "Manage Direct Credit Runs":
                soapRequest = soapRequest.replace("${#Activity}", "Manage Direct Credit Runs");
                soapRequest = soapRequest.replace("${#FileName}", "finance/ManageDirectCreditRuns4495.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "4495");
                soapRequest = soapRequest.replace("${#Category}", "Finance Administration");
                break;
            case "Manage Journals":
                soapRequest = soapRequest.replace("${#Activity}", "Manage Journals");
                soapRequest = soapRequest.replace("${#FileName}", "finance/ManageJournals2028.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "2028");
                soapRequest = soapRequest.replace("${#Category}", "Finance Administration");
                break;
            case "Manage Month End":
                soapRequest = soapRequest.replace("${#Activity}", "Manage Month End");
                soapRequest = soapRequest.replace("${#FileName}", "finance/ManageMonthEnd3020.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "3020");
                soapRequest = soapRequest.replace("${#Category}", "Finance Administration");
                break;
            case "Manage Payment Plans":
                soapRequest = soapRequest.replace("${#Activity}", "Manage Payment Plans");
                soapRequest = soapRequest.replace("${#FileName}", "finance/ManagePaymentPlans507.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "507");
                soapRequest = soapRequest.replace("${#Category}", "Finance Administration");
                break;
            case "Manage Rejection and Overdue Profiles":
                soapRequest = soapRequest.replace("${#Activity}", "Manage Rejection and Overdue Profiles");
                soapRequest = soapRequest.replace("${#FileName}", "finance/ManageRejectionandOverdueProfiles4352.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "4352");
                soapRequest = soapRequest.replace("${#Category}", "Finance Administration");
                break;
            case "Manage Working day Calendar":
                soapRequest = soapRequest.replace("${#Activity}", "Manage Working day Calendar");
                soapRequest = soapRequest.replace("${#FileName}", "finance/ManageWorkingDayCalendar4350.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "4350");
                soapRequest = soapRequest.replace("${#Category}", "Finance Administration");
                break;
            case "Produce Statements":
                soapRequest = soapRequest.replace("${#Activity}", "Produce Statements");
                soapRequest = soapRequest.replace("${#FileName}", "finance/ProduceStatements514.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "514");
                soapRequest = soapRequest.replace("${#Category}", "Finance Administration");
                break;
            case "Portfolio Transfer":
                soapRequest = soapRequest.replace("${#Activity}", "Portfolio Transfer");
                soapRequest = soapRequest.replace("${#FileName}", "trading/PortfolioTransfer1924.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "1924");
                soapRequest = soapRequest.replace("${#Category}", "Policy Administration");
                break;
            case "Risk Search":
                soapRequest = soapRequest.replace("${#Activity}", "Risk Search");
                soapRequest = soapRequest.replace("${#FileName}", "trading/RiskSearch505.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "505");
                soapRequest = soapRequest.replace("${#Category}", "Policy Administration");
                break;
            case "Manage Receipts":
                soapRequest = soapRequest.replace("${#Activity}", "Manage Receipts");
                soapRequest = soapRequest.replace("${#FileName}", "finance/ManageReceipts509.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "509");
                soapRequest = soapRequest.replace("${#Category}", "Receipts");
                break;
            case "Reconcile Receipts and Journals":
                soapRequest = soapRequest.replace("${#Activity}", "Reconcile Receipts and Journals");
                soapRequest = soapRequest.replace("${#FileName}", "finance/ReconcileReceipts520.xml");
                soapRequest = soapRequest.replace("${#UniqueReference}", "520");
                soapRequest = soapRequest.replace("${#Category}", "Receipts");
                break;


        }


// soapRequest = soapRequest.replace("${#TestSuite#inception-date}", dateSelection);
        String response = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/WorkItemSave", "WorkItemSaveService/saveNewWorkItem");

    }

    public String randomString() {
        rndText = obj_generalInformationUtil.randomFirstName();
        return rndText;
    }

    public void validateLastNametoUrn(String sName, int URN) throws IOException, ParseException {
        String response = validateLastName(sName);
        excelLog.logBooleanResult(sName + " : " + URN, response, response.contains("<v1_1:personURN>" + URN + "</v1_1:personURN>"), "URN to Last Name Validation");


    }

    public String validateLastName(String sName) throws IOException, ParseException {
        sName = sName.trim();
        boolean status = false, type1 = true;
        int len = sName.split(" ").length, lastindex;
        lastindex = len - 1;
        if (len == 0) {
            Assert.assertTrue(false);
        }
        String surName = sName.split(" ")[lastindex];
        File f = new File("src/test/resources/Cognos_XML/SearchPersonWS-SurName.xml");
        String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "DL4B Background User");
        soapRequest = soapRequest.replace("${#Sur-Name}", surName);

//        soapRequest = soapRequest.replace("${#TestSuite#inception-date}", dateSelection);
        String response = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/SearchPersonWS", "SearchPersonWSService/searchPerson");

//        excelLog.logBooleanResult(soapRequest,response,false,"Debug");
        ArrayList<String> nodes = new ArrayList<String>();
        try {
            nodes = serviceUtil.getNodeValues(response, "v1:name");
        } catch (NullPointerException e) {
            excelLog.logBooleanResult(sName + " is a valid user name", sName + " is not a valid user name", status, "Last Name Webservice validation");
            return "0";
        }
        if (nodes.size() == 0 && len > 3) {
            surName = sName.split(" ")[lastindex - 1];

            soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "DL4B Background User");
            soapRequest = soapRequest.replace("${#Sur-Name}", surName);

//        soapRequest = soapRequest.replace("${#TestSuite#inception-date}", dateSelection);
            response = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/SearchPersonWS", "SearchPersonWSService/searchPerson");

//        excelLog.logBooleanResult(soapRequest,response,false,"Debug");
            try {
                nodes = serviceUtil.getNodeValues(response, "v1:name");
            } catch (NullPointerException e) {
                excelLog.logBooleanResult(sName + " is a valid user name", sName + " is not a valid user name", status, "Last Name Webservice validation");
                return "0";
            }

            type1 = false;
        }
        String Actual;
        for (String node : nodes) {
            if (node.split(",").length > 1) {
                if (type1) {
                    Actual = node.split(",")[1].trim() + " " + node.split(",")[0];
                } else {
                    String title = node.replaceAll(".* ", "");
                    String str = node.split(title)[0].trim();
                    Actual = str.split(",")[1].trim() + " " + str.split(",")[0];
                    Actual = Actual + " " + title;
                }
            } else

            {
                Actual = node.replace(",", "");
            }
            if (Actual.equalsIgnoreCase(sName)) {
                status = true;
                break;
            }
        }
        excelLog.logBooleanResult(sName + " is a valid user name", nodes.toString(), status, "Last Name Webservice validation");
        return response;
    }

    public void tax(String xml) throws ParserConfigurationException, IOException, SAXException {
        String result1 = "";
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        InputSource src = new InputSource();
        src.setCharacterStream(new StringReader(xml));
        Document doc = null;
        doc = builder.parse(src);
        NodeList covers = doc.getElementsByTagName("stn_1:coverageClassName");
        Node sibling;
        Map<String, String> coversPrem = new HashMap<>();
        for (int i = 0; i <= covers.getLength(); i++) {
            sibling = covers.item(i).getNextSibling();
            while (!(sibling instanceof Element) && sibling != null) {
                sibling = sibling.getNextSibling();
                if (sibling.getNodeName().equals("stn_1:isCoverage"))
                    break;
            }
            if (sibling.getTextContent().equals("true")) {
                while (!(sibling instanceof Element) && sibling != null) {
                    sibling = sibling.getNextSibling();
                    if (sibling.getNodeName().equals("stn_1:calculatedPremium"))
                        break;
                }
            }
            excelLog.logBooleanResult(covers.item(i).getTextContent().trim(), sibling.getTextContent().trim().split("\n")[0],
                    false, "Debug Tax");

//            coversPrem.put(covers.item(i).getTextContent().trim(),sibling.getTextContent().trim().split("\n")[0]);
//            map.put(covers.item(i).getTextContent().trim(),sibling.getTextContent().trim().split("\n")[0]);
        }
    }

    public ArrayList<String> getListOfCoveragesWithNon0Premium(String PPSR) throws ParserConfigurationException, IOException, SAXException {

        ArrayList<String> covers = serviceUtil.getNodeValues(PPSR, "stn_1:coverageClassName");
        ArrayList<String> isCover = serviceUtil.getNodeValues(PPSR, "stn_1:isCoverage");
        ArrayList<String> premium = serviceUtil.getNodeValues(PPSR, "stn_1:calculatedPremium");
        Document doc = DocumentBuilderFactory.newInstance()
                .newDocumentBuilder()
                .parse(new InputSource(new StringReader(PPSR)));
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        InputSource src = new InputSource();
        src.setCharacterStream(new StringReader(PPSR));
        doc = builder.parse(src);
        ;

//        excelLog.logBooleanResult(covers.toString(), isCover.toString(), false, premium.toString());
        ArrayList<String> retunStrList = new ArrayList<String>();
        Assert.assertTrue(covers.size() == isCover.size());
        int ctr = 0;
        for (int i = 0; i < covers.size(); i++) {
            if (isCover.get(i).equals("true")) {
//                excelLog.logBooleanResult(covers.get(i),premium.get( ctr).trim().split("\n")[0],false,"debug");
                NodeList list = doc.getElementsByTagName("stn_1:calculatedPremium").item(ctr).getParentNode().getChildNodes();
                Node tax = null;
                for (int child = 0; child < list.getLength(); child++) {
                    if (list.item(child).getNodeName().equalsIgnoreCase("stn_1:taxes")) {
                        tax = list.item(child);
                        break;
                    }

                }
                String taxAmount = tax.getTextContent().split("\n")[8].trim();
//

                if (!premium.get(ctr).trim().split("\n")[0].trim().equals("0.00") || !taxAmount.equals("0.00")) {
                    retunStrList.add(covers.get(i) + "#" + premium.get(ctr).trim().split("\n")[0] + "#" + taxAmount);
                }
                ctr++;

            }


        }
        Assert.assertTrue(premium.size() == ctr);
        return retunStrList;
//        excelLog.logBooleanResult(retunStrList.toString(),"",false,"");
    }


    public ArrayList<String> getListOfCoveragesWithNon0PremiumCan(String PPSR) throws ParserConfigurationException, IOException, SAXException {

        ArrayList<String> covers = serviceUtil.getNodeValues(PPSR, "stn_1:coverageClassName");
        ArrayList<String> isCover = serviceUtil.getNodeValues(PPSR, "stn_1:isCoverage");
        ArrayList<String> premium = serviceUtil.getNodeValues(PPSR, "stn_1:proRataPremium");
        Document doc = DocumentBuilderFactory.newInstance()
                .newDocumentBuilder()
                .parse(new InputSource(new StringReader(PPSR)));
        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
        InputSource src = new InputSource();
        src.setCharacterStream(new StringReader(PPSR));
        doc = builder.parse(src);
        ;

//        excelLog.logBooleanResult(covers.toString(), isCover.toString(), false, premium.toString());
        ArrayList<String> retunStrList = new ArrayList<String>();
        Assert.assertTrue(covers.size() == isCover.size());
        int ctr = 0;
        for (int i = 0; i < covers.size(); i++) {
            if (isCover.get(i).equals("true")) {
//                excelLog.logBooleanResult(covers.get(i),premium.get( ctr).trim().split("\n")[0],false,"debug");
                NodeList list = doc.getElementsByTagName("stn_1:proRataPremium").item(ctr).getParentNode().getChildNodes();
                Node tax = null;
                for (int child = 0; child < list.getLength(); child++) {
                    if (list.item(child).getNodeName().equalsIgnoreCase("stn_1:taxes")) {
                        tax = list.item(child);
                        break;
                    }

                }
                String taxAmount = tax.getTextContent().split("\n")[8].trim();
//

                if (!premium.get(ctr).trim().split("\n")[0].trim().equals("0.00") || !taxAmount.equals("0.00")) {
                    retunStrList.add(covers.get(i) + "#" + premium.get(ctr).trim().split("\n")[0] + "#" + taxAmount);
                }
                ctr++;

            }


        }
        Assert.assertTrue(premium.size() == ctr);
        return retunStrList;
//        excelLog.logBooleanResult(retunStrList.toString(),"",false,"");
    }


    public NodeList getXmlValuebyXpath(String xml, String xpathStr) throws Exception {

        Document doc = DocumentBuilderFactory.newInstance()
                .newDocumentBuilder()
                .parse(new InputSource(new StringReader(xml)));
        XPath xpath = XPathFactory.newInstance().newXPath();
        NodeList nodes = (NodeList) xpath.evaluate(
                xpathStr, doc,
                XPathConstants.NODESET);
        return nodes;

//        nodes = (NodeList) xpath.evaluate(
//                "//*", doc,
//                XPathConstants.NODESET);
//        for (int i = 0; i < nodes.getLength(); i++)
//            System.out.println("Nodes: "+nodes.item(i).getNodeName());

//
//        String result1 = "";
//        DocumentBuilder builder = DocumentBuilderFactory.newInstance().newDocumentBuilder();
//        InputSource src = new InputSource();
//        src.setCharacterStream(new StringReader(xml));
//        Document doc = null;
//         doc = builder.parse(src);
//        NodeList covers = doc.getElementsByTagName("stn_1:coverageclassname");
//        Node sibling;
//        Map<String, String> coversPrem = new HashMap<>();
//        for (int i = 0; i <= covers.getLength(); i++) {
//            sibling = covers.item(i).getNextSibling();
//            while (!(sibling instanceof Element) && sibling != null) {
//                sibling = sibling.getNextSibling();
//                if(sibling.getNodeName().equals("stn_1:iscoverage"))
//                    break;
//            }
//            if(sibling.getTextContent().equals("true"))
//            {
//                while (!(sibling instanceof Element) && sibling != null) {
//                    sibling = sibling.getNextSibling();
//                    if(sibling.getNodeName().equals("stn_1:calculatedpremium"))
//                        break;
//                }
//            }
////            coversPrem.put(covers.item(i).getTextContent().trim(),sibling.getTextContent().trim().split("\n")[0]);
//            map.put(covers.item(i).getTextContent().trim(),sibling.getTextContent().trim().split("\n")[0]);
//        }


    }

    public List<String> getActualUAC_RowValues(String usrId) throws IOException, ParseException {
        File f = new File("src/test/resources/Cognos_XML/RetrieveUserProfileWS-PrincipleId.xml");
        String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "DL4B Background User");
        soapRequest = soapRequest.replace("${#PersonPrincipleId}", usrId);
        soapRequest = soapRequest.replace("${#Project#select-contact-id}", "THIV");
        String response1 = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/RetrieveUserProfileWS", "RetrieveUserProfileWSService/retrieveProfile");
        List<String> nodes = new ArrayList<>();
        String node = serviceUtil.getNodeValue(response1, "v1:username");
        nodes.add(node);

        node = serviceUtil.getNodeValue(response1, "v1_1:personIdentity");
        f = new File("src/test/resources/Cognos_XML/PersonRetrieve-personIdentity.xml");
        soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "DL4B Background User");
        soapRequest = soapRequest.replace("${#personIdentity}", node);

        String response2 = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/PersonRetrieve", "PersonRetrieveService/retrievePerson");
        String[] info = serviceUtil.getNodeValue(response2, "stn_1:Personnel").trim().split("\n");
        nodes.add(info[0]);

        node = serviceUtil.getNodeValue(response1, "v1_2:name");
        nodes.add(node);
        node = serviceUtil.getNodeValue(response1, "v1_4:name");
        nodes.add(node);

        nodes.add(info[7]);
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMM d, yyyy");
        dateFormat.setLenient(false);
        nodes.add(new SimpleDateFormat("MMM d, yyyy").format(new SimpleDateFormat("yyyy-MM-d").parse(info[4].trim().split("z")[0])));


        return nodes;
    }


    public String createPerson() throws IOException {
        File f = new File("src/test/resources/System_Users_XML/PersonSave.xml");
        String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "DL4B Background User");
        String surname = "Automation" + Long.toHexString(System.currentTimeMillis());
        soapRequest = soapRequest.replace("${#TestCase#personSurname}", surname);
        String fname = "Test" + Long.toHexString(System.currentTimeMillis());
        soapRequest = soapRequest.replace("${#TestCase#personFirstName}", fname);
        String response1 = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/PersonSave", "PersonSaveService/saveNewPersonAndHoldLock");
        String objId = serviceUtil.getNodeValue(response1, "stn_1:objectIdentity");
        return surname + "#" + objId + "#"+fname;

    }

    public String addSysUserAcc(String surname, String objID) throws IOException {
        File f = new File("src/test/resources/System_Users_XML/SystemUserSave.xml");
        String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "DL4B Background User");
        soapRequest = soapRequest.replace("${#TestCase#personID}", objID);
        soapRequest = soapRequest.replace("${#TestCase#principalIdPrefix}_${#TestCase#surnameCounter1}", surname);
        String response1 = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/SystemUserSave", "SystemUserSaveService/saveSystemUser");
        return response1;
    }

    public String addPrincAcc(String objID, String strAccessprofile, String strSkillprofile, String strRole) throws IOException {
        File f = new File("src/test/resources/System_Users_XML/PersonnelSave.xml");
        String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "DL4B Background User");
        soapRequest = soapRequest.replace("${#TestCase#personID}", objID);
        String stn_1_objectIdentity = "", stn_1_skillProfileName = "", stn_1_skillProfileDescription = "", stn_1_category = "";
        String stn_1_accessProfileName = "", stn_1_accessProfileDescription = "";
        switch (strRole) {
            case "Underwriter":
                strRole = "trader";
                break;
            case "Finance Officer":
                strRole = "finance";
                break;

        }
        soapRequest = soapRequest.replace("${#TestCase#Role}",strRole);
        switch (strSkillprofile) {
            case "AML/Sanctions":
                stn_1_objectIdentity = "107";
                stn_1_skillProfileName = "AML/Sanctions";
                stn_1_skillProfileDescription = "AML/Sanctions";
                stn_1_category = "Security";
                break;
            case "Advanced Operational PUA L1":
                stn_1_objectIdentity = "55";
                stn_1_skillProfileName = "Advanced Operational PUA L1";
                stn_1_skillProfileDescription = "Advanced Operational PUA L1";
                stn_1_category = "Trading";
                break;
            case "Advanced Operational PUA L2":
                stn_1_objectIdentity = "57";
                stn_1_skillProfileName = "Advanced Operational PUA L2";
                stn_1_skillProfileDescription = "Advanced Operational PUA L2";
                stn_1_category = "Trading";
                break;
            case "Advanced Operational PUA L3":
                stn_1_objectIdentity = "102";
                stn_1_skillProfileName = "Advanced Operational PUA L3";
                stn_1_skillProfileDescription = "Advanced Operational PUA L3";
                stn_1_category = "Trading";
                break;
            case "Counter Fraud":
                stn_1_objectIdentity = "202";
                stn_1_skillProfileName = "Counter Fraud";
                stn_1_skillProfileDescription = "Counter Fraud";
                stn_1_category = "Security";
                break;
            case "Finance Journal Unlimited":
                stn_1_objectIdentity = "106";
                stn_1_skillProfileName = "Finance Journal Unlimited";
                stn_1_skillProfileDescription = "Finance Journal Unlimited";
                stn_1_category = "Finance";
                break;
            case "Finance Journal £100":
                stn_1_objectIdentity = "104";
                stn_1_skillProfileName = "Finance Journal £100";
                stn_1_skillProfileDescription = "Finance Journal £100";
                stn_1_category = "Finance";
                break;
            case "Finance Journal £25":
                stn_1_objectIdentity = "103";
                stn_1_skillProfileName = "Finance Journal £25";
                stn_1_skillProfileDescription = "Finance Journal £25";
                stn_1_category = "Finance";
                break;
            case "Finance Journal £250":
                stn_1_objectIdentity = "105";
                stn_1_skillProfileName = "Finance Journal £250";
                stn_1_skillProfileDescription = "Finance Journal £250";
                stn_1_category = "Finance";
                break;
            case "Full Role Maintenance Profile":
                stn_1_objectIdentity = "2";
                stn_1_skillProfileName = "Full Role Maintenance Profile";
                stn_1_skillProfileDescription = "Allow full role maintenance ability";
                stn_1_category = "Security";
                break;
            case "Online":
                stn_1_objectIdentity = "108";
                stn_1_skillProfileName = "Online";
                stn_1_skillProfileDescription = "Online";
                stn_1_category = "Trading";
                break;
            case "Read Only":
                stn_1_objectIdentity = "53";
                stn_1_skillProfileName = "Read Only";
                stn_1_skillProfileDescription = "Read Only";
                stn_1_category = "Trading";
                break;
            case "Standard Operational No PUA":
                stn_1_objectIdentity = "56";
                stn_1_skillProfileName = "Standard Operational No PUA";
                stn_1_skillProfileDescription = "Standard Operational Access No PUA";
                stn_1_category = "Trading";
                break;
            case "Standard Operational PUA L1":
                stn_1_objectIdentity = "54";
                stn_1_skillProfileName = "Standard Operational PUA L1";
                stn_1_skillProfileDescription = "Standard Operational PUA L1";
                stn_1_category = "Trading";
                break;
            case "System Administrator":
                stn_1_objectIdentity = "52";
                stn_1_skillProfileName = "System Administrator";
                stn_1_skillProfileDescription = "System Administrator";
                stn_1_category = "Contacts";
                break;
            case "UAC":
                stn_1_objectIdentity = "152";
                stn_1_skillProfileName = "UAC";
                stn_1_skillProfileDescription = "UAC";
                stn_1_category = "Security";
                break;
            default:
                Assert.assertTrue("Unknown skill profile", false);


        }
        soapRequest = soapRequest.replace("${#TestCase#skillProfileId}", stn_1_objectIdentity);
        soapRequest = soapRequest.replace("${#TestCase#skillProfileName}", stn_1_skillProfileName);
        soapRequest = soapRequest.replace("${#TestCase#skillProfileDescription}", stn_1_skillProfileDescription);
        soapRequest = soapRequest.replace("${#TestCase#skillProfileCategory}", stn_1_category);

        switch (strAccessprofile) {
            case "AML/Sanctions":
                stn_1_objectIdentity = "57";
                stn_1_accessProfileName = "AML/Sanctions";
                stn_1_accessProfileDescription = "AML/Sanctions";

                stn_1_category = "Security";
                break;
            case "Advanced User":
                stn_1_objectIdentity = "105";
                stn_1_accessProfileName = "Advanced User";
                stn_1_accessProfileDescription = "Advanced User";

                stn_1_category = "Trading";
                break;
            case "Basic User with PUA":
                stn_1_objectIdentity = "159";
                stn_1_accessProfileName = "Basic User with PUA";
                stn_1_accessProfileDescription = "Basic User with PUA";

                stn_1_category = "Trading";
                break;
            case "Basic User without PUA":
                stn_1_objectIdentity = "103";
                stn_1_accessProfileName = "Basic User without PUA";
                stn_1_accessProfileDescription = "Basic User without PUA";

                stn_1_category = "Trading";
                break;
            case "Claims Re-Key":
                stn_1_objectIdentity = "155";
                stn_1_accessProfileName = "Claims Re-Key";
                stn_1_accessProfileDescription = "Claims Re-Key";

                stn_1_category = "Claims";
                break;
            case "Counter Fraud":
                stn_1_objectIdentity = "203";
                stn_1_accessProfileName = "Counter Fraud";
                stn_1_accessProfileDescription = "Counter Fraud";

                stn_1_category = "Security";
                break;
            case "Exceptional User":
                stn_1_objectIdentity = "109";
                stn_1_accessProfileName = "Exceptional User";
                stn_1_accessProfileDescription = "Exceptional User";

                stn_1_category = "Security";
                break;
            case "Finance User":
                stn_1_objectIdentity = "107";
                stn_1_accessProfileName = "Finance User";
                stn_1_accessProfileDescription = "Finance User";

                stn_1_category = "Finance";
                break;
            case "Full System Access Profile":
                stn_1_objectIdentity = "3";
                stn_1_accessProfileName = "Full System Access Profile";
                stn_1_accessProfileDescription = "Full System Rights";

                stn_1_category = "Trading";
                break;
            case "Online":
                stn_1_objectIdentity = "111";
                stn_1_accessProfileName = "Online";
                stn_1_accessProfileDescription = "Online";

                stn_1_category = "Security";
                break;
            case "Read Only":
                stn_1_objectIdentity = "53";
                stn_1_accessProfileName = "Read Only";
                stn_1_accessProfileDescription = "Read only";

                stn_1_category = "Trading";
                break;
            case "UAC Governance":
                stn_1_objectIdentity = "153";
                stn_1_accessProfileName = "UAC Governance";
                stn_1_accessProfileDescription = "UAC Governance";

                stn_1_category = "Security";
                break;
            case "UAC Provisioning":
                stn_1_objectIdentity = "55";
                stn_1_accessProfileName = "UAC Provisioning";
                stn_1_accessProfileDescription = "UAC Provisioning";

                stn_1_category = "Security";
                break;
            case "Workbaskets":
                stn_1_objectIdentity = "157";
                stn_1_accessProfileName = "Workbaskets";
                stn_1_accessProfileDescription = "Workbaskets";

                stn_1_category = "Trading";
                break;
            default:
                Assert.assertTrue("Unknown Access profile", false);


        }

        soapRequest = soapRequest.replace("${#TestCase#accessProfileId}", stn_1_objectIdentity);
        soapRequest = soapRequest.replace("${#TestCase#accessProfileName}", stn_1_accessProfileName);
        soapRequest = soapRequest.replace("${#TestCase#accessProfileDescription}", stn_1_accessProfileDescription);

        soapRequest = soapRequest.replace("{#TestCase#accessProfileCategory}", stn_1_category);

        String response1 = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/PersonnelSave", "PersonnelSaveService/savePersonnel");
        return response1;

    }

    public String personUpdateReleaseLock(String objID) throws IOException {
        File f = new File("src/test/resources/System_Users_XML/PersonUpdate.xml");
        String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "DL4B Background User");
        soapRequest = soapRequest.replace("${#TestCase#personID}", objID);

        String response1 = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/PersonUpdate", "PersonUpdatePersonUpdateService/updateExistingPersonAndReleaseLock");
        return response1;

    }

    public String getPersonInfo(String objID) throws IOException {

        File f = new File("src/test/resources/System_Users_XML/PersonRetrieve.xml");
        String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "DL4B Background User");
        soapRequest = soapRequest.replace("${#TestCase#personID}", objID);

        String response1 = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/PersonRetrieve", "PersonRetrieveService/retrievePerson");

        return response1;
    }

    public void exportSysUWUser(String objID, String strSysUserEffDate,String strUnderwriterEffDate, String strpersonEffectiveDate, String strpersonUniqueReference, String strsystemUserRoleCode, String strunderwriterRoleCode) throws IOException {
// objID,  strSysUserEffDate, strUnderwriterEffDate,  strpersonEffectiveDate,  strpersonUniqueReference,  strsystemUserRoleCode,  strunderwriterRoleCode
        File f = new File("src/test/resources/System_Users_XML/ContactBackgroundProcessContact_ExportSystemUser.xml");
        String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "DL4B Background User");
        soapRequest = soapRequest.replace("${#TestCase#personID}", objID);
        soapRequest = soapRequest.replace("${#TestCase#systemUserEffectiveDate}", strSysUserEffDate);
        soapRequest = soapRequest.replace("${#TestCase#personEffectiveDate}", strpersonEffectiveDate);
        soapRequest = soapRequest.replace("${#TestCase#personUniqueReference}", strpersonUniqueReference);
        soapRequest = soapRequest.replace("${#TestCase#systemUserRoleCode}", strsystemUserRoleCode);

        String response1 = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/ContactBackgroundProcessContact", "ContactBackgroundProcessContactService/exportBackgroundProcess");


         f = new File("src/test/resources/System_Users_XML/ContactBackgroundProcessContact_ExportUnderWriter.xml");
         soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "DL4B Background User");
        soapRequest = soapRequest.replace("${#TestCase#personID}", objID);
        soapRequest = soapRequest.replace("${#TestCase#underwriterEffectiveDate}", strUnderwriterEffDate);
        soapRequest = soapRequest.replace("${#TestCase#personEffectiveDate}", strpersonEffectiveDate);
        soapRequest = soapRequest.replace("${#TestCase#personUniqueReference}", strpersonUniqueReference);
        soapRequest = soapRequest.replace("${#TestCase#underwriterRoleCode}", strunderwriterRoleCode);

        response1 = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/ContactBackgroundProcessContact", "ContactBackgroundProcessContactService/exportBackgroundProcess");


    }

    public void terminateUser(String objID) throws IOException {

        File f = new File("src/test/resources/System_Users_XML/PersonUpdate_Terminate.xml");
//        String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "RYDTAMLSANC");
        String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "Automation161b19b569e");
        soapRequest = soapRequest.replace("${#TestSuite#person_Id}", objID);

        String response1 = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/PersonUpdate", "PersonUpdateService/updateExistingPersonAndHoldLock");

    }
    public void suspendUser(String objID) throws IOException {

        File f = new File("src/test/resources/System_Users_XML/PersonUpdate_Suspend.xml");
        String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "RYDTAMLSANC");
        soapRequest = soapRequest.replace("${#TestSuite#person_Id}", objID);

        String response1 = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/PersonUpdate", "PersonUpdateService/updateExistingPersonAndHoldLock");

    }
    public void reactivateUser(String objID) throws IOException {

        File f = new File("src/test/resources/System_Users_XML/PersonUpdate_Reactivate.xml");
        String soapRequest = new String(Files.readAllBytes(Paths.get(f.getPath()))).replace("${#Project#select-contact-id}", "RYDTAMLSANC");
        soapRequest = soapRequest.replace("${#TestSuite#person_Id}", objID);

        String response1 = serviceUtil.getResponse(soapRequest, System.getProperty("ENV") + "/PersonUpdate", "PersonUpdateService/updateExistingPersonAndHoldLock");

    }



    public void downloadSettigsManualCheckBoxClick() throws Throwable {

//        obj_commonUtil.switchFrame("settings");
        WebElement ele = waitForElementVisible(By.tagName("settings-ui"));
        WebElement shadow = getShadowRootElement(ele);

        //cssSelector only works for subsequent elements of shadow elements
        ele = shadow.findElement(By.cssSelector("settings-main"));
        shadow = getShadowRootElement(ele);

        ele = shadow.findElement(By.cssSelector("settings-basic-page"));
        shadow = getShadowRootElement(ele);

//        ele = shadow.findElement(By.cssSelector("settings-section"));
//        shadow = getShadowRootElement(ele);

        ele = shadow.findElement(By.cssSelector("settings-downloads-page"));
        shadow = getShadowRootElement(ele);

        ele = shadow.findElement(By.cssSelector("settings-toggle-button"));
        shadow = getShadowRootElement(ele);

        ele = shadow.findElement(By.cssSelector("paper-toggle-button"));
        shadow = getShadowRootElement(ele);

        ele = shadow.findElement(By.cssSelector("#toggleButton"));
        ele.click();




    }
    public WebElement getShadowRootElement(WebElement element) {
        //cssSelector only works for subsequent elements of shadow elements
        WebElement ele = (WebElement) ((JavascriptExecutor)getDriver)
                .executeScript("return arguments[0].shadowRoot", element);
        return ele;
    }

    public class ValueAndRowspanCounter
    {
        public int rowSpn;
        public  String value;
        ValueAndRowspanCounter(WebElement ele)
        {
            boolean attrPresent = isAttribtuePresent(ele, "rowspan");
            if (attrPresent) {
                rowSpn = Integer.parseInt(ele.getAttribute("rowspan"));
            } else {
                rowSpn = 1;
            }
            value = ele.getText();

        }

        ValueAndRowspanCounter(int rowSpn,String value)
        {
            this.rowSpn= rowSpn;
            this.value=value;

        }

        }



}

