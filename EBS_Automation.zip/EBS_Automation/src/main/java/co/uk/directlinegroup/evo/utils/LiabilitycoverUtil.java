package co.uk.directlinegroup.evo.utils;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

/**
 * Created by 323835 on 5/18/2017.
 */
public class LiabilitycoverUtil {

    private CommonUtil commonutil = new CommonUtil();

    public void publicLiability(List<List<String>> data, String fieldName, WebElement property) throws Throwable {
        String StrVal = commonutil.datapicker(data, fieldName);
        String val = "£";
        String ss = val.concat(StrVal);
        new Select((property)).selectByVisibleText(ss);
    }
}
