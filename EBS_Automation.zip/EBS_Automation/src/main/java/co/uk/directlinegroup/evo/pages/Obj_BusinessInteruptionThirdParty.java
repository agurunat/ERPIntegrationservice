package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class Obj_BusinessInteruptionThirdParty extends AbstractPage {

    public WebElement rentChair() {
        return waitForElementToBeClickableAndReturnElement(By.xpath("//*[@id='C8__BUT_150E2AD778D3C2DE272983' or @id='C8__BUT_150E2AD778D3C2DE272983']"));

    }

    public WebElement nameOfSaloon() {
        return waitForElementPresent(By.xpath("//*[@id='C8__QUE_006AB5B0B0C7206C624273' or @id='C8__QUE_006AB5B0B0C7206C624273']"));

    }

    public WebElement postcode() {
        return waitForElementPresent(By.xpath("//*[@id='C8__QUE_72934B4CEE6D3139317179' or @id='C8__QUE_72934B4CEE6D3139317179']"));
    }

    public WebElement addSaloon() {
        return waitForElementToBeClickableAndReturnElement(By.xpath("//*[@id='C8__BUT_006AB5B0B0C7206C648375' or @id='C8__BUT_006AB5B0B0C7206C648375']"));
    }

    public WebElement nextbutton() {
        return waitForElementToBeClickableAndReturnElement(By.xpath("//*[@id='C8__BUT_006AB5B0B0C7206C624835' or @id='C8__BUT_006AB5B0B0C7206C624835']"));
    }
    public WebElement thirdPartyBinButton()
    {
        return waitForElementPresent(By.id("C8__BUT_23035B723C653FC6660780"));
    }
    public List<WebElement> eleAccordionBITP() {
        return findElements(By.id("BI-ThirdParty"));
    }
    public WebElement moreOptionBIThirdParty() {
        return waitForElementPresent(By.xpath("//*[@id='C6__QUE_965BD2C07905F7002825070']/p"));
    }
    public WebElement validationPopUp(){
        return waitForElementPresent(By.xpath("//*[@id='C8__HEAD_523D3ECD008FAE54670308']"));
    }
    public WebElement validationPopUpYesButton(){
        return waitForElementPresent(By.xpath("//*[@id='C8__BUT_523D3ECD008FAE54670615']"));
    }
    public WebElement validationPopUpNoButton(){
        return waitForElementPresent(By.xpath("//*[@id='C8__BUT_523D3ECD008FAE54670620']"));
    }
}
