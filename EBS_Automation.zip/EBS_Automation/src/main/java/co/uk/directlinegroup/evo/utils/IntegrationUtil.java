package co.uk.directlinegroup.evo.utils;

import org.apache.log4j.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;

public class IntegrationUtil {
    String regexMulDigits = "\\d+";
    String regexSingleDigit = "\\d";
    String regexSingleNonDigit = "\\D";
    String regexMulNonDigit = "\\D+";
    static Logger log = Logger.getLogger(IntegrationUtil.class);

    public static boolean flag = false;


    //ArrayList<String> actualVal = new ArrayList<String>();
    private IntegrationReportUtil reportUtil = new IntegrationReportUtil();


    public void inteliimatchValidateScenario(String amount, String BankAccntNo, String TnxType, String DebitCredit, String BatchReference, String TnxReference, String PaymentMethod, String TnxDate, String NoOfRows) throws Exception {

        try {
            File directory = new File("src\\test\\resources\\Integration\\Intellimatch");
            //get all the files from a directory
            File[] fList = directory.listFiles();

            for (File file : fList) {


                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));
                // reportUtil.createExcel("src\\test\\resources\\Integration\\IntegrationResults.xls");

                // List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\470774\\Desktop\\Pradeep\\Intellimatch.txt"));
                ArrayList<String> al = new ArrayList<String>();
                int count = 0;
                for (String line : lines) {
                    String[] result1 = line.split("\\|");

                    int fieldsSize = result1.length;
                    String StrfieldsSize = Integer.toString(fieldsSize);

                    if (line != lines.get(0)) {


                        //*****************Integrity Check******************//
                      /*  stringMatchCompare("Integration_Results",result1[0],("^[\\D]{1}$"));
                        stringCompare("Integration_Results",result1[0],("D"));
                        stringMatchCompare("Integration_Results",result1[1],("^[\\d]{6,8}$")); //static
                        stringMatchCompare("Integration_Results",result1[2],("^(0?[1-9]|[12][\\d]|3[01])[\\/\\-](0?[1-9]|1[012])[\\/\\-]\\d{4}$")); ///date format check
                        stringMatchCompare("Integration_Results",result1[3],("^(0?[1-9]|[12][\\d]|3[01])[\\/\\-](0?[1-9]|1[012])[\\/\\-]\\d{4}$")); ///date format check
                        stringMatchCompare("Integration_Results",result1[4],("^-?\\d+(\\.\\d{1,2})?$"));
                        stringMatchCompare("Integration_Results",result1[6],("^[\\D]{2}$")); //static
                        stringMatchCompare("Integration_Results",result1[7],("^[\\D]{3}$"));
                        stringCompare("Integration_Results",result1[7],("GBP"));
                        stringMatchCompare("Integration_Results",result1[8],("^[\\d]{5}$"));
                        stringMatchCompare("Integration_Results",result1[10],(regexMulNonDigit));

                        Assert.assertTrue(StrfieldsSize.equals("11"));//no of fields validation
*/


                        //*****************Accuracy Check******************//
                        if (line.contains(BatchReference)) {
                            stringCompare("Integration_Results", "Row identifier", result1[0], ("D")); //row identifier
                            stringCompare("Integration_Results", "Bank Account Number", result1[1], (BankAccntNo)); //Bank Account Number
                            String CoverStartDate = TnxDate.substring(6) + "/" + TnxDate.substring(4, 6) + "/" + TnxDate.substring(0, 4);
                            stringCompare("Integration_Results", "Posting Date", result1[2], (CoverStartDate)); ///////Posting Date
                            stringCompare("Integration_Results", "Transaction Date", result1[3], (CoverStartDate)); ////////////Transaction Date
                            if (DebitCredit.equalsIgnoreCase("CR")) {
                                stringCompare("Integration_Results", "Amount", result1[4], ("-" + amount));//////////amount
                            } else {
                                stringCompare("Integration_Results", "Amount", result1[4], (amount));//////////amount
                            }
                            stringCompare("Integration_Results", "TransactionType", result1[5], (TnxType));//////TnxType
                            stringCompare("Integration_Results", "DebitCredit", result1[6], (DebitCredit));//////////////DebitCredit
                            stringCompare("Integration_Results", "Currrecy", result1[7], ("GBP"));
                            stringCompare("Integration_Results", "BatchReference", result1[8], (BatchReference));//////BatchReference
                            String[] reference = result1[9].split("-");
                            stringContains("Integration_Results", "TransactionReference", reference[0], (TnxReference));////TnxReference
                            //Change because first 2 installments will be always card evenyhough payment made in Monthly DD
                            if (PaymentMethod.equalsIgnoreCase("Monthly DD")) {
                                PaymentMethod = "Card";
                            }
                            stringCompare("Integration_Results", "PaymentMethod", result1[10], (PaymentMethod));///////////PaymentMethod
                            count++;
                        }

                        al.add(result1[8]);


                    }
                }

                String CountSize = Integer.toString(count);
                if (count > 0) {
                    //    Assert.assertTrue(NoOfRows.equals(CountSize));//no of rows validation
                }

                int found = 0;
                int notfound = 0;

                for (String e : al) {
                    if (e.equals(BatchReference)) {
                        found++;
                    } else {
                        notfound++;
                    }
                }
                if (found > 0) {
                } else {
                    stringCompare("Integration_Results", "BatchReference", BatchReference, "Not Found");//////BatchReference
                }
            }

        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();
            throw (e);
        }

    }


    public void amlValidateScenario(String contact, String contactName, String Address, String Address1, String Address2, String contactNo, String policyNumber, String NoOfPremises, String IntPartyContactNme, String PartnerCntctName, String PersonContactName, String Prem2Addr, String Prem2Country) throws Exception {

        try {

            File directory = new File("src\\test\\resources\\Integration\\AML");
            //get all the files from a directory
            File[] fList = directory.listFiles();

            for (File file : fList) {


                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));

                //reportUtil.createExcel("src\\test\\resources\\Integration\\IntegrationResults.xls");

                //List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\470774\\Desktop\\Pradeep\\ToTest\\GL2.txt"));
                int count = 0;
                int contactcount1 = 0;
                int Partnercontactcount1 = 0;
                int IntPartycount1 = 0;
                int Personcontactcount1 = 0;
                ArrayList<String> al = new ArrayList<String>();

                for (String line : lines) {

                    String[] result1 = line.trim().split("\\~");

                    int fieldsSize = result1.length;
                    String StrfieldsSize = Integer.toString(fieldsSize);

                    //Assert.assertTrue(StrfieldsSize.equals("32"));//no of fields validation

                    //*****************Integrity Check******************//
                    /*stringMatchCompare("Integration_Results", result1[0], (regexMulDigits));
                    stringMatchCompare("Integration_Results", result1[1], (regexSingleNonDigit));

                    if (result1[1].contains("C")) {
                        stringCompare("Integration_Results", result1[1], ("C"));//contact
                    } else {
                        stringCompare("Integration_Results", result1[1], ("I"));
                    }

                    stringMatchCompare("Integration_Results", result1[2], (regexSingleDigit));
                    stringCompare("Integration_Results", result1[2], ("1")); //static
                    stringMatchCompare("Integration_Results", result1[3], (regexMulNonDigit));

                    stringCompare("Integration_Results", result1[7], "");
                    stringCompare("Integration_Results", result1[8], (""));
                    stringCompare("Integration_Results", result1[9], (""));
                    stringCompare("Integration_Results", result1[10], (""));
                    stringCompare("Integration_Results", result1[11], (" "));
                    stringMatchCompare("Integration_Results", result1[12], ("^[A-Z]{5}$"));
                    stringCompare("Integration_Results", result1[12], ("GBEVO")); //static
                    stringMatchCompare("Integration_Results", result1[13], (regexMulDigits));// Date
                    stringCompare("Integration_Results", result1[14], (""));
                    stringCompare("Integration_Results", result1[15], (""));
                    // Assert.assertTrue((result1[16].equals("")) || (result1[16].matches(regexMulNonDigit)));
                    multipleStringCompare("Integration_Results", result1[16], ";" + regexMulNonDigit + "");
                    stringMatchCompare("Integration_Results", result1[17], (regexSingleNonDigit));
                    stringCompare("Integration_Results", result1[17], ("A"));    //static
                    stringCompare("Integration_Results", result1[18], (""));
                    stringCompare("Integration_Results", result1[19], (""));
                    stringCompare("Integration_Results", result1[20], (""));
                    stringMatchCompare("Integration_Results", result1[21], "^[\\d]{10}$");
                    // Assert.assertTrue((result1[22].equals("")) || (result1[22].matches("^[\\d]{10}$")));
                    multipleStringCompare("Integration_Results", result1[22], ";^[\\d]{10}$");
                    // Assert.assertTrue((result1[23].equals("")) || (result1[23].matches("^[\\d]{10}$")));
                    multipleStringCompare("Integration_Results", result1[23], ";^[\\d]{10}$");
                    stringCompare("Integration_Results", result1[24], (""));
                    stringMatchCompare("Integration_Results", result1[25], ("^[\\D]{2}$"));
                    stringMatchCompare("Integration_Results", result1[26], ("^[\\D]{2}$"));
                    stringMatchCompare("Integration_Results", result1[27], ("^[\\D]{2}$"));
                    stringMatchCompare("Integration_Results", result1[28], ("^[\\D]{2}$"));
                    stringMatchCompare("Integration_Results", result1[29], ("^[\\D]{2}$"));
                    stringCompare("Integration_Results", result1[25], ("GB"));   //static
                    stringCompare("Integration_Results", result1[26], ("GB"));   //static
                    stringCompare("Integration_Results", result1[27], ("GB"));   //static
                    stringCompare("Integration_Results", result1[28], ("GB"));   //static
                    stringCompare("Integration_Results", result1[29], ("GB"));   //static
                    stringMatchCompare("Integration_Results", result1[30], ("^[\\d]{9}$"));
                    stringMatchCompare("Integration_Results", result1[31], ("^[a-zA-Z\\d]{4}$"));
                    stringCompare("Integration_Results", result1[31], ("DL4B"));    //static
                    *///*****************End of Integrity Check******************//


                    //*****************Accuracy Check******************//
                    if ((line.contains(policyNumber)) && (result1[2].equals("1"))) {


                        //   stringMatchCompare("Integration_Results", "Integrity check for digits", result1[0], (regexMulDigits)); //Integrity check for digits


                        if (result1[1].contains("C")) {
                            stringCompare("Integration_Results", "Contact Name", result1[1], ("C"));//contact
                        } else {
                            stringCompare("Integration_Results", "Contact Name", result1[1], ("I"));
                        }


                        //Integrity check for digits
                        //stringCompare("Integration_Results", result1[2], ("1")); //static


                        //Integrity check for characters
                        //if(NoOfPremises.equals("1")){
                        if (result1[3].equalsIgnoreCase(contactName)) {
                            contactcount1++;
                        } else if (result1[3].equalsIgnoreCase(PartnerCntctName)) {
                            Partnercontactcount1++;
                        } else if (result1[3].equalsIgnoreCase(IntPartyContactNme)) {
                            IntPartycount1++;
                        } else if (result1[3].equalsIgnoreCase(PersonContactName)) {
                            Personcontactcount1++;
                        }


                        String Addres = Address;
                        Address = Addres.replace(",", " ");
                        // stringContains("Integration_Results", "Address", result1[4], (Address)); //Address
                        //stringContains("Integration_Results", "Address1", result1[5], (Address2));  //Address1


                        // stringCompare("Integration_Results", "Address2", result1[6], (Address2));//Address2

                        //Integrity check for characters
                        stringCompare("Integration_Results", "Source System", result1[12], ("GBEVO")); //static


                        //Integrity check for digits
                        //stringCompare("Integration_Results", "ContactNumber", result1[0], (contactNo)); //contactNo


                        //Integrity check for digits
                        stringCompare("Integration_Results", "Policy Status", result1[17], ("A"));    //static
                        stringCompare("Integration_Results", "KP/G Identifier", result1[25], ("GB"));   //static
                        stringCompare("Integration_Results", "KP/G Link to customer", result1[26], ("GB"));   //static
                        stringCompare("Integration_Results", "Additional AML Country 1", result1[27], ("GB"));   //static
                        stringCompare("Integration_Results", "Additional AML Country 2", result1[28], ("GB"));   //static
                        stringCompare("Integration_Results", "Additional AML Country 3", result1[29], ("GB"));   //static
                        stringCompare("Integration_Results", "Policy Number", result1[30], (policyNumber));   //policyNumber
                        stringCompare("Integration_Results", "Supplement Field 1", result1[31], ("DL4B"));    //static

                        count++;

                    }

                    if ((line.contains(policyNumber)) && (result1[2].equals("2"))) {


                        //   stringMatchCompare("Integration_Results", "Integrity check for digits", result1[0], (regexMulDigits)); //Integrity check for digits


                        if (result1[1].contains("C")) {
                            stringCompare("Integration_Results", "Contact Name", result1[1], ("C"));//contact
                        } else {
                            stringCompare("Integration_Results", "Contact Name", result1[1], ("I"));
                        }


                        //Integrity check for digits
                        //stringCompare("Integration_Results", result1[2], ("1")); //static


                        //Integrity check for characters
                        //if(NoOfPremises.equals("1")){
                        if (result1[3].equalsIgnoreCase(contactName)) {
                            contactcount1++;
                        } else if (result1[3].equalsIgnoreCase(PartnerCntctName)) {
                            Partnercontactcount1++;
                        } else if (result1[3].equalsIgnoreCase(IntPartyContactNme)) {
                            IntPartycount1++;
                        } else if (result1[3].equalsIgnoreCase(PersonContactName)) {
                            Personcontactcount1++;
                        }


                        //     String Addres = Address;
                        //  Address = Addres.replace(","," ");
                        //   stringContains("Integration_Results", "Address", result1[4], (Address)); //Address
                        //   stringContains("Integration_Results", "Address1", result1[5], (Address2));  //Address1


                        String Addres1 = Prem2Addr;
                        Address = Addres1.replace(",", "");
                        //   stringContains("Integration_Results", "Address", result1[4], (Address)); //Address
                        //stringContains("Integration_Results", "Address1", result1[5], (Prem2Country));  //Address1


                        // stringCompare("Integration_Results", "Address2", result1[6], (Address2));//Address2

                        //Integrity check for characters
                        stringCompare("Integration_Results", "Source System", result1[12], ("GBEVO")); //static


                        //Integrity check for digits
                        //  stringCompare("Integration_Results", "ContactNumber", result1[0], (contactNo)); //contactNo


                        //Integrity check for digits
                        stringCompare("Integration_Results", "Policy Status", result1[17], ("A"));    //static
                        stringCompare("Integration_Results", "KP/G Identifier", result1[25], ("GB"));   //static
                        stringCompare("Integration_Results", "KP/G Link to customer", result1[26], ("GB"));   //static
                        stringCompare("Integration_Results", "Additional AML Country 1", result1[27], ("GB"));   //static
                        stringCompare("Integration_Results", "Additional AML Country 2", result1[28], ("GB"));   //static
                        stringCompare("Integration_Results", "Additional AML Country 3", result1[29], ("GB"));   //static
                        stringCompare("Integration_Results", "Policy Number", result1[30], (policyNumber));   //policyNumber
                        stringCompare("Integration_Results", "Supplement Field 1", result1[31], ("DL4B"));    //static

                        count++;

                    }
                    if ((line.contains(policyNumber)) && (result1[2].equals("3"))) {


                        //   stringMatchCompare("Integration_Results", "Integrity check for digits", result1[0], (regexMulDigits)); //Integrity check for digits


                        if (result1[1].contains("C")) {
                            stringCompare("Integration_Results", "Contact Name", result1[1], ("C"));//contact
                        } else {
                            stringCompare("Integration_Results", "Contact Name", result1[1], ("I"));
                        }


                        //Integrity check for digits
                        //stringCompare("Integration_Results", result1[2], ("1")); //static


                        //Integrity check for characters
                        //if(NoOfPremises.equals("1")){
                        if (result1[3].equalsIgnoreCase(contactName)) {
                            contactcount1++;
                        } else if (result1[3].equalsIgnoreCase(PartnerCntctName)) {
                            Partnercontactcount1++;
                        } else if (result1[3].equalsIgnoreCase(IntPartyContactNme)) {
                            IntPartycount1++;
                        } else if (result1[3].equalsIgnoreCase(PersonContactName)) {
                            Personcontactcount1++;
                        }


                        //     String Addres = Address;
                        //  Address = Addres.replace(","," ");
                        //   stringContains("Integration_Results", "Address", result1[4], (Address)); //Address
                        //   stringContains("Integration_Results", "Address1", result1[5], (Address2));  //Address1


                        String Addres1 = Prem2Addr;
                        Address = Addres1.replace(",", "");
                        //   stringContains("Integration_Results", "Address", result1[4], (Address)); //Address
                        //stringContains("Integration_Results", "Address1", result1[5], (Prem2Country));  //Address1


                        // stringCompare("Integration_Results", "Address2", result1[6], (Address2));//Address2

                        //Integrity check for characters
                        stringCompare("Integration_Results", "Source System", result1[12], ("GBEVO")); //static


                        //Integrity check for digits
                        //  stringCompare("Integration_Results", "ContactNumber", result1[0], (contactNo)); //contactNo


                        //Integrity check for digits
                        stringCompare("Integration_Results", "Policy Status", result1[17], ("A"));    //static
                        stringCompare("Integration_Results", "KP/G Identifier", result1[25], ("GB"));   //static
                        stringCompare("Integration_Results", "KP/G Link to customer", result1[26], ("GB"));   //static
                        stringCompare("Integration_Results", "Additional AML Country 1", result1[27], ("GB"));   //static
                        stringCompare("Integration_Results", "Additional AML Country 2", result1[28], ("GB"));   //static
                        stringCompare("Integration_Results", "Additional AML Country 3", result1[29], ("GB"));   //static
                        stringCompare("Integration_Results", "Policy Number", result1[30], (policyNumber));   //policyNumber
                        stringCompare("Integration_Results", "Supplement Field 1", result1[31], ("DL4B"));    //static

                        count++;

                    }
                    al.add(result1[30]);

                    //*****************End of Accuracy Check******************//

                }
                if (NoOfPremises.equalsIgnoreCase("null")) {
                    NoOfPremises = "0";
                }

                int NoOfRows = Integer.parseInt(NoOfPremises) * 4;
                int TotalNoOfRows = NoOfRows + 4;
                String RowSize = Integer.toString(TotalNoOfRows);

                String CountSize = Integer.toString(count);

                stringCompare("Integration_Results", "Record", CountSize + "rows", RowSize + "rows");

                String contactCountSize = Integer.toString(contactcount1);
                String PartnercontactCountSize = Integer.toString(Partnercontactcount1);
                String IntPartycountSize = Integer.toString(IntPartycount1);
                String PersoncontactcountSize = Integer.toString(Personcontactcount1);


                int NoOfPremisesCnt = Integer.parseInt(NoOfPremises) + 1;
                String NoOfPremisesCount = Integer.toString(NoOfPremisesCnt);

                stringCompare("Integration_Results", "Contacts", contactCountSize + " contacts", NoOfPremisesCount + " Contacts");
                stringCompare("Integration_Results", "partners", PartnercontactCountSize + " Partner contacts", NoOfPremisesCount + " Partner contacts");
                stringCompare("Integration_Results", "InrestedParty", IntPartycountSize + " Interested Party contacts", NoOfPremisesCount + " Interested Party contacts");
                stringCompare("Integration_Results", "Personal Contact", PersoncontactcountSize + " Personal contacts", NoOfPremisesCount + " Personal contacts");

                   /* Assert.assertTrue(contactCountSize.equals(NoOfPremisesCount));//no of rows validation
                    Assert.assertTrue(PartnercontactCountSize.equals(NoOfPremisesCount));//no of rows validation
                    Assert.assertTrue(IntPartycountSize.equals(NoOfPremisesCount));//no of rows validation
                    Assert.assertTrue(PersoncontactcountSize.equals(NoOfPremisesCount));//no of rows validation
*/


                // if(count>0) {

                //Assert.assertTrue(RowSize.equals(CountSize));//no of rows validation

                // }

                int found = 0;
                int notfound = 0;

                for (String e : al) {
                    if (e.equals(policyNumber)) {
                        found++;
                    } else {
                        notfound++;
                    }
                }
                if (found > 0) {
                } else {
                    stringCompare("Integration_Results", "Policy No :", policyNumber, "Not Found");//////Policy No
                }

            }


        } catch (Exception e) {
            log.error("Unexpected error", e);
            e.printStackTrace();

            throw (e);
        }

    }

    public void GeospatialValidateScenario(String changeType, String insuredLocId, String versionSeq, String policyNumber, String businessName, String Address1, String Address2, String Address4, String Address5, String Address6, String BusinessType, String postCode, String TnxDate, String COB, String totalSumInsured, String NoOfRows, String Premise2) throws Exception {

        try {


            File directory = new File("src\\test\\resources\\Integration\\Geospatial");
            //get all the files from a directory
            File[] fList = directory.listFiles();

            for (File file : fList) {


                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));
                // reportUtil.createExcel("src\\test\\resources\\Integration\\IntegrationResults.xls");
                ArrayList<String> al = new ArrayList<String>();
                ArrayList<String> al1 = new ArrayList<String>();

                //List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\470774\\Desktop\\Pradeep\\Geospatial.csv"));

                int count = 0;
                int count1 = 0;

                for (String line : lines) {

                    // String[] result1 = line.replace("\"", "").split("\\,");


                    String[] result1 = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");

                    for (int i = 0; i < result1.length; i++) {
                        result1[i] = result1[i].replace("\"", "");
                    }


                    if (line == lines.get(0)) {
                        int fieldsSize = result1.length;
                        String StrfieldsSize = Integer.toString(fieldsSize);

                        //Assert.assertTrue(StrfieldsSize.equals("26"));//no of fields validation


                    } else if (line != lines.get(0)) {

                        //*****************Integrity Check******************//
/*
                        stringMatchCompare("Integration_Results", result1[0], (regexMulNonDigit));
                        stringMatchCompare("Integration_Results", result1[1], (regexMulNonDigit));
                        stringCompare("Integration_Results", result1[1], ("GB")); //TERRITORY-static
                        stringMatchCompare("Integration_Results", result1[2], ("^[\\d]{9}$"));
                        stringMatchCompare("Integration_Results", result1[3], ("^[\\d]{4,5}$"));
                        stringMatchCompare("Integration_Results", result1[4], ("^([1-9]|([012][\\d])|(3[01]))/([0]{0,1}[1-9]|1[012])/\\d\\d\\d\\d [012]{0,1}[\\d]:[0-6][\\d]$")); ///date format
                        stringCompare("Integration_Results", result1[5], (""));
                        stringCompare("Integration_Results", result1[6], (""));
                        stringCompare("Integration_Results", result1[7], (""));
                        stringMatchCompare("Integration_Results", result1[8], ("^[\\d]{9}$"));
                        stringMatchCompare("Integration_Results", result1[9], ("^[\\d]{3}$"));
                        stringCompare("Integration_Results", result1[9], (COB)); //COB_ID -static
                        stringMatchCompare("Integration_Results", result1[10], ("^[\\d]{3}$"));
                        stringCompare("Integration_Results", result1[10], (COB)); //COB_DESCRIPTION -static
                        stringMatchCompare("Integration_Results", result1[11], (regexMulDigits +"."+regexMulDigits));
                        stringMatchCompare("Integration_Results", result1[12], (regexMulNonDigit));
                        //stringMatchCompare("Integration_Results", result1[13], (""));
                        multipleStringCompare("Integration_Results", result1[14], ";" + regexMulNonDigit + "");
                        multipleStringCompare("Integration_Results", result1[15], ";" + regexMulNonDigit + "");
                        stringMatchCompare("Integration_Results", result1[16], (regexMulNonDigit));

                        //Assert.assertTrue((result1[16],("")) || (result1[16],(regexMulNonDigit)));
                        multipleStringCompare("Integration_Results", result1[17], ";" + regexMulNonDigit + "");

                        stringMatchCompare("Integration_Results", result1[18], (regexMulNonDigit));
                        stringMatchCompare("Integration_Results", result1[19], (regexMulNonDigit));


                        if(result1[20].equals("")){
                            stringCompare("Integration_Results", result1[20], (""));
                            stringMatchCompare("Integration_Results", result1[21], ("^[\\d]{5}$"));
                            stringCompare("Integration_Results", result1[21], ("22190")); //SECTION_ID
                            stringMatchCompare("Integration_Results", result1[22], ("^[A-Z]{3}$"));
                            stringCompare("Integration_Results", result1[22], ("DLC")); //ITEM_ID
                            stringMatchCompare("Integration_Results", result1[23], ("^([1-9]|([012][\\d])|(3[01]))/([0]{0,1}[1-9]|1[012])/\\d\\d\\d\\d [012]{0,1}[\\d]:[0-6][\\d]$")); ///date format
                            stringMatchCompare("Integration_Results", result1[24], ("^([1-9]|([012][\\d])|(3[01]))/([0]{0,1}[1-9]|1[012])/\\d\\d\\d\\d [012]{0,1}[\\d]:[0-6][\\d]$")); ///date format
                            stringMatchCompare("Integration_Results", result1[25], ("^[A-Z]{1,2}[\\dR][\\dA-Z]? [\\d][A-Z]{2}$"));
                        } else {
                            stringMatchCompare("Integration_Results", result1[20], (regexMulNonDigit));
                            stringMatchCompare("Integration_Results", result1[21], (regexMulNonDigit));
                            stringCompare("Integration_Results", result1[22], (""));
                            stringMatchCompare("Integration_Results", result1[23], ("^[\\d]{5}$"));
                            stringCompare("Integration_Results", result1[23], ("22190")); //SECTION_ID
                            stringMatchCompare("Integration_Results", result1[24], ("^[A-Z]{3}$"));
                            stringCompare("Integration_Results", result1[24], ("DLC")); //ITEM_ID
                            stringMatchCompare("Integration_Results", result1[25], ("^([1-9]|([012][\\d])|(3[01]))/([0]{0,1}[1-9]|1[012])/\\d\\d\\d\\d [012]{0,1}[\\d]:[0-6][\\d]$")); ///date format
                            stringMatchCompare("Integration_Results", result1[26], ("^([1-9]|([012][\\d])|(3[01]))/([0]{0,1}[1-9]|1[012])/\\d\\d\\d\\d [012]{0,1}[\\d]:[0-6][\\d]$")); ///date format
                            stringMatchCompare("Integration_Results", result1[27], ("^[A-Z]{1,2}[\\dR][\\dA-Z]? [\\d][A-Z]{2}$"));
                        }
*/


                        //*****************End of Integrity Check******************/


                        //*****************Accuracy Check******************//


                        if (NoOfRows.equals("1")) {
                            if (line.contains(policyNumber)) {


                                if (result1[13].contains(Address1)) {


                                    if (result1[0].contains("insert")) {
                                        stringCompare("Integration_Results", "ChangeType", result1[0], (changeType));//changeType
                                    } else {
                                        stringCompare("Integration_Results", "ChangeType", result1[0], ("update"));
                                    }


                                    stringCompare("Integration_Results", "Territtory", result1[1], ("GB")); //TERRITORY-static

                                    String insuredLocList[] = insuredLocId.split("#");
                                    int Inscount = 0;
                                    if (result1[2].matches(regexMulDigits)) {
                                        for (int x = 0; x < insuredLocList.length; x++) {
                                            if (insuredLocList[x].equals(result1[2])) {
                                                //stringCompare("Integration_Results", "Insured Location Id", insuredLocList[x], (result1[2]));//INSURED_LOCATION_ID
                                                //stringCompare("Integration_Results", "Insured Location Id", insuredLocList[x], (result1[2]));//INSURED_LOCATION_ID
                                                break;
                                            } else {
                                                Inscount++;
                                                if (Inscount == insuredLocList.length) {
                                                    for (int y = 0; y < insuredLocList.length; y++) {
                                                        //stringCompare("Integration_Results", "Insured Location Id", insuredLocList[y], (result1[2]));//INSURED_LOCATION_ID
                                                        //stringCompare("Integration_Results", "Insured Location Id", insuredLocList[y], (result1[2]));//INSURED_LOCATION_ID
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    int VersCount = 0;
                                    String VersionSeqList[] = versionSeq.split("#");
                                    if (result1[3].matches(regexMulDigits)) {
                                        for (int x = 0; x < VersionSeqList.length; x++) {
                                            if (VersionSeqList[x].equals(result1[3])) {
                                                //stringCompare("Integration_Results", "Version Sequence", result1[3], (versionSeq)); //VERSION_SEQUENCE
                                                break;
                                            } else {
                                                VersCount++;
                                                if (VersCount == VersionSeqList.length) {
                                                    for (int y = 0; y < VersionSeqList.length; y++) {
                                                        //stringCompare("Integration_Results", "Version Sequence", VersionSeqList[y], (result1[3])); //VERSION_SEQUENCE
                                                    }
                                                }
                                            }
                                        }
                                    }


                                    String CoverStartDate = TnxDate.substring(6) + "/" + TnxDate.substring(4, 6) + "/" + TnxDate.substring(0, 4) + " 00:00";


                                    String dt = CoverStartDate;  // Start date
                                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                                    Calendar c = Calendar.getInstance();
                                    c.setTime(sdf.parse(dt));
                                    c.add(Calendar.DATE, -1);  // number of days to add

                                    c.add(Calendar.YEAR, 1);
                                    dt = sdf.format(c.getTime());
                                    String coverEndDate = dt + " 23:59";
                                    stringCompare("Integration_Results", "CoverStartDate", result1[4], (CoverStartDate));// Need to update value from Webservice call
                                    stringCompare("Integration_Results", "MovementFlag", result1[5], (""));
                                    stringCompare("Integration_Results", "Inforce Flag", result1[6], (""));
                                    stringCompare("Integration_Results", "CurrentFlag", result1[7], (""));
                                    stringCompare("Integration_Results", "Policy Number", result1[8], (policyNumber));   //policyNumber
                                    stringCompare("Integration_Results", "COB ID", result1[9], (COB)); //COB_ID -static

                                    switch (COB) {
                                        case "561":
                                            stringCompare("Integration_Results", "COB Description", result1[10], "Bed and Breakfast"); //COB_DESCRIPTION -static
                                            break;
                                        case "560":
                                            stringCompare("Integration_Results", "COB Description", result1[10], "Hair and Beauty"); //COB_DESCRIPTION -static
                                            break;
                                    }


                                    int SumInsCount = 0;
                                    String SumInsCountList[] = totalSumInsured.split("#");
                                    if (result1[11].matches(regexMulDigits + "." + regexMulDigits)) {
                                        for (int x = 0; x < SumInsCountList.length; x++) {
                                            if (SumInsCountList[x].equals(result1[11])) {
                                                stringCompare("Integration_Results", "TOTAL_SUM_INSUREDT", result1[11], (totalSumInsured)); //TOTAL_SUM_INSUREDT
                                                break;
                                            } else {
                                                SumInsCount++;
                                                if (SumInsCount == SumInsCountList.length) {
                                                    for (int y = 0; y < SumInsCountList.length; y++) {
                                                        stringCompare("Integration_Results", "TOTAL_SUM_INSURED", SumInsCountList[y], (result1[11])); //TOTAL_SUM_INSURED
                                                    }
                                                }
                                            }
                                        }
                                    }


                                    stringCompare("Integration_Results", "BusinessName", result1[12], (businessName)); //BUSINESS_NAME


                                    if (!result1[13].isEmpty()) {
                                        stringCompare("Integration_Results", "Address1", result1[13], (Address1)); //Address1
                                    }

                           /* String result3 =result1[14]+","+result1[15]+","+result1[16];
                            if (!result3.isEmpty()) {
                                stringContains("Integration_Results", result3, (Address2)); //Address2
                            } else {
                                stringCompare("Integration_Results", result3, ("")); //Address2
                            }*/

                           /* if (!result1[17].isEmpty()) {
                                stringContains("Integration_Results", result1[15], (Address3)); //Address3
                            } else {
                                stringCompare("Integration_Results", result1[15], ("")); //Address3
                            }*/
                                    // stringCompare("Integration_Results", result1[17], ("")); //Address3

                           /* if (!result1[16].isEmpty()) {
                                stringContains("Integration_Results", result1[16], (Address4)); //Address4
                            } else {
                                stringCompare("Integration_Results", result1[16], ("")); //Address4
                            }

                            if (result1[17].matches(regexMulNonDigit)) {
                                stringCompare("Integration_Results", result1[17], (Address5)); //Address5
                            } else {
                                stringCompare("Integration_Results", result1[17], ("")); //Address5
                            }


*/


                                    if (result1[20].equals("")) {
                                        if (result1[18].matches(regexMulNonDigit)) {
                                            stringCompare("Integration_Results", "Address6", result1[18], (Address6)); //Address6
                                        }
                                        stringCompare("Integration_Results", "BusinessType", result1[19], (BusinessType)); //BUSINESS_TYPE
                                        stringCompare("Integration_Results", "DTI Class", result1[20], (""));//DTI_CLASS
                                        stringCompare("Integration_Results", "Section ID", result1[21], ("22190")); //SECTION_ID
                                        stringCompare("Integration_Results", "Item ID", result1[22], ("DLC")); //ITEM_ID
                                        stringCompare("Integration_Results", "CoverStartDate", result1[23], (CoverStartDate));// Need to update value from Webservice call
                                        stringCompare("Integration_Results", "CoverEndDate", result1[24], (coverEndDate));// Need to update value from Webservice call
                                        stringCompare("Integration_Results", "Postcode", result1[25], (postCode)); //post Code Validation
                                    } else {
                                        if (result1[20].matches(regexMulNonDigit)) {
                                            stringCompare("Integration_Results", "Address6", result1[20], (Address6)); //Address6
                                        }
                                        stringCompare("Integration_Results", "Business Type", result1[21], (BusinessType)); //BUSINESS_TYPE
                                        stringCompare("Integration_Results", "DTI Class", result1[22], (""));//DTI_CLASS
                                        stringCompare("Integration_Results", "Section ID", result1[23], ("22190")); //SECTION_ID
                                        stringCompare("Integration_Results", "ITEM ID", result1[24], ("DLC")); //ITEM_ID
                                        stringCompare("Integration_Results", "CoverStartDate", result1[25], (CoverStartDate));// Need to update value from Webservice call
                                        stringCompare("Integration_Results", "CoverEndDate", result1[26], (coverEndDate));// Need to update value from Webservice call
                                        stringCompare("Integration_Results", "Postcode", result1[27], (postCode)); //post Code Validation
                                    }


                                    count++;
                                }

                            }
                        } else if (NoOfRows.equals("2")) {
                            if (line.contains(policyNumber)) {


                                if (count == 0) {
                                    if (result1[13].contains(Address1)) {


                                        if (result1[0].contains("insert")) {
                                            stringCompare("Integration_Results", "ChangeType", result1[0], (changeType));//changeType
                                        } else {
                                            stringCompare("Integration_Results", "ChangeType", result1[0], ("update"));
                                        }


                                        stringCompare("Integration_Results", "Territory", result1[1], ("GB")); //TERRITORY-static

                                        String insuredLocList[] = insuredLocId.split("#");
                                        int Inscount = 0;
                                        if (result1[2].matches(regexMulDigits)) {
                                            for (int x = 0; x < insuredLocList.length; x++) {
                                                if (insuredLocList[x].equals(result1[2])) {
                                                    //stringCompare("Integration_Results", "InsuredLocationID", insuredLocList[x], (result1[2]));//INSURED_LOCATION_ID
                                                    break;
                                                } else {
                                                    Inscount++;
                                                    if (Inscount == insuredLocList.length) {
                                                        for (int y = 0; y < insuredLocList.length; y++) {
                                                            //stringCompare("Integration_Results", "InsuredLocationID", insuredLocList[y], (result1[2]));//INSURED_LOCATION_ID
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        int VersCount = 0;
                                        String VersionSeqList[] = versionSeq.split("#");
                                        if (result1[3].matches(regexMulDigits)) {
                                            for (int x = 0; x < VersionSeqList.length; x++) {
                                                if (VersionSeqList[x].equals(result1[3])) {
                                                    //stringCompare("Integration_Results", "Version Sequnce", result1[3], (versionSeq)); //VERSION_SEQUENCE
                                                    break;
                                                } else {
                                                    VersCount++;
                                                    if (VersCount == VersionSeqList.length) {
                                                        for (int y = 0; y < VersionSeqList.length; y++) {
                                                            //stringCompare("Integration_Results", "Version Sequence", VersionSeqList[y], (result1[3])); //VERSION_SEQUENCE
                                                        }
                                                    }
                                                }
                                            }
                                        }


                                        String CoverStartDate = TnxDate.substring(6) + "/" + TnxDate.substring(4, 6) + "/" + TnxDate.substring(0, 4) + " 00:00";
                                        String dt = CoverStartDate;  // Start date
                                        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                                        Calendar c = Calendar.getInstance();
                                        c.setTime(sdf.parse(dt));
                                        c.add(Calendar.DATE, -1);  // number of days to add

                                        c.add(Calendar.YEAR, 1);
                                        dt = sdf.format(c.getTime());
                                        String coverEndDate = dt + " 23:59";
                                        stringCompare("Integration_Results", "CoverStartDate", result1[4], (CoverStartDate));// Need to update value from Webservice call
                                        stringCompare("Integration_Results", "Movement Sequence", result1[5], (""));
                                        stringCompare("Integration_Results", "Inforce Flag", result1[6], (""));
                                        stringCompare("Integration_Results", "Current Flag", result1[7], (""));
                                        stringCompare("Integration_Results", "Policy Number", result1[8], (policyNumber));   //policyNumber
                                        stringCompare("Integration_Results", "COB ID", result1[9], (COB)); //COB_ID -static

                                        switch (COB) {
                                            case "561":
                                                stringCompare("Integration_Results", "COB Description", result1[10], "Bed and Breakfast"); //COB_DESCRIPTION -static
                                                break;
                                            case "560":
                                                stringCompare("Integration_Results", "COB Description", result1[10], "Hair and Beauty"); //COB_DESCRIPTION -static
                                                break;
                                        }

                                        int SumInsCount = 0;
                                        String SumInsCountList[] = totalSumInsured.split("#");
                                        if (result1[11].matches(regexMulDigits + "." + regexMulDigits)) {
                                            for (int x = 0; x < SumInsCountList.length; x++) {
                                                if (SumInsCountList[x].equals(result1[11])) {
                                                    // stringCompare("Integration_Results", "Total Sum Insured", result1[11], (versionSeq)); //TOTAL_SUM_INSURED
                                                    break;
                                                } else {
                                                    SumInsCount++;
                                                    if (SumInsCount == SumInsCountList.length) {
                                                        for (int y = 0; y < SumInsCountList.length; y++) {
                                                            //   stringCompare("Integration_Results", "Total Sum Insured", SumInsCountList[y], (result1[11])); //TOTAL_SUM_INSURED
                                                        }
                                                    }
                                                }
                                            }
                                        }


                                        stringCompare("Integration_Results", "Business Name", result1[12], (businessName)); //BUSINESS_NAME


                                        if (!result1[13].isEmpty()) {
                                            stringCompare("Integration_Results", "Address1", result1[13], (Address1)); //Address1
                                        }


                                        if (result1[20].equals("")) {
                                            if (result1[18].matches(regexMulNonDigit)) {
                                                stringCompare("Integration_Results", "Address6", result1[18], (Address6)); //Address6
                                            }
                                            stringCompare("Integration_Results", "BusinessType", result1[19], (BusinessType)); //BUSINESS_TYPE
                                            stringCompare("Integration_Results", "DTI Class", result1[20], (""));//DTI_CLASS
                                            stringCompare("Integration_Results", "Section ID", result1[21], ("22190")); //SECTION_ID
                                            stringCompare("Integration_Results", "Item ID", result1[22], ("DLC")); //ITEM_ID
                                            stringCompare("Integration_Results", "CoverStartDate", result1[23], (CoverStartDate));// Need to update value from Webservice call
                                            stringCompare("Integration_Results", "CoverEndDate", result1[24], (coverEndDate));// Need to update value from Webservice call
                                            stringCompare("Integration_Results", "PostCode", result1[25], (postCode)); //post Code Validation
                                        } else {
                                            if (result1[20].matches(regexMulNonDigit)) {
                                                stringCompare("Integration_Results", "Address6", result1[20], (Address6)); //Address6
                                            }
                                            stringCompare("Integration_Results", "BUSINESS_TYPE", result1[21], (BusinessType)); //BUSINESS_TYPE
                                            stringCompare("Integration_Results", "DTI_CLASS", result1[22], (""));//DTI_CLASS
                                            stringCompare("Integration_Results", "SECTION_ID", result1[23], ("22190")); //SECTION_ID
                                            stringCompare("Integration_Results", "ITEM_ID", result1[24], ("DLC")); //ITEM_ID
                                            stringCompare("Integration_Results", "CoverStartDate", result1[25], (CoverStartDate));// Need to update value from Webservice call
                                            stringCompare("Integration_Results", "CoverEndDate", result1[26], (coverEndDate));// Need to update value from Webservice call
                                            stringCompare("Integration_Results", "Postcode", result1[27], (postCode)); //post Code Validation
                                        }


                                        count++;
                                    }

                                } else if (count == 1) {
                                    if (result1[13].contains(Premise2)) {


                                        if (result1[0].contains("insert")) {
                                            stringCompare("Integration_Results", "ChangeType", result1[0], (changeType));//changeType
                                        } else {
                                            stringCompare("Integration_Results", "ChnageType", result1[0], ("update"));
                                        }


                                        stringCompare("Integration_Results", "TERRITORY", result1[1], ("GB")); //TERRITORY-static

                                        String insuredLocList[] = insuredLocId.split("#");
                                        int Inscount = 0;
                                        if (result1[2].matches(regexMulDigits)) {
                                            for (int x = 0; x < insuredLocList.length; x++) {
                                                if (insuredLocList[x].equals(result1[2])) {
                                                    stringCompare("Integration_Results", "INSURED_LOCATION_ID", insuredLocList[x], (result1[2]));//INSURED_LOCATION_ID
                                                    break;
                                                } else {
                                                    Inscount++;
                                                    if (Inscount == insuredLocList.length) {
                                                        for (int y = 0; y < insuredLocList.length; y++) {
                                                            stringCompare("Integration_Results", "INSURED_LOCATION_ID", insuredLocList[y], (result1[2]));//INSURED_LOCATION_ID
                                                        }
                                                    }
                                                }
                                            }
                                        }

                                        int VersCount = 0;
                                        String VersionSeqList[] = versionSeq.split("#");
                                        if (result1[3].matches(regexMulDigits)) {
                                            for (int x = 0; x < VersionSeqList.length; x++) {
                                                if (VersionSeqList[x].equals(result1[3])) {
                                                    stringCompare("Integration_Results", "VERSION_SEQUENCE", result1[3], (versionSeq)); //VERSION_SEQUENCE
                                                    break;
                                                } else {
                                                    VersCount++;
                                                    if (VersCount == VersionSeqList.length) {
                                                        for (int y = 0; y < VersionSeqList.length; y++) {
                                                            stringCompare("Integration_Results", "VERSION_SEQUENCE", VersionSeqList[y], (result1[3])); //VERSION_SEQUENCE
                                                        }
                                                    }
                                                }
                                            }
                                        }


                                        String CoverStartDate = TnxDate.substring(6) + "/" + TnxDate.substring(4, 6) + "/" + TnxDate.substring(0, 4) + " 00:00";
                                        String dt = CoverStartDate;  // Start date
                                        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
                                        Calendar c = Calendar.getInstance();
                                        c.setTime(sdf.parse(dt));
                                        c.add(Calendar.DATE, -1);  // number of days to add

                                        c.add(Calendar.YEAR, 1);
                                        dt = sdf.format(c.getTime());
                                        String coverEndDate = dt + " 23:59";
                                        stringCompare("Integration_Results", "CoverStartDate", result1[4], (CoverStartDate));// Need to update value from Webservice call
                                        stringCompare("Integration_Results", "Movement Sequence", result1[5], (""));
                                        stringCompare("Integration_Results", "Inforce Flag", result1[6], (""));
                                        stringCompare("Integration_Results", "Currrent Flag", result1[7], (""));
                                        stringCompare("Integration_Results", "policyNumber", result1[8], (policyNumber));   //policyNumber
                                        stringCompare("Integration_Results", "COB_ID", result1[9], (COB)); //COB_ID -static

                                        switch (COB) {
                                            case "561":
                                                stringCompare("Integration_Results", "COB Description", result1[10], "Bed and Breakfast"); //COB_DESCRIPTION -static
                                                break;
                                            case "560":
                                                stringCompare("Integration_Results", "COB Description", result1[10], "Hair and Beauty"); //COB_DESCRIPTION -static
                                                break;
                                        }


                                        int SumInsCount = 0;
                                        String SumInsCountList[] = totalSumInsured.split("#");
                                        if (result1[11].matches(regexMulDigits + "." + regexMulDigits)) {
                                            for (int x = 0; x < SumInsCountList.length; x++) {
                                                if (SumInsCountList[x].equals(result1[11])) {
                                                    stringCompare("Integration_Results", "versionSeq", result1[11], (versionSeq)); //TOTAL_SUM_INSURED
                                                    break;
                                                } else {
                                                    SumInsCount++;
                                                    if (SumInsCount == SumInsCountList.length) {
                                                        for (int y = 0; y < SumInsCountList.length; y++) {
                                                            stringCompare("Integration_Results", "TOTAL_SUM_INSURED", SumInsCountList[y], (result1[11])); //TOTAL_SUM_INSURED
                                                        }
                                                    }
                                                }
                                            }
                                        }


                                        stringCompare("Integration_Results", "BUSINESS_NAME", result1[12], (businessName)); //BUSINESS_NAME


                                        if (!result1[13].isEmpty()) {
                                            stringCompare("Integration_Results", "Premise2", result1[13], (Premise2)); //Premise2
                                        }

                           /* String result3 =result1[14]+","+result1[15]+","+result1[16];
                            if (!result3.isEmpty()) {
                                stringContains("Integration_Results", result3, (Address2)); //Address2
                            } else {
                                stringCompare("Integration_Results", result3, ("")); //Address2
                            }*/

                           /* if (!result1[17].isEmpty()) {
                                stringContains("Integration_Results", result1[15], (Address3)); //Address3
                            } else {
                                stringCompare("Integration_Results", result1[15], ("")); //Address3
                            }*/
                                        // stringCompare("Integration_Results", result1[17], ("")); //Address3

                           /* if (!result1[16].isEmpty()) {
                                stringContains("Integration_Results", result1[16], (Address4)); //Address4
                            } else {
                                stringCompare("Integration_Results", result1[16], ("")); //Address4
                            }

                            if (result1[17].matches(regexMulNonDigit)) {
                                stringCompare("Integration_Results", result1[17], (Address5)); //Address5
                            } else {
                                stringCompare("Integration_Results", result1[17], ("")); //Address5
                            }


*/

                                        if (result1[20].equals("")) {
                                            if (result1[18].matches(regexMulNonDigit)) {
                                                stringCompare("Integration_Results", "Address6", result1[18], (Address6)); //Address6
                                            }
                                            stringCompare("Integration_Results", "BusinessType", result1[19], (BusinessType)); //BUSINESS_TYPE
                                            stringCompare("Integration_Results", "DTI_CLASS", result1[20], (""));//DTI_CLASS
                                            stringCompare("Integration_Results", "SECTION_ID", result1[21], ("22190")); //SECTION_ID
                                            stringCompare("Integration_Results", "ITEM_ID", result1[22], ("DLC")); //ITEM_ID
                                            stringCompare("Integration_Results", "CoverStartDate", result1[23], (CoverStartDate));// Need to update value from Webservice call
                                            stringCompare("Integration_Results", "CoverEndDate", result1[24], (coverEndDate));// Need to update value from Webservice call
                                            stringCompare("Integration_Results", "PostCode", result1[25], (postCode)); //post Code Validation
                                        } else {
                                            if (result1[20].matches(regexMulNonDigit)) {
                                                stringCompare("Integration_Results", "Address6", result1[20], (Address6)); //Address6
                                            }
                                            stringCompare("Integration_Results", "BUSINESS_TYPE", result1[21], (BusinessType)); //BUSINESS_TYPE
                                            stringCompare("Integration_Results", "DTI_CLASS", result1[22], (""));//DTI_CLASS
                                            stringCompare("Integration_Results", "SECTION_ID", result1[23], ("22190")); //SECTION_ID
                                            stringCompare("Integration_Results", "ITEM_ID", result1[24], ("DLC")); //ITEM_ID
                                            stringCompare("Integration_Results", "CoverStartDate", result1[25], (CoverStartDate));// Need to update value from Webservice call
                                            stringCompare("Integration_Results", "CoverEndDate", result1[26], (coverEndDate));// Need to update value from Webservice call
                                            stringCompare("Integration_Results", "Postcode", result1[27], (postCode)); //post Code Validation
                                        }


                                        count++;
                                    }
                                }

                                count1++;
                            }


                        }
                        al.add(result1[8]);
                        al.add(result1[13]);

                        //*****************End of Accuracy Check******************//
                    }
                }
                String CountSize = Integer.toString(count);
                //if(count>0) {
                //stringCompare("Integration_Results", "Premise", NoOfRows , (CountSize)); //post Code Validatio
//                Assert.assertTrue(NoOfRows.equals(CountSize));//no of rows validation
                // }

                /*if(count==0) {
                    if (count1 > 0) {
                        stringCompare("Integration_Results", NoOfRows + "WebService Premise", (CountSize + "File Rows with matching policy no only")); //post Code Validatio
                        Assert.assertTrue(NoOfRows.equals(CountSize));//no of rows validation
                    }
                }*/

                int found = 0;
                int notfound = 0;


                for (String e : al) {
                    if (e.equals(policyNumber)) {
                        found++;
                    } else {
                        notfound++;
                    }
                }
                if (found > 0) {
                } else {
                    stringCompare("Integration_Results", "Policy number", policyNumber, "Not Found");//////policyNumber
                }
            }
        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();

            throw (e);
        }
    }

    public void GL(String Identifier, String SSPProcessDate, String TransactionType, String Offering, String Product, String Channel, String Amount, String PolicyNo,
                   String ReceiptCash, String Card, String BankAccountID, String paymentType, String ReceiptID, String ReceiptItemID, String HeaderNo) throws Exception {

        try {
            File directory = new File("src\\test\\resources\\Integration\\GL");


            //get all the files from a directory
            File[] fList = directory.listFiles();

            for (File file : fList) {


                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));
                // reportUtil.createExcel("src\\test\\resources\\Integration\\IntegrationResults.xls");


                // List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\470774\\Desktop\\Pradeep\\GL1.txt"));
                int count1 = 0;
                ArrayList<String> al1 = new ArrayList<String>();
                ArrayList<String> al = new ArrayList<String>();
                for (String line : lines) {


                    //*****************Integrity &Accuracy Check******************//
                    if (line == lines.get(0)) {
                        String[] result1 = line.split("\\|");

                        int fieldsSize = result1.length;
                        String StrfieldsSize = Integer.toString(fieldsSize);

                        //Assert.assertTrue(StrfieldsSize.equals("4"));//no of fields validation


                        if (result1[0].matches(regexSingleNonDigit)) {
                            //stringCompare("Integration_Results", "ROW ID header", result1[0], ("H"));//RowID Header Static
                        }
                        //stringCompare("Integration_Results", "Identifier", result1[1], (Identifier));//Identifier
                        //stringCompare("Integration_Results", "SSPProcessDate", result1[2], (SSPProcessDate));//SSPProcessDate
                        //stringCompare("Integration_Results", "HeaderNo", result1[3], (HeaderNo));// Need to update value from Webservice call
                    } else {

                        String[] result1 = line.split("\\|");

                        int fieldsSize = result1.length;
                        String StrfieldsSize = Integer.toString(fieldsSize);


                        if (line == lines.get(1)) {
                            //Assert.assertTrue(StrfieldsSize.equals("25"));//no of fields validation

                        }

                        //*****************Integrity Check******************//
                        /*stringMatchCompare("Integration_Results", result1[0], (regexSingleNonDigit));//Identifier of the Row
                        stringCompare("Integration_Results", result1[0], ("D"));//Identifier of the Row
                        stringMatchCompare("Integration_Results", result1[1], ("^[A-Z]{3}$"));//Underwriting entity code-Underwriter
                        stringCompare("Integration_Results", result1[1], ("UKI"));//Underwriting entity code-Underwriter
                        stringCompare("Integration_Results", result1[3], ("Direct Line"));
                        stringMatchCompare("Integration_Results", result1[4], (regexMulNonDigit));
                        stringMatchCompare("Integration_Results", result1[8], ("^[\\D]{3}$")); //TERRITORY-static
                        stringCompare("Integration_Results", result1[8], ("GBP")); //TERRITORY-static
                        stringMatchCompare("Integration_Results", result1[9], ("^[\\d]{9}$")); //TERRITORY-static


                        *///*****************End of Integrity Check******************//


                        if (line.contains(PolicyNo)) {

                            stringCompare("Integration_Results", "Identifier", result1[0], ("D"));//Identifier of the Row
                            if (result1[1].matches("^[A-Z]{3}$")) {
                                stringCompare("Integration_Results", "UWI Entry Code", result1[1], ("UKI"));//Underwriting entity code-Underwriter
                            }

                            String tnxtypeList[] = TransactionType.split("#");
                            int count = 0;
                            if (result1[2].matches(regexMulNonDigit)) {
                                for (int x = 0; x < tnxtypeList.length; x++) {
                                    if (tnxtypeList[x].equals(result1[2])) {
                                        stringCompare("Integration_Results", "Transaction Type", tnxtypeList[x], (result1[2]));//TransactionType
                                        break;
                                    }/*else {
                                        count ++;
                                        if(count == tnxtypeList.length) {
                                            for (int y = 0; y < tnxtypeList.length; y++) {
                                                stringCompare("Integration_Results", tnxtypeList[y], (result1[2]));//TransactionType
                                            }
                                        }
                                    }*/
                                }
                            }

                            stringCompare("Integration_Results", "Brand", result1[3], ("Direct Line"));//Brand-Static-DirectLine
                            stringCompare("Integration_Results", "Offering", result1[4], (Offering));//Offering

                            String coverList[] = Product.split("#");
                            if (result1[5].matches(regexMulNonDigit)) {
                                for (int v = 0; v < coverList.length; v++) {
                                    if (coverList[v].equals(result1[5])) {
                                        stringCompare("Integration_Results", "Product", coverList[v], (result1[5]));//Product
                                        //productCoverCount = productCoverCount + 1;
                                    }
                                }
                            } else if (result1[5].isEmpty()) {
                                stringCompare("Integration_Results", "Product", result1[5], (""));//Product
                            }


                            if (result1[6].matches(regexMulNonDigit)) {
                                stringCompare("Integration_Results", "Channel", result1[6], (Channel));//Channel
                            } else if (result1[6].isEmpty()) {
                                stringCompare("Integration_Results", "Channel", result1[6], (""));//Channel
                            }

                            if (result1[7].matches(regexMulDigits)) {
                                stringMatchCompare("Integration_Results", "Amount", result1[7], (regexMulDigits));//Amount
                            } else if (result1[7].isEmpty()) {
                                stringCompare("Integration_Results", "Amount", result1[7], (""));//Amount
                            }

                            stringCompare("Integration_Results", "Territoy", result1[8], ("GBP")); //TERRITORY-static
                            stringCompare("Integration_Results", "Policy Number", result1[9], (PolicyNo));   //policyNumber

                            if (result1[10].matches(regexMulNonDigit)) {
                                //Assert.assertTrue(!result1[10].isEmpty());
                                //stringMatchCompare("Integration_Results", "Tax Reference", result1[10], (regexMulNonDigit));   //tax ref no
                            } else if (result1[10].isEmpty()) {
                                stringCompare("Integration_Results", "Tax Reference", result1[10], (""));//tax ref no
                            }

                            String[] CardType = result1[12].split("-");


                            if (result1[12].isEmpty()) {
                                stringCompare("Integration_Results", "FreeChargeCode", result1[12], (""));
                            } else {
                                stringContains("Integration_Results", "Card Number", CardType[1], (Card)); //card details
                            }

                            if (result1[2].equals("RECEIPT_CASH")) {
                                if (!result1[7].startsWith("-")) {
                                    //Assert.assertTrue(!result1[7].startsWith("-"));

                                    //stringCompare("Integration_Results", "Receipt Cash", result1[7], (ReceiptCash));

                                    stringCompare("Integration_Results", "Bank Account ID", result1[14], (BankAccountID));   //bank account id
                                    // stringCompare("Integration_Results", "Payment Type", result1[15], (paymentType));   //payment type

                                    //stringCompare("Integration_Results", "Receipt Id", result1[19], (ReceiptID)); //ReceiptId
                                    //stringCompare("Integration_Results", "Receipt Item Id", result1[20], (ReceiptItemID)); //ReceiptItemID

                                    // Assert.assertTrue(!result1[23].startsWith("-"));

                                    //stringCompare("Integration_Results", "Receipt Cash", result1[23], (ReceiptCash));

                                    stringCompare("Integration_Results", "Value", result1[24], ("0"));
                                } else {
                                    //Assert.assertTrue(result1[7].startsWith("-"));

                                    //stringCompare("Integration_Results", "ReceiptCash", result1[7], ("-" + ReceiptCash));

                                    stringCompare("Integration_Results", "Bank Account Number", result1[14], (BankAccountID));   //bank account id
                                    // stringCompare("Integration_Results", "Payment Type", result1[15], (paymentType));   //payment type

                                    //stringCompare("Integration_Results", "Receipt ID", result1[19], (ReceiptID)); //ReceiptId
                                    //stringCompare("Integration_Results", "Receipt Item Id", result1[20], (ReceiptItemID)); //ReceiptItemID

                                    //Assert.assertTrue(result1[24].startsWith("-"));

                                    //stringCompare("Integration_Results", "Receipt Cash", result1[24], ("-" + ReceiptCash));

                                    stringCompare("Integration_Results", "Value", result1[23], ("0"));
                                }

                            } else if (result1[2].equals("RECEIPT_DEBTORS")) {
                                if ((result1[7].startsWith("-"))) {
                                    // Assert.assertTrue(result1[7].startsWith("-"));

                                    // stringCompare("Integration_Results", "ReceiptCash", result1[7], ("-" + ReceiptCash));
                                    stringCompare("Integration_Results", "BankAccountID", result1[14], (BankAccountID));   //bank account id
                                    // stringCompare("Integration_Results", "paymentType", result1[15], (paymentType));   //payment type

                                    //stringCompare("Integration_Results", "ReceiptID", result1[19], (ReceiptID)); //ReceiptId
                                    //stringCompare("Integration_Results", "ReceiptItemID", result1[20], (ReceiptItemID)); //ReceiptItemID

                                    stringCompare("Integration_Results", "Value", result1[23], ("0"));
                                    //Assert.assertTrue(result1[24].startsWith("-"));

                                    //stringCompare("Integration_Results", "Receipt Cash", result1[24], ("-" + ReceiptCash));
                                } else {
                                    //Assert.assertTrue(!result1[7].startsWith("-"));

                                    //stringCompare("Integration_Results", "ReceiptCash", result1[7], (ReceiptCash));
                                    stringCompare("Integration_Results", "BankAccountID", result1[14], (BankAccountID));   //bank account id
                                    // stringCompare("Integration_Results", "Payment Type", result1[15], (paymentType));   //payment type

                                    //stringCompare("Integration_Results", "Receipt Id", result1[19], (ReceiptID)); //ReceiptId
                                    //stringCompare("Integration_Results", "Receipt Item Id", result1[20], (ReceiptItemID)); //ReceiptItemID

                                    stringCompare("Integration_Results", "value", result1[24], ("0"));
                                    //Assert.assertTrue(!result1[23].startsWith("-"));

                                    //stringCompare("Integration_Results", "ReceiptCash", result1[23], (ReceiptCash));
                                }
                            }


                            String AmountList[] = Amount.split("#");

                            for (int t = 0; t < coverList.length; t++) {
                                if (coverList[t].equals(result1[5])) {

                                    al.add(line);

                                    for (int m = 0; m < AmountList.length; m++) {
                                        if (AmountList[m].equals(result1[7])) {
                                            // Assert.assertTrue(AmountList[0].equals(result1[7]));
                                            //      Assert.assertTrue(result1[7].equals(AmountList[m]));
                                        }
                                    }
                                }
                            }
                            count1++;

                        }
                        al1.add(result1[9]);


                    }


                }
                int found = 0;
                int notfound = 0;

                for (String e : al1) {
                    if (e.equals(PolicyNo)) {
                        found++;
                    } else {
                        notfound++;
                    }
                }
                /*if (found > 0) {
                } else {
                    stringCompare("Integration_Results", "PolicyNumber", PolicyNo, "not found");//////BatchReference
                }*/
                //////////////Validation////////////
                int sum = 0;

                String coverList1[] = Product.split("#");
                String AmountList1[] = Amount.split("#");


                int coverSize = coverList1.length * 4;
                String StrCoverSize = Integer.toString(coverSize);

                int alSize = al.size();
                String StrAlSize = Integer.toString(alSize);///no of rows

                if (StrCoverSize.equals(StrAlSize)) {
                    //Assert.assertTrue(StrCoverSize.equals(StrAlSize));//no of rows with covers validation
                    stringCompare("Integration_Results", "Count Compare", StrCoverSize, StrAlSize);//////row size
                    //stringCompare("Integration_Results", "Count Compare", "count based on cover size is"+StrCoverSize, "mismatch with row size"+StrAlSize);//////row size
                } else {
                    stringCompare("Integration_Results", "Count Compare", StrCoverSize, StrAlSize);//////row size
                    //stringCompare("Integration_Results", "Count Compare", "count based on cover size is"+StrCoverSize, "mismatch with row size"+StrAlSize);//////row size
                    //Assert.assertTrue(StrCoverSize.equals(StrAlSize));//no of rows with covers validation
                }


                /********* positive and negative check **********/

                for (String s : al) {
                    String[] result2 = s.split("\\|");
                    if (result2[2].contains("DEBTORS")) {
                        //   Assert.assertTrue(!result2[7].startsWith("-"));
                    } else {
                        //   Assert.assertTrue(result2[7].startsWith("-"));
                    }
                    int taxRow = 0;

                    for (String s1 : al) {
                        String s2[] = s1.split("\\|");
                        for (int t = 0; t < AmountList1.length; t++) {
                            double Strresult1 = Double.parseDouble(AmountList1[t]);
                            double TaxValue1 = (Strresult1 * 12) / 100;
                            double roundOff = Math.round(TaxValue1 * 100.0) / 100.0;
                            String StrTaxValue1 = Double.toString(roundOff);

                            if (s2[23].contains(StrTaxValue1)) {
                                taxRow = taxRow + 1;
                            } else if (s2[24].contains(StrTaxValue1)) {
                                taxRow = taxRow + 1;
                            }
                        }
                    }
                    int FinalTaxRow = taxRow * 2;
                    String StrFinalTaxRow = Integer.toString(FinalTaxRow);
                    //Assert.assertEquals(StrAlSize, StrFinalTaxRow);
                }


            }
        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();

            throw (e);
        }

    }

    public void ELTO(String currentInsurerID, String OriginalInsurerID, String Policyno, String PolicyHoldername, String EmployerName, String coverStartDate, String coverEndDate, String Address, String YesNo) throws Exception {

        try {

            File directory = new File("src\\test\\resources\\Integration\\ELTO");
            //get all the files from a directory
            File[] fList = directory.listFiles();

            for (File file : fList) {


                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));
                //reportUtil.createExcel("src\\test\\resources\\Integration\\IntegrationResults.xls");


                //List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\470774\\Desktop\\Pradeep\\ELTO.txt"));

                ArrayList<String> al = new ArrayList<String>();
                for (String line : lines) {

                    List result1 = Arrays.asList(line.split("\\ "));
                    List result2 = Arrays.asList(line.split("\\,"));


                    String AddressList[] = Address.split(",");

                    /************ Header Validation *************/////////////////
                    if (line == lines.get(0)) {
                        String first = result1.get(0).toString().substring(0, 1);
                        String firstLength = Integer.toString(first.length());
                        String second = result1.get(0).toString().substring(1, 2);
                        String secondLength = Integer.toString(second.length());
                        String third = result1.get(0).toString().substring(2, 6);
                        String thirdLength = Integer.toString(third.length());
                        String fourth = result1.get(0).toString().substring(6, 7);
                        String fourthLength = Integer.toString(fourth.length());
                        String fifth = result1.get(0).toString().substring(7, 11);
                        String sixth = result1.get(0).toString().substring(11, 15);
                        String sixthLength = Integer.toString(sixth.length());
                        String seventh = result1.get(0).toString().substring(15, 24);
                        String eigth = result1.get(200).toString().substring(0, 8);
                        String ninth = result1.get(200).toString().substring(8, 12);
                        String ninthLength = Integer.toString(ninth.length());
                        String tenth = result1.get(200).toString().substring(12, 13);
                        String tenthLength = Integer.toString(tenth.length());

                       /* *//***Integrity Check****//*
                        stringCompare("Integration_Results", firstLength, ("1"));
                        stringCompare("Integration_Results", secondLength, ("1"));
                        stringCompare("Integration_Results", thirdLength, ("4"));
                        stringCompare("Integration_Results", fourthLength, ("1"));
                        stringCompare("Integration_Results", sixthLength, ("4"));
                        stringCompare("Integration_Results", ninthLength, ("4"));
                        stringCompare("Integration_Results", tenthLength, ("1"));
                        stringMatchCompare("Integration_Results", third, (regexMulDigits));
                        stringMatchCompare("Integration_Results", fourth, (regexSingleNonDigit));
                        stringMatchCompare("Integration_Results", fifth, (regexMulDigits));
                        stringMatchCompare("Integration_Results", fifth, ("^[\\d]{4}$"));
                        Assert.assertTrue(!fifth.isEmpty());
                        Assert.assertTrue(!sixth.isEmpty());
                        stringMatchCompare("Integration_Results", seventh, ("^[\\d]{9}$"));
                        stringMatchCompare("Integration_Results", eigth, ("^[\\d]{8}$"));
                        stringMatchCompare("Integration_Results", ninth, ("^[\\d]{4}$"));
*/

                        /*****Accuracy Check*****/
                        stringCompare("Integration_Results", "Record Type", first, ("H")); //Header Record Type
                        stringCompare("Integration_Results", "File Type", second, ("C")); //File Type
                        stringCompare("Integration_Results", "Version Number", third, ("0001"));//File Version Number

                        //Supplier Type
                        if (fourth.equals("I")) {
                            stringCompare("Integration_Results", "Supplier Type", fourth, ("I"));
                        } else {
                            stringCompare("Integration_Results", "Supplier Type", fourth, ("D"));
                        }

                        stringCompare("Integration_Results", "Sequence Number", seventh, ("000000001"));//File Sequence Number
                        stringCompare("Integration_Results", "System date", eigth, ("20170906"));//need to update system date
                        stringCompare("Integration_Results", "Version", ninth, ("1624"));//need to update system date_time
                        stringCompare("Integration_Results", "Value", tenth, ("#"));

                    } else if (line.equals(lines.get(lines.size() - 1))) {

                        String first = result1.get(0).toString().substring(0, 1);
                        String firstLength = Integer.toString(first.length());
                        String second = result1.get(0).toString().substring(1, 10);
                        String third = result1.get(0).toString().substring(10, 19);
                        String ThirdAftRemZeros = third.replaceFirst("^0*", "");
                        String fourth = result1.get(0).toString().substring(19, 20);

                        /***Integrity Check****/
/*
                        stringCompare("Integration_Results", firstLength, ("1"));
                        stringMatchCompare("Integration_Results", second, ("^[\\d]{9}$"));
                        stringMatchCompare("Integration_Results", third, ("^[\\d]{9}$"));
*/


                        /*****Accuracy Check*****/
                        stringCompare("Integration_Results", "Trailer Record Type", first, ("T")); // Trailer Record Type
                        stringCompare("Integration_Results", "Sequnce Number", second, ("000000001"));//File Sequence Number

                        String strLineSize = Integer.toString(lines.size());
                        stringCompare("Integration_Results", "Data Record", ThirdAftRemZeros, (strLineSize));//Data Record Count
                        stringCompare("Integration_Results", "value", fourth, ("#"));


                    } else {
                        String policyNumberfield = result1.get(0).toString().substring(34, 43);
                        if (policyNumberfield.contains(Policyno)) {

                            String first = result1.get(0).toString().substring(0, 1);
                            String firstLength = Integer.toString(first.length());
                            String second = result1.get(0).toString().substring(1, 10);
                            String third = result1.get(0).toString().substring(10, 14);
                            String fourth = result1.get(0).toString().substring(14, 18);
                            String fifth = result1.get(0).toString().substring(34, 43);
                            String sixth = result1.get(30).toString().substring(0, 1);
                            String seventh = result1.get(30).toString().substring(1, 2);
                            String eighth = result1.get(30).toString().substring(2);
                            String ninth = result1.get(275).toString().trim();
                            String tenth = result1.get(520).toString().substring(0, 8);
                            String eleventh = result1.get(520).toString().substring(8, 16);
                            String Address1 = result2.get(0).toString().substring(1141);
                            String Address2 = result2.get(1).toString();
                            String Address3[] = result2.get(2).toString().split("\\s\\s");

/*

                            */
/***Integrity Check****//*

                            stringCompare("Integration_Results", firstLength, ("1"));
                            stringCompare("Integration_Results", first, ("P")); // Record Type
                            stringMatchCompare("Integration_Results", second, ("^[\\d]{9}$"));
                            stringCompare("Integration_Results", second, ("000000001"));//File Sequence Number
                            stringMatchCompare("Integration_Results", third, ("^[\\d]{4}$"));
                            stringMatchCompare("Integration_Results", fourth, ("^[\\d]{4}$"));
                            stringMatchCompare("Integration_Results", fifth, ("^[\\d]{25}$"));
                            stringMatchCompare("Integration_Results", sixth, (regexSingleNonDigit));
                            stringCompare("Integration_Results", sixth, ("N"));//Dummy Policy Flag
                            stringMatchCompare("Integration_Results", seventh, (regexSingleNonDigit));
                            stringCompare("Integration_Results", seventh, ("P"));//Policy Type
                            stringMatchCompare("Integration_Results", tenth, ("^[\\d]{8}$"));
                            stringMatchCompare("Integration_Results", eleventh, ("^[\\d]{8}$"));
*/

                            /*****Accuracy Check*****/
                            stringCompare("Integration_Results", "Record Type", first, ("P")); // Record Type
                            stringCompare("Integration_Results", "Sequence Number", second, ("000000001"));//File Sequence Number
                            stringCompare("Integration_Results", "currentInsurerID", third, (currentInsurerID));//currentInsurerID
                            stringCompare("Integration_Results", "OriginalInsurerID", fourth, (OriginalInsurerID));//OriginalInsurerID
                            stringCompare("Integration_Results", "PolicyNumber", fifth, (Policyno));//Policyno
                            stringCompare("Integration_Results", "Dummy Policy Flag", sixth, ("N"));//Dummy Policy Flag
                            stringCompare("Integration_Results", "Policy Type", seventh, ("P"));//Policy Type
                            stringCompare("Integration_Results", "PolicyHoldername", eighth, (PolicyHoldername));//PolicyHoldername
                            stringCompare("Integration_Results", "EmployerName", ninth, (EmployerName));//EmployerName
                            stringMatchCompare("Integration_Results", "coverStartDate", tenth, (coverStartDate));//coverStartDate
                            stringMatchCompare("Integration_Results", "coverEndDate", eleventh, (coverEndDate));//coverEndDate
                            stringCompare("Integration_Results", "Address1 validation", Address1, (AddressList[0]));//Address1 validation
                            stringCompare("Integration_Results", "Address2 validation", Address2, (AddressList[1]));//Address2 validation
                            stringCompare("Integration_Results", "Address3 validation", Address3[0], (AddressList[2]));//Address3 validation

                            if (Address3[243].contains(YesNo)) {
                                if (Address3[243].equals(YesNo)) {
                                    stringCompare("Integration_Results", "ERN Number", Address3[243], ("1N123/A234"));

                                } else {
                                    stringCompare("Integration_Results", "ERN", Address3[243], ("1N"));
                                }
                            } else {
                                stringCompare("Integration_Results", "ERN", Address3[243], ("1Y"));
                            }
                            stringCompare("Integration_Results", "Value", Address3[253], ("#"));

                        }
                        //String fifth = result1.get(0).toString().substring(18, 43);
                        // stringCompare("Integration_Results", fifth, (Policyno));//Policyno
                        al.add(policyNumberfield);

                    }
                }

                int found = 0;
                int notfound = 0;

                for (String e : al) {
                    if (e.equals(Policyno)) {
                        found++;
                    } else {
                        notfound++;
                    }
                }
                if (found > 0) {
                } else {
                    stringCompare("Integration_Results", "Policyno", Policyno, "Not Found");//////BatchReference
                }


            }
        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();

            throw (e);
        }


    }


    public void DDI(String subSerialNo, String ownerIdNo, String sumNoHDR1, String sumNoHDR2, String TodaysDate, String TnxCode, String PayerSortCode, String PayerAccntNo, String OrigAccntName, String PayerAccntName, String ReferenceNo, String OriginatorSortCode, String OriginatorAccountNo
    ) throws Exception {

        try {

            File directory = new File("src\\test\\resources\\Integration\\DDI");
            //get all the files from a directory
            File[] fList = directory.listFiles();

            ArrayList<String> al1 = new ArrayList<String>();

            for (File file : fList) {


                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));
                //reportUtil.createExcel("src\\test\\resources\\Integration\\IntegrationResults.xls");


                String payerAccntNo = "";
                String payerAccntType = "";
                String tnxCode = "";
                String OrigSrtCode = "";
                String OrigAccntNo = "";
                String Zeroes = "";
                String OrigName = "";
                String Reference = "";
                String PayerName = "";
                String payerSortCode = "";
                String DateIntegrity = "";


                //List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\470774\\Desktop\\Pradeep\\DDI.txt"));
                int count1 = 0;
                for (String line : lines) {
                    List result1 = Arrays.asList(line.split("\\ "));


                    /************ Header Validation *************/////////////////

                    if (line == lines.get(0)) {
                        String vol = result1.get(0).toString().substring(0, 3); ///////Volume Identifier
                        String lblNo = result1.get(0).toString().substring(3, 4); ///////label number
                        String submSerialNo1 = result1.get(0).toString().substring(4, 5); ///////submission SerialNo1
                        String submSerialNo2 = result1.get(0).toString().substring(5, 10); ///////submission SerialNo2
                        String sumNo = result1.get(31).toString().substring(0, 6);  ///////sumNo
                        String sumNoLength = Integer.toString(sumNo.length());
                        String lblStdLvl = result1.get(63).toString();  //////label standard level

                        //Integrity Check***
                       /* stringMatchCompare("Integration_Results",vol,("^[A-Z]{3}$"));  //////////Volume Identifier
                        stringMatchCompare("Integration_Results",lblNo,(regexSingleDigit));//label number
                        stringCompare("Integration_Results",submSerialNo1,("I"));////submission SerialNo1
                        stringMatchCompare("Integration_Results",submSerialNo2,("^[\\d]{5}$"));////submission SerialNo2
                        stringCompare("Integration_Results",sumNoLength,("6")); //sumNo
                        stringMatchCompare("Integration_Results",lblStdLvl,("^[\\d]{1}$"));//sumNo*/


                        /*****Accuracy Check*****/
                        stringCompare("Integration_Results", "Volume Identifier", vol, ("VOL")); //Volume Identifier
                        stringCompare("Integration_Results", "label number", lblNo, ("1")); ///label number
                        stringCompare("Integration_Results", "submission SerialNo1", submSerialNo1, ("I"));////submission SerialNo1
                        stringCompare("Integration_Results", "submission SerialNo", submSerialNo2, (subSerialNo));////submission SerialNo2
                        stringCompare("Integration_Results", "sumNo", sumNo, (ownerIdNo));//sumNo
                        stringCompare("Integration_Results", "owner identification", lblStdLvl, ("1"));//owner identification


                    } else if (line == lines.get(1)) {    ////HDR1


                        String HDR = result1.get(0).toString().substring(0, 3); /////label identifier
                        String lblNo = result1.get(0).toString().substring(3, 4); ///////label number
                        String FileId = result1.get(0).toString().substring(4, 5); /////file identifier
                        String SumNo1 = result1.get(0).toString().substring(5, 11); /////SumNo
                        String S = result1.get(0).toString().substring(11, 12); /////S
                        String One = result1.get(2).toString().substring(0, 1); ////1
                        String SumNo2 = result1.get(2).toString().substring(1, 7); ////SumNo2
                        String setId1 = result1.get(2).toString().substring(7, 8); ////set identification
                        String setId2 = result1.get(2).toString().substring(8, 13); ////set identification
                        String fileSecNo = result1.get(2).toString().substring(13, 17); ////file section number
                        String fileSeqNo = result1.get(2).toString().substring(17, 21); ///file sequence number
                        String CreationDate = result1.get(9).toString().substring(0, 5); ////CreationDate
                        String ExpirationDate = result1.get(10).toString().substring(0, 5); ////ExpirationDate
                        String BlockCount = result1.get(11).toString().substring(0, 6); ////BlockCount


                      /*  *//***Integrity Check****//*
                        stringMatchCompare("Integration_Results",HDR,("^[A-Z]{3}$"));  ///////////label identifier
                        stringMatchCompare("Integration_Results",lblNo,(regexSingleDigit));//label number
                        stringMatchCompare("Integration_Results",FileId,(regexSingleNonDigit));////file identifier
                        stringMatchCompare("Integration_Results",SumNo1,("^[\\d]{6}$"));///////SumNo
                        stringMatchCompare("Integration_Results",S,(regexMulNonDigit));///////S
                        stringMatchCompare("Integration_Results",One,(regexSingleDigit));///////1
                        Assert.assertTrue(!SumNo2.isEmpty());///////SumNo2
                        stringMatchCompare("Integration_Results",setId1,(regexSingleNonDigit));/////set identification
                        stringMatchCompare("Integration_Results",setId2,("^[\\d]{5}$"));/////set identification
                        stringMatchCompare("Integration_Results",fileSecNo,("^[\\d]{4}$"));/////file section number
                        stringMatchCompare("Integration_Results",fileSeqNo,("^[\\d]{4}$"));//////file sequence number
                        stringMatchCompare("Integration_Results",CreationDate,("^[\\d]{5}$"));/////CreationDate
                        stringMatchCompare("Integration_Results",ExpirationDate,("^[\\d]{5}$"));/////ExpirationDate
                        stringMatchCompare("Integration_Results",BlockCount,("^[\\d]{6}$"));/////BlockCount*/


                        /*****Accuracy Check*****/
                        stringCompare("Integration_Results", "label identifier", HDR, ("HDR")); ////////////label identifier
                        stringCompare("Integration_Results", "label number", lblNo, ("1"));//label number
                        stringCompare("Integration_Results", "file identifier", FileId, ("A"));///file identifier
                        stringCompare("Integration_Results", "SumNo", SumNo1, (sumNoHDR1));///////SumNo
                        stringCompare("Integration_Results", "S", S, ("S"));///S
                        stringCompare("Integration_Results", "S", One, ("1"));///S
                        stringCompare("Integration_Results", "SumNo2", SumNo2, (sumNoHDR2));///////SumNo2
                        stringCompare("Integration_Results", "submission SerialNo", setId1, ("D"));////submission SerialNo
                        stringCompare("Integration_Results", "submission SerialNo", setId2, (subSerialNo));////submission SerialNo
                        stringCompare("Integration_Results", "file section number", fileSecNo, ("0001"));/////file section number
                        // stringCompare("Integration_Results","file sequence number",fileSeqNo,("0001"));//////file sequence number
                        stringCompare("Integration_Results", "CreationDate", CreationDate, (TodaysDate));/////CreationDate /////current date yyddd /need to put less than cond to UHL13
                        //Assert.assertThat(ExpirationDate, greaterThan(TodaysDate));/////ExpirationDate /////current date yyddd /need to put greater than  to UHL1
                        stringCompare("Integration_Results", "BlockCount", BlockCount, ("000000"));/////BlockCount
                    } else if (line == lines.get(2)) {    ////HDR2

                        String HDR = result1.get(0).toString().substring(0, 3); /////label identifier
                        String lblNo = result1.get(0).toString().substring(3, 4); ///////label number
                        String FileId = result1.get(0).toString().substring(4, 5); /////record format
                        String BlockLength = result1.get(0).toString().substring(5, 10); ////BlockLength
                        String RecordLength = result1.get(0).toString().substring(10, 15); ////recordLength
                        String bufferOffset = result1.get(35).toString().substring(0, 2); ////bufferOffset

                     /*   *//***Integrity Check****//*
                        stringMatchCompare("Integration_Results",HDR,("^[A-Z]{3}$"));  ///////////label identifier
                        stringMatchCompare("Integration_Results",lblNo,(regexSingleDigit));//label number
                        stringMatchCompare("Integration_Results",FileId,(regexSingleNonDigit));/////record format
                        stringMatchCompare("Integration_Results",BlockLength,("^[\\d]{5}$"));  //////record format
                        stringMatchCompare("Integration_Results",RecordLength,("^[\\d]{5}$"));  /////recordLength
                        stringMatchCompare("Integration_Results",bufferOffset,("^[\\d]{2}$"));  /////bufferOffset*/


                        /*****Accuracy Check*****/
                        stringCompare("Integration_Results", "label identifier", HDR, ("HDR")); ////////////label identifier
                        stringCompare("Integration_Results", "label number", lblNo, ("2"));//label number
                        stringCompare("Integration_Results", "record format", FileId, ("F"));/////record format
                        stringCompare("Integration_Results", "recordLength", RecordLength, ("00100"));////recordLength
                        stringCompare("Integration_Results", "bufferOffset", bufferOffset, ("00"));////bufferOffset


                    } else if (line == lines.get(3)) {    ////UHL1

                        String UHL1 = result1.get(0).toString().substring(0, 3); /////label identifier
                        String lblNo = result1.get(0).toString().substring(3, 4); ///////label number
                        String CurrDate = result1.get(1).toString().substring(0, 5); ///processing date
                        String RecPartyIDno = result1.get(1).toString().substring(5, 11); ///Receiving Party ID No
                        String currencyCode = result1.get(5).toString().substring(0, 2);//currencyCode
                        String countryCode = result1.get(5).toString().substring(2, 8);//countryCode
                        String workCode = result1.get(5).toString().substring(8, 9);//workCode
                        String workCode1 = result1.get(6).toString().substring(0, 5);//workCode1
                        String fileNumber = result1.get(8).toString().substring(0, 3);//fileNumber


                       /* *//***Integrity Check****//*
                        stringMatchCompare("Integration_Results",UHL1,("^[A-Z]{3}$"));  ///////////label identifier
                        stringMatchCompare("Integration_Results",lblNo,(regexSingleDigit));//label number
                        stringMatchCompare("Integration_Results",CurrDate,("^[\\d]{5}$"));////processing date
                        stringMatchCompare("Integration_Results",RecPartyIDno,("^[\\d]{6}$"));//////Receiving Party ID No
                        stringMatchCompare("Integration_Results",currencyCode,("^[0]{2}$"));//////currencyCode
                        stringMatchCompare("Integration_Results",countryCode,("^[0]{6}$"));////countryCode
                        stringMatchCompare("Integration_Results",workCode,(regexSingleDigit));///workCode
                        stringMatchCompare("Integration_Results",workCode1,("^[A-Z]{5}$"));///workCode1
                        stringMatchCompare("Integration_Results",fileNumber,("^[0]{3}$"));///fileNumber*/


                        /*****Accuracy Check*****/
                        stringCompare("Integration_Results", "label identifier", UHL1, ("UHL")); ////////////label identifier
                        stringCompare("Integration_Results", "label number", lblNo, ("1"));//label number
                        stringCompare("Integration_Results", "processing date", CurrDate, (TodaysDate));//processing date
                        stringCompare("Integration_Results", "Receiving Party ID No", RecPartyIDno, ("999999"));////Receiving Party ID No
                        stringCompare("Integration_Results", "currencyCode", currencyCode, ("00"));//////currencyCode
                        stringCompare("Integration_Results", "countryCode", countryCode, ("000000"));////countryCode
                        stringCompare("Integration_Results", "workCode", workCode, ("1"));///workCode
                        stringCompare("Integration_Results", "workCode1", workCode1, ("DAILY"));///workCode1
                        stringCompare("Integration_Results", "fileNumber", fileNumber, ("000"));////fileNumber


                    } else if (line.equals(lines.get(lines.size() - 3))) {  ////EOF1

                        String EOF = result1.get(0).toString().substring(0, 3); /////label identifier
                        String lblNo = result1.get(0).toString().substring(3, 4); ///////label number
                        String FileId = result1.get(0).toString().substring(4, 5); /////file identifier
                        String SumNo1 = result1.get(0).toString().substring(5, 11); /////SumNo
                        String S = result1.get(0).toString().substring(11, 12); /////S
                        String One = result1.get(2).toString().substring(0, 1); ////1
                        String SumNo2 = result1.get(2).toString().substring(1, 7); ////SumNo2
                        String setId1 = result1.get(2).toString().substring(7, 8); ////set identification
                        String setId2 = result1.get(2).toString().substring(8, 13); ////set identification
                        String fileSecNo = result1.get(2).toString().substring(13, 17); ////file section number
                        String fileSeqNo = result1.get(2).toString().substring(17, 21); ///file sequence number
                        String CreationDate = result1.get(9).toString().substring(0, 5); ////CreationDate
                        String ExpirationDate = result1.get(10).toString().substring(0, 5); ////ExpirationDate

                       /* *//***Integrity Check****//*
                        stringMatchCompare("Integration_Results","label identifier",EOF,("^[A-Z]{3}$"));  ///////////label identifier
                        stringMatchCompare("Integration_Results","label number",lblNo,(regexSingleDigit));//label number
                        stringMatchCompare("Integration_Results","file identifier",FileId,(regexSingleNonDigit));////file identifier
                        stringMatchCompare("Integration_Results",SumNo1,("^[\\d]{6}$"));///////SumNo
                        stringMatchCompare("Integration_Results",S,(regexMulNonDigit));///////S
                        stringMatchCompare("Integration_Results",One,(regexSingleDigit));///////1
                        Assert.assertTrue(!SumNo2.isEmpty());///////SumNo2
                        stringMatchCompare("Integration_Results",setId1,(regexSingleNonDigit));/////set identification
                        stringMatchCompare("Integration_Results",setId2,("^[\\d]{5}$"));/////set identification
                        stringMatchCompare("Integration_Results",fileSecNo,("^[\\d]{4}$"));/////file section number
                        stringMatchCompare("Integration_Results",fileSeqNo,("^[\\d]{4}$"));//////file sequence number
                        stringMatchCompare("Integration_Results",CreationDate,("^[\\d]{5}$"));/////CreationDate
                        stringMatchCompare("Integration_Results",ExpirationDate,("^[\\d]{5}$"));/////ExpirationDate*/


                        //*****Accuracy Check*****//
                        stringCompare("Integration_Results", "label identifier", EOF, ("EOF")); ////////////label identifier
                        stringCompare("Integration_Results", "label number", lblNo, ("1"));//label number
                        stringCompare("Integration_Results", "file identifier", FileId, ("A"));///file identifier
                        stringCompare("Integration_Results", "SumNo", SumNo1, (sumNoHDR1));///////SumNo
                        stringCompare("Integration_Results", "S", S, ("S"));///S
                        stringCompare("Integration_Results", "Number", One, ("1"));///1
                        stringCompare("Integration_Results", "SumNo2", SumNo2, (sumNoHDR2));///////SumNo2
                        stringCompare("Integration_Results", "submission SerialNo", setId1, ("D"));////submission SerialNo
                        stringCompare("Integration_Results", "submission SerialNo", setId2, (subSerialNo));////submission SerialNo
                        stringCompare("Integration_Results", "file section number", fileSecNo, ("0001"));/////file section number
                        stringCompare("Integration_Results", "file sequence number", fileSeqNo, ("0001"));//////file sequence number
                        stringCompare("Integration_Results", "CreationDate", CreationDate, (TodaysDate));/////CreationDate /////current date yyddd /need to put less than cond to UHL13
                        //Assert.assertThat(ExpirationDate, greaterThan(TodaysDate));/////ExpirationDate /////current date yyddd /need to put greater than  to UHL1
                        //Assert.assertThat( Long.parseLong(ExpirationDate), greaterThan(Long.parseLong(CreationDate)));


                    } else if (line.equals(lines.get(lines.size() - 2))) {  //EOF2
                        String EOF = result1.get(0).toString().substring(0, 3); /////label identifier
                        String lblNo = result1.get(0).toString().substring(3, 4); ///////label number
                        String FileId = result1.get(0).toString().substring(4, 5); /////record format
                        String BlockLength = result1.get(0).toString().substring(5, 10); ////BlockLength
                        String RecordLength = result1.get(0).toString().substring(10, 15); ////recordLength
                        String bufferOffset = result1.get(35).toString().substring(0, 2); ////bufferOffset

                      /*  *//***Integrity Check****//*
                        stringMatchCompare("Integration_Results",EOF,("^[A-Z]{3}$"));  ///////////label identifier
                        stringMatchCompare("Integration_Results",lblNo,(regexSingleDigit));//label number
                        stringMatchCompare("Integration_Results",FileId,(regexSingleNonDigit));/////record format
                        stringMatchCompare("Integration_Results",BlockLength,("^[\\d]{5}$"));  //////record format
                        stringMatchCompare("Integration_Results",RecordLength,("^[\\d]{5}$"));  /////recordLength
                        stringMatchCompare("Integration_Results",bufferOffset,("^[\\d]{2}$"));  /////bufferOffset*/

                        /*****Accuracy Check*****/
                        stringCompare("Integration_Results", "label identifier", EOF, ("EOF")); ////////////label identifier
                        stringCompare("Integration_Results", "label number", lblNo, ("2"));//label number
                        stringCompare("Integration_Results", "record format", FileId, ("F"));/////record format
                        stringCompare("Integration_Results", "recordLength", RecordLength, ("00100"));////recordLength
                        stringCompare("Integration_Results", "bufferOffset", bufferOffset, ("00"));////bufferOffset


                    } else if (line.equals(lines.get(lines.size() - 1))) {   //UTL

                        String UTL = result1.get(0).toString().substring(0, 3); /////label identifier
                        String lblNo = result1.get(0).toString().substring(3, 4); ///////label number
                        String ZeroFilled = result1.get(0).toString().substring(4, 44); ///ZeroFilled
                        String DDICount = result1.get(8).toString().substring(0, 7); ///DDICount
                        String DDICountAftRemZeros = DDICount.replaceFirst("^0*", "");


                  /*      *//***Integrity Check****//*
                        stringMatchCompare("Integration_Results",UTL,("^[A-Z]{3}$"));  ///////////label identifier
                        stringMatchCompare("Integration_Results",lblNo,(regexSingleDigit));//label number
                        stringMatchCompare("Integration_Results",ZeroFilled,("^[0]{40}$"));///ZeroFilled
                        stringMatchCompare("Integration_Results",DDICount,("^[\\d]{7}$"));///DDICount*/


                        /*****Accuracy Check*****/
                        stringCompare("Integration_Results", "label identifier", UTL, ("UTL")); ////////////label identifier
                        stringCompare("Integration_Results", "label number", lblNo, ("1"));//label number
                        stringCompare("Integration_Results", "ZeroFilled", ZeroFilled, ("0000000000000000000000000000000000000000"));////ZeroFilled


                        int DDIRows = lines.size() - 7;
                        String StrDDIRows = Integer.toString(DDIRows);
                        //Assert.assertTrue(DDICountAftRemZeros.equals(StrDDIRows));//DDICount

                    } else {
                        String[] result2 = line.split("\\s\\s");
                        if (result1.get(0).toString().matches("^[\\d]{13}$")) {
                            payerSortCode = result1.get(0).toString().substring(0, 6);///////payer's sorting code
                            payerAccntNo = result1.get(0).toString().substring(6, 13);/////payer's a/c number
                            payerAccntType = result1.get(1).toString().substring(0, 1);/////payer's account type
                            tnxCode = result1.get(1).toString().substring(1, 3);///transaction code
                            OrigSrtCode = result1.get(1).toString().substring(3, 9);///originating sorting code
                            OrigAccntNo = result1.get(1).toString().substring(9);///originating account code
                            Zeroes = result2[2].substring(0, 11);///Amount
                            OrigName = result2[2].substring(11, 29);///ORIGINATOR_ACCOUNT_NAME
                            Reference = result2[2].substring(29, 38);/////REFERENCE
                            PayerName = result2[6].substring(0);/////PAYER_OR_DEST_ACCOUNT_NAME
                            int arSize = result1.size() - 1;
                            DateIntegrity = result1.get(arSize).toString();///DateIntegrity

                        } else if (result1.get(0).toString().matches("^[\\d]{12}$")) {
                            payerSortCode = result1.get(0).toString().substring(0, 6);///////payer's sorting code
                            payerAccntNo = result1.get(0).toString().substring(6, 12);/////payer's a/c number
                            payerAccntType = result1.get(2).toString().substring(0, 1);/////payer's account type
                            tnxCode = result1.get(2).toString().substring(1, 3);///transaction code
                            OrigSrtCode = result1.get(2).toString().substring(3, 9);///originating sorting code
                            OrigAccntNo = result1.get(2).toString().substring(9);///originating account code
                            Zeroes = result2[3].substring(0, 11);///Amount
                            OrigName = result2[3].substring(11, 29);///ORIGINATOR_ACCOUNT_NAME
                            Reference = result2[3].substring(29, 38);/////REFERENCE
                            PayerName = result2[7].substring(0);/////PAYER_OR_DEST_ACCOUNT_NAME
                            int arSize = result1.size() - 1;
                            DateIntegrity = result1.get(arSize).toString();///DateIntegrity
                        } else {
                            payerSortCode = result1.get(0).toString().substring(0, 6);///////payer's sorting code
                            payerAccntNo = result1.get(0).toString().substring(6, 14);/////payer's a/c number
                            payerAccntType = result1.get(0).toString().substring(14, 15);/////payer's account type
                            tnxCode = result1.get(0).toString().substring(15, 17);///transaction code
                            OrigSrtCode = result1.get(0).toString().substring(17, 23);///originating sorting code
                            OrigAccntNo = result1.get(0).toString().substring(23, 31);///originating account code
                            Zeroes = result2[2].substring(0, 11);///zeroes
                            OrigName = result2[2].substring(11, 29);///ORIGINATOR_ACCOUNT_NAME
                            Reference = result2[2].substring(29, 38);/////REFERENCE
                            PayerName = result2[6].substring(0);/////PAYER_OR_DEST_ACCOUNT_NAME
                            int arSize = result1.size() - 1;
                            DateIntegrity = result1.get(arSize).toString();///DateIntegrity
                        }

                    /*    *//***Integrity Check****//*
                        stringMatchCompare("Integration_Results",payerSortCode,("^[\\d]{6}$"));//////payer's sorting code
                        stringMatchCompare("Integration_Results",payerAccntNo,("^[\\d]{6,8}$"));//////payer's sorting code
                        stringMatchCompare("Integration_Results",payerAccntType,(regexSingleDigit));//////payer's account type
                        stringMatchCompare("Integration_Results",payerAccntType,("0")); ////////payer's account type
                        Assert.assertTrue(!tnxCode.isEmpty());/////transaction code
                        stringMatchCompare("Integration_Results",OrigSrtCode,("^[\\d]{6}$"));////originating sorting code
                        stringMatchCompare("Integration_Results",OrigAccntNo,("^[\\d]{8}$"));//////originating account code
                        stringMatchCompare("Integration_Results",Zeroes,("^[0]{11}$"));////zeroes
                        stringMatchCompare("Integration_Results",Zeroes,("00000000000")); //////zeroes
                        stringMatchCompare("Integration_Results",OrigName,(regexMulNonDigit));////ORIGINATOR_ACCOUNT_NAME
                        stringMatchCompare("Integration_Results",Reference,("^[\\d]{9}$"));//////REFERENCE
                        stringMatchCompare("Integration_Results",PayerName,("^(?=.*[a-zA-Z\\d\\s].*)[a-zA-Z\\d\\s]{1,}$"));/////PAYER_OR_DEST_ACCOUNT_NAME
                        stringMatchCompare("Integration_Results",DateIntegrity,("^[\\d]{5}$"));////DateIntegrity*/

                        if (line.contains(ReferenceNo)) {
                            /*****Accuracy Check*****/
                            stringCompare("Integration_Results", "payer's sorting code", payerSortCode, (OriginatorSortCode)); /////////payer's sorting code
                            stringCompare("Integration_Results", "payer's a/c number", payerAccntNo, (OriginatorAccountNo)); ///////payer's a/c number
                            stringCompare("Integration_Results", "payer's account type", payerAccntType, ("0")); ////////payer's account type
                            stringCompare("Integration_Results", "transaction code", tnxCode, (TnxCode)); ////transaction code
                            stringCompare("Integration_Results", "originating sorting code", OrigSrtCode, (PayerSortCode)); ///PayerSortCode
                            stringCompare("Integration_Results", "originating account code", OrigAccntNo, (PayerAccntNo)); /////PayerAccntNo
                            stringCompare("Integration_Results", "Zeroes", Zeroes, ("00000000000")); //////zeroes
                            stringCompare("Integration_Results", "ORIGINATOR_ACCOUNT_NAME", OrigName, (OrigAccntName)); ////ORIGINATOR_ACCOUNT_NAME
                            stringCompare("Integration_Results", "REFERENCE", Reference, (ReferenceNo)); /////REFERENCE
                            stringCompare("Integration_Results", "/PAYER_OR_DEST_ACCOUNT_NAME", PayerName.trim(), (PayerAccntName)); /////PAYER_OR_DEST_ACCOUNT_NAME
                            count1++;
                        }
                        al1.add(Reference);

                    }
                }
                int found = 0;
                int notfound = 0;

                for (String e : al1) {
                    if (e.equals(ReferenceNo)) {
                        found++;
                    } else {
                        notfound++;
                    }
                }
                if (found > 0) {
                } else {
                    stringCompare("Integration_Results", "ReferenceNo", ReferenceNo, "Not Found");//////BatchReference
                }
            }
        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();

            throw (e);
        }
    }


    public void DDC(String subSerialNo, String ownerIdNo, String sumNoHDR1, String sumNoHDR2, String TodaysDate, String ReferenceNo, String PayerSortCode, String PayerAccntNo, String TnxCode, String OrigSortCode, String OrigAccountNo,
                    String OrigAccntName, String PayerAccntName, String Amount, String Narrative, String PayerAccntNameContra, String ContraDestSortCode, String ContraOrigSortCode, String ContraDestAccntNo, String ContraOrigAccntNo, String ContraTnxCode, String ContraAmount) throws Exception {

        try {
            File directory = new File("src\\test\\resources\\Integration\\DDC");
            //get all the files from a directory
            File[] fList = directory.listFiles();

            for (File file : fList) {


                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));
                //reportUtil.createExcel("src\\test\\resources\\Integration\\IntegrationResults.xls");

                int Sum1 = 0;
                int Sum2 = 0;
                String payerAccntNo = "";
                String payerAccntType = "";
                String tnxCode = "";
                String OrigSrtCode = "";
                String OrigAccntNo = "";
                String Amountt = "";
                String OrigName = "";
                String Reference = "";
                String PayerName = "";
                String payerSortCode = "";

                String NinetyNineTnxCode = "";
                String ZeroOneTnxCode = "";
                int Count1 = 0;
                int Count2 = 0;
                int CountC1 = 0;
                int CountC2 = 0;


                // List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\470774\\Desktop\\Pradeep\\DDC.txt"));
                ArrayList<String> al = new ArrayList<String>();
                int Countt = 0;

                for (String line : lines) {

                    List result1 = Arrays.asList(line.split("\\ "));

                    /************ Header Validation *************/
                    if (line == lines.get(0)) {

                        String vol = result1.get(0).toString().substring(0, 3); ///////Volume Identifier
                        String lblNo = result1.get(0).toString().substring(3, 4); ///////label number
                        String submSerialNo1 = result1.get(0).toString().substring(4, 5); ///////submission SerialNo1
                        String submSerialNo2 = result1.get(0).toString().substring(5, 10); ///////submission SerialNo2
                        String sumNo = result1.get(31).toString().substring(0, 6);  ///////sumNo
                        String sumNoLength = Integer.toString(sumNo.length());
                        String lblStdLvl = result1.get(63).toString();  //////label standard level


                       /* *//***Integrity Check****//*
                        stringMatchCompare("Integration_Results",vol,("^[A-Z]{3}$"));  //////////Volume Identifier
                        stringMatchCompare("Integration_Results",lblNo,(regexSingleDigit));//label number
                        stringMatchCompare("Integration_Results",submSerialNo1,(regexSingleNonDigit));////submission SerialNo1
                        stringMatchCompare("Integration_Results",submSerialNo2,("^[\\d]{5}$"));////submission SerialNo2
                        stringCompare("Integration_Results",sumNoLength,("6")); //sumNo
                        stringMatchCompare("Integration_Results",lblStdLvl,("^[\\d]{1}$"));//lblStdLvl*/


                        /*****Accuracy Check*****/
                        stringCompare("Integration_Results", "Volume Identifier", vol, ("VOL")); //Volume Identifier
                        stringCompare("Integration_Results", "label number", lblNo, ("1")); ///label number
                        stringCompare("Integration_Results", "submission SerialNo1", submSerialNo1, ("P"));////submission SerialNo1
                        stringCompare("Integration_Results", "submission SerialNo2", submSerialNo2, (subSerialNo));////submission SerialNo2
                        stringCompare("Integration_Results", "sumNo", sumNo, (ownerIdNo));//sumNo
                        stringCompare("Integration_Results", "owner identification", lblStdLvl, ("1"));//owner identification


                    } else if (line == lines.get(1)) {    ////HDR1

                        String HDR = result1.get(0).toString().substring(0, 3); /////label identifier
                        String lblNo = result1.get(0).toString().substring(3, 4); ///////label number
                        String FileId = result1.get(0).toString().substring(4, 5); /////file identifier
                        String SumNo1 = result1.get(0).toString().substring(5, 11); /////SumNo
                        String S = result1.get(0).toString().substring(11, 12); /////S
                        String One = result1.get(2).toString().substring(0, 1); ////1
                        String SumNo2 = result1.get(2).toString().substring(1, 7); ////SumNo2
                        String setId1 = result1.get(2).toString().substring(7, 8); ////set identification
                        String setId2 = result1.get(2).toString().substring(8, 13); ////set identification
                        String fileSecNo = result1.get(2).toString().substring(13, 17); ////file section number
                        String fileSeqNo = result1.get(2).toString().substring(17, 21); ///file sequence number
                        String CreationDate = result1.get(9).toString().substring(0, 5); ////CreationDate
                        String ExpirationDate = result1.get(10).toString().substring(0, 5); ////ExpirationDate
                        String BlockCount = result1.get(11).toString().substring(0, 6); ////BlockCount

                      /*  *//***Integrity Check****//*
                        stringMatchCompare("Integration_Results",HDR,("^[A-Z]{3}$"));  ///////////label identifier
                        stringMatchCompare("Integration_Results",lblNo,(regexSingleDigit));//label number
                        stringMatchCompare("Integration_Results",FileId,(regexSingleNonDigit));////file identifier
                        stringMatchCompare("Integration_Results",SumNo1,("^[\\d]{6}$"));///////SumNo
                        stringMatchCompare("Integration_Results",S,(regexMulNonDigit));///////S
                        stringMatchCompare("Integration_Results",One,(regexSingleDigit));///////1
                        Assert.assertTrue(!SumNo2.isEmpty());///////SumNo2
                        stringMatchCompare("Integration_Results",setId1,(regexSingleNonDigit));/////set identification
                        stringMatchCompare("Integration_Results",setId2,("^[\\d]{5}$"));/////set identification
                        stringMatchCompare("Integration_Results",fileSecNo,("^[\\d]{4}$"));/////file section number
                        stringMatchCompare("Integration_Results",fileSeqNo,("^[\\d]{4}$"));//////file sequence number
                        stringMatchCompare("Integration_Results",CreationDate,("^[\\d]{5}$"));/////CreationDate
                        stringMatchCompare("Integration_Results",ExpirationDate,("^[\\d]{5}$"));/////ExpirationDate
                        stringMatchCompare("Integration_Results",BlockCount,("^[\\d]{6}$"));/////BlockCount
*/

                        /*****Accuracy Check*****/
                        stringCompare("Integration_Results", "label identifier", HDR, ("HDR")); ////////////label identifier
                        stringCompare("Integration_Results", "label number", lblNo, ("1"));//label number
                        stringCompare("Integration_Results", "file identifier", FileId, ("A"));///file identifier
                        stringCompare("Integration_Results", "SumNo", SumNo1, (sumNoHDR1));///////SumNo
                        stringCompare("Integration_Results", "S", S, ("S"));///S
                        stringCompare("Integration_Results", "1", One, ("1"));///1
                        stringCompare("Integration_Results", "SumNo2", SumNo2, (sumNoHDR2));///////SumNo2
                        stringCompare("Integration_Results", "submission SerialNo", setId1, ("D"));////submission SerialNo
                        stringCompare("Integration_Results", "submission SerialNo", setId2, (subSerialNo));////submission SerialNo
                        stringCompare("Integration_Results", "file section number", fileSecNo, ("0001"));/////file section number
                        stringCompare("Integration_Results", "file sequence number", fileSeqNo, ("0001"));//////file sequence number
                        stringCompare("Integration_Results", "CreationDate", CreationDate, (TodaysDate));/////CreationDate /////current date yyddd /need to put less than cond to UHL13
                        //Assert.assertThat(ExpirationDate, greaterThan(TodaysDate));/////ExpirationDate /////current date yyddd /need to put greater than  to UHL1
                        //Assert.assertThat( Long.parseLong(ExpirationDate), greaterThan(Long.parseLong(CreationDate)));
                        stringCompare("Integration_Results", "BlockCount", BlockCount, ("000000"));/////BlockCount


                    } else if (line == lines.get(2)) {    ////HDR2

                        String HDR = result1.get(0).toString().substring(0, 3); /////label identifier
                        String lblNo = result1.get(0).toString().substring(3, 4); ///////label number
                        String FileId = result1.get(0).toString().substring(4, 5); /////record format
                        String BlockLength = result1.get(0).toString().substring(5, 10); ////BlockLength
                        String RecordLength = result1.get(0).toString().substring(10, 15); ////recordLength
                        String bufferOffset = result1.get(35).toString().substring(0, 2); ////bufferOffset

/*
                        *//***Integrity Check****//*
                        stringMatchCompare("Integration_Results",HDR,("^[A-Z]{3}$"));  ///////////label identifier
                        stringMatchCompare("Integration_Results",lblNo,(regexSingleDigit));//label number
                        stringMatchCompare("Integration_Results",FileId,(regexSingleNonDigit));/////record format
                        stringMatchCompare("Integration_Results",BlockLength,("^[\\d]{5}$"));  //////record format
                        stringMatchCompare("Integration_Results",RecordLength,("^[\\d]{5}$"));  /////recordLength
                        stringMatchCompare("Integration_Results",bufferOffset,("^[\\d]{2}$"));  /////bufferOffset*/


                        /*****Accuracy Check*****/
                        stringCompare("Integration_Results", "label identifier", HDR, ("HDR")); ////////////label identifier
                        stringCompare("Integration_Results", "label number", lblNo, ("2"));//label number
                        stringCompare("Integration_Results", "record format", FileId, ("F"));/////record format
                        stringCompare("Integration_Results", "recordLength", RecordLength, ("00100"));////recordLength
                        stringCompare("Integration_Results", "recordLength", bufferOffset, ("00"));////recordLength


                    } else if (line == lines.get(3)) {    ////UHL1

                        String UHL1 = result1.get(0).toString().substring(0, 3); /////label identifier
                        String lblNo = result1.get(0).toString().substring(3, 4); ///////label number
                        String CurrDate = result1.get(1).toString().substring(0, 5); ///processing date
                        String RecPartyIDno = result1.get(1).toString().substring(5, 11); ///Receiving Party ID No
                        String currencyCode = result1.get(5).toString().substring(0, 2);//currencyCode
                        String countryCode = result1.get(5).toString().substring(2, 8);//countryCode
                        String workCode = result1.get(5).toString().substring(8, 9);//workCode
                        String workCode1 = result1.get(6).toString().substring(0, 5);//workCode1
                        String fileNumber = result1.get(8).toString().substring(0, 3);//fileNumber
/*
                       // **Integrity Check***
                        stringMatchCompare("Integration_Results",UHL1,("^[A-Z]{3}$"));  ///////////label identifier
                        stringMatchCompare("Integration_Results",lblNo,(regexSingleDigit));//label number
                        stringMatchCompare("Integration_Results",CurrDate,("^[\\d]{5}$"));////processing date
                        stringMatchCompare("Integration_Results",RecPartyIDno,("^[\\d]{6}$"));//////Receiving Party ID No
                        stringMatchCompare("Integration_Results",currencyCode,("^[0]{2}$"));//////currencyCode
                        stringMatchCompare("Integration_Results",countryCode,("^[0]{6}$"));////countryCode
                        stringMatchCompare("Integration_Results",workCode,(regexSingleDigit));///workCode
                        stringMatchCompare("Integration_Results",workCode1,("^[A-Z]{5}$"));///workCode1
                        stringMatchCompare("Integration_Results",fileNumber,("^[0]{3}$"));///fileNumber*/


                        /*****Accuracy Check*****/
                        stringCompare("Integration_Results", "label identifier", UHL1, ("UHL")); ////////////label identifier
                        stringCompare("Integration_Results", "label number", lblNo, ("1"));//label number
                        stringCompare("Integration_Results", "processing date", CurrDate, (TodaysDate));//processing date
                        stringCompare("Integration_Results", "Receiving Party ID No", RecPartyIDno, ("999999"));////Receiving Party ID No
                        stringCompare("Integration_Results", "currencyCode", currencyCode, ("00"));//////currencyCode
                        stringCompare("Integration_Results", "countryCode", countryCode, ("000000"));////countryCode
                        stringCompare("Integration_Results", "workCode", workCode, ("1"));///workCode
                        stringCompare("Integration_Results", "workCode1", workCode1, ("DAILY"));///workCode1
                        stringCompare("Integration_Results", "fileNumber", fileNumber, ("000"));////fileNumber


                    } else if (line.equals(lines.get(lines.size() - 3))) {  ////EOF1

                        String EOF = result1.get(0).toString().substring(0, 3); /////label identifier
                        String lblNo = result1.get(0).toString().substring(3, 4); ///////label number
                        String FileId = result1.get(0).toString().substring(4, 5); /////file identifier
                        String SumNo1 = result1.get(0).toString().substring(5, 11); /////SumNo
                        String S = result1.get(0).toString().substring(11, 12); /////S
                        String One = result1.get(2).toString().substring(0, 1); ////1
                        String SumNo2 = result1.get(2).toString().substring(1, 7); ////SumNo2
                        String setId1 = result1.get(2).toString().substring(7, 8); ////set identification
                        String setId2 = result1.get(2).toString().substring(8, 13); ////set identification
                        String fileSecNo = result1.get(2).toString().substring(13, 17); ////file section number
                        String fileSeqNo = result1.get(2).toString().substring(17, 21); ///file sequence number
                        String CreationDate = result1.get(9).toString().substring(0, 5); ////CreationDate
                        String ExpirationDate = result1.get(10).toString().substring(0, 5); ////ExpirationDate

/*
                        *//***Integrity Check****//*
                        stringMatchCompare("Integration_Results",EOF,("^[A-Z]{3}$"));  ///////////label identifier
                        stringMatchCompare("Integration_Results",lblNo,(regexSingleDigit));//label number
                        stringMatchCompare("Integration_Results",FileId,(regexSingleNonDigit));////file identifier
                        stringMatchCompare("Integration_Results",SumNo1,("^[\\d]{6}$"));///////SumNo
                        stringMatchCompare("Integration_Results",S,(regexMulNonDigit));///////S
                        stringMatchCompare("Integration_Results",One,(regexSingleDigit));///////1
                        Assert.assertTrue(!SumNo2.isEmpty());///////SumNo2
                        stringMatchCompare("Integration_Results",setId1,(regexSingleNonDigit));/////set identification
                        stringMatchCompare("Integration_Results",setId2,("^[\\d]{5}$"));/////set identification
                        stringMatchCompare("Integration_Results",fileSecNo,("^[\\d]{4}$"));/////file section number
                        stringMatchCompare("Integration_Results",fileSeqNo,("^[\\d]{4}$"));//////file sequence number
                        stringMatchCompare("Integration_Results",CreationDate,("^[\\d]{5}$"));/////CreationDate
                        stringMatchCompare("Integration_Results",ExpirationDate,("^[\\d]{5}$"));/////ExpirationDate*/


                        /*****Accuracy Check*****/
                        stringCompare("Integration_Results", "label identifier", EOF, ("EOF")); ////////////label identifier
                        stringCompare("Integration_Results", "label number", lblNo, ("1"));//label number
                        stringCompare("Integration_Results", "file identifier", FileId, ("A"));///file identifier
                        stringCompare("Integration_Results", "SumNo", SumNo1, (sumNoHDR1));///////SumNo
                        stringCompare("Integration_Results", "S", S, ("S"));///S
                        stringCompare("Integration_Results", "1", One, ("1"));///1
                        stringCompare("Integration_Results", "SumNo2", SumNo2, (sumNoHDR2));///////SumNo2
                        stringCompare("Integration_Results", "submission SerialNo", setId1, ("D"));////submission SerialNo
                        stringCompare("Integration_Results", "submission SerialNo", setId2, (subSerialNo));////submission SerialNo
                        stringCompare("Integration_Results", "file section number", fileSecNo, ("0001"));/////file section number
                        stringCompare("Integration_Results", "file sequence number", fileSeqNo, ("0001"));//////file sequence number
                        stringCompare("Integration_Results", "CreationDate", CreationDate, (TodaysDate));/////CreationDate /////current date yyddd /need to put less than cond to UHL13
                        //Assert.assertThat(ExpirationDate, greaterThan(TodaysDate));/////ExpirationDate /////current date yyddd /need to put greater than  to UHL1


                    } else if (line.equals(lines.get(lines.size() - 2))) {  //EOF2
                        String EOF = result1.get(0).toString().substring(0, 3); /////label identifier
                        String lblNo = result1.get(0).toString().substring(3, 4); ///////label number
                        String FileId = result1.get(0).toString().substring(4, 5); /////record format
                        String BlockLength = result1.get(0).toString().substring(5, 10); ////BlockLength
                        String RecordLength = result1.get(0).toString().substring(10, 15); ////recordLength
                        String bufferOffset = result1.get(35).toString().substring(0, 2); ////bufferOffset

/*

                        */
/***Integrity Check****//*

                        stringMatchCompare("Integration_Results",EOF,("^[A-Z]{3}$"));  ///////////label identifier
                        stringMatchCompare("Integration_Results",lblNo,(regexSingleDigit));//label number
                        stringMatchCompare("Integration_Results",FileId,(regexSingleNonDigit));/////record format
                        stringMatchCompare("Integration_Results",BlockLength,("^[\\d]{5}$"));  //////record format
                        stringMatchCompare("Integration_Results",RecordLength,("^[\\d]{5}$"));  /////recordLength
                        stringMatchCompare("Integration_Results",bufferOffset,("^[\\d]{2}$"));  /////bufferOffset

*/

                        /*****Accuracy Check*****/
                        stringCompare("Integration_Results", "label identifier", EOF, ("EOF")); ////////////label identifier
                        stringCompare("Integration_Results", "label number", lblNo, ("2"));//label number
                        stringCompare("Integration_Results", "record format", FileId, ("F"));/////record format
                        stringCompare("Integration_Results", "recordLength", RecordLength, ("00100"));////recordLength
                        stringCompare("Integration_Results", "bufferOffset", bufferOffset, ("00"));////bufferOffset


                    } else if (line.equals(lines.get(lines.size() - 1))) {   //UTL


                        String UTL = result1.get(0).toString().substring(0, 3); /////label identifier
                        String lblNo = result1.get(0).toString().substring(3, 4); ///////label number
                        String ZeroFilled1 = result1.get(0).toString().substring(4, 17); ///ZeroFilled1
                        String ZeroFilled2 = result1.get(0).toString().substring(17, 30); ///ZeroFilled2
                        String Digits = result1.get(0).toString().substring(4, 44); ///ZeroFilled
                        String CountUTL1 = result1.get(0).toString().substring(30, 37); ///CountUTL1
                        String CountUTL2 = result1.get(0).toString().substring(37, 44); ///CountUTL2
                        String DDICount = result1.get(8).toString().substring(0, 7); ///DDICount



                     /*   *//***Integrity Check****//*
                        stringMatchCompare("Integration_Results",UTL,("^[A-Z]{3}$"));  ///////////label identifier
                        stringMatchCompare("Integration_Results",lblNo,(regexSingleDigit));//label number
                        stringMatchCompare("Integration_Results",ZeroFilled1,("^[\\d]{13}$"));///ZeroFilled1
                        stringMatchCompare("Integration_Results",ZeroFilled2,("^[\\d]{13}$"));///ZeroFilled2
                        stringMatchCompare("Integration_Results",Digits,("^[\\d]{40}$"));///ZeroFilled
                        stringMatchCompare("Integration_Results",DDICount,("^[0]{7}$"));///DDICount
                        stringMatchCompare("Integration_Results",CountUTL1,("^[\\d]{7}$"));///CountUTL1
                        stringMatchCompare("Integration_Results",CountUTL2,("^[\\d]{7}$"));///CountUTL2*/


                        /*****Accuracy Check*****/
                        stringCompare("Integration_Results", "label identifier", UTL, ("UTL")); ////////////label identifier
                        stringCompare("Integration_Results", "label number", lblNo, ("1"));//label number


                        /*****Validation****/
                        String ZerofilledReplace1 = ZeroFilled1.replaceFirst("^0*", "");
                        String ZerofilledReplace2 = ZeroFilled1.replaceFirst("^0*", "");
                        String CountUTL1Replace1 = CountUTL1.replaceFirst("^0*", "");
                        String CountUTL2Replace2 = CountUTL2.replaceFirst("^0*", "");

                        int A = 0, B = 0, TotalAmountContra = 0;
                        if (!NinetyNineTnxCode.isEmpty()) {
                            A = Integer.parseInt(NinetyNineTnxCode);
                        }
                        if (!ZeroOneTnxCode.isEmpty()) {
                            B = Integer.parseInt(ZeroOneTnxCode);
                        }

                        if (!NinetyNineTnxCode.isEmpty() && !ZeroOneTnxCode.isEmpty()) {
                            TotalAmountContra = A + B;
                            String strTotalAmountContra = Integer.toString(TotalAmountContra);

                            //Assert.assertTrue(ZerofilledReplace1.equals(strTotalAmountContra));////////ZeroFilled1
                            //Assert.assertTrue(ZerofilledReplace2.equals(strTotalAmountContra));///ZeroFilled2

                        } else if (NinetyNineTnxCode.isEmpty()) {
                            String strTotalAmountContra = Integer.toString(B);

                            //Assert.assertTrue(ZerofilledReplace1.equals(strTotalAmountContra));////////ZeroFilled1
                            //Assert.assertTrue(ZerofilledReplace2.equals(strTotalAmountContra));///ZeroFilled2

                        } else if (ZeroOneTnxCode.isEmpty()) {
                            String strTotalAmountContra = Integer.toString(A);

                            //Assert.assertTrue(ZerofilledReplace1.equals(strTotalAmountContra));////////ZeroFilled1
                            //Assert.assertTrue(ZerofilledReplace2.equals(strTotalAmountContra));///ZeroFilled2
                        }
                        int TotalCountC1 = Count1 + CountC1;
                        int TotalCountC2 = Count2 + CountC2;

                        String strTotalCountC1 = Integer.toString(TotalCountC1);
                        String strTotalCountC2 = Integer.toString(TotalCountC2);

                        //Assert.assertTrue(CountUTL1Replace1.equals(strTotalCountC1));////////ZeroFilled1
                        //Assert.assertTrue(CountUTL2Replace2.equals(strTotalCountC2));///ZeroFilled2

                    } else if (line.contains("CONTRA")) {
                        String[] result2 = line.split("\\s\\s");
                        payerSortCode = result1.get(0).toString().substring(0, 6);///////payer's sorting code
                        payerAccntNo = result1.get(0).toString().substring(6, 14);/////payer's a/c number
                        payerAccntType = result1.get(0).toString().substring(14, 15);/////payer's account type
                        tnxCode = result1.get(0).toString().substring(15, 17);///transaction code
                        OrigSrtCode = result1.get(0).toString().substring(17, 23);///originating sorting code
                        OrigAccntNo = result1.get(0).toString().substring(23, 31);///originating account code
                        Amountt = result1.get(4).toString().substring(0, 11);///

                        OrigName = result1.get(4).toString().substring(11);///Narrative
                        Reference = result1.get(16).toString().substring(0, 6);/////REFERENCE
                        PayerName = result2[14].trim();
/*
                        ////Integrity Check
                        stringMatchCompare("Integration_Results",OrigName,(regexMulDigits));///Narrative
                        stringMatchCompare("Integration_Results",Reference,("^[A-Z]{6}$"));//////REFERENCE
                        stringMatchCompare("Integration_Results",PayerName,(regexMulNonDigit));/////PAYER_OR_DEST_ACCOUNT_NAME

                        stringMatchCompare("Integration_Results",payerSortCode,("^[\\d]{6}$"));//////payer's sorting code
                        stringMatchCompare("Integration_Results",payerAccntNo,("^[\\d]{7,8}$"));//////payerAccntNo
                        stringMatchCompare("Integration_Results",payerAccntType,(regexSingleDigit));//////payer's account type
                        stringMatchCompare("Integration_Results",tnxCode,("^[\\d]{2}$"));/////transaction code
                        stringMatchCompare("Integration_Results",OrigSrtCode,("^[\\d]{6}$"));////originating sorting code
                        stringMatchCompare("Integration_Results",OrigAccntNo,("^[\\d]{8}$"));//////originating account code
                        stringMatchCompare("Integration_Results",Amountt,("^[\\d]{11}$"));////Amountt*/


                        /*****Accuracy Check*****/
                        stringCompare("Integration_Results", "payer's sorting code", payerSortCode, (ContraDestSortCode)); /////////payer's sorting code
                        stringCompare("Integration_Results", "payer's a/c number", payerAccntNo, (ContraDestAccntNo)); ///////payer's a/c number
                        stringCompare("Integration_Results", "payer's account type", payerAccntType, ("0")); ////////payer's account type
                        stringCompare("Integration_Results", "originating sorting code", OrigSrtCode, (ContraOrigSortCode)); ///originating sorting code
                        stringCompare("Integration_Results", "originating account code", OrigAccntNo, (ContraOrigAccntNo)); /////originating account code
                        stringCompare("Integration_Results", "ORIGINATOR_ACCOUNT_NAME", OrigName, (PayerAccntNameContra)); ////ORIGINATOR_ACCOUNT_NAME
                        stringCompare("Integration_Results", "REFERENCE", Reference.trim(), ("CONTRA")); /////REFERENCE
                        stringCompare("Integration_Results", "PAYER_OR_DEST_ACCOUNT_NAME", PayerName.trim(), (Narrative)); /////PAYER_OR_DEST_ACCOUNT_NAME

                        String AmounttReplace = Amountt.replaceFirst("^0*", "");
                        if (tnxCode.equals("17")) {
                            if (!NinetyNineTnxCode.isEmpty()) {
                                CountC1 = CountC1 + 1;
                                stringCompare("Integration_Results", "Amount", AmounttReplace, (NinetyNineTnxCode)); //////Amountt
                            }
                        } else if (tnxCode.equals("99")) {
                            if (!ZeroOneTnxCode.isEmpty()) {
                                CountC2 = CountC2 + 1;
                                stringCompare("Integration_Results", "Amountt", AmounttReplace, (ZeroOneTnxCode)); //////Amountt
                            }
                        }
                    } else {
                        String[] result2 = line.split("\\s\\s");
                        payerSortCode = result1.get(0).toString().substring(0, 6);///////payer's sorting code
                        if (result1.get(0).toString().matches("^[\\d]{13}$")) {
                            payerAccntNo = result1.get(0).toString().substring(6, 13);/////payer's a/c number
                            payerAccntType = result1.get(1).toString().substring(0, 1);/////payer's account type
                            tnxCode = result1.get(1).toString().substring(1, 3);///transaction code
                            OrigSrtCode = result1.get(1).toString().substring(3, 9);///originating sorting code
                            OrigAccntNo = result1.get(1).toString().substring(9);///originating account code
                            Amountt = result2[2].substring(0, 11);///Amount
                            OrigName = result2[2].substring(11, 29);///ORIGINATOR_ACCOUNT_NAME
                            Reference = result2[2].substring(29, 45);/////REFERENCE
                            PayerName = result2[3];/////PAYER_OR_DEST_ACCOUNT_NAME
                        } else {
                            payerAccntNo = result1.get(0).toString().substring(6, 14);/////payer's a/c number
                            payerAccntType = result1.get(0).toString().substring(14, 15);/////payer's account type
                            tnxCode = result1.get(0).toString().substring(15, 17);///transaction code
                            OrigSrtCode = result1.get(0).toString().substring(17, 23);///originating sorting code
                            OrigAccntNo = result1.get(0).toString().substring(23, 31);///originating account code
                            Amountt = result2[2].substring(0, 11);///Amount
                            OrigName = result2[2].substring(11, 29);///ORIGINATOR_ACCOUNT_NAME
                            Reference = result2[2].substring(29);/////REFERENCE
                            PayerName = result2[3];/////PAYER_OR_DEST_ACCOUNT_NAME
                        }

             /*           *//***Integrity Check****//*
                        stringMatchCompare("Integration_Results",payerSortCode,("^[\\d]{6}$"));//////payer's sorting code
                        stringMatchCompare("Integration_Results",payerAccntNo,("^[\\d]{7,8}$"));//////payerAccntNo
                        stringMatchCompare("Integration_Results",payerAccntType,(regexSingleDigit));//////payer's account type
                        stringCompare("Integration_Results",payerAccntType,("0")); ////////payer's account type
                        stringMatchCompare("Integration_Results",tnxCode,("^[\\d]{2}$"));/////transaction code
                        stringMatchCompare("Integration_Results",OrigSrtCode,("^[\\d]{6}$"));////originating sorting code
                        stringMatchCompare("Integration_Results",OrigAccntNo,("^[\\d]{8}$"));//////originating account code
                        stringMatchCompare("Integration_Results",Amountt,("^[\\d]{11}$"));////Amountt*/

                        if (line.contains(ReferenceNo)) {

                            /*****Accuracy Check*****/
                            stringCompare("Integration_Results", "payer's sorting code", payerSortCode, (PayerSortCode)); /////////payer's sorting code
                            stringCompare("Integration_Results", "payer's a/c number", payerAccntNo, (PayerAccntNo)); ///////payer's a/c number
                            stringCompare("Integration_Results", "payer's account type", payerAccntType, ("0")); ////////payer's account type
                            stringCompare("Integration_Results", "transaction code", tnxCode, (TnxCode)); ////transaction code
                            stringCompare("Integration_Results", "originating sorting code", OrigSrtCode, (OrigSortCode)); ///originating sorting code
                            stringCompare("Integration_Results", "originating account code", OrigAccntNo, (OrigAccountNo)); /////originating account code
                            stringCompare("Integration_Results", "Amount", Amountt, (Amount)); //////Amountt
                            stringCompare("Integration_Results", "ORIGINATOR_ACCOUNT_NAME", OrigName.trim(), (OrigAccntName)); ////ORIGINATOR_ACCOUNT_NAME
                            stringCompare("Integration_Results", "REFERENCE", Reference.trim(), (ReferenceNo)); /////REFERENCE
                            stringCompare("Integration_Results", "PAYER_OR_DEST_ACCOUNT_NAME", PayerName.trim(), (PayerAccntName)); /////PAYER_OR_DEST_ACCOUNT_NAME
                            //Countt++;

                        }
                        al.add(Reference);


                        if (tnxCode.equals("01")) {
                            int Amnt1 = Integer.parseInt(Amountt);
                            Sum1 = Sum1 + Amnt1;
                            String StrSum1 = Integer.toString(Sum1);
                            ZeroOneTnxCode = StrSum1.replaceFirst("^0*", "");
                            Count1 = Count1 + 1;
                        } else if (tnxCode.equals("99")) {
                            int Amnt2 = Integer.parseInt(Amountt);
                            Sum2 = Sum2 + Amnt2;
                            String StrSum2 = Integer.toString(Sum2);
                            NinetyNineTnxCode = StrSum2.replaceFirst("^0*", "");
                            Count2 = Count2 + 1;
                        }
                    }
                }

                int found = 0;
                int notfound = 0;

                for (String e : al) {
                    if (e.equals(ReferenceNo)) {
                        found++;
                    } else {
                        notfound++;
                    }
                }
                if (found > 0) {
                } else {
                    stringCompare("Integration_Results", "ReferenceNo", ReferenceNo, "Not Found");//////BatchReference
                }
            }
        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();

            throw (e);
        }
    }


    public void CCAUTO(String CardExpiryDate, String TnxAmount, String policyNo) throws Exception {

        try {
            File directory = new File("src\\test\\resources\\Integration\\CCAUTO");
            //get all the files from a directory
            File[] fList = directory.listFiles();

            for (File file : fList) {


                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));
                //reportUtil.createExcel("src\\test\\resources\\Integration\\IntegrationResults.xls");


                // List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\470774\\Desktop\\Pradeep\\CCAUTO.csv"));
                ArrayList<String> al = new ArrayList<String>();
                int count1 = 0;
                for (String line : lines) {
                    String[] result = line.split("\\,");

                    if (line.equals(lines.get(lines.size() - 1))) {
                        // stringMatchCompare("Integration_Results", "Static value", result[0], ("^[\\d]{9}$")); //static //need to uncomment once added in new integrity check method
                        int CCAUTORows = lines.size() - 1;
                        String StrCCAUTORows = Integer.toString(CCAUTORows);
                        String CCAUTOCount = result[0];
                        String FinalCCAUTOCount = CCAUTOCount.replaceFirst("^0*", "");
                        stringCompare("Integration_Results", "CCAUTORows", FinalCCAUTOCount, (StrCCAUTORows));//CCAUTORows
                    } else {
                        int fieldsSize = result.length;
                        String StrfieldsSize = Integer.toString(fieldsSize);
                        //*****************Integrity Check******************//
                       /* stringMatchCompare("Integration_Results",result[0],("^[\\d]{2}$")); //static
                        stringMatchCompare("Integration_Results",result[1],("^(?=.*[a-zA-Z\\d].*)[a-zA-Z\\d]{15,}$")); //Masked Card Number
                        stringMatchCompare("Integration_Results",result[2],("^[\\d]{4}$")); //CardExpiryDate
                        stringMatchCompare("Integration_Results",result[3],("")); //null check
                        stringMatchCompare("Integration_Results",result[4],("")); //null check
                        stringMatchCompare("Integration_Results",result[5],(regexMulDigits));  //Tnx amnt
                        stringMatchCompare("Integration_Results",result[6],(regexMulDigits));  //Tnx Ref
                        stringMatchCompare("Integration_Results",result[7],(""));  //null
                        stringMatchCompare("Integration_Results",result[8],("^[\\D]{3}$")); //static GBP
                        stringCompare("Integration_Results",result[8],("GBP"));//////////////static GBP
                        stringMatchCompare("Integration_Results",result[9],(""));  //null
                                      stringMatchCompare("Integration_Results",result[10],("^[\\d]{9}$")); //Policy no
                        stringMatchCompare("Integration_Results",result[11],("^[a-zA-Z]{2}[\\d]{1}[a-zA-Z]{9}$")); //DL4BEVOPHONE
                        stringCompare("Integration_Results",result[11],("DL4BEVOPHONE"));///////////////DL4BEVOPHONE*/

                        if (line.contains(policyNo)) {
                            stringCompare("Integration_Results", "no of fields validation", StrfieldsSize, ("12"));//no of fields validation
                            stringCompare("Integration_Results", "Static", result[0], ("47"));/////////////////////////static
                            stringCompare("Integration_Results", "CardExpiryDate", result[2], (CardExpiryDate));
                            double TransactionAmount = Double.parseDouble(TnxAmount) * 100;
                            int intTransactionAmount = new Double(TransactionAmount).intValue();
                            String strTransactionAmount = Integer.toString(intTransactionAmount);
                            stringCompare("Integration_Results", "TransactionAmount", result[5], (strTransactionAmount));//////////TransactionAmount
                            stringCompare("Integration_Results", "Currency", result[8], ("GBP"));//////////////static GBP
                            stringCompare("Integration_Results", "Policy Number", result[10], (policyNo));///////////////////policy no
                            stringCompare("Integration_Results", "Channel", result[11], ("DL4BEVOPHONE"));///////////////DL4BEVOPHONE
                            count1++;
                        }
                        al.add(result[10]);

                    }
                }


                int found = 0;
                int notfound = 0;

                for (String e : al) {
                    if (e.equals(policyNo)) {
                        found++;
                    } else {
                        notfound++;
                    }
                }
                if (found > 0) {
                } else {
                    stringCompare("Integration_Results", "policyNo", policyNo, "Not Found");//////BatchReference
                }

            }
        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();

            throw (e);
        }

    }

    ///////// To read from property file

    public List<String> getClaimData(String header) {
        Properties prop = new Properties();
        InputStream input = null;
        List<String> lstClaimHeaderDetails = new ArrayList<String>();

        try {
            input = new FileInputStream("src/test/resources/Integration.properties");
            prop.load(input);
            String claimHeader = prop.getProperty(header);
            String[] arrClaimHeaderDetails = claimHeader.split("@");
            lstClaimHeaderDetails = Arrays.asList(arrClaimHeaderDetails);
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            if (input != null) {
                try {
                    input.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
        return lstClaimHeaderDetails;
    }


    ////////// To replace value of property file with feature file
    public List<List<String>> parameterMapping(Integer iSize, List<List<String>> parameters) {
        List<List<String>> newParameters = new ArrayList<>();
        String dataRecord = "";
        String dataHeader = "";
        List<String> headerDetails = getClaimData(parameters.get(0).get(0));
        newParameters.add(headerDetails);
        for (int row = 1; row < iSize + 1; row++) {
            List<String> recordDetails = getClaimData(parameters.get(row).get(0));
            for (int column = 1; column < parameters.get(0).size(); column++) {
                dataHeader = parameters.get(0).get(column);
                dataRecord = parameters.get(row).get(column);
                int indexc = headerDetails.indexOf(dataHeader);
                recordDetails.set(indexc, recordDetails.get(indexc).replace(recordDetails.get(indexc), dataRecord));
            }
            newParameters.add(recordDetails);
        }
        return newParameters;
    }

    public boolean stringCompare(String sheetName, String ColumnName, String Expected, String Actual) throws Exception {
        //reportUtil.excelwrite("Summary", "Integration_Results", ColumnName, Expected, Actual);
        reportUtil.excelwrite("Summary", "Integration_Results", ColumnName, Actual, Expected);


        flag = Expected.equals(Actual);
        return flag;
    }


    public boolean stringContains(String sheetName, String ColumnName, String Expected, String Actual) throws Exception {
        if (!Expected.contains(Actual)) {
            // expected.add(Expected);
            //actualVal.add(Actual);
            flag = false;

            reportUtil.excelwrite("Summary", "Integration_Results", ColumnName, Expected, Actual);
            //reportUtil.excelwrite( sheetName, expected, actual);
        } else {
            reportUtil.excelwrite("Summary", "Integration_Results", ColumnName, Expected, Actual);
            flag = true;
        }
        return flag;
    }

    public boolean stringMatchCompare(String sheetName, String ColumnName, String Expected, String Actual) throws Exception {
        reportUtil.excelwrite("Summary", "Integration_Results", ColumnName, Expected, Actual);
        flag = Expected.matches(Actual);
        return flag;
    }

    public boolean multipleStringCompare(String sheetName, String ColumnName, String Expected, String Actual) throws Exception {
        if (Actual.contains(";")) {
            String[] actual = Actual.split(";");
            if ((Expected.equals(actual[0]))) {
                reportUtil.excelwrite("Summary", "Integration_Results", ColumnName, Expected, Actual);
                flag = true;
                // expected.add(Expected);
                // actualVal.add(actual[0]);
            } else if (Expected.matches(actual[1])) {
                reportUtil.excelwrite("Summary", "Integration_Results", ColumnName, Expected, Actual);
                flag = true;
                //reportUtil.excelwrite( sheetName, expected, actual);
            } else {

                flag = false;
                reportUtil.excelwrite("Summary", "Integration_Results", ColumnName, Expected, Actual);
            }
        }
        return flag;

    }


    //Syed---Integrity check for Intellimatch/Geo/CCAuto/AML
    public void inteliimatchValidateIntegrityCheck(String strFileName) throws Exception {

        try {
            File directory = new File("src\\test\\resources\\Integration\\Intellimatch");
            //get all the files from a directory
            File[] fList = directory.listFiles();

/*
            String filepath="src\\test\\resources\\Integration\\"+"IntellimatchResults"+".xls";
            String strFilePath="src\\test\\resources\\Integration\\";
            String strFileName="IntellimatchResults";
            String strSheetName="IntellimatchIntegrity";
            reportUtil.createExcelReport(strFilePath,strFileName,strSheetName);
*/
            String filepath = "target\\" + strFileName + ".xls";
            String strFilePath = "target\\";
            String strSheetName = "IntellimatchIntegrity";
            reportUtil.createExcelConsolidatedReport(strFilePath, strFileName, strSheetName);


            for (File file : fList) {

                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));


                int lineflag = 0;
                int linenumber = 1;
                for (String line : lines) {
                    String[] result1 = line.split("\\|");

                    int fieldsSize = result1.length;
                    String StrfieldsSize = Integer.toString(fieldsSize);
                    int fieldflag = 0;
                    String Fieldfailure = "";
                    if (line != lines.get(0)) {
                        linenumber = linenumber + 1;

                        //*****************Integrity Check******************//

                        //D Record
                        if (!result1[0].equals("D")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "D is not available in the record type;";
                        }
                        //DLGAccountnumber Record
                        if (!result1[1].equals("31355461")) {
                            fieldflag += 1;
                            Fieldfailure = Fieldfailure + "Account number 31355461 is not available;";
                        }

                        //Posting Date
                        if (!result1[2].matches("^(0?[1-9]|[12][\\d]|3[01])[\\/\\-](0?[1-9]|1[012])[\\/\\-]\\d{4}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Posting date is not in the right format;";
                        }
                        //Transactiondate
                        if (!result1[3].matches("^(0?[1-9]|[12][\\d]|3[01])[\\/\\-](0?[1-9]|1[012])[\\/\\-]\\d{4}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Transaction date is not in the right format;";
                        }
                        //Amount
                        if (!result1[4].matches("^-?\\d+(\\.\\d{1,2})?$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Amount is not in the right format;";
                        }
                        //Transactiontype
                        if (!(result1[5].equals("PAYMENT_CASH") || result1[5].equals("RECEIPT_CASH"))) {

                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Transactiontype is other than PAYMENT_CASH/RECEIPT_CASH;";
                        }
                        //Credit/Debit
                        if (!(result1[6].equals("CR") || result1[6].equals("DR"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Credit/Debit is other than CR/DR;";
                        }
                        //GBP
                        if (!result1[7].equals("GBP")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Currency other than GBP is available;";
                        }

                        try {
                            String[] reference = result1[9].split("-");

                            if (!(reference[0].equals("DL4BEVOWEB") ||
                                    reference[0].equals("DL4BEVOPHONE") ||
                                    reference[0].equals("DL4BEVORENEW") ||
                                    reference[0].equals("Reverse") ||
                                    reference[0].equals("299650"))) {

                                fieldflag = fieldflag + 1;
                                Fieldfailure = Fieldfailure + "Channel in Transaction Reference is not in the defined format;";
                                if (!(reference[1].equals("American Express") ||
                                        reference[1].equals("MasterCard") ||
                                        reference[1].equals("Visa") ||
                                        reference[1].equals("BACS"))) {

                                    Fieldfailure = Fieldfailure + "Payment type in Transaction Reference is not in the defined format;";
                                }
                            } else if (!(reference[1].equals("American Express") ||
                                    reference[1].equals("MasterCard") ||
                                    reference[1].equals("Visa") ||
                                    reference[1].equals("BACS"))) {

                                fieldflag = fieldflag + 1;
                                Fieldfailure = Fieldfailure + "Payment type in Transaction Reference is not in the defined format;";
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        //PaymentMethod
                        if (!(result1[10].equals("Card") || result1[10].equals("Direct debit"))) {

                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Payment method is other than card/Direct debit;";
                        }

                        //Assert.assertTrue(StrfieldsSize.equals("11"));//no of fields validation
                        String strFilename, strStatus, strReason, strLine;
                        if (fieldflag == 0) {
                            strFilename = file.getName();
                            strStatus = "PASS";
                            strReason = "All Fields are in right format";
                            strLine = Integer.toString(linenumber);
                            reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                        } else {
                            lineflag = lineflag + 1;
                            if (fieldflag == 1) {

                                strFilename = file.getName();
                                strStatus = "FAIL";
                                strReason = fieldflag + " field is not in right format. Reason :" + Fieldfailure;
                                strLine = Integer.toString(linenumber);
                                reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                            } else {
                                strFilename = file.getName();
                                strStatus = "FAIL";
                                strReason = fieldflag + " fields is not in right format. Reason :" + Fieldfailure;
                                strLine = Integer.toString(linenumber);
                                reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                            }
                        }
                    }
                }
                if (lineflag == 0) {
                    if (lines.size() == 1) {
                    } else {
                    }
                } else {
                    if (lineflag == 1) {
                    } else {
                    }
                }
            }

        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();

            throw (e);
        }

    }

    public void amlValidateIntegrityCheck(String strFileName) throws Exception {


        try {
            File directory = new File("src\\test\\resources\\Integration\\AML");
            //get all the files from a directory
            File[] fList = directory.listFiles();

/*
            String filepath="src\\test\\resources\\Integration\\"+"IntegrationAMLResults"+".xls";
            String strFilePath="src\\test\\resources\\Integration\\";
            String strFileName="IntegrationAMLResults";
            String strSheetName="AMLIntegrity";
            reportUtil.createExcelReport(strFilePath,strFileName,strSheetName);
*/

            String filepath = "target\\" + strFileName + ".xls";
            String strFilePath = "target\\";
            String strSheetName = "AMLIntegrity";
            reportUtil.createExcelConsolidatedReport(strFilePath, strFileName, strSheetName);

            for (File file : fList) {

                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));


                int lineflag = 0;
                int linenumber = 0;
                for (String line : lines) {
                    String[] result1 = line.split("\\~");

                    int fieldsSize = result1.length;
                    String StrfieldsSize = Integer.toString(fieldsSize);
                    int fieldflag = 0;
                    String Fieldfailure = "";

                    linenumber = linenumber + 1;

                    //*****************Integrity Check******************//

                    //ID Field
                    if (!result1[0].matches(regexMulDigits)) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "ID is not in the right format;";
                    }

                    //Client Type Record
                    if (!(result1[1].equals("C") || result1[1].equals("I"))) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Client Type is other than C/I;";
                    }
                    //Sequence number Field
                    if (!result1[2].matches(regexSingleDigit)) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Sequence number is not in the right format;";
                    }

                    //Name Field
                    if (!result1[3].matches(regexMulNonDigit)) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Name Contains Numeric value;";
                    }

                    //Address Field
                    if (result1[4].equals("")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Address is blank;";
                    }

                    //City Field
                    if (!(result1[5].matches(regexMulNonDigit) || result1[5].equals(""))) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "City Contains Numeric value;";
                    }

                    //Country Field
                    if (!result1[6].equals("United Kingdom")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Country is blank;";
                    }

                    //National Field
                    if (!result1[7].equals("")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "National id is not blank;";
                    }

                    //Passport Field
                    if (!result1[8].equals("")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Passport number is not blank;";
                    }

                    //BIC Field
                    if (!result1[9].equals("")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "BIC is not blank;";
                    }

                    //Date of Birth Field
                    if (!(result1[10].equals("") || result1[10].matches("^[\\d]{8}$"))) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Date of bith is not in right format;";
                    }

                    //Gender Field
                    if (!(result1[11].equals(" ") || result1[11].equals("M") || result1[11].equals("F"))) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Gender is not in right format;";
                    }

                    //SourceSystem Field
                    if (!result1[12].equals("GBEVO")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Source field is other than GBEVO;";
                    }

                    //Party Open Date Field
                    if (!(result1[13].matches("^[\\d]{8}$") || result1[13].equals(""))) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Party Open Date field is not in the right format;";
                    }
                    //Birth Place Field
                    if (!result1[14].equals("")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Birth place field is other than blank;";
                    }

                    //Natonality Place Field
                    if (!result1[15].equals("")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Nationality field is other than blank;";
                    }

                    //Risk Country Field
                    if (!(result1[16].equals("United Kingdom") || result1[16].equals(""))) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Riskcountry field is other than United Kingdon/blank;";
                    }

                    //Customer status Field
                    if (!(result1[17].equals("A") || result1[17].equals("S"))) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Customer Status field is other than A/S;";
                    }

                    //GIDe Field
                    if (!result1[18].equals("")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "GID field is other than blank;";
                    }

                    //Kp/G Field
                    if (!result1[19].equals("")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "KP/G identifier field is other than blank;";
                    }

                    //Kp/G link Place Field
                    if (!result1[20].equals("")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "KP/G link identifier field is other than blank;";
                    }

                    //Home Telephone Field
                    if (!(result1[21].matches(regexMulDigits) || result1[21].equals(""))) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Home Telephone is not in right format;";
                    }
                    //Office Telephone Field
                    if (!(result1[22].matches(regexMulDigits) || result1[22].equals(""))) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Office Telephone is not in right format;";
                    }
                    //Mobile Telephone Field
                    if (!(result1[23].matches(regexMulDigits) || result1[23].equals(""))) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Mobile number is not in right format;";
                    }

                    //Other Telephone Field
                    if (!result1[24].equals("")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Other Telephone is not blank;";
                    }

                    //AML Add Field1 Telephone Field
                    if (!result1[25].equals("GB")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "AML Add Field1 is other than GB;";
                    }
                    //AML Add Field2 Telephone Field
                    if (!result1[26].equals("GB")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "AML Add Field2 is other than GB;";
                    }
                    //AML Add Field3 Telephone Field
                    if (!result1[27].equals("GB")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "AML Add Field3 is other than GB;";
                    }
                    //AML Add Field4 Telephone Field
                    if (!result1[28].equals("GB")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "AML Add Field4 is other than GB;";
                    }
                    //AML Add Field5 Telephone Field
                    if (!result1[29].equals("GB")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "AML Add Field5 is other than GB;";
                    }

                    //Other  Field
                    if (!result1[30].matches("^[\\d]{9}$")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "AML Add Field5 is other than GB;";
                    }

                    //Suppliment  Field
                    if (!result1[31].equals("DL4B")) {
                        fieldflag = fieldflag + 1;
                        Fieldfailure = Fieldfailure + "Suppliment is other than DL4B;";
                    }


                    String strFilename, strStatus, strReason, strLine;
                    if (fieldflag == 0) {
                        strFilename = file.getName();
                        strStatus = "PASS";
                        strReason = "All Fields are in right format";
                        strLine = Integer.toString(linenumber);
                        reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                    } else {
                        lineflag = lineflag + 1;
                        if (fieldflag == 1) {

                            strFilename = file.getName();
                            strStatus = "FAIL";
                            strReason = fieldflag + " field is not in right format. Reason :" + Fieldfailure;
                            strLine = Integer.toString(linenumber);
                            reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                        } else {
                            strFilename = file.getName();
                            strStatus = "FAIL";
                            strReason = fieldflag + " fields is not in right format. Reason :" + Fieldfailure;
                            strLine = Integer.toString(linenumber);
                            reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);
                        }
                    }

                }
                if (lineflag == 0) {
                    if (lines.size() == 1) {
                    } else {
                    }
                } else {
                    if (lineflag == 1) {
                    } else {
                    }
                }
            }

        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();

            throw (e);
        }

    }

    public void GeospatialValidateIntegrityCheck(String strFileName) throws Exception {

        try {


            File directory = new File("src\\test\\resources\\Integration\\Geospatial");
            //get all the files from a directory
            File[] fList = directory.listFiles();

/*            String filepath="src\\test\\resources\\Integration\\"+"GeospatialResults"+".xls";
            String strFilePath="src\\test\\resources\\Integration\\";
            String strFileName="GeospatialResults";
            String strSheetName="GeospatialIntegrity";
            reportUtil.createExcelReport(strFilePath,strFileName,strSheetName);*/

            String filepath = "target\\" + strFileName + ".xls";
            String strFilePath = "target\\";
            String strSheetName = "GeospatialIntegrity";
            reportUtil.createExcelConsolidatedReport(strFilePath, strFileName, strSheetName);


            for (File file : fList) {


                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));

                int count = 0;
                int lineflag = 0;
                int linenumber = 1;

                for (String line : lines) {


                    String[] result1 = line.split(",(?=([^\"]*\"[^\"]*\")*[^\"]*$)");

                    for (int i = 0; i < result1.length; i++) {
                        result1[i] = result1[i].replace("\"", "");
                    }

                    int fieldflag = 0;
                    String Fieldfailure = "";

                    if (line == lines.get(0)) {
                        int fieldsSize = result1.length;
                        String StrfieldsSize = Integer.toString(fieldsSize);

                        //Assert.assertTrue(StrfieldsSize.equals("26"));//no of fields validation


                    } else if (line != lines.get(0)) {
                        linenumber = linenumber + 1;

                        //*****************Integrity Check******************//

                        //Type Record
                        if (!(result1[0].equals("insert") || result1[0].equals("update") || result1[0].equals("delete"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "CHANGE_TYPE is other than insert/update/delete;";
                        }
                        //Territory Record
                        if (!(result1[1].equals("GB") || result1[1].equals("NI"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Territory is other than GB/NI;";
                        }

                        //Location ID
                        if (!(result1[2].matches("^[\\d]{9}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Location ID is not in right format;";
                        }

                        //Version
                        if (!(result1[3].matches("^[\\d+]$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Version sequence is not in right format;";
                        }

                        //Version date
                        if (!(result1[4].matches("^([1-9]|([012][\\d])|(3[01]))/([0]{0,1}[1-9]|1[012])/\\d\\d\\d\\d [012]{0,1}[\\d]:[0-6][\\d]$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Version date is not in right format;";
                        }

                        //Movement sequence
                        if (!(result1[5].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Movement sequence is other than blank;";
                        }

                        //Inforce flag
                        if (!(result1[6].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Inforce flag is other than blank;";
                        }

                        //current flag
                        if (!(result1[7].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Current flag is other than blank;";
                        }

                        //Policy number
                        if (!(result1[8].matches("^[\\d]{9}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Policy number is not in right format;";
                        }
                        //COBID number
                        if (!(result1[9].equals("560") || result1[9].equals("561"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "COBID number is other than 560/561;";
                        }

                        //COBID description
                        //COBID description
                        if (!(result1[10].equalsIgnoreCase("Bed and Breakfast") || result1[10].equalsIgnoreCase("Hair and Beauty"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "COB Description is other than Bed and Breakfast/Hair and Beauty;";
                        }

                        //sum insured
                        if (!(result1[11].matches(regexMulDigits + "." + regexMulDigits))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Total sum insured is not in right format;";
                        }

                        //Business name
                        if (!(result1[12].matches(regexMulNonDigit))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Business name is not in right format;";
                        }

                        //Address line1
                        //if (!(result1[13].matches("\\d+\\s+(([a-zA-Z])+|([a-zA-Z]+\\s+[a-zA-Z]+))\\s+[a-zA-Z]*")))
                        if (!(result1[13].matches("[0-9a-zA-Z #,-]+"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Address line1 is not in right format;";
                        }
                        //Address line 2
                        if (!(result1[14].matches("[0-9a-zA-Z #,-]+") || result1[14].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Address line2 is not in right format;";
                        }
                        //Address line3
                        if (!(result1[15].matches("[0-9a-zA-Z #,-]+") || result1[15].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Address line3 is blank;";
                        }
                        //Address line 4
                        if ((result1[16].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Address line 4 is blank;";
                        }
                        //Address line5
                        if ((result1[17].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Address line 5 is blank;";
                        }
                        //Address line6
                        if ((result1[18].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Address line 6 is blank;";
                        }

                        //Business type
                        if (!(result1[19].matches(regexMulNonDigit))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Buisness Type contains numberic;";
                        }

                        //DTI Class Field
                        if (!result1[20].equals("")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "DTI class is not blank;";
                        }

                        //section id Field
                        if (!result1[21].equals("22190")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Section is other than 22190;";
                        }

                        //Item id Field
                        if (!result1[22].equals("DLC")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Item ID is other than DLC;";
                        }

                        //start date id Field
                        if (!(result1[23].matches("^([1-9]|([012][\\d])|(3[01]))/([0]{0,1}[1-9]|1[012])/\\d\\d\\d\\d [012]{0,1}[\\d]:[0-6][\\d]$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Start date is not in right format;";
                        }

                        //End Date Field
                        if (!(result1[24].matches("^([1-9]|([012][\\d])|(3[01]))/([0]{0,1}[1-9]|1[012])/\\d\\d\\d\\d [012]{0,1}[\\d]:[0-6][\\d]$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "End date is not in right format;";
                        }

                        //postcode
                        if (!(result1[25].matches("^[A-Za-z]{1,2}[\\dR][\\dA-Za-z]? [\\d][A-Za-z]{2}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Post code is not in right format;";
                        }

                        //*****************End of Integrity Check******************//

                        String strFilename, strStatus, strReason, strLine;
                        if (fieldflag == 0) {
                            strFilename = file.getName();
                            strStatus = "PASS";
                            strReason = "All Fields are in right format";
                            strLine = Integer.toString(linenumber);
                            reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                        } else {
                            lineflag = lineflag + 1;
                            if (fieldflag == 1) {

                                strFilename = file.getName();
                                strStatus = "FAIL";
                                strReason = fieldflag + " field is not in right format. Reason :" + Fieldfailure;
                                strLine = Integer.toString(linenumber);
                                reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                            } else {
                                strFilename = file.getName();
                                strStatus = "FAIL";
                                strReason = fieldflag + " fields is not in right format. Reason :" + Fieldfailure;
                                strLine = Integer.toString(linenumber);
                                reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                            }
                        }

                    }
                }

                if (lineflag == 0) {
                    if (lines.size() == 1) {
                    } else {
                    }
                } else {
                    if (lineflag == 1) {
                    } else {
                    }
                }

            }
        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();

            throw (e);
        }
    }

    public void CCAUTOValidateIntegrityCheck(String strFileName) throws Exception {

        try {
            File directory = new File("src\\test\\resources\\Integration\\CCAUTO");
            //get all the files from a directory
            File[] fList = directory.listFiles();

            /*String filepath="src\\test\\resources\\Integration\\"+"CCAUTOResults"+".xls";
            String strFilePath="src\\test\\resources\\Integration\\";
            String strFileName="CCAUTOResults";
            String strSheetName="CCAUTOIntegrity";
            reportUtil.createExcelReport(strFilePath,strFileName,strSheetName);
            */
            String filepath = "target\\" + strFileName + ".xls";
            String strFilePath = "target\\";
            String strSheetName = "CCAUTOIntegrity";
            reportUtil.createExcelConsolidatedReport(strFilePath, strFileName, strSheetName);


            for (File file : fList) {


                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));

                int lineflag = 0;
                int linenumber = 0;

                for (String line : lines) {

                    int fieldflag = 0;
                    String Fieldfailure = "";
                    linenumber = linenumber + 1;

                    String[] result = line.split("\\,");

                    if (line.equals(lines.get(lines.size() - 1))) {

                        //Trailer record ID
                        if (!(result[0].matches("^[\\d]{9}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Location ID is not in right format;";
                        }
                    } else {
                        int fieldsSize = result.length;
                        String StrfieldsSize = Integer.toString(fieldsSize);

                        //*****************Integrity Check******************//
                        // Record
                        if (!(result[0].equals("47"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Other than 47;";
                        }

                        // Masked Card number
                        if (!(result[1].matches("^(?=.*[a-zA-Z\\d].*)[a-zA-Z\\d]{15,}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Masked card number not in right format;";
                        }
                        // Card Expiry
                        if (!(result[2].matches("^[\\d]{4}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Card Expiry is not in right format;";
                        }
                        // Record
                        if (!(result[3].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Field 4 is not null;";
                        }
                        // Record
                        if (!(result[4].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Field 5 is not null;";
                        }
                        // Transaction amount
                        if (!(result[5].matches(regexMulDigits))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Transaction amount is not in right format;";
                        }
                        // Card Expiry
                        if (!(result[6].matches(regexMulDigits))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Transaction reference is not in right format;";
                        }

                        // Record
                        if (!(result[7].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Field 8 is not null;";
                        }
                        // GBPRecord
                        if (!(result[8].equals("GBP"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Currency is other than GBP;";
                        }
                        // Record
                        if (!(result[9].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Field 10 is not null;";
                        }
                        // Policynumber
                        if (!(result[10].matches("^[\\d]{9}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Policy number is not in right format;";
                        }
                        //
                        if (!(result[11].equals("DL4BEVOWEB") ||
                                result[11].equals("DL4BEVOPHONE") ||
                                result[11].equals("DL4BEVORENEW") ||
                                result[11].equals("Reverse"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Channel in Transaction Reference is not in the defined format;";
                        }
                    }

                    String strFilename, strStatus, strReason, strLine;
                    if (fieldflag == 0) {
                        strFilename = file.getName();
                        strStatus = "PASS";
                        strReason = "All Fields are in right format";
                        strLine = Integer.toString(linenumber);
                        reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                    } else {
                        lineflag = lineflag + 1;
                        if (fieldflag == 1) {

                            strFilename = file.getName();
                            strStatus = "FAIL";
                            strReason = fieldflag + " field is not in right format. Reason :" + Fieldfailure;
                            strLine = Integer.toString(linenumber);
                            reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                        } else {
                            strFilename = file.getName();
                            strStatus = "FAIL";
                            strReason = fieldflag + " fields is not in right format. Reason :" + Fieldfailure;
                            strLine = Integer.toString(linenumber);
                            reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                        }
                    }

                }

                if (lineflag == 0) {
                    if (lines.size() == 1) {
                    } else {
                    }
                } else {
                    if (lineflag == 1) {
                    } else {
                    }
                }
            }
        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();

            throw (e);
        }

    }

    public void GLValidateIntegrityCheck(String strFileName) throws Exception {

        try {
            File directory = new File("src\\test\\resources\\Integration\\GL");


            //get all the files from a directory
            File[] fList = directory.listFiles();

            /*String filepath="src\\test\\resources\\Integration\\"+"GLResults"+".xls";
            String strFilePath="src\\test\\resources\\Integration\\";
            String strFileName="GLResults";
            String strSheetName="GLIntegrity";
            reportUtil.createExcelReport(strFilePath,strFileName,strSheetName);
            */

            String filepath = "target\\" + strFileName + ".xls";
            String strFilePath = "target\\";
            String strSheetName = "GLIntegrity";
            reportUtil.createExcelConsolidatedReport(strFilePath, strFileName, strSheetName);


            for (File file : fList) {


                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));
                int lineflag = 0;
                int linenumber = 0;


                // List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\470774\\Desktop\\Pradeep\\GL1.txt"));
                ArrayList<String> al = new ArrayList<String>();
                for (String line : lines) {

                    int fieldflag = 0;
                    String Fieldfailure = "";
                    linenumber = linenumber + 1;


                    //*****************Integrity &Accuracy Check******************//
                    if (line == lines.get(0)) {
                        String[] result1 = line.split("\\|");

                        int fieldsSize = result1.length;
                        String StrfieldsSize = Integer.toString(fieldsSize);

                        //Assert.assertTrue(StrfieldsSize.equals("4"));//no of fields validation


                        //*****************Integrity Check******************//

                        //Header
                        if (!result1[0].equals("H")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Header record starts with otherthan H;";
                        }
                        //Identifier
                        if (!result1[1].equals("EVO_FAH_DAILY")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Identifier is otherthan EVO_FAH_DAILY;";
                        }
                        //Process date
                        if (!result1[2].matches("^[\\d]{8}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Process is not in the right format;";
                        }
                        //Process date
                        if (!result1[3].matches("^[\\d]{14}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Process identifier is not in the right format;";
                        }


                    } else {

                        String[] result1 = line.split("\\|");

                        int fieldsSize = result1.length;
                        String StrfieldsSize = Integer.toString(fieldsSize);


                        if (line == lines.get(1)) {
                            //Assert.assertTrue(StrfieldsSize.equals("25"));//no of fields validation

                        }


                        //Identifer the Trailer record ID
                        if (!(result1[0].equals("D"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Row  ID is other than D;";
                        }
                        //UW
                        if (!(result1[1].equals("UKI"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Underwriter is otherthan UKI;";
                        }


                        //Transaction
                        /*
                        TRADING_GROSS_WRITTEN_PREMIUM
                        TRADING_CHARGES
                        TRADING_CHARGES_TAX
                        TRADING_TAXES
                        TRADING_DEBTORS
                        RECEIPT_DEBTORS
                        RECEIPT_GL
                        RECEIPT_CASH
                        PAYMENT_DEBTORS
                        PAYMENT_GL
                        PAYMENT_CASH
                        */
                        if (!(result1[2].equals("TRADING_GROSS_WRITTEN_PREMIUM") ||
                                result1[2].equals("TRADING_CHARGES") ||
                                result1[2].equals("TRADING_CHARGES_TAX") ||
                                result1[2].equals("TRADING_TAXES") ||
                                result1[2].equals("TRADING_DEBTORS") ||
                                result1[2].equals("RECEIPT_DEBTORS") ||
                                result1[2].equals("RECEIPT_GL") ||
                                result1[2].equals("RECEIPT_CASH") ||
                                result1[2].equals("PAYMENT_DEBTORS") ||
                                result1[2].equals("PAYMENT_GL") ||
                                result1[2].equals("PAYMENT_CASH"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Transaction type is not in the defined format;";
                        }

                        //Brand type
                        if (!(result1[3].equals("Direct Line"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Brand is other than Direct Line;";
                        }

                        //Product type
                        if (!(result1[4].matches(regexMulNonDigit))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Product type is contains numeric;";
                        }

                        //Offering type
                        if (!(result1[5].matches(regexMulNonDigit) || result1[5].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Offering type is contains numeric;";
                        }

                        //channel
                        if (!(result1[6].equals("WEB") || result1[6].equals("CALL"))) {
                            if (!result1[2].contains("RECEIPT")) {
                                fieldflag = fieldflag + 1;
                                Fieldfailure = Fieldfailure + "Channel is other than WEB/CALL;";
                            }
                        }

                        //Amount
                        if (result1[7].matches(regexMulDigits)) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Amount is contains other than numeric;";
                        }

                        //Currency
                        if (!(result1[8].equals("GBP"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Channel is other than WEB/CALL;";
                        }

                        //Policy ref
                        if (!(result1[9].matches("^[\\d]{9}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Policy reference contains the other than numeric;";
                        }

                        //TAX
                        if (!(result1[10].matches(regexMulNonDigit) || result1[10].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "TAX Code contains digit ;";
                        }

                        //Freecharge code
                        if (!(result1[11].matches(regexMulNonDigit) || result1[11].equals("") || result1[11].equals("PF"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Free Charge Code not in right format;";
                        }

                        try {

                            if (!result1[2].contains("RECEIPT_CASH")) {
                                String[] reference = result1[12].split("-");

                                if (!(reference[0].equals("DL4BEVOWEB") ||
                                        reference[0].equals("DL4BEVOPHONE") ||
                                        reference[0].equals("DL4BEVORENEW") ||
                                        reference[0].equals("Reverse") ||
                                        reference[0].equals("299650"))) {

                                    fieldflag = fieldflag + 1;
                                    Fieldfailure = Fieldfailure + "Channel in Transaction Reference is not in the defined format;";
                                    if (!(reference[1].equals("American Express") ||
                                            reference[1].equals("MasterCard") ||
                                            reference[1].equals("Visa") ||
                                            reference[1].equals("BACS"))) {

                                        Fieldfailure = Fieldfailure + "Payment type in Transaction Reference is not in the defined format;";
                                    }
                                } else if (!(reference[1].equals("American Express") ||
                                        reference[1].equals("MasterCard") ||
                                        reference[1].equals("Visa") ||
                                        reference[1].equals("BACS"))) {

                                    fieldflag = fieldflag + 1;
                                    Fieldfailure = Fieldfailure + "Payment type in Transaction Reference is not in the defined format;";
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                        //GLA
                        if (!(result1[13].matches(regexMulDigits) || result1[13].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "GL Account not in right format ;";
                        }

                        //Organisation
                        if (!(result1[14].equals("31355461") || result1[14].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Organisation ID not in right format ;";
                        }

                        //Payment method
                        if (!(result1[15].matches(regexMulDigits) || result1[15].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Payment method not in right format ;";
                        }

                        //Rejection code
                        if (!(result1[16].matches(regexMulDigits) || result1[16].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Rejection code not in right format ;";
                        }

                        //journal id
                        if (!(result1[17].matches(regexMulDigits) || result1[17].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "journal id not in right format ;";
                        }

                        //journal item id
                        if (!(result1[18].matches(regexMulDigits) || result1[18].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "journal item id not in right format ;";
                        }

                        //Reciept id
                        if (!(result1[19].matches(regexMulDigits) || result1[19].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Reciept id not in right format ;";
                        }

                        //journal item id
                        if (!(result1[20].matches(regexMulDigits) || result1[20].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Reciept item id not in right format ;";
                        }
                        //Payemnt id
                        if (!(result1[21].matches(regexMulDigits) || result1[21].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Payment ID not in right format ;";
                        }

                        //recievalble id
                        if (!(result1[22].matches(regexMulDigits) || result1[22].equals(""))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Recievalble id not in right format ;";
                        }

                        //recievalble id
                        if (!(result1[23].matches(regexMulDigits + "." + regexMulDigits) || result1[23].equals("0"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Debit Amount id not in right format ;";
                        }

                        //recievalble id
                        if (!(result1[24].matches("-" + regexMulDigits + "." + regexMulDigits) || result1[24].equals("0"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Credit Amount not in right format ;";
                        }


                        //*****************End of Integrity Check******************//


                    }


                    String strFilename, strStatus, strReason, strLine;
                    if (fieldflag == 0) {
                        strFilename = file.getName();
                        strStatus = "PASS";
                        strReason = "All Fields are in right format";
                        strLine = Integer.toString(linenumber);
                        reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                    } else {
                        lineflag = lineflag + 1;
                        if (fieldflag == 1) {

                            strFilename = file.getName();
                            strStatus = "FAIL";
                            strReason = fieldflag + " field is not in right format. Reason :" + Fieldfailure;
                            strLine = Integer.toString(linenumber);
                            reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                        } else {
                            strFilename = file.getName();
                            strStatus = "FAIL";
                            strReason = fieldflag + " fields is not in right format. Reason :" + Fieldfailure;
                            strLine = Integer.toString(linenumber);
                            reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                        }
                    }

                }

                if (lineflag == 0) {
                    if (lines.size() == 1) {
                    } else {
                    }
                } else {
                    if (lineflag == 1) {
                    } else {
                    }
                }
            }
        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();

            throw (e);
        }

    }

    //---Integrity check for ELTO/DDI/DDC
    public void ELTOValidateIntegrityCheck(String strFileName) throws Exception {

        try {

            File directory = new File("src\\test\\resources\\Integration\\ELTO");
            //get all the files from a directory
            File[] fList = directory.listFiles();

/*            String filepath="src\\test\\resources\\Integration\\"+"ELTOResults"+".xls";
            String strFilePath="src\\test\\resources\\Integration\\";
            String strFileName="ELTOResults";
            String strSheetName="ELTOIntegrity";
            reportUtil.createExcelReport(strFilePath,strFileName,strSheetName);*/

            String filepath = "target\\" + strFileName + ".xls";
            String strFilePath = "target\\";
            String strSheetName = "ELTOIntegrity";
            reportUtil.createExcelConsolidatedReport(strFilePath, strFileName, strSheetName);


            for (File file : fList) {


                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));
                int lineflag = 0;
                int linenumber = 0;

                for (String line : lines) {

                    int fieldflag = 0;
                    String Fieldfailure = "";
                    linenumber = linenumber + 1;

                    List result1 = Arrays.asList(line.split("\\ "));
                    List result2 = Arrays.asList(line.split("\\,"));


                    /*
                    /************ Header Validation *************///
                    if (line == lines.get(0)) {

                        String first = line.substring(0, 1);
                        String second = line.substring(1, 2);
                        String third = line.substring(2, 6);
                        String fourth = line.substring(6, 7);
                        String fifth = line.substring(7, 11);
                        String sixth = line.substring(11, 15);
                        String seventh = line.substring(15, 24);
                        String eigth = line.substring(224, 232);
                        String ninth = line.substring(232, 236);
                        String tenth = line.substring(236, 237);
                        /***Integrity Check****/


                        //Header Record
                        if (!first.equals("H")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Header record starts with otherthan H;";
                        }
                        //File Type Record
                        if (!second.equals("C")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Type is otherthan C;";
                        }
                        //Supplier ID
                        if (!(fourth.equals("I") || fourth.equals("D"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Supplier is other than I/D;";
                        }
                        ///File Version Number
                        if (!third.equals("0001")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File version is other than 0001;";
                        }
                        //0053 Record
                        if (!(fifth.equals("0053") || fifth.matches("^[\\d]{4}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Value is other than 0053 ;";
                        }
                        //DL04 Record
                        if (!sixth.equals("DL04")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Value is other than DL04;";
                        }
                        //File sequence number
                        if (!seventh.matches("^[\\d]{9}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File sequence number is not in the right format;";
                        }
                        //Processig date Record
                        if (!eigth.matches("^[\\d]{8}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Processing date not in the right format;";
                        }
                        //Header Record
                        if (!ninth.matches("^[\\d]{4}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Processing date not in the right format;";
                        }
                        //Delimiter Record
                        if (!tenth.equals("#")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Delimiter is other than #;";
                        }


                    }
                    /************ Trailer Validation *************///
                    else if (line.equals(lines.get(lines.size() - 1))) {


                        String first = line.substring(0, 1);
                        String second = line.substring(1, 10);
                        String third = line.substring(10, 19);
                        String ThirdAftRemZeros = third.replaceFirst("^0*", "");
                        String fourth = line.substring(19, 20);

                        //Trailer Record
                        if (!first.equals("T")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Trailer record starts with otherthan T;";
                        }
                        //File sequence number
                        if (!second.matches("^[\\d]{9}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File sequence number in trailer record is not in the right format;";
                        }
                        String strLineSize = Integer.toString(lines.size());
                        //Count
                        if (!ThirdAftRemZeros.equals(strLineSize)) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Row count is not match in trailer record;";

                        } else if (!third.matches("^[\\d]{9}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Count in trailer record is not in the right format;";
                        }

                        //Delimiter Record
                        if (!fourth.equals("#")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Delimiter in Trailer record is other than #;";
                        }


                    }
                    /************ Policy record Validation *************///
                    else {

                        String first = line.substring(0, 1);
                        String second = line.substring(1, 10);
                        String third = line.substring(10, 14);
                        String fourth = line.substring(14, 18);
                        String fifth = line.substring(18, 43);
                        String sixth = line.substring(73, 74);
                        String seventh = line.substring(74, 75);
                        String eigth = line.substring(75, 325);
                        String ninth = line.substring(325, 575);
                        String tenth = line.substring(575, 583);
                        String eleventh = line.substring(583, 591);
                        String Address = line.substring(1141, 1265);
                        String EPRN = line.substring(1751, 1761);
                        String Trailer = line.substring(1773, 1774);


                        //Trailer Record
                        if (!first.equals("P")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Policy record starts with otherthan P;";
                        }
                        //Sequence number
                        if (!second.matches("^[\\d]{9}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Type is otherthan C;";
                        }
                        //currentInsurerID ID
                        if (!(third.equals("0053") || third.matches("^[\\d]{4}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "currentInsurerID is other than 0053 ;";
                        }

                        //OrigianlInsurerID
                        if (!(fourth.equals("0053") || fourth.matches("^[\\d]{4}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Original InsurerID is other than 0053 ;";
                        }
                        //Policyno

                        if (!fifth.matches("^[\\d]{25}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Policy number is not in the right format ;";
                        }
                        //Policy flag Record
                        if (!sixth.equals("N")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Policy flag is other than N;";
                        }

                        //Policy Type Record
                        if (!seventh.equals("P")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Policy type is other than P;";
                        }

                        //PolicyHoldername
                        if (!eigth.matches(regexMulNonDigit)) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "PolicyHolder Name Contains Numeric;";
                        }
                        //Employer name
                        if (!ninth.matches(regexMulNonDigit)) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Employer Name Contains Numeric;";
                        }

                        //coverStartDate
                        if (!tenth.matches("^[\\d]{8}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "CoverStartDate is not in right format";
                        }
                        //coverEndDate
                        if (!eleventh.matches("^[\\d]{8}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "CoverEndDate is not in right format;";
                        }

                        //Address line 1
                        if (!(Address.matches("[0-9a-zA-Z #,-]+"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Address line1 is not in right format;";
                        }
            /*            //Address line 2
                        if (!(Address2.matches("[0-9a-zA-Z #,-]+")||Address2.equals("")))
                        {
                            fieldflag=fieldflag+1;
                            Fieldfailure=Fieldfailure+"Address line2 is not in right format;";
                        }
                        //Address line3
                        if (!(Address3.matches("[0-9a-zA-Z #,-]+")||Address3.equals("")))
                        {
                            fieldflag=fieldflag+1;
                            Fieldfailure=Fieldfailure+"Address line 3 is not in right format;";
                        }
*/
                        //EPRN Record
                        if (!(EPRN.startsWith("1Y") || EPRN.startsWith("1N"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "EPRN is other than 1Y/1N;";
                        }
                        //Delimiter Record
                        if (!Trailer.equals("#")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Delimiter is other than #;";
                        }

                    }

                    String strFilename, strStatus, strReason, strLine;
                    if (fieldflag == 0) {
                        strFilename = file.getName();
                        strStatus = "PASS";
                        strReason = "All Fields are in right format";
                        strLine = Integer.toString(linenumber);
                        reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);
                    } else {
                        lineflag = lineflag + 1;
                        if (fieldflag == 1) {
                            strFilename = file.getName();
                            strStatus = "FAIL";
                            strReason = fieldflag + " field is not in right format. Reason :" + Fieldfailure;
                            strLine = Integer.toString(linenumber);
                            reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                        } else {
                            strFilename = file.getName();
                            strStatus = "FAIL";
                            strReason = fieldflag + " fields is not in right format. Reason :" + Fieldfailure;
                            strLine = Integer.toString(linenumber);
                            reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);
                        }
                    }
                }
                if (lineflag == 0) {
                    if (lines.size() == 1) {
                    } else {
                    }
                } else {
                    if (lineflag == 1) {
                    } else {
                    }
                }
            }
        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();
            throw (e);
        }
    }

    public void DDIValidateIntegrityCheck(String strFileName) throws Exception {

        try {

            File directory = new File("src\\test\\resources\\Integration\\DDI");
            //get all the files from a directory
            File[] fList = directory.listFiles();

/*
            String filepath="src\\test\\resources\\Integration\\"+"DDIResults"+".xls";
            String strFilePath="src\\test\\resources\\Integration\\";
            String strFileName="DDIResults";
            String strSheetName="DDIIntegrity";
            reportUtil.createExcelReport(strFilePath,strFileName,strSheetName);
*/

            String filepath = "target\\" + strFileName + ".xls";
            String strFilePath = "target\\";
            String strSheetName = "DDIIntegrity";
            reportUtil.createExcelConsolidatedReport(strFilePath, strFileName, strSheetName);


            for (File file : fList) {


                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));
                int lineflag = 0;
                int linenumber = 0;


                String payerAccntNo = "";
                String payerAccntType = "";
                String tnxCode = "";
                String OrigSrtCode = "";
                String OrigAccntNo = "";
                String Zeroes = "";
                String OrigName = "";
                String Reference = "";
                String PayerName = "";
                String payerSortCode = "";
                String DateIntegrity = "";
                String delimiter = "";


                //List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\470774\\Desktop\\Pradeep\\DDI.txt"));

                for (String line : lines) {

                    int fieldflag = 0;
                    String Fieldfailure = "";
                    linenumber = linenumber + 1;

                    List result1 = Arrays.asList(line.split("\\ "));


                    /************ Header Validation *************/////////////////

                    if (line == lines.get(0)) {
                        String vol = line.substring(0, 3); ///////Volume Identifier
                        String lblNo = line.substring(3, 4); ///////label number
                        String submSerialNo1 = line.substring(4, 5); ///////submission SerialNo1
                        String submSerialNo2 = line.substring(5, 10); ///////submission SerialNo2
                        String sumNo = line.substring(41, 47);  ///////SunNo
                        String lblStdLvl = line.substring(79, 80);  //////label standard level

                        // Record
                        if (!(vol.equals("VOL"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Volume record starts  with Other than VOL;";
                        }
                        // lblNo Record
                        if (!(lblNo.equals("1"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Label number in Volume record is Other than 1;";
                        }

                        // submSerialNo1
                        if (!(submSerialNo1.equals("I"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Submission Serial is other than I;";
                        }

                        // Card Expiry
                        if (!(submSerialNo2.matches("^[\\d]{5}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Submission Serial is not in right format;";
                        }

                        // submSerialNo1
                        if (!(sumNo.equals("B83255"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "SUN number is other than B83255;";
                        }

                        // submSerialNo1
                        if (!(lblStdLvl.equals("1"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Label standard level is other than 1;";
                        }


                    } else if (line == lines.get(1)) {    ////HDR1


                        String HDR = line.substring(0, 3); /////label identifier
                        String lblNo = line.substring(3, 4); ///////label number
                        String FileId = line.substring(4, 5); /////file identifier
                        String SumNo1 = line.substring(5, 11); /////SumNo
                        String S = line.substring(11, 12); /////S
                        String One = line.substring(14, 15); ////1
                        String SumNo2 = line.substring(15, 21); ////SumNo2
                        String setId1 = line.substring(21, 22); ////set identification
                        String setId2 = line.substring(22, 27); ////set identification
                        String fileSecNo = line.substring(27, 31); ////file section number
                        String fileSeqNo = line.substring(31, 35); ///file sequence number
                        String CreationDate = line.substring(42, 47); ////CreationDate
                        String ExpirationDate = line.substring(48, 53); ////ExpirationDate
                        String BlockCount = line.substring(54, 60); ////BlockCount


                        // Record
                        if (!(HDR.equals("HDR"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "HDR record starts  with Other than HDR;";
                        }

                        //Label
                        if (!(lblNo.equals("1"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Label in HDR record is Other than 1;";
                        }

                        //File ID
                        if (!(FileId.equals("A"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Identifier in HDR record is start with Other than A;";
                        }

                        //Sun number
                        if (!(SumNo1.equals("299650"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "SUN number in HDR record is start with Other than 299650;";
                        }

                        //Sun number
                        if (!(S.equals("S"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "12th position in HDR record is invalid;";
                        }

                        //One number
                        if (!(One.equals("1"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "13th position in HDR record is invalid;";
                        }

                        //Sun number
                        if (!(SumNo2.equals("B83255"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "SUN number in HDR record is start with Other than B83255;";
                        }


                        //SET ID
                        if (!(setId1.equals("D"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Set Identifier in HDR record is start with Other than D;";
                        }

                        //SET ID2
                        if (!(setId2.matches(("^[\\d]{5}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Set Identifier in HDR record is start with Other than D;";
                        }

                        //File Section Number
                        if (!(fileSecNo.matches(("^[\\d]{4}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Section Number in HDR record is start with Other than D;";
                        }

                        //File Sequence Number
                        if (!(fileSeqNo.matches(("^[\\d]{4}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Sequence Number in HDR record is start with Other than D;";
                        }

                        //CreationDate
                        if (!(CreationDate.matches(("^[\\d]{5}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "CreationDate in HDR record is start with Other than D;";
                        }

                        //ExpirationDate
                        if (!(ExpirationDate.matches(("^[\\d]{5}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "ExpirationDate in HDR record is start with Other than D;";
                        }

                        //BlockCount
                        if (!(BlockCount.matches(("^[\\d]{6}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "BlockCount in HDR record is start with Other than D;";
                        }


                    } else if (line == lines.get(2)) {    ////HDR2

                        String HDR = line.substring(0, 3); /////label identifier
                        String lblNo = line.substring(3, 4); ///////label number
                        String FileId = line.substring(4, 5); /////record format
                        String BlockLength = line.substring(5, 10); ////BlockLength
                        String RecordLength = line.substring(10, 15); ////recordLength
                        String bufferOffset = line.substring(50, 52); ////bufferOffset

                        // Record
                        if (!(HDR.equals("HDR"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "HDR2 record starts with Other than HDR;";
                        }
                        //Label
                        if (!(lblNo.equals("2"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Label in HDR2 record is Other than 2;";
                        }
                        //File ID
                        if (!(FileId.equals("F"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Identifier in HDR2 record is start with Other than F;";
                        }
                        //BlockLength
                        if (!(BlockLength.matches(("^[\\d]{5}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "BlockLength in HDR2 record is not in right format;";
                        }
                        //RecordLength
                        if (!(RecordLength.equals(("00100")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "RecordLength in HDR2 record is other than 00100;";
                        }
                        //bufferOffset
                        if (!(bufferOffset.equals(("00")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "bufferOffset in HDR2 record is other than 00;";
                        }


                    } else if (line == lines.get(3)) {    ////UHL1

                        String UHL1 = line.substring(0, 3); /////label identifier
                        String lblNo = line.substring(3, 4); ///////label number
                        String CurrDate = line.substring(5, 10); ///processing date
                        String RecPartyIDno = line.substring(10, 16); ///Receiving Party ID No
                        String currencyCode = line.substring(20, 22);//currencyCode
                        String countryCode = line.substring(22, 28);//countryCode
                        String workCode = line.substring(28, 35);//workCode
                        String fileNumber = line.substring(37, 40);//fileNumber

                        // Record
                        if (!(UHL1.equals("UHL"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "UHL1 record starts  with Other than HDR;";
                        }

                        //Label
                        if (!(lblNo.equals("1"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Label in UHL1 record is Other than 1;";
                        }

                        //CurrDate
                        if (!(CurrDate.matches("^[\\d]{5}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Current Date in UHL1 record is not in right format;";
                        }

                        //RecPartyIDno
                        if (!(RecPartyIDno.equals("999999"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Receiving party ID in UHL1 record is Other than 1;";
                        }

                        //currencyCode
                        if (!(currencyCode.equals("00"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "currencyCode in UHL1 record is Other than 00;";
                        }

                        //currencyCode
                        if (!(countryCode.equals("000000"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "countryCode in UHL1 record is Other than 000000;";
                        }

                        //currencyCode
                        if (!(workCode.equals("1 DAILY"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "1 DAILY in UHL1 record is not in right format;";
                        }

                        //fileNumber
                        if (!(fileNumber.equals("000"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Number in UHL1 record is not in right format;";
                        }


                    } else if (line.equals(lines.get(lines.size() - 3))) {  ////EOF1

                        String EOF = line.substring(0, 3); /////label identifier
                        String lblNo = line.substring(3, 4); ///////label number
                        String FileId = line.substring(4, 5); /////file identifier
                        String SumNo1 = line.substring(5, 11); /////SumNo
                        String S = line.substring(11, 12); /////S
                        String One = line.substring(14, 15); ////1
                        String SumNo2 = line.substring(15, 21); ////SumNo2
                        String setId1 = line.substring(21, 22); ////set identification
                        String setId2 = line.substring(22, 27); ////set identification
                        String fileSecNo = line.substring(27, 31); ////file section number
                        String fileSeqNo = line.substring(31, 35); ///file sequence number
                        String CreationDate = line.substring(42, 47); ////CreationDate
                        String ExpirationDate = line.substring(48, 53); ////ExpirationDate
                        String BlockCount = line.substring(54, 60); ////BlockCount


                        // Record
                        if (!(EOF.equals("EOF"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "EOF2 record starts  with Other than EOF;";
                        }

                        //Label
                        if (!(lblNo.equals("1"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Label in EOF record is Other than 1;";
                        }

                        //File ID
                        if (!(FileId.equals("A"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Identifier in EOF record is start with Other than A;";
                        }


                        //Sun number
                        if (!(SumNo1.equals("299650"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "SUN number in EOF record is start with Other than 299650;";
                        }

                        //Sun number
                        if (!(S.equals("S"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "12th position in EOF record is invalid;";
                        }

                        //One number
                        if (!(One.equals("1"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "13th position in EOF record is invalid;";
                        }

                        //Sun number
                        if (!(SumNo2.equals("B83255"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "SUN number in EOF record is start with Other than B83255;";
                        }


                        //SET ID
                        if (!(setId1.equals("D"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Set Identifier in EOF record is start with Other than D;";
                        }

                        //SET ID2
                        if (!(setId2.matches(("^[\\d]{5}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Set Identifier in EOF record is not in right format;";
                        }

                        //File Section Number
                        if (!(fileSecNo.matches(("^[\\d]{4}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Section Number in EOF record is not in right format;";
                        }

                        //File Sequence Number
                        if (!(fileSeqNo.matches(("^[\\d]{4}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Sequence Number in EOF record is is not in right format;";
                        }

                        //CreationDate
                        if (!(CreationDate.matches(("^[\\d]{5}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "CreationDate in EOF record is not in right format;";
                        }

                        //ExpirationDate
                        if (!(ExpirationDate.matches(("^[\\d]{5}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "ExpirationDate in EOF record is not in right format;";
                        }


                    } else if (line.equals(lines.get(lines.size() - 2))) {  //EOF2
                        String EOF = line.substring(0, 3); /////label identifier
                        String lblNo = line.substring(3, 4); ///////label number
                        String FileId = line.substring(4, 5); /////record format
                        String BlockLength = line.substring(5, 10); ////BlockLength
                        String RecordLength = line.substring(10, 15); ////recordLength
                        String bufferOffset = line.substring(50, 52); ////bufferOffset


                        // Record
                        if (!(EOF.equals("EOF"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "EOF2 record starts with Other than EOF;";
                        }
                        //Label
                        if (!(lblNo.equals("2"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Label in HDR2 record is Other than 2;";
                        }
                        //File ID
                        if (!(FileId.equals("F"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Identifier in HDR2 record is start with Other than F;";
                        }
                        //BlockLength
                        if (!(BlockLength.matches(("^[\\d]{5}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "BlockLength in HDR2 record is not in right format;";
                        }
                        //RecordLength
                        if (!(RecordLength.equals(("00100")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "RecordLength in HDR2 record is other than 00100;";
                        }
                        //bufferOffset
                        if (!(bufferOffset.equals(("00")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "bufferOffset in HDR2 record is other than 00;";
                        }


                    } else if (line.equals(lines.get(lines.size() - 1))) {   //UTL

                        String UTL = line.substring(0, 3); /////label identifier
                        String lblNo = line.substring(3, 4); ///////label number
                        String ZeroFilled = line.substring(4, 44); ///ZeroFilled
                        String DDICount = line.substring(52, 59); ///DDICount
                        String DDICountAftRemZeros = DDICount.replaceFirst("^0*", "");

                        // Record
                        if (!(UTL.equals("UTL"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "UTL record starts  with Other than UTL;";
                        }

                        //Label
                        if (!(lblNo.equals("1"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Label in HDR record is Other than 1;";
                        }

                        // ZeroFilledRecord
                        if (!(ZeroFilled.matches("^[0]{40}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "ZeroFilled in UTL record starts;";
                        }

                        int DDIRows = lines.size() - 7;
                        String StrDDIRows = Integer.toString(DDIRows);

                        if (!(DDICountAftRemZeros.equals(StrDDIRows))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "DDI Record count is not matached in UTL Record;";
                        } else if (!(DDICount.matches("^[\\d]{7}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "DDI Record count  in UTL record is not in right format;";

                        }


                    } else {
                        payerSortCode = line.substring(0, 6);///////payer's sorting code
                        payerAccntNo = line.substring(6, 14);/////payer's a/c number
                        payerAccntType = line.substring(14, 15);/////payer's account type
                        tnxCode = line.substring(15, 17);///transaction code
                        OrigSrtCode = line.substring(17, 23);///originating sorting code
                        OrigAccntNo = line.substring(23, 31);///originating account code
                        Zeroes = line.substring(35, 46);///Amount
                        OrigName = line.substring(46, 64);///ORIGINATOR_ACCOUNT_NAME
                        Reference = line.substring(64, 82).trim();/////REFERENCE
                        PayerName = line.substring(82, 101);/////PAYER_OR_DEST_ACCOUNT_NAME
                        delimiter = line.substring(101, 106);/////PAYER_OR_DEST_ACCOUNT_NAME

                        if (!payerSortCode.matches("^[\\d]{6}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " PayerSortCode in Instruction record is not in right format;";

                        }

                        if (!payerAccntNo.matches("^[\\d]{6,8}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " PayerAccntNo in Instruction record is not in right format;";

                        }
                        if (!payerAccntType.equals("0")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " PayerAccntType in Instruction record is other than 0;";

                        }

                        if (!(tnxCode.equals("0N") || tnxCode.equals("0C") || tnxCode.equals("0S"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Transaction type in Instruction record is other than 0N/0C/0S;";

                        }

                        if (!OrigSrtCode.equals("160400")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " OriginatorSortCode in Instruction record is other than 160400;";

                        }
                        if (!OrigAccntNo.equals("31355461")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Originator Account number  in Instruction record is other than 31355461;";

                        }

                        if (!Zeroes.equals("00000000000")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Amount in Instruction record is not in right format;";

                        }

                        if (!OrigName.matches(regexMulNonDigit)) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Originator Name in Instruction record is not in right format;";

                        }
                        if (!Reference.matches(("^[\\d]{9}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Reference in Instruction record is not in right format;";

                        }
                        if (!PayerName.matches(("^(?=.*[a-zA-Z\\d\\s].*)[a-zA-Z\\d\\s]{1,}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " PayerName in Instruction record is not in right format;";

                        }
                        if (!delimiter.matches(("^[\\d]{5}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Delimiter in Instruction record is not in right format;";

                        }
                    }

                    String strFilename, strStatus, strReason, strLine;
                    if (fieldflag == 0) {
                        strFilename = file.getName();
                        strStatus = "PASS";
                        strReason = "All Fields are in right format";
                        strLine = Integer.toString(linenumber);
                        reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                    } else {
                        lineflag = lineflag + 1;
                        if (fieldflag == 1) {

                            strFilename = file.getName();
                            strStatus = "FAIL";
                            strReason = fieldflag + " field is not in right format. Reason :" + Fieldfailure;
                            strLine = Integer.toString(linenumber);
                            reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                        } else {
                            strFilename = file.getName();
                            strStatus = "FAIL";
                            strReason = fieldflag + " fields is not in right format. Reason :" + Fieldfailure;
                            strLine = Integer.toString(linenumber);
                            reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                        }
                    }
                }

                if (lineflag == 0) {
                    if (lines.size() == 1) {
                    } else {
                    }
                } else {
                    if (lineflag == 1) {
                    } else {
                    }
                }
            }
        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();

            throw (e);
        }
    }

    public void DDCValidateIntegrityCheck(String strFileName) throws Exception {

        try {
            File directory = new File("src\\test\\resources\\Integration\\DDC");
            //get all the files from a directory
            File[] fList = directory.listFiles();

            /*String filepath="src\\test\\resources\\Integration\\"+"DDCResults"+".xls";
            String strFilePath="src\\test\\resources\\Integration\\";
            String strFileName="DDCResults";
            String strSheetName="DDCIntegrity";
            reportUtil.createExcelReport(strFilePath,strFileName,strSheetName);*/

            String filepath = "target\\" + strFileName + ".xls";
            String strFilePath = "target\\";
            String strSheetName = "DDCIntegrity";
            reportUtil.createExcelConsolidatedReport(strFilePath, strFileName, strSheetName);


            for (File file : fList) {


                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));

                int lineflag = 0;
                int linenumber = 0;

                int Sum1 = 0;
                int Sum2 = 0;
                String payerAccntNo = "";
                String payerAccntType = "";

                String destSortCode = "";
                String destAccntNo = "";
                String destAccntType = "";
                String tnxCode = "";
                String OrigSrtCode = "";
                String OrigAccntNo = "";
                String Amountt = "";
                String OrigName = "";
                String Reference = "";
                String PayerName = "";
                String payerSortCode = "";

                String NinetyNineTnxCode = "";
                String ZeroOneTnxCode = "";
                int Count1 = 0;
                int Count2 = 0;
                int CountC1 = 0;
                int CountC2 = 0;


                for (String line : lines) {

                    int fieldflag = 0;
                    String Fieldfailure = "";
                    linenumber = linenumber + 1;

                    List result1 = Arrays.asList(line.split("\\ "));

                    /************ Header Validation *************/
                    if (line == lines.get(0)) {

                        String vol = line.substring(0, 3); ///////Volume Identifier
                        String lblNo = line.substring(3, 4); ///////label number
                        String submSerialNo1 = line.substring(4, 5); ///////submission SerialNo1
                        String submSerialNo2 = line.substring(5, 10); ///////submission SerialNo2
                        String sumNo = line.toString().substring(41, 47);  ///////sumNo
                        String lblStdLvl = line.substring(79, 80);  //////label standard level


                        // Record
                        if (!(vol.equals("VOL"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Volume record starts  with Other than VOL;";
                        }
                        // lblNo Record
                        if (!(lblNo.equals("1"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Label number in Volume record is Other than 1;";
                        }

                        // submSerialNo1
                        if (!(submSerialNo1.equals("P"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Submission Serial is other than P;";
                        }

                        // Card submSerialNo2
                        if (!(submSerialNo2.matches("^[\\d]{5}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Submission Serial is not in right format;";
                        }

                        // sumnumber
                        if (!(sumNo.equals("B83255"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "SUN number is other than B83255;";
                        }

                        // label
                        if (!(lblStdLvl.equals("1"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Label standard level is other than 1;";
                        }


                    } else if (line == lines.get(1)) {    ////HDR1

                        String HDR = line.substring(0, 3); /////label identifier
                        String lblNo = line.substring(3, 4); ///////label number
                        String FileId = line.substring(4, 5); /////file identifier
                        String SumNo1 = line.substring(5, 11); /////SumNo
                        String S = line.substring(11, 12); /////S
                        String One = line.substring(14, 15); ////1
                        String SumNo2 = line.substring(15, 21); ////SumNo2
                        String setId1 = line.substring(21, 22); ////set identification
                        String setId2 = line.substring(22, 27); ////set identification
                        String fileSecNo = line.substring(27, 31); ////file section number
                        String fileSeqNo = line.substring(31, 35); ///file sequence number
                        String CreationDate = line.substring(42, 47); ////CreationDate
                        String ExpirationDate = line.substring(48, 53); ////ExpirationDate
                        String BlockCount = line.substring(54, 60); ////BlockCount


                        // Record
                        if (!(HDR.equals("HDR"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "HDR1 record starts  with Other than HDR;";
                        }

                        //Label
                        if (!(lblNo.equals("1"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Label in HDR1 record is Other than 1;";
                        }

                        //File ID
                        if (!(FileId.equals("A"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Identifier in HDR1 record is start with Other than A;";
                        }

                        //Sun number
                        if (!(SumNo1.equals("299650"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "SUN number in HDR1 record is start with Other than 299650;";
                        }

                        //Sun number
                        if (!(S.equals("S"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "12th position in HDR1 record is invalid;";
                        }

                        //One number
                        if (!(One.equals("1"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "13th position in HDR1 record is invalid;";
                        }

                        //Sun number
                        if (!(SumNo2.equals("B83255"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "SUN number in HDR1 record is start with Other than B83255;";
                        }


                        //SET ID
                        if (!(setId1.equals("D"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Set Identifier in HDR1 record is start with Other than D;";
                        }

                        //SET ID2
                        if (!(setId2.matches(("^[\\d]{5}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Set Identifier in HDR1 record is start with Other than D;";
                        }

                        //File Section Number
                        if (!(fileSecNo.matches(("^[\\d]{4}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Section Number in HDR1 record is start with Other than D;";
                        }

                        //File Sequence Number
                        if (!(fileSeqNo.matches(("^[\\d]{4}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Sequence Number in HDR1 record is start with Other than D;";
                        }

                        //CreationDate
                        if (!(CreationDate.matches(("^[\\d]{5}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "CreationDate in HDR1 record is start with Other than D;";
                        }

                        //ExpirationDate
                        if (!(ExpirationDate.matches(("^[\\d]{5}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "ExpirationDate in HDR1 record is start with Other than D;";
                        }

                        //BlockCount
                        if (!(BlockCount.matches(("^[\\d]{6}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "BlockCount in HDR1 record is start with Other than D;";
                        }


                    } else if (line == lines.get(2)) {    ////HDR2

                        String HDR = line.substring(0, 3); /////label identifier
                        String lblNo = line.substring(3, 4); ///////label number
                        String FileId = line.substring(4, 5); /////record format
                        String BlockLength = line.substring(5, 10); ////BlockLength
                        String RecordLength = line.substring(10, 15); ////recordLength
                        String bufferOffset = line.substring(50, 52); ////bufferOffset


                        // Record
                        if (!(HDR.equals("HDR"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "HDR2 record starts with Other than HDR;";
                        }
                        //Label
                        if (!(lblNo.equals("2"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Label in HDR2 record is Other than 2;";
                        }
                        //File ID
                        if (!(FileId.equals("F"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Identifier in HDR2 record is start with Other than F;";
                        }
                        //BlockLength
                        if (!(BlockLength.matches(("^[\\d]{5}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "BlockLength in HDR2 record is not in right format;";
                        }
                        //RecordLength
                        if (!(RecordLength.equals(("00100")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "RecordLength in HDR2 record is other than 00100;";
                        }
                        //bufferOffset
                        if (!(bufferOffset.equals(("00")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "bufferOffset in HDR2 record is other than 00;";
                        }


                    } else if (line == lines.get(3)) {    ////UHL1

                        String UHL1 = line.substring(0, 3); /////label identifier
                        String lblNo = line.substring(3, 4); ///////label number
                        String CurrDate = line.substring(5, 10); ///processing date
                        String RecPartyIDno = line.substring(10, 16); ///Receiving Party ID No
                        String currencyCode = line.substring(20, 22);//currencyCode
                        String countryCode = line.substring(22, 28);//countryCode
                        String workCode = line.substring(28, 35);//workCode
                        //String workCode1 = result1.get(6).toString().substring(37, 40);//workCode1
                        String fileNumber = line.substring(37, 40);//fileNumber


                        // Record
                        if (!(UHL1.equals("UHL"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "UHL1 record starts  with Other than HDR;";
                        }

                        //Label
                        if (!(lblNo.equals("1"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Label in UHL1 record is Other than 1;";
                        }

                        //CurrDate
                        if (!(CurrDate.matches("^[\\d]{5}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Current Date in UHL1 record is not in right format;";
                        }

                        //RecPartyIDno
                        if (!(RecPartyIDno.equals("999999"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Receiving party ID in UHL1 record is Other than 1;";
                        }

                        //currencyCode
                        if (!(currencyCode.equals("00"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "currencyCode in UHL1 record is Other than 00;";
                        }

                        //currencyCode
                        if (!(countryCode.equals("000000"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "countryCode in UHL1 record is Other than 000000;";
                        }

                        //currencyCode
                        if (!(workCode.equals("1 DAILY"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "1 DAILY in UHL1 record is not in right format;";
                        }

                        //fileNumber
                        if (!(fileNumber.equals("000"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Number in UHL1 record is not in right format;";
                        }


                    } else if (line.equals(lines.get(lines.size() - 3))) {  ////EOF1

                        String EOF = line.substring(0, 3); /////label identifier
                        String lblNo = line.substring(3, 4); ///////label number
                        String FileId = line.substring(4, 5); /////file identifier
                        String SumNo1 = line.substring(5, 11); /////SumNo
                        String S = line.substring(11, 12); /////S
                        String One = line.substring(14, 15); ////1
                        String SumNo2 = line.substring(15, 21); ////SumNo2
                        String setId1 = line.substring(21, 22); ////set identification
                        String setId2 = line.substring(22, 27); ////set identification
                        String fileSecNo = line.substring(27, 31); ////file section number
                        String fileSeqNo = line.substring(31, 35); ///file sequence number
                        String CreationDate = line.substring(42, 47); ////CreationDate
                        String ExpirationDate = line.substring(48, 53); ////ExpirationDate
                        String BlockCount = line.substring(54, 60); ////BlockCount


                        // Record
                        if (!(EOF.equals("EOF"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "EOF2 record starts  with Other than EOF;";
                        }

                        //Label
                        if (!(lblNo.equals("1"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Label in EOF record is Other than 1;";
                        }

                        //File ID
                        if (!(FileId.equals("A"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Identifier in EOF record is start with Other than A;";
                        }


                        //Sun number
                        if (!(SumNo1.equals("299650"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "SUN number in EOF record is start with Other than 299650;";
                        }

                        //Sun number
                        if (!(S.equals("S"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "12th position in EOF record is invalid;";
                        }

                        //One number
                        if (!(One.equals("1"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "13th position in EOF record is invalid;";
                        }

                        //Sun number
                        if (!(SumNo2.equals("B83255"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "SUN number in EOF record is start with Other than B83255;";
                        }


                        //SET ID
                        if (!(setId1.equals("D"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Set Identifier in EOF record is start with Other than D;";
                        }

                        //SET ID2
                        if (!(setId2.matches(("^[\\d]{5}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Set Identifier in EOF record is not in right format;";
                        }

                        //File Section Number
                        if (!(fileSecNo.matches(("^[\\d]{4}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Section Number in EOF record is not in right format;";
                        }

                        //File Sequence Number
                        if (!(fileSeqNo.matches(("^[\\d]{4}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Sequence Number in EOF record is is not in right format;";
                        }

                        //CreationDate
                        if (!(CreationDate.matches(("^[\\d]{5}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "CreationDate in EOF record is not in right format;";
                        }

                        //ExpirationDate
                        if (!(ExpirationDate.matches(("^[\\d]{5}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "ExpirationDate in EOF record is not in right format;";
                        }


                    } else if (line.equals(lines.get(lines.size() - 2))) {  //EOF2

                        String EOF = line.substring(0, 3); /////label identifier
                        String lblNo = line.substring(3, 4); ///////label number
                        String FileId = line.substring(4, 5); /////record format
                        String BlockLength = line.substring(5, 10); ////BlockLength
                        String RecordLength = line.substring(10, 15); ////recordLength
                        String bufferOffset = line.substring(50, 52); ////bufferOffset

                        // Record
                        if (!(EOF.equals("EOF"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "EOF2 record starts with Other than EOF;";
                        }
                        //Label
                        if (!(lblNo.equals("2"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Label in HDR2 record is Other than 2;";
                        }
                        //File ID
                        if (!(FileId.equals("F"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "File Identifier in HDR2 record is start with Other than F;";
                        }
                        //BlockLength
                        if (!(BlockLength.matches(("^[\\d]{5}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "BlockLength in HDR2 record is not in right format;";
                        }
                        //RecordLength
                        if (!(RecordLength.equals(("00100")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "RecordLength in HDR2 record is other than 00100;";
                        }
                        //bufferOffset
                        if (!(bufferOffset.equals(("00")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "bufferOffset in HDR2 record is other than 00;";
                        }


                    } else if (line.equals(lines.get(lines.size() - 1))) {   //UTL


                        String UTL = line.substring(0, 3); /////label identifier
                        String lblNo = line.substring(3, 4); ///////label number
                        String Debit = line.substring(4, 17); ///Total Debit value
                        String Credit = line.substring(17, 30); ///Total Credit value
                        String Digits = line.substring(30, 37); ///ZeroFilled
                        String CountDebit = line.substring(30, 37); ///CountUTL1
                        String CountCredit = line.substring(37, 44); ///CountUTL2
                        String DDICount = line.substring(52, 59); ///DDICount


                        // Record
                        if (!(UTL.equals("UTL"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "UTL record starts  with Other than UTL;";
                        }

                        //Label
                        if (!(lblNo.equals("1"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Label in UTL record is Other than 1;";
                        }

                        //Debit
                        if (!(Debit.matches(("^[\\d]{13}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Debit in UTL record is not in right format;";
                        }

                        //Credit
                        if (!(Credit.matches(("^[\\d]{13}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Credit in UTL record is not in right format;";
                        }

                        //Debit
                        if (!(CountDebit.matches(("^[\\d]{7}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Debitcount in UTL record is not in right format;";
                        }

                        //Credit
                        if (!(CountCredit.matches(("^[\\d]{7}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Creditcount in UTL record is not in right format;";
                        }

                        //DDICount
                        if (!(DDICount.matches(("^[0]{7}$")))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "DDICount in UTL record is not in right format;";
                        }


                    } else if (line.contains("CONTRA")) {
                        String[] result2 = line.split("\\s\\s");

                        destSortCode = line.substring(0, 6);///////dest's sorting code
                        destAccntNo = line.substring(6, 14);/////dest a/c number
                        destAccntType = line.substring(14, 15);/////payer's account type
                        tnxCode = line.substring(15, 17);///transaction code
                        OrigSrtCode = line.substring(17, 23);///originating sorting code
                        OrigAccntNo = line.substring(23, 31);///originating account code
                        Amountt = line.substring(35, 46);//
                        OrigName = line.substring(46, 64).trim();///Narrative
                        Reference = line.substring(64, 82).trim();/////REFERENCE
                        PayerName = line.substring(82, 100);//PayersName


                        if (!destSortCode.equals("160400")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Destination SortCode in CONTRA record is other than 160400;";

                        }
                        if (!destAccntNo.equals("31355461")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Destination Account number  in CONTRA record is other than 31355461;";

                        }
                        if (!destAccntType.equals("0")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Destination Account Type  in CONTRA record is other than 0;";

                        }

                        if (!(tnxCode.equals("17") || tnxCode.equals("99"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Transaction Code in CONTRA record is other than 17/99;";

                        }

                        if (!OrigSrtCode.matches(("^[\\d]{6}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Orginator SortCode in CONTRA record is other than 160400;";

                        }
                        if (!OrigAccntNo.matches(("^[\\d]{8}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Orginator Account number  in CONTRA record is other than 31355461;";

                        }

                        if (!Amountt.matches(("^[\\d]{11}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Amount number in CONTRA record is not in right format;";

                        }

                        if (!OrigName.matches(("^[\\d]{6}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Narrative  in CONTRA record is not in right format;";

                        }

                        if (!Reference.equals(("CONTRA"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " CONTRA identification in CONTRA record is other than CONTRA;";

                        }

                        if (!PayerName.equals(("UK Insurance Limit"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Payer Name in CONTRA record is other than UK Insurance Limit;";

                        }
                    } else {
                        String[] result2 = line.split("\\s\\s");

                        payerSortCode = line.substring(0, 6);///////payer's sorting code
                        payerAccntNo = line.substring(6, 14);/////payer's a/c number
                        payerAccntType = line.substring(14, 15);/////payer's account type
                        tnxCode = line.substring(15, 17);///transaction code
                        OrigSrtCode = line.substring(17, 23);///originating sorting code
                        OrigAccntNo = line.substring(23, 31);///originating account code
                        Amountt = line.substring(35, 46);///Amount
                        OrigName = line.substring(46, 64);///ORIGINATOR_ACCOUNT_NAME
                        Reference = line.substring(64, 82).trim();/////REFERENCE
                        PayerName = line.substring(82, 100);/////PAYER_OR_DEST_ACCOUNT_NAME

                        if (!payerSortCode.matches("^[\\d]{6}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " PayerSortCode in Instruction record is not in right format;";

                        }

                        if (!payerAccntNo.matches("^[\\d]{6,8}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " PayerAccntNo in Instruction record is not in right format;";

                        }
                        if (!payerAccntType.equals("0")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " PayerAccntType in Instruction record is other than 0;";

                        }

                        if (!(tnxCode.equals("01") || tnxCode.equals("17") || tnxCode.equals("18") || tnxCode.equals("19") || tnxCode.equals("99"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Transaction type in Instruction record is other than 01/17/18/19/99;";

                        }

                        if (!OrigSrtCode.equals("160400")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " OriginatorSortCode in Instruction record is other than 160400;";

                        }
                        if (!OrigAccntNo.equals("31355461")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Originator Account number  in Instruction record is other than 31355461;";

                        }

                        if (!Amountt.matches(("^[\\d]{11}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Amount in Instruction record is not in right format;";

                        }

                        if (!OrigName.matches(regexMulNonDigit)) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Originator Name in Instruction record is not in right format;";

                        }

                        if (!Reference.matches(("[\\d{9}]-[\\d+]-"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " Reference in Instruction record is not in right format;";

                        }
                        if (!PayerName.matches(("^(?=.*[a-zA-Z\\d\\s].*)[a-zA-Z\\d\\s]{1,}$"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + " PayerName in Instruction record is not in right format;";

                        }

                    }


                    String strFilename, strStatus, strReason, strLine;
                    if (fieldflag == 0) {
                        strFilename = file.getName();
                        strStatus = "PASS";
                        strReason = "All Fields are in right format";
                        strLine = Integer.toString(linenumber);
                        reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                    } else {
                        lineflag = lineflag + 1;
                        if (fieldflag == 1) {

                            strFilename = file.getName();
                            strStatus = "FAIL";
                            strReason = fieldflag + " field is not in right format. Reason :" + Fieldfailure;
                            strLine = Integer.toString(linenumber);
                            reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);

                        } else {
                            strFilename = file.getName();
                            strStatus = "FAIL";
                            strReason = fieldflag + " fields is not in right format. Reason :" + Fieldfailure;
                            strLine = Integer.toString(linenumber);
                            reportUtil.excelwriteReport(filepath, strSheetName, strFilename, strLine, strStatus, strReason);
                        }
                    }
                }
                if (lineflag == 0) {
                    if (lines.size() == 1) {
                    } else {
                    }
                } else {
                    if (lineflag == 1) {
                    } else {
                    }
                }
            }
        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();
            throw (e);
        }
    }

    //Julian Date for Integration
    public String convertToJulian(String unformattedDate, String format) {
        String dayS = "", monthS = "", yearS = "";

        switch (format) {
            case "YYYYMMDD":
                dayS = unformattedDate.substring(6, 8);
                monthS = unformattedDate.substring(4, 6);
                yearS = unformattedDate.substring(0, 4);
                break;
            case "DDMMYYYY":
                dayS = unformattedDate.substring(0, 2);
                monthS = unformattedDate.substring(2, 4);
                yearS = unformattedDate.substring(4, 8);
                break;

        }
    /*Unformatted Date: ddmmyyyy*/
        String julianDate = "";
        String julianDateVal = "";
        int resultJulian = 0;
        if (unformattedDate.length() > 0) {
     /*Days of month*/
            int[] monthValues = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};



     /*Convert to Integer*/
            int day = Integer.valueOf(dayS);
            int month = Integer.valueOf(monthS);
            int year = Integer.valueOf(yearS);

            //Leap year check
            if (year % 4 == 0) {
                monthValues[1] = 29;
            }
            //Start building Julian date
            //julianDate = "1";
            //last two digit of year: 2012 ==> 12
            julianDate += yearS.substring(2, 4);

            int julianDays = 0;
            for (int i = 0; i < month - 1; i++) {
                julianDays += monthValues[i];
            }
            julianDays += day;

            if (String.valueOf(julianDays).length() < 2) {
                julianDate += "00";
            }
            if (String.valueOf(julianDays).length() < 3) {
                julianDate += "0";
            }


            julianDate += String.valueOf(julianDays);
            resultJulian = Integer.valueOf(julianDate) + 1;
            julianDateVal += String.valueOf(julianDays);

        }

        return julianDateVal;
    }

    public void inteliimatchValidateIntegrityCheck1(String strFileName) throws Exception {


        try {
            File directory = new File("src\\test\\resources\\Integration\\Intellimatch");
            //get all the files from a directory
            File[] fList = directory.listFiles();

/*
            String filepath="src\\test\\resources\\Integration\\"+"IntellimatchResults"+".xls";
            String strFilePath="src\\test\\resources\\Integration\\";
            String strFileName="IntellimatchResults";
            String strSheetName="IntellimatchIntegrity";
            reportUtil.createExcelReport(strFilePath,strFileName,strSheetName);
*/
            String filepath = "target\\" + strFileName + ".xls";
            String strFilePath = "target\\";
            String strSheetName = "IntellimatchIntegrity";
            reportUtil.createExcelConsolidatedReport(strFilePath, strFileName, strSheetName);


            for (File file : fList) {
                ArrayList<ArrayList<String>> outputArray = new ArrayList<ArrayList<String>>();
                int outputval = 0;

                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));


                int lineflag = 0;
                int linenumber = 1;
                for (String line : lines) {
                    int lineval = 0;
                    String[] result1 = line.split("\\|");

                    int fieldsSize = result1.length;
                    String StrfieldsSize = Integer.toString(fieldsSize);
                    int fieldflag = 0;
                    String Fieldfailure = "";
                    if (line != lines.get(0)) {
                        linenumber = linenumber + 1;

                        //*****************Integrity Check******************//

                        //D Record
                        if (!result1[0].equals("D")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "D is not available in the record type;";
                        }
                        //DLGAccountnumber Record
                        if (!result1[1].equals("31355461")) {
                            fieldflag += 1;
                            Fieldfailure = Fieldfailure + "Account number 31355461 is not available;";
                        }

                        //Posting Date
                        if (!result1[2].matches("^(0?[1-9]|[12][\\d]|3[01])[\\/\\-](0?[1-9]|1[012])[\\/\\-]\\d{4}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Posting date is not in the right format;";
                        }
                        //Transactiondate
                        if (!result1[3].matches("^(0?[1-9]|[12][\\d]|3[01])[\\/\\-](0?[1-9]|1[012])[\\/\\-]\\d{4}$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Transaction date is not in the right format;";
                        }
                        //Amount
                        if (!result1[4].matches("^-?\\d+(\\.\\d{1,2})?$")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Amount is not in the right format;";
                        }
                        //Transactiontype
                        if (!(result1[5].equals("PAYMENT_CASH") || result1[5].equals("RECEIPT_CASH"))) {

                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Transactiontype is other than PAYMENT_CASH/RECEIPT_CASH;";
                        }
                        //Credit/Debit
                        if (!(result1[6].equals("CR") || result1[6].equals("DR"))) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Credit/Debit is other than CR/DR;";
                        }
                        //GBP
                        if (!result1[7].equals("GBP")) {
                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Currency other than GBP is available;";
                        }

                        try {
                            String[] reference = result1[9].split("-");

                            if (!(reference[0].equals("DL4BEVOWEB") ||
                                    reference[0].equals("DL4BEVOPHONE") ||
                                    reference[0].equals("DL4BEVORENEW") ||
                                    reference[0].equals("Reverse") ||
                                    reference[0].equals("299650"))) {

                                fieldflag = fieldflag + 1;
                                Fieldfailure = Fieldfailure + "Channel in Transaction Reference is not in the defined format;";
                                if (!(reference[1].equals("American Express") ||
                                        reference[1].equals("MasterCard") ||
                                        reference[1].equals("Visa") ||
                                        reference[1].equals("BACS"))) {

                                    Fieldfailure = Fieldfailure + "Payment type in Transaction Reference is not in the defined format;";
                                }
                            } else if (!(reference[1].equals("American Express") ||
                                    reference[1].equals("MasterCard") ||
                                    reference[1].equals("Visa") ||
                                    reference[1].equals("BACS"))) {

                                fieldflag = fieldflag + 1;
                                Fieldfailure = Fieldfailure + "Payment type in Transaction Reference is not in the defined format;";
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                        //PaymentMethod
                        if (!(result1[10].equals("Card") || result1[10].equals("Direct debit"))) {

                            fieldflag = fieldflag + 1;
                            Fieldfailure = Fieldfailure + "Payment method is other than card/Direct debit;";
                        }

                        //Assert.assertTrue(StrfieldsSize.equals("11"));//no of fields validation
                        String strFilename, strStatus, strReason, strLine;
                        if (fieldflag == 0) {
                            strFilename = file.getName();
                            strStatus = "PASS";
                            strReason = "All Fields are in right format";
                            strLine = Integer.toString(linenumber);
                            //reportUtil.excelwriteReport(filepath,strSheetName,strFilename,strLine,strStatus,strReason);
                            ArrayList<String> lineresult = new ArrayList<String>();
                            lineresult.add(0, strFilename);
                            lineresult.add(1, strLine);
                            lineresult.add(2, strStatus);
                            lineresult.add(3, strReason);
                            outputArray.add(outputval++, lineresult);


                        } else {
                            lineflag = lineflag + 1;
                            if (fieldflag == 1) {

                                strFilename = file.getName();
                                strStatus = "FAIL";
                                strReason = fieldflag + " field is not in right format. Reason :" + Fieldfailure;
                                strLine = Integer.toString(linenumber);
                                //reportUtil.excelwriteReport(filepath,strSheetName,strFilename,strLine,strStatus,strReason);

                                ArrayList<String> lineresult = new ArrayList<String>();
                                lineresult.add(0, strFilename);
                                lineresult.add(1, strLine);
                                lineresult.add(2, strStatus);
                                lineresult.add(3, strReason);
                                outputArray.add(outputval++, lineresult);


                            } else {
                                strFilename = file.getName();
                                strStatus = "FAIL";
                                strReason = fieldflag + " fields is not in right format. Reason :" + Fieldfailure;
                                strLine = Integer.toString(linenumber);
                                //reportUtil.excelwriteReport(filepath,strSheetName,strFilename,strLine,strStatus,strReason);

                                ArrayList<String> lineresult = new ArrayList<String>();
                                lineresult.add(0, strFilename);
                                lineresult.add(1, strLine);
                                lineresult.add(2, strStatus);
                                lineresult.add(3, strReason);
                                outputArray.add(outputval++, lineresult);
                            }
                        }
                    }
                }
                if (lineflag == 0) {
                    if (lines.size() == 1) {
                    } else {
                    }
                } else {
                    if (lineflag == 1) {
                    } else {
                    }
                }
                reportUtil.excelwriteReportList(filepath, strSheetName, outputArray);
            }
        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();
            throw (e);
        }
    }

    public void ELTOCheck(String currentInsurerID, String OriginalInsurerID, String Policyno, String PolicyHoldername, String EmployerName, String coverStartDate, String coverEndDate, String Address, String YesNo) throws Exception {
        try {

            File directory = new File("src\\test\\resources\\Integration\\ELTO");
            //get all the files from a directory
            File[] fList = directory.listFiles();

            for (File file : fList) {


                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));
                //reportUtil.createExcel("src\\test\\resources\\Integration\\IntegrationResults.xls");


                //List<String> lines = Files.readAllLines(Paths.get("C:\\Users\\470774\\Desktop\\Pradeep\\ELTO.txt"));

                ArrayList<String> al = new ArrayList<String>();
                for (String line : lines) {

                    List result1 = Arrays.asList(line.split("\\ "));
                    List result2 = Arrays.asList(line.split("\\,"));


                    String AddressList[] = Address.split(",");

                    /************ Header Validation *************/////////////////
                    if (line == lines.get(0)) {

/*                        String first = result1.get(0).toString().substring(0, 1);
                        String firstLength = Integer.toString(first.length());
                        String second = result1.get(0).toString().substring(1, 2);
                        String secondLength = Integer.toString(second.length());
                        String third = result1.get(0).toString().substring(2, 6);
                        String thirdLength = Integer.toString(third.length());
                        String fourth = result1.get(0).toString().substring(6, 7);
                        String fourthLength = Integer.toString(fourth.length());
                        String fifth = result1.get(0).toString().substring(7, 11);
                        String sixth = result1.get(0).toString().substring(11, 15);
                        String sixthLength = Integer.toString(sixth.length());
                        String seventh = result1.get(0).toString().substring(15, 24);
                        String eigth = result1.get(200).toString().substring(0, 8);
                        String ninth = result1.get(200).toString().substring(8, 12);
                        String ninthLength = Integer.toString(ninth.length());
                        String tenth = result1.get(200).toString().substring(12, 13);
                        String tenthLength = Integer.toString(tenth.length());*/

                        String first = line.substring(0, 1);
                        String second = line.substring(1, 2);
                        String third = line.substring(2, 6);
                        String fourth = line.substring(6, 7);
                        String fifth = line.substring(7, 11);
                        String sixth = line.substring(11, 15);
                        String seventh = line.substring(15, 24);
                        String eigth = line.substring(224, 232);
                        String ninth = line.substring(232, 236);
                        String tenth = line.substring(236, 237);



                       /* *//***Integrity Check****//*
                        stringCompare("Integration_Results", firstLength, ("1"));
                        stringCompare("Integration_Results", secondLength, ("1"));
                        stringCompare("Integration_Results", thirdLength, ("4"));
                        stringCompare("Integration_Results", fourthLength, ("1"));
                        stringCompare("Integration_Results", sixthLength, ("4"));
                        stringCompare("Integration_Results", ninthLength, ("4"));
                        stringCompare("Integration_Results", tenthLength, ("1"));
                        stringMatchCompare("Integration_Results", third, (regexMulDigits));
                        stringMatchCompare("Integration_Results", fourth, (regexSingleNonDigit));
                        stringMatchCompare("Integration_Results", fifth, (regexMulDigits));
                        stringMatchCompare("Integration_Results", fifth, ("^[\\d]{4}$"));
                        Assert.assertTrue(!fifth.isEmpty());
                        Assert.assertTrue(!sixth.isEmpty());
                        stringMatchCompare("Integration_Results", seventh, ("^[\\d]{9}$"));
                        stringMatchCompare("Integration_Results", eigth, ("^[\\d]{8}$"));
                        stringMatchCompare("Integration_Results", ninth, ("^[\\d]{4}$"));
*/

                        /*****Accuracy Check*****/
                       /* stringCompare("Integration_Results", "Record Type", first, ("H")); //Header Record Type
                        stringCompare("Integration_Results", "File Type", second, ("C")); //File Type
                        stringCompare("Integration_Results", "Version Number", third, ("0001"));//File Version Number
*/
                        //Supplier Type
                        if (fourth.equals("I")) {
                            /*stringCompare("Integration_Results", "Supplier Type", fourth, ("I"));*/
                        } else {
                           /* stringCompare("Integration_Results", "Supplier Type", fourth, ("D"));*/
                        }
/*

                        stringCompare("Integration_Results", "Sequence Number", seventh, ("000000001"));//File Sequence Number
                        stringCompare("Integration_Results", "System date", eigth, ("20170906"));//need to update system date
                        stringCompare("Integration_Results", "Version", ninth, ("1624"));//need to update system date_time
                        stringCompare("Integration_Results", "Value", tenth, ("#"));
*/

                    } else if (line.equals(lines.get(lines.size() - 1))) {

                       /* String first = result1.get(0).toString().substring(0, 1);
                        String firstLength = Integer.toString(first.length());
                        String second = result1.get(0).toString().substring(1, 10);
                        String third = result1.get(0).toString().substring(10, 19);
                        String ThirdAftRemZeros = third.replaceFirst("^0*", "");
                        String fourth = result1.get(0).toString().substring(19, 20);*/

                        String first = line.substring(0, 1);
                        String second = line.substring(1, 10);
                        String third = line.substring(10, 19);
                        String ThirdAftRemZeros = third.replaceFirst("^0*", "");
                        String fourth = line.substring(19, 20);

                        /***Integrity Check****/
/*
                        stringCompare("Integration_Results", firstLength, ("1"));
                        stringMatchCompare("Integration_Results", second, ("^[\\d]{9}$"));
                        stringMatchCompare("Integration_Results", third, ("^[\\d]{9}$"));
*/


                       /* *//*****Accuracy Check*****//*
                        stringCompare("Integration_Results", "Trailer Record Type", first, ("T")); // Trailer Record Type
                        stringCompare("Integration_Results", "Sequnce Number", second, ("000000001"));//File Sequence Number

                        String strLineSize = Integer.toString(lines.size());
                        stringCompare("Integration_Results", "Data Record", ThirdAftRemZeros, (strLineSize));//Data Record Count
                        stringCompare("Integration_Results", "value", fourth, ("#"));*/


                    } else {
                        String policyNumberfield = line.substring(34, 43);
                        if (policyNumberfield.contains(Policyno)) {

                            stringCompare("Integration_Results", "Policyno", Policyno, policyNumberfield);//////BatchReference
                            /*String first = result1.get(0).toString().substring(0, 1);
                            String firstLength = Integer.toString(first.length());
                            String second = result1.get(0).toString().substring(1, 10);
                            String third = result1.get(0).toString().substring(10, 14);
                            String fourth = result1.get(0).toString().substring(14, 18);
                            String fifth = result1.get(0).toString().substring(34, 43);
                            String sixth = result1.get(30).toString().substring(0, 1);
                            String seventh = result1.get(30).toString().substring(1, 2);
                            String eighth = result1.get(30).toString().substring(2);
                            String ninth = result1.get(275).toString().trim();
                            String tenth = result1.get(520).toString().substring(0, 8);
                            String eleventh = result1.get(520).toString().substring(8, 16);
                            String Address1 = result2.get(0).toString().substring(1141);
                            String Address2 = result2.get(1).toString();
                            String Address3[] = result2.get(2).toString().split("\\s\\s");
                            */

                            String first = line.substring(0, 1);
                            String second = line.substring(1, 10);
                            String third = line.substring(10, 14);
                            String fourth = line.substring(14, 18);
                            String fifth = line.substring(34, 43);
                            String sixth = line.substring(73, 74);
                            String seventh = line.substring(74, 75);
                            String eighth = line.substring(75, 325);
                            String ninth = line.substring(325, 575);
                            String tenth = line.substring(575, 583);
                            String eleventh = line.substring(583, 591);
                            String fullAddress = line.substring(1141, 1265);
                            String strEPRN = line.substring(1751, 1761).trim();
                            String strTrailer = line.substring(1773, 1774);


/*

                            */
/***Integrity Check****//*

                            stringCompare("Integration_Results", firstLength, ("1"));
                            stringCompare("Integration_Results", first, ("P")); // Record Type
                            stringMatchCompare("Integration_Results", second, ("^[\\d]{9}$"));
                            stringCompare("Integration_Results", second, ("000000001"));//File Sequence Number
                            stringMatchCompare("Integration_Results", third, ("^[\\d]{4}$"));
                            stringMatchCompare("Integration_Results", fourth, ("^[\\d]{4}$"));
                            stringMatchCompare("Integration_Results", fifth, ("^[\\d]{25}$"));
                            stringMatchCompare("Integration_Results", sixth, (regexSingleNonDigit));
                            stringCompare("Integration_Results", sixth, ("N"));//Dummy Policy Flag
                            stringMatchCompare("Integration_Results", seventh, (regexSingleNonDigit));
                            stringCompare("Integration_Results", seventh, ("P"));//Policy Type
                            stringMatchCompare("Integration_Results", tenth, ("^[\\d]{8}$"));
                            stringMatchCompare("Integration_Results", eleventh, ("^[\\d]{8}$"));
*/

                            /*****Accuracy Check*****/
                            stringCompare("Integration_Results", "Record Type", first, ("P")); // Record Type
                            stringCompare("Integration_Results", "Sequence Number", second, ("000000001"));//File Sequence Number
                            stringCompare("Integration_Results", "currentInsurerID", third, (currentInsurerID));//currentInsurerID
                            stringCompare("Integration_Results", "OriginalInsurerID", fourth, (OriginalInsurerID));//OriginalInsurerID
                            stringCompare("Integration_Results", "PolicyNumber", fifth, (Policyno));//Policyno
                            stringCompare("Integration_Results", "Dummy Policy Flag", sixth, ("N"));//Dummy Policy Flag
                            stringCompare("Integration_Results", "Policy Type", seventh, ("P"));//Policy Type
                            stringCompare("Integration_Results", "PolicyHoldername", eighth, (PolicyHoldername));//PolicyHoldername
                            stringCompare("Integration_Results", "EmployerName", ninth, (EmployerName));//EmployerName
                            stringMatchCompare("Integration_Results", "coverStartDate", tenth, (coverStartDate));//coverStartDate
                            stringMatchCompare("Integration_Results", "coverEndDate", eleventh, (coverEndDate));//coverEndDate

                            /*stringCompare("Integration_Results", "Address1 validation", Address1, (AddressList[0]));//Address1 validation
                            stringCompare("Integration_Results", "Address2 validation", Address2, (AddressList[1]));//Address2 validation
                            stringCompare("Integration_Results", "Address3 validation", Address3[0], (AddressList[2]));//Address3 validation
*/
                            if (strEPRN.contains(YesNo)) {
                                if (strEPRN.equals(YesNo)) {
                                    stringCompare("Integration_Results", "ERN Number", strEPRN, ("1N123/A234"));

                                } else {
                                    stringCompare("Integration_Results", "ERN", strEPRN, ("1N"));
                                }
                            } else {
                                stringCompare("Integration_Results", "ERN", strEPRN, ("1Y"));
                            }
                            stringCompare("Integration_Results", "Value", strTrailer, ("#"));

                        }
                        //String fifth = result1.get(0).toString().substring(18, 43);
                        // stringCompare("Integration_Results", fifth, (Policyno));//Policyno
                        al.add(policyNumberfield);

                    }
                }

                int found = 0;
                int notfound = 0;

                for (String e : al) {
                    if (e.equals(Policyno)) {
                        found++;
                    } else {
                        notfound++;
                    }
                }
                if (found > 0) {
                } else {
                    stringCompare("Integration_Results", "Policyno", Policyno, "Not Found");//////BatchReference
                }
            }
        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();
            throw (e);
        }
    }

    public List<Map<String, List<String>>> glNewReporting(String Identifier, String SSPProcessDate, String TransactionType, String Offering, String Product, String Channel, String Amount, String PolicyNo,
                                                          String ReceiptCash, String Card, String BankAccountID, String paymentType, String ReceiptID, String ReceiptItemID, String HeaderNo) throws Exception {
        List<Map<String, List<String>>> listReturn = new ArrayList<Map<String, List<String>>>();
        int linecount = 0;
        try {
            File directory = new File("src\\test\\resources\\Integration\\GL");

            //This is the final list you need

            //get all the files from a directory
            File[] fList = directory.listFiles();

            for (File file : fList) {
                int pcount = 0;

                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));


                int count1 = 0;
                ArrayList<String> al1 = new ArrayList<String>();
                ArrayList<String> al = new ArrayList<String>();
                for (String line : lines) {
                    Map<String, List<String>> listMap = new HashMap<String, List<String>>();


                    //*****************Integrity &Accuracy Check******************//
                    if (line == lines.get(0)) {
                        String[] result1 = line.split("\\|");

                        int fieldsSize = result1.length;
                        String StrfieldsSize = Integer.toString(fieldsSize);

                        //Assert.assertTrue(StrfieldsSize.equals("4"));//no of fields validation


                        if (result1[0].matches(regexSingleNonDigit)) {
                            //stringCompare("Integration_Results", "ROW ID header", result1[0], ("H"));//RowID Header Static
                        }
                        //stringCompare("Integration_Results", "Identifier", result1[1], (Identifier));//Identifier
                        //stringCompare("Integration_Results", "SSPProcessDate", result1[2], (SSPProcessDate));//SSPProcessDate
                        //stringCompare("Integration_Results", "HeaderNo", result1[3], (HeaderNo));// Need to update value from Webservice call
                    } else {

                        String[] result1 = line.split("\\|");

                        int fieldsSize = result1.length;
                        String StrfieldsSize = Integer.toString(fieldsSize);
                        if (line == lines.get(1)) {
                            //Assert.assertTrue(StrfieldsSize.equals("25"));//no of fields validation
                        }
                        if (line.contains(PolicyNo)) {
                            pcount++;
                            //*stringCompare("Integration_Results", "Identifier", result1[0], ("D"));//Identifier of the Row
                            listMap.put("Identifier", Arrays.asList("D", result1[0]));

                            if (result1[1].matches("^[A-Z]{3}$")) {

                                //*stringCompare("Integration_Results", "UWI Entry Code", result1[1], ("UKI"));//Underwriting entity code-Underwriter
                                listMap.put("UWI Entry Code", Arrays.asList("UKI", result1[1]));

                            }

                            String tnxtypeList[] = TransactionType.split("#");
                            int count = 0;
                            if (result1[2].matches(regexMulNonDigit)) {
                                for (int x = 0; x < tnxtypeList.length; x++) {
                                    if (tnxtypeList[x].equals(result1[2])) {
                                        //*stringCompare("Integration_Results", "Transaction Type", tnxtypeList[x], (result1[2]));//TransactionType
                                        listMap.put("Transaction Type", Arrays.asList(tnxtypeList[x], result1[2]));

                                        break;
                                    }/*else {
                                        count ++;
                                        if(count == tnxtypeList.length) {
                                            for (int y = 0; y < tnxtypeList.length; y++) {
                                                stringCompare("Integration_Results", tnxtypeList[y], (result1[2]));//TransactionType
                                            }
                                        }
                                    }*/
                                }
                            }

                            //*stringCompare("Integration_Results", "Brand", result1[3], ("Direct Line"));//Brand-Static-DirectLine
                            listMap.put("Brand", Arrays.asList("Direct Line", result1[3]));

                            //*stringCompare("Integration_Results", "Offering", result1[4], (Offering));//Offering
                            listMap.put("Offering", Arrays.asList(Offering, result1[4]));

                            String coverList[] = Product.split("#");
                            if (result1[5].matches(regexMulNonDigit)) {
                                for (int v = 0; v < coverList.length; v++) {
                                    if (coverList[v].equals(result1[5])) {
                                        //*stringCompare("Integration_Results", "Product", coverList[v], (result1[5]));//Product
                                        //productCoverCount = productCoverCount + 1;
                                        listMap.put("Product", Arrays.asList(coverList[v], result1[5]));

                                    }
                                }
                            } else if (result1[5].isEmpty()) {
                                //*stringCompare("Integration_Results", "Product", result1[5], (""));//Product
                                listMap.put("Product", Arrays.asList("", result1[5]));
                            }


                            if (result1[6].matches(regexMulNonDigit)) {
                                //*stringCompare("Integration_Results", "Channel", result1[6], (Channel));//Channel
                                listMap.put("Channel", Arrays.asList(Channel, result1[6]));

                            } else if (result1[6].isEmpty()) {
                                //*stringCompare("Integration_Results", "Channel", result1[6], (""));//Channel
                                listMap.put("Channel", Arrays.asList("", result1[6]));

                            }

                            if (result1[7].matches(regexMulDigits)) {
                                //*stringMatchCompare("Integration_Results", "Amount", result1[7], (regexMulDigits));//Amount
                                listMap.put("Ammount", Arrays.asList("", result1[7]));

                            } else if (result1[7].isEmpty()) {
                                //*stringCompare("Integration_Results", "Amount", result1[7], (""));//Amount
                                listMap.put("Ammount", Arrays.asList("", result1[7]));

                            }

                            //*stringCompare("Integration_Results", "Territoy", result1[8], ("GBP")); //TERRITORY-static
                            listMap.put("Territory", Arrays.asList("GBP", result1[8]));

                            //*stringCompare("Integration_Results", "Policy Number", result1[9], (PolicyNo));   //policyNumber
                            listMap.put("Policy Number", Arrays.asList(PolicyNo, result1[9]));

                            if (result1[10].matches(regexMulNonDigit)) {
                                //Assert.assertTrue(!result1[10].isEmpty());
                                //stringMatchCompare("Integration_Results", "Tax Reference", result1[10], (regexMulNonDigit));   //tax ref no

                            } else if (result1[10].isEmpty()) {

                                //*stringCompare("Integration_Results", "Tax Reference", result1[10], (""));//tax ref no
                                listMap.put("Tax Reference", Arrays.asList("", result1[10]));

                            }

                            if (result1[12].isEmpty()) {

                                //*stringCompare("Integration_Results", "FreeChargeCode", result1[12], (""));
                                listMap.put("FreeChargeCode", Arrays.asList("", result1[12]));


                            } else {
                                //*stringCompare("Integration_Results", "Card Number", result1[12], (Card)); //card details
                                listMap.put("Card Number", Arrays.asList(Card, result1[12]));
                            }

                            if (result1[2].equals("RECEIPT_CASH")) {
                                if (!result1[7].startsWith("-")) {
                                    //Assert.assertTrue(!result1[7].startsWith("-"));

                                    //stringCompare("Integration_Results", "Receipt Cash", result1[7], (ReceiptCash));

                                    //*stringCompare("Integration_Results", "Bank Account ID", result1[14], (BankAccountID));   //bank account id
                                    listMap.put("Bank Account ID", Arrays.asList(BankAccountID, result1[14]));

                                    //*stringCompare("Integration_Results", "Payment Type", result1[15], (paymentType));   //payment type
                                    listMap.put("Payment Type", Arrays.asList(paymentType, result1[15]));

                                    //stringCompare("Integration_Results", "Receipt Id", result1[19], (ReceiptID)); //ReceiptId
                                    //stringCompare("Integration_Results", "Receipt Item Id", result1[20], (ReceiptItemID)); //ReceiptItemID

                                    // Assert.assertTrue(!result1[23].startsWith("-"));

                                    //stringCompare("Integration_Results", "Receipt Cash", result1[23], (ReceiptCash));

                                    //*stringCompare("Integration_Results", "Value", result1[24], ("0"));
                                    listMap.put("Value", Arrays.asList("0", result1[24]));

                                } else {
                                    //Assert.assertTrue(result1[7].startsWith("-"));

                                    //stringCompare("Integration_Results", "ReceiptCash", result1[7], ("-" + ReceiptCash));

                                    //*stringCompare("Integration_Results", "Bank Account Number", result1[14], (BankAccountID));   //bank account id
                                    listMap.put("Bank Account ID", Arrays.asList(BankAccountID, result1[14]));

                                    //*stringCompare("Integration_Results", "Payment Type", result1[15], (paymentType));   //payment type
                                    listMap.put("Payment Type", Arrays.asList(paymentType, result1[15]));

                                    //stringCompare("Integration_Results", "Receipt ID", result1[19], (ReceiptID)); //ReceiptId
                                    //stringCompare("Integration_Results", "Receipt Item Id", result1[20], (ReceiptItemID)); //ReceiptItemID

                                    //Assert.assertTrue(result1[24].startsWith("-"));

                                    //stringCompare("Integration_Results", "Receipt Cash", result1[24], ("-" + ReceiptCash));

                                    //*stringCompare("Integration_Results", "Value", result1[23], ("0"));
                                    listMap.put("Value", Arrays.asList("0", result1[23]));

                                }

                            } else if (result1[2].equals("RECEIPT_DEBTORS")) {
                                if ((result1[7].startsWith("-"))) {
                                    // Assert.assertTrue(result1[7].startsWith("-"));

                                    // stringCompare("Integration_Results", "ReceiptCash", result1[7], ("-" + ReceiptCash));
                                    //*stringCompare("Integration_Results", "BankAccountID", result1[14], (BankAccountID));   //bank account id
                                    listMap.put("Bank Account ID", Arrays.asList(BankAccountID, result1[14]));

                                    //*stringCompare("Integration_Results", "paymentType", result1[15], (paymentType));   //payment type
                                    listMap.put("Payment Type", Arrays.asList(paymentType, result1[15]));

                                    //stringCompare("Integration_Results", "ReceiptID", result1[19], (ReceiptID)); //ReceiptId
                                    //stringCompare("Integration_Results", "ReceiptItemID", result1[20], (ReceiptItemID)); //ReceiptItemID

                                    //*stringCompare("Integration_Results", "Value", result1[23], ("0"));
                                    listMap.put("Value", Arrays.asList("0", result1[23]));

                                    //Assert.assertTrue(result1[24].startsWith("-"));

                                    //stringCompare("Integration_Results", "Receipt Cash", result1[24], ("-" + ReceiptCash));
                                } else {
                                    //Assert.assertTrue(!result1[7].startsWith("-"));

                                    //stringCompare("Integration_Results", "ReceiptCash", result1[7], (ReceiptCash));
                                    //*stringCompare("Integration_Results", "BankAccountID", result1[14], (BankAccountID));   //bank account id
                                    listMap.put("Bank Account ID", Arrays.asList(BankAccountID, result1[14]));

                                    //*stringCompare("Integration_Results", "Payment Type", result1[15], (paymentType));   //payment type
                                    listMap.put("Payment Type", Arrays.asList(paymentType, result1[15]));

                                    //stringCompare("Integration_Results", "Receipt Id", result1[19], (ReceiptID)); //ReceiptId
                                    //stringCompare("Integration_Results", "Receipt Item Id", result1[20], (ReceiptItemID)); //ReceiptItemID

                                    //*stringCompare("Integration_Results", "value", result1[24], ("0"));
                                    listMap.put("Value", Arrays.asList("0", result1[24]));

                                    //Assert.assertTrue(!result1[23].startsWith("-"));

                                    //stringCompare("Integration_Results", "ReceiptCash", result1[23], (ReceiptCash));
                                }
                            }


                            String AmountList[] = Amount.split("#");

                            for (int t = 0; t < coverList.length; t++) {
                                if (coverList[t].equals(result1[5])) {

                                    al.add(line);

                                    for (int m = 0; m < AmountList.length; m++) {
                                        if (AmountList[m].equals(result1[7])) {
                                            // Assert.assertTrue(AmountList[0].equals(result1[7]));
                                            //      Assert.assertTrue(result1[7].equals(AmountList[m]));
                                        }
                                    }
                                }
                            }
                            count1++;

                        }
                        al1.add(result1[9]);


                    }

                    listReturn.add(linecount++, listMap);


                }
                int found = 0;
                int notfound = 0;

                for (String e : al1) {
                    if (e.equals(PolicyNo)) {
                        found++;
                    } else {
                        notfound++;
                    }
                }
                if (found > 0) {
                } else {
                    stringCompare("Integration_Results", "PolicyNumber", PolicyNo, "not found");//////BatchReference
                    Map<String, List<String>> listMap1 = new HashMap<String, List<String>>();
                    listMap1.put("Record Found", Arrays.asList(PolicyNo, "Not Found"));
                    listMap1.put("PolicyNo", Arrays.asList(PolicyNo, "Not Available"));
                    listReturn.add(linecount++, listMap1);
                }
                //////////////Validation////////////
                int sum = 0;

                String coverList1[] = Product.split("#");
                String AmountList1[] = Amount.split("#");


                int coverSize = coverList1.length * 4;
                String StrCoverSize = Integer.toString(coverSize);

                int alSize = al.size();
                String StrAlSize = Integer.toString(alSize);///no of rows

                if (StrCoverSize.equals(StrAlSize)) {
                    //Assert.assertTrue(StrCoverSize.equals(StrAlSize));//no of rows with covers validation
                    //*stringCompare("Integration_Results", "Count Compare", StrCoverSize, StrAlSize);//////row size
                    Map<String, List<String>> listMap1 = new HashMap<String, List<String>>();
                    listMap1.put("Count", Arrays.asList(StrCoverSize, Integer.toString(pcount)));
                    listReturn.add(linecount++, listMap1);

                    //stringCompare("Integration_Results", "Count Compare", "count based on cover size is"+StrCoverSize, "mismatch with row size"+StrAlSize);//////row size
                } else {
                    //*stringCompare("Integration_Results", "Count Compare", StrCoverSize, StrAlSize);//////row size
                    //stringCompare("Integration_Results", "Count Compare", "count based on cover size is"+StrCoverSize, "mismatch with row size"+StrAlSize);//////row size
                    //Assert.assertTrue(StrCoverSize.equals(StrAlSize));//no of rows with covers validation
                    Map<String, List<String>> listMap1 = new HashMap<String, List<String>>();
                    listMap1.put("Count", Arrays.asList(StrCoverSize, Integer.toString(pcount)));
                    listReturn.add(linecount++, listMap1);
                }


                /********* positive and negative check **********/

                for (String s : al) {
                    String[] result2 = s.split("\\|");
                    if (result2[2].contains("DEBTORS")) {
                        //   Assert.assertTrue(!result2[7].startsWith("-"));
                    } else {
                        //   Assert.assertTrue(result2[7].startsWith("-"));
                    }
                    int taxRow = 0;

                    for (String s1 : al) {
                        String s2[] = s1.split("\\|");
                        for (int t = 0; t < AmountList1.length; t++) {
                            double Strresult1 = Double.parseDouble(AmountList1[t]);
                            double TaxValue1 = (Strresult1 * 12) / 100;
                            double roundOff = Math.round(TaxValue1 * 100.0) / 100.0;
                            String StrTaxValue1 = Double.toString(roundOff);

                            if (s2[23].contains(StrTaxValue1)) {
                                taxRow = taxRow + 1;
                            } else if (s2[24].contains(StrTaxValue1)) {
                                taxRow = taxRow + 1;
                            }
                        }
                    }
                    int FinalTaxRow = taxRow * 2;
                    String StrFinalTaxRow = Integer.toString(FinalTaxRow);
                    //Assert.assertEquals(StrAlSize, StrFinalTaxRow);
                }


            }
        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();

            throw (e);
        }
        return listReturn;
    }

    public List<Map<String, List<String>>> inteliimatchNewReporting(String amount, String BankAccntNo, String TnxType, String DebitCredit, String BatchReference, String TnxReference, String PaymentMethod, String TnxDate, String NoOfRows) throws Exception {

        List<Map<String, List<String>>> listReturn = new ArrayList<Map<String, List<String>>>();
        int linecount = 0;
        try {
            File directory = new File("src\\test\\resources\\Integration\\Intellimatch");
            //get all the files from a directory
            File[] fList = directory.listFiles();

            for (File file : fList) {


                List<String> lines = Files.readAllLines(Paths.get(file.getPath()));

                ArrayList<String> al = new ArrayList<String>();
                int count = 0;
                for (String line : lines) {

                    Map<String, List<String>> listMap = new HashMap<String, List<String>>();
                    String[] result1 = line.split("\\|");

                    int fieldsSize = result1.length;
                    String StrfieldsSize = Integer.toString(fieldsSize);

                    if (line != lines.get(0)) {


                        //*****************Accuracy Check******************//
                        if (result1[8].equals(BatchReference)) {
                            listMap.put("Record Found", Arrays.asList("Found", "Found"));
                            //*stringCompare("Integration_Results", "Row identifier", result1[0], ("D")); //row identifier
                            listMap.put("Row identifier", Arrays.asList("D", result1[0]));
                            //*stringCompare("Integration_Results", "Bank Account Number", result1[1], (BankAccntNo)); //Bank Account Number
                            listMap.put("Bank Account Number", Arrays.asList(BankAccntNo, result1[1]));
                            String CoverStartDate = TnxDate.substring(6) + "/" + TnxDate.substring(4, 6) + "/" + TnxDate.substring(0, 4);
                            //*stringCompare("Integration_Results", "Posting Date", result1[2], (CoverStartDate)); ///////Posting Date
                            listMap.put("Posting Date", Arrays.asList(CoverStartDate, result1[2]));
                            //*stringCompare("Integration_Results", "Transaction Date", result1[3], (CoverStartDate)); ////////////Transaction Date
                            listMap.put("Transaction Date", Arrays.asList(CoverStartDate, result1[3]));
                            if (DebitCredit.equalsIgnoreCase("CR")) {
                                //*stringCompare("Integration_Results", "Amount", result1[4], ("-"+amount));//////////amount
                                listMap.put("Amount", Arrays.asList(("-" + amount), result1[4]));
                            } else {
                                //*stringCompare("Integration_Results", "Amount", result1[4], (amount));//////////amount
                                listMap.put("Amount", Arrays.asList((amount), result1[4]));
                            }
                            //*stringCompare("Integration_Results", "TransactionType", result1[5], (TnxType));//////TnxType
                            listMap.put("TransactionType", Arrays.asList(TnxType, result1[5]));
                            //*stringCompare("Integration_Results", "DebitCredit", result1[6], (DebitCredit));//////////////DebitCredit
                            listMap.put("DebitCredit", Arrays.asList(DebitCredit, result1[6]));
                            //*stringCompare("Integration_Results", "Currrecy", result1[7], ("GBP"));
                            listMap.put("Currency", Arrays.asList("GBP", result1[7]));
                            //*stringCompare("Integration_Results", "BatchReference", result1[8], (BatchReference));//////BatchReference
                            listMap.put("BatchReference", Arrays.asList(BatchReference, result1[8]));
                            String[] reference = result1[9].split("-");
                            //*stringContains("Integration_Results", "TransactionReference", reference[0], (TnxReference));////TnxReference
                            listMap.put("TransactionReference", Arrays.asList(TnxReference, reference[0]));
                            //*stringCompare("Integration_Results", "PaymentMethod", result1[10], (PaymentMethod));///////////PaymentMethod
                            listMap.put("PaymentMethod", Arrays.asList(PaymentMethod, result1[10]));

                            count++;
                        }

                        al.add(result1[8]);


                    }
                    listReturn.add(linecount++, listMap);
                }

                String CountSize = Integer.toString(count);
                if (count > 0) {
                    //    Assert.assertTrue(NoOfRows.equals(CountSize));//no of rows validation
                    Map<String, List<String>> listMap1 = new HashMap<String, List<String>>();
                    listMap1.put("Count", Arrays.asList("1", Integer.toString(count)));
                    listReturn.add(linecount++, listMap1);
                } else {
                    Map<String, List<String>> listMap1 = new HashMap<String, List<String>>();
                    listMap1.put("Count", Arrays.asList("1", Integer.toString(count)));
                    listReturn.add(linecount++, listMap1);
                }

                int found = 0;
                int notfound = 0;

                for (String e : al) {
                    if (e.equals(BatchReference)) {
                        found++;
                    } else {
                        notfound++;
                    }
                }
                if (found > 0) {
                } else {
                    //*stringCompare("Integration_Results", "BatchReference", BatchReference, "Not Found");//////BatchReference
                    Map<String, List<String>> listMap1 = new HashMap<String, List<String>>();
                    listMap1.put("Record Found", Arrays.asList(BatchReference, "Not Found"));
                    listMap1.put("BatchReference", Arrays.asList(BatchReference, "Not Available"));
                    listReturn.add(linecount++, listMap1);
                }
            }

        } catch (Exception e) {
            log.error("Unexpected Exception", e);
            e.printStackTrace();

            throw (e);
        }
        return listReturn;

    }


}
