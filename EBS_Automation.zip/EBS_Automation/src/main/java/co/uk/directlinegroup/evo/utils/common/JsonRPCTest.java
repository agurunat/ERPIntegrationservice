package co.uk.directlinegroup.evo.utils.common;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import java.nio.file.Files;
import java.nio.file.Paths;

public class JsonRPCTest {

    public static void main(String[] args) throws Exception {
        HttpClient httpClient = HttpClientBuilder.create().build();
        try {
            HttpPost request = new HttpPost("https://dlg-sit.ssp-hosting.com/DLGCT2/TechnologyFrameworksWeb/ComponentSaveSME_INSSMEv1");
            String jSonRequest = new String(Files.readAllBytes(Paths.get("C:\\Users\\257783\\Desktop\\PIrequest.txt")));
            StringEntity params = new StringEntity(jSonRequest);
            request.addHeader("content-type", "text/xml; charset=UTF-8");
            request.addHeader("SOAPAction", "ComponentSaveSME_INSSMEv1Service/saveNewComponent");
            request.setEntity(params);
            HttpResponse response = httpClient.execute(request);
            String result = EntityUtils.toString(response.getEntity());
            System.out.println(result);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }


}