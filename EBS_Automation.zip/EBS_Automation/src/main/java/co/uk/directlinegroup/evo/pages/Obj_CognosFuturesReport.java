package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.By;

public class Obj_CognosFuturesReport extends AbstractPage {

    public WebElement AsAtDate() {
        return waitForElementVisible(By.xpath("(//input[starts-with(@class,'clsSelectDateEditBox')])[1]"));
    }

    public WebElement reportStartDateTextbox() {
        return waitForElementVisible(By.xpath("(//input[starts-with(@class,'clsSelectDateEditBox')])[2]"));
    }

    public WebElement reportEndDateTextbox() {
        return waitForElementVisible(By.xpath("(//input[starts-with(@class,'clsSelectDateEditBox')])[3]"));
    }

    public WebElement reportEmptySpan() {
        return waitForElementVisible(By.xpath("//*[@id='rt_NS_']/tbody/tr[2]/td/div[1]"));
    }

}
