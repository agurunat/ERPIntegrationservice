package co.uk.directlinegroup.evo.utils;

/*
    Tag value missing in Source table and validate those value as null in Target table
    Eg: policy_term_months tag will not be available in Source table but it should have value in target table as null value.
 */

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;



public class ARMissingTaginSourceFileCompare extends  Reader {

    String xmlId = null;

    public static void main(String[] args) {
        try {
            Reader rd = new Reader();
            String getCellValue = rd.lookUpreference("DLG_PULSE_CONVERSION_TYPE","Common Lookup",0,1);

            String csvSplitBy = ",";
            // ----------- read XML File ----------------------------
            File inputFile = new File("C:\\Test\\AR_Trans.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

            NodeList nList = doc.getElementsByTagName("dlg_ar_transaction");
            System.out.println("----------------------------");
            for (int j = 0; j < nList.getLength(); j++) {
                Node nNode = nList.item(j);
                System.out.println("\nCurrent Element :" + nNode.getNodeName());
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    String xmlId = eElement
                            .getElementsByTagName("id")
                            .item(0)
                            .getTextContent();

                    // --------- Read the csv file ------------------
                    Scanner out = new Scanner(new BufferedReader(new FileReader("C:\\Test\\ARMissingTaginSourceFileCompare.csv")));
                    while (out.hasNextLine()) {
                        String data = out.nextLine();
                        String[] value = data.split(csvSplitBy);
                        for (int csv = 0; csv < value.length; csv++) {
                            if (value[csv].equals(xmlId)) {
                                //------------ validate id tag ---------------
                                String xmlID = eElement
                                        .getElementsByTagName("id")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(xmlID)) {
                                    System.out.println("XML id :-" + xmlID + " is matching with CSV File:-" + value[csv] + " ------------ > PASS");
                                    csv++;
                                } else {
                                    System.out.println("id is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }

                                //------------ validate Base Currency Amount  ---------------
                                String xmlbaseCurrencyAmount = eElement
                                        .getElementsByTagName("base_currency_amount")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("base_currency_amount")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Base Currency Amount :-" + xmlbaseCurrencyAmount + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Base Currency Amount is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }

                                //------------ validate Currency cd  ---------------
                                String xmlcurrencyCode = eElement
                                        .getElementsByTagName("currency_cd")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("currency_cd")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Currency cd :-" + xmlcurrencyCode + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Currency cd is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }

                                //------------ validate Payer Name   ---------------
                                String xmlpayerName = eElement
                                        .getElementsByTagName("payer_name")
                                        .item(0)
                                        .getTextContent();

                                if (value[csv].equals(eElement
                                        .getElementsByTagName("payer_name")
                                        .item(0)
                                        .getTextContent())) {
                                    System.out.println("XML Payer Name :-" + xmlpayerName + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Payer Name is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                }

                                //------------ validate policy_term ---------------
                                boolean blnPolicyterm = eElement
                                        .getElementsByTagName("policy_term_months").equals(0);
                                //System.out.println("Policy Term Month Tag name not displayed " + blnPolicyterm);
                                if (!blnPolicyterm) {
                                    System.out.println("Policy term month fields does not available in Source file and values from CSV File:-" + value[csv] + " ----- > PASS");
                                    csv++;
                                } else {
                                    System.out.println("Policy term month fields is available in Source file and values from CSV File:-" + value[csv] + " ----- > Fail");
                                }

                                //------------ validate policy_term ---------------
                                boolean blnlookUpValue = eElement
                                        .getElementsByTagName("policy_lookup_value").equals(0);
                                //System.out.println("Tag name not displayed" + blnlookUpValue);
                                if (!blnlookUpValue) {
                                    System.out.println("DLG_PULSE_CONVERSION_TYPE fields values in lookup Table value is :-" + getCellValue + " and values from CSV File:-" + value[csv] + " ----- > PASS");

                                } else {
                                    System.out.println("Policy term month fields is available in Source file and values from CSV File:-" + value[csv] + " ----- > Fail");
                                }
                            }
                        }
                    }
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ParserConfigurationException e) {
            e.printStackTrace();
        } catch (SAXException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}



