package co.uk.directlinegroup.evo.utils;

/**
 * Created by 470774 on 9/28/2017.
 */


import org.apache.poi.hssf.usermodel.*;
import org.apache.poi.hssf.util.HSSFColor;
import org.apache.poi.ss.util.CellRangeAddress;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by 289949 on 9/20/2017.
 */
public class IntegrationReportUtil {
    // TODO Auto-generated method stub

    // TODO Auto-generated method stub

    public void createExcel(String strPath) throws Exception {
        // TODO Auto-generated method stub

        HSSFWorkbook WorkBook = new HSSFWorkbook();
        HSSFSheet sheet = WorkBook.createSheet("Summary");
        HSSFSheet sheet1 = WorkBook.createSheet("Integration_Results");
        HSSFSheet sheet2 = WorkBook.createSheet("Cognos_Results");
        FileOutputStream fo = new FileOutputStream(new File("src\\test\\resources\\Integration\\IntegrationResults.xls"));

        HSSFRow SummaryRow = sheet.createRow(0);
        SummaryRow.createCell(0).setCellValue("TC_ID");
        SummaryRow.createCell(1).setCellValue("ModuleName");
        SummaryRow.createCell(2).setCellValue("Result");
        HSSFRow integerationRow = sheet1.createRow(0);
        integerationRow.createCell(0).setCellValue("Field Name");
        integerationRow.createCell(1).setCellValue("Expected Content");
        integerationRow.createCell(2).setCellValue("Actual Content");
        integerationRow.createCell(3).setCellValue("Status");
        HSSFRow cognosRow = sheet2.createRow(0);
        cognosRow.createCell(0).setCellValue("TC_ID");
        cognosRow.createCell(1).setCellValue("Expected Content");
        cognosRow.createCell(2).setCellValue("Actual Content");
        cognosRow.createCell(3).setCellValue("Status");
        cognosRow.createCell(4).setCellValue("Reference");
        WorkBook.write(fo);
        fo.close();
    }


    public void excelwrite(String SummarySheet, String IntegerationSheet, String ColumnName, String sourceVal, String targetVal)throws Exception {
        ArrayList<String> oIntegerationArray = new ArrayList<String>();
        ArrayList<String> oSummaryarray = new ArrayList<String>();
        FileInputStream fis = null;
        FileOutputStream f2;
        FileOutputStream fileOut;
            fis = new FileInputStream("src\\test\\resources\\Integration\\IntegrationResults.xls");
            HSSFWorkbook oIntegerationWb = new HSSFWorkbook(fis);
            f2 = new FileOutputStream("src\\test\\resources\\Integration\\IntegrationResults.xls");
            fileOut= new FileOutputStream("src\\test\\resources\\Integration\\IntegrationResults.xls");
            HSSFWorkbook oSummaryWb = oIntegerationWb;
            HSSFSheet oIntegerationSheet = oIntegerationWb.getSheet(IntegerationSheet);
            HSSFSheet oSummarySheet = oIntegerationWb.getSheet(SummarySheet);
            int SummaryTotalRow = oSummarySheet.getLastRowNum();
            int SummarycolCount = oSummarySheet.getRow(0).getLastCellNum();
            HSSFRow sRow = oSummarySheet.getRow(0);
            for (int i = 0; i < SummarycolCount; i++) {
                oSummaryarray.add(sRow.getCell(i).getStringCellValue());
            }
            int IntegerationTotalRow = oIntegerationSheet.getLastRowNum();
            int IntegerationColCount = oIntegerationSheet.getRow(0).getLastCellNum();
            int tccol0 = 0, tccol3 = 0, tccol4 = 0, tccol5 = 0, tccol6 = 0, tccol = 0, tccol1 = 0, tccol2 = 0;
            HSSFRow iRow = oIntegerationSheet.getRow(0);
            for (int i = 0; i < IntegerationColCount; i++) {
                oIntegerationArray.add(iRow.getCell(i).getStringCellValue());
            }

            for (int i = 0; i <= IntegerationTotalRow; i++) {
                for (int j = 0; j < IntegerationColCount; j++) {

                    if (oIntegerationArray.get(j).equalsIgnoreCase("Field Name")) {
                        tccol0 = j;
                    }

                    if (oIntegerationArray.get(j).equalsIgnoreCase("Actual Content")) {
                        tccol = j;
                    }
                    if (oIntegerationArray.get(j).equalsIgnoreCase("Expected Content")) {
                        tccol1 = j;
                    }
                    if (oIntegerationArray.get(j).equalsIgnoreCase("Status")) {
                        tccol2 = j;
                    }
                }
            }
            HSSFCellStyle styleFail = oIntegerationWb.createCellStyle();
            styleFail.setFillForegroundColor(HSSFColor.RED.index);
            styleFail.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

            HSSFCellStyle stylePass = oIntegerationWb.createCellStyle();
            stylePass.setFillForegroundColor(HSSFColor.GREEN.index);
            stylePass.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

            HSSFFont font = oIntegerationWb.createFont();
            font.setColor(HSSFColor.BLACK.index);
            styleFail.setFont(font);
            stylePass.setFont(font);

            HSSFRow integerationTotalRow = oIntegerationSheet.createRow(IntegerationTotalRow + 1);
            //integerationTotalRow.createCell(tccol0).setCellValue("TC0001");
            integerationTotalRow.createCell(tccol0).setCellValue(ColumnName);
            integerationTotalRow.createCell(tccol).setCellValue(targetVal);
            integerationTotalRow.createCell(tccol1).setCellValue(sourceVal);
            boolean flag = true;
            if (!sourceVal.equalsIgnoreCase(targetVal)) {
                HSSFCell cell = integerationTotalRow.createCell(tccol2);
                cell.setCellValue("Fail");
                cell.setCellStyle(styleFail);
            } else {
                HSSFCell cell = integerationTotalRow.createCell(tccol2);
                cell.setCellValue("Pass");
                cell.setCellStyle(stylePass);
            }
            // integerationTotalRow.createCell(tccol2).setCellValue(sourceVal.equalsIgnoreCase(targetVal));
            IntegerationTotalRow = IntegerationTotalRow + 1;

            oIntegerationWb.write(f2);
            //f2.close();

            for (int s = 0; s <= SummaryTotalRow; s++) {
                for (int ss = 0; ss < SummarycolCount; ss++) {
                    if (oSummaryarray.get(ss).equalsIgnoreCase("Result")) {
                        tccol2 = ss;
                    }
                }
            }

            for (int pageRow = 0; pageRow < 1; pageRow++) {
                HSSFRow summaryTotalRow = oSummarySheet.createRow(SummaryTotalRow + 1);
                summaryTotalRow.createCell(tccol0).setCellValue("TC0001");
                summaryTotalRow.createCell(tccol1).setCellValue("Integration");
                summaryTotalRow.createCell(tccol2).setCellValue("FAIL");
                SummaryTotalRow = SummaryTotalRow + 1;
            }
            oSummaryWb.write(fileOut);

            f2.close();
            fileOut.close();





    }

    public void createExcelReport(String strPath, String FileName, String Sheetname) throws Exception {
        // TODO Auto-generated method stub
        String filepath = strPath + FileName + ".xls";
        HSSFWorkbook WorkBook = new HSSFWorkbook();
        HSSFSheet sheet1 = WorkBook.createSheet(Sheetname);
        HSSFSheet sheet2 = WorkBook.createSheet("SummarySheet");
        FileOutputStream fo = new FileOutputStream(new File(filepath));

        HSSFRow integerationRow = sheet1.createRow(0);
        integerationRow.createCell(0).setCellValue("FileName");
        integerationRow.createCell(1).setCellValue("LineNo");
        integerationRow.createCell(2).setCellValue("Status");
        integerationRow.createCell(3).setCellValue("Reason");

        HSSFRow summaryRow = sheet2.createRow(0);
        summaryRow.createCell(0).setCellValue("FileName");
        summaryRow.createCell(1).setCellValue("LineNo");
        summaryRow.createCell(2).setCellValue("Status");
        summaryRow.createCell(3).setCellValue("Reason");

        WorkBook.write(fo);
        fo.close();
    }

    public void excelwriteReport(String strFilePath, String strSheetName, String filenameVal, String lineVal, String statusVal, String reasonVal) throws IOException {
        ArrayList<String> oIntegerationArray = new ArrayList<String>();
        ArrayList<String> oSummaryarray = new ArrayList<String>();


        FileInputStream fis = new FileInputStream(strFilePath);
        HSSFWorkbook oIntegerationWb = new HSSFWorkbook(fis);
            FileOutputStream fos = new FileOutputStream(strFilePath);
            HSSFWorkbook oSummaryWb = oIntegerationWb;
            HSSFSheet oIntegerationSheet = oIntegerationWb.getSheet(strSheetName);
            HSSFSheet oSummarySheet = oIntegerationWb.getSheet("SummarySheet");

            int SummaryTotalRow = oSummarySheet.getLastRowNum();
            int SummarycolCount = oSummarySheet.getRow(0).getLastCellNum();
            HSSFRow sRow = oSummarySheet.getRow(0);
            for (int i = 0; i < SummarycolCount; i++) {
                oSummaryarray.add(sRow.getCell(i).getStringCellValue());
            }

            int IntegerationTotalRow = oIntegerationSheet.getLastRowNum();
            int IntegerationColCount = oIntegerationSheet.getRow(0).getLastCellNum();

            HSSFRow iRow = oIntegerationSheet.getRow(0);
            for (int i = 0; i < IntegerationColCount; i++) {
                oIntegerationArray.add(iRow.getCell(i).getStringCellValue());
            }

            int tccol0 = 0, tccol3 = 0, tccol4 = 0, tccol5 = 0, tccol6 = 0, tccol = 0, tccol1 = 0, tccol2 = 0;


            for (int i = 0; i <= IntegerationTotalRow; i++) {
                for (int j = 0; j < IntegerationColCount; j++) {

                    if (oIntegerationArray.get(j).equalsIgnoreCase("FileName")) {
                        tccol0 = j;
                    }

                    if (oIntegerationArray.get(j).equalsIgnoreCase("LineNo")) {
                        tccol1 = j;
                    }
                    if (oIntegerationArray.get(j).equalsIgnoreCase("Status")) {
                        tccol2 = j;
                    }
                    if (oIntegerationArray.get(j).equalsIgnoreCase("Reason")) {
                        tccol3 = j;
                    }
                }
            }


            HSSFCellStyle styleFail = oIntegerationWb.createCellStyle();
            styleFail.setFillForegroundColor(HSSFColor.RED.index);
            styleFail.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

            HSSFCellStyle stylePass = oIntegerationWb.createCellStyle();
            stylePass.setFillForegroundColor(HSSFColor.GREEN.index);
            stylePass.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

            HSSFFont font = oIntegerationWb.createFont();
            font.setColor(HSSFColor.BLACK.index);
            styleFail.setFont(font);
            stylePass.setFont(font);


            HSSFRow integerationTotalRow = oIntegerationSheet.createRow(IntegerationTotalRow + 1);
            integerationTotalRow.createCell(tccol0).setCellValue(filenameVal);
            integerationTotalRow.createCell(tccol1).setCellValue(lineVal);

            if (statusVal.equalsIgnoreCase("fail")) {
                HSSFCell cell = integerationTotalRow.createCell(tccol2);
                cell.setCellValue(statusVal);
                cell.setCellStyle(styleFail);
            }
            if (statusVal.equalsIgnoreCase("pass")) {
                HSSFCell cell = integerationTotalRow.createCell(tccol2);
                cell.setCellValue(statusVal);
                cell.setCellStyle(stylePass);
            }


            integerationTotalRow.createCell(tccol3).setCellValue(reasonVal);
            oIntegerationSheet.autoSizeColumn(tccol0);
            oIntegerationSheet.autoSizeColumn(tccol1);
            oIntegerationSheet.autoSizeColumn(tccol2);
            oIntegerationSheet.autoSizeColumn(tccol3);

            IntegerationTotalRow = IntegerationTotalRow + 1;

            oIntegerationWb.write(fos);
            fos.close();
        fis.close();


    }

//Create Excel Consolidated report

    public void createExcelConsolidatedReport(String strPath, String FileName, String Sheetname) throws Exception {
        HSSFWorkbook workbook;
        HSSFSheet worksheet;
        HSSFSheet sWorksheet;
        String strFilePath = strPath + FileName + ".xls";
        File file = new File(strFilePath);


        if (!file.exists()) {
            workbook = new HSSFWorkbook();    //if the workbook was just created
            worksheet = workbook.createSheet(Sheetname);
            HSSFRow nRow = worksheet.createRow(0);
            nRow.createCell(0).setCellValue("FileName");
            nRow.createCell(1).setCellValue("LineNo");
            nRow.createCell(2).setCellValue("Status");
            nRow.createCell(3).setCellValue("Reason");

            sWorksheet = workbook.createSheet("SummarySheet");
            HSSFRow sRow = sWorksheet.createRow(0);
            sRow.createCell(0).setCellValue("FileName");
            sRow.createCell(1).setCellValue("LineNo");
            sRow.createCell(2).setCellValue("Status");
            sRow.createCell(3).setCellValue("Reason");

            FileOutputStream fileOut = new FileOutputStream(file);
            workbook.write(fileOut);
            fileOut.close();
        } else {
            try (FileInputStream inputStream = new FileInputStream(file)) {


                if (inputStream.available() >= 512) {

                    workbook = new HSSFWorkbook(inputStream); //If there is already data in a workbook
                    worksheet = workbook.createSheet(Sheetname);
                    HSSFRow nRow = worksheet.createRow(0);
                    nRow.createCell(0).setCellValue("FileName");
                    nRow.createCell(1).setCellValue("LineNo");
                    nRow.createCell(2).setCellValue("Status");
                    nRow.createCell(3).setCellValue("Reason");

                    FileOutputStream fileOut = new FileOutputStream(file);
                    workbook.write(fileOut);
                    fileOut.close();
                    inputStream.close();
                }
           /*else{
                workbook = new HSSFWorkbook(inputStream);    //If there is already data in a workbook
                worksheet = workbook.createSheet(Sheetname);
                HSSFRow nRow = worksheet.createRow(0);
                nRow.createCell(0).setCellValue("FileName");
                nRow.createCell(1).setCellValue("LineNo");
                nRow.createCell(2).setCellValue("Status");
                nRow.createCell(3).setCellValue("Reason");

                sWorksheet = workbook.createSheet("SummarySheet");
                HSSFRow sRow = sWorksheet.createRow(0);
                sRow.createCell(0).setCellValue("FileName");
                sRow.createCell(1).setCellValue("LineNo");
                sRow.createCell(2).setCellValue("Status");
                sRow.createCell(3).setCellValue("Reason");

                workbook.write(fileOut);
                fileOut.close();
                inputStream.close();
            }
*/
                inputStream.close();
            }catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void excelwriteReportList(String strFilePath, String strSheetName, ArrayList<ArrayList<String>> outputArray) throws IOException {
        ArrayList<String> oIntegerationArray = new ArrayList<String>();
        ArrayList<String> oSummaryarray = new ArrayList<String>();


        FileInputStream fis = new FileInputStream(strFilePath);
        HSSFWorkbook oIntegerationWb = new HSSFWorkbook(fis);
        FileOutputStream fos = new FileOutputStream(strFilePath);
        try (FileOutputStream fileOut = new FileOutputStream(strFilePath)) {
        }

        HSSFWorkbook oSummaryWb = oIntegerationWb;
        HSSFSheet oIntegerationSheet = oIntegerationWb.getSheet(strSheetName);
        HSSFSheet oSummarySheet = oIntegerationWb.getSheet("SummarySheet");

        int SummaryTotalRow = oSummarySheet.getLastRowNum();
        int SummarycolCount = oSummarySheet.getRow(0).getLastCellNum();
        HSSFRow sRow = oSummarySheet.getRow(0);
        for (int i = 0; i < SummarycolCount; i++) {
            oSummaryarray.add(sRow.getCell(i).getStringCellValue());
        }

        int IntegerationTotalRow = oIntegerationSheet.getLastRowNum();
        int IntegerationColCount = oIntegerationSheet.getRow(0).getLastCellNum();

        HSSFRow iRow = oIntegerationSheet.getRow(0);
        for (int i = 0; i < IntegerationColCount; i++) {
            oIntegerationArray.add(iRow.getCell(i).getStringCellValue());
        }

        int tccol0 = 0, tccol3 = 0, tccol4 = 0, tccol5 = 0, tccol6 = 0, tccol = 0, tccol1 = 0, tccol2 = 0;


        for (int i = 0; i <= IntegerationTotalRow; i++) {
            for (int j = 0; j < IntegerationColCount; j++) {

                if (oIntegerationArray.get(j).equalsIgnoreCase("FileName")) {
                    tccol0 = j;
                }

                if (oIntegerationArray.get(j).equalsIgnoreCase("LineNo")) {
                    tccol1 = j;
                }
                if (oIntegerationArray.get(j).equalsIgnoreCase("Status")) {
                    tccol2 = j;
                }
                if (oIntegerationArray.get(j).equalsIgnoreCase("Reason")) {
                    tccol3 = j;
                }
            }
        }


        for (int k = 0; k < outputArray.size(); k++) {
            HSSFRow integerationTotalRow = oIntegerationSheet.createRow(IntegerationTotalRow + 1);

            integerationTotalRow.createCell(tccol0).setCellValue(outputArray.get(k).get(0));
            integerationTotalRow.createCell(tccol1).setCellValue(outputArray.get(k).get(1));

            if (outputArray.get(k).get(2).equalsIgnoreCase("fail")) {
                HSSFCell cell = integerationTotalRow.createCell(tccol2);
                cell.setCellValue(outputArray.get(k).get(2));
                HSSFCellStyle styleFail = oIntegerationWb.createCellStyle();
                styleFail.setFillForegroundColor(HSSFColor.RED.index);
                styleFail.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
                HSSFFont font = oIntegerationWb.createFont();
                font.setColor(HSSFColor.BLACK.index);

                styleFail.setFont(font);
                cell.setCellStyle(styleFail);
            }
            if (outputArray.get(k).get(2).equalsIgnoreCase("pass")) {
                HSSFCell cell = integerationTotalRow.createCell(tccol2);
                cell.setCellValue(outputArray.get(k).get(2));
                HSSFCellStyle stylePass = oIntegerationWb.createCellStyle();
                stylePass.setFillForegroundColor(HSSFColor.GREEN.index);
                stylePass.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
                HSSFFont font = oIntegerationWb.createFont();
                font.setColor(HSSFColor.BLACK.index);
                stylePass.setFont(font);
                cell.setCellStyle(stylePass);
            }
            integerationTotalRow.createCell(tccol3).setCellValue(outputArray.get(k).get(3));


            IntegerationTotalRow = IntegerationTotalRow + 1;
        }


        oIntegerationSheet.autoSizeColumn(tccol0);
        oIntegerationSheet.autoSizeColumn(tccol1);
        oIntegerationSheet.autoSizeColumn(tccol2);
        oIntegerationSheet.autoSizeColumn(tccol3);

        oIntegerationWb.write(fos);
        fos.close();
        fis.close();


    }

    //Syed New Excel Reporting Format
    public void excelCreateNewReport(String strPath, String sheetName,String integration) throws Exception {


        CommonUtil Objintegration = new CommonUtil();
        List<String> headerDetails = Objintegration.getIntegrationProperties(integration);

        HSSFWorkbook WorkBook = new HSSFWorkbook();
        HSSFSheet sheet1 = WorkBook.createSheet(sheetName);
        FileOutputStream fo = new FileOutputStream(new File(strPath));

      /*
        HSSFSheet sheet = WorkBook.createSheet("Summary");
        HSSFRow SummaryRow = sheet.createRow(0);
        SummaryRow.createCell(0).setCellValue("TC_ID");
        SummaryRow.createCell(1).setCellValue("ModuleName");
        SummaryRow.createCell(2).setCellValue("Result");
*/


        HSSFRow integerationRow = sheet1.createRow(0);
        HSSFRow integerationRow2 = sheet1.createRow(1);
        int r1cl = 0;
        int r2cl = 0;
        for (int c = 0; c < headerDetails.size(); c++) {
            integerationRow.createCell(r1cl++).setCellValue(headerDetails.get(c));
            integerationRow.createCell(r1cl++).setCellValue("");
            integerationRow2.createCell(r2cl++).setCellValue("Expected");
            integerationRow2.createCell(r2cl++).setCellValue("Actual");
        }
        WorkBook.write(fo);
        fo.close();
    }

    public void excelWriteNewReport(String strFilePath, String strSheetName, List<Map<String, List<String>>> listReturn) throws IOException {
        FileInputStream fis = new FileInputStream(strFilePath);
        HSSFWorkbook oIntegerationWb = new HSSFWorkbook(fis);
        FileOutputStream fos = new FileOutputStream(strFilePath);
        try (FileOutputStream fileOut = new FileOutputStream(strFilePath)) {
        }catch (Exception e) {
            e.printStackTrace();
        }


        HSSFSheet oIntegerationSheet = oIntegerationWb.getSheet(strSheetName);

       /*
       HSSFWorkbook oSummaryWb = oIntegerationWb;
       HSSFSheet oSummarySheet = oIntegerationWb.getSheet("Summary");
        int SummaryTotalRow = oSummarySheet.getLastRowNum();
        int SummarycolCount = oSummarySheet.getRow(0).getLastCellNum();
        HSSFRow sRow = oSummarySheet.getRow(0);

        for (int i = 0; i < SummarycolCount; i++) {
            oSummaryarray.add(sRow.getCell(i).getStringCellValue());
        }
        */
        int IntegerationTotalRow = oIntegerationSheet.getLastRowNum();
        int IntegerationColCount = oIntegerationSheet.getRow(0).getLastCellNum();
        HSSFRow iRow = oIntegerationSheet.getRow(0);
        HSSFCellStyle styleFail = oIntegerationWb.createCellStyle();
        HSSFCellStyle stylePass = oIntegerationWb.createCellStyle();
        HSSFCellStyle styleWarn = oIntegerationWb.createCellStyle();
        HSSFPalette palette = oIntegerationWb.getCustomPalette();
        HSSFColor myColor = palette.findSimilarColor(250, 151, 6);
        short palIndex = myColor.getIndex();

        styleFail.setFillForegroundColor(HSSFColor.RED.index);
        styleFail.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        stylePass.setFillForegroundColor(HSSFColor.GREEN.index);
        stylePass.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);
        styleWarn.setFillForegroundColor(palIndex);
        styleWarn.setFillPattern(HSSFCellStyle.SOLID_FOREGROUND);

        HSSFFont font = oIntegerationWb.createFont();
        font.setColor(HSSFColor.BLACK.index);

        String expCount="";
        String actCount="";
        int actualCount=0;

        for (int i = 0; i < listReturn.size(); i++) {
            //HSSFRow integerationTotalRow = oIntegerationSheet.createRow(IntegerationTotalRow+1);
            Map<String, List<String>> listMap = new HashMap<String, List<String>>();
            listMap = listReturn.get(i);
            if (!listMap.isEmpty()) {
                HSSFRow integerationTotalRow = oIntegerationSheet.createRow(IntegerationTotalRow+1);
                if((IntegerationTotalRow+1)==17)
                {
                }
                actualCount++;

                for (String key : listMap.keySet()) {

                    for (int j = 0; j < IntegerationColCount; j++) {
                        if (iRow.getCell(j).getStringCellValue().equalsIgnoreCase(key)) {
                            List<String> value = listMap.get(key);


                            if (value.get(0).equals(value.get(1))) {
                                HSSFCell expectedCell = integerationTotalRow.createCell(j);
                                HSSFCell actualCell = integerationTotalRow.createCell(j + 1);

                                expectedCell.setCellValue(value.get(0));
                                actualCell.setCellValue(value.get(1));
                            } else {
                                HSSFCell expectedCell = integerationTotalRow.createCell(j);
                                HSSFCell actualCell = integerationTotalRow.createCell(j + 1);

                                expectedCell.setCellValue(value.get(0));
                                actualCell.setCellValue(value.get(1));
                                styleFail.setFont(font);
                                expectedCell.setCellStyle(styleFail);
                                actualCell.setCellStyle(styleFail);
                            }
                        }
                        if (key.equalsIgnoreCase("Count")) {
                            List<String> value = listMap.get(key);
                            expCount=value.get(0);
                            actCount=value.get(1);
                            /*if(!actCount.equals("0")) {
                                integerationTotalRow.createCell(0).setCellValue("Expected is" + expCount + ", Actual count is" + (actCount));
                            }
                            else
                            {
                                integerationTotalRow.createCell(0).setCellValue("");
                            }*/

                        }
                    }
                }
                IntegerationTotalRow = IntegerationTotalRow + 1;
            }
        }

        HSSFRow integerationTotalRow1 = oIntegerationSheet.createRow(IntegerationTotalRow+1);
        integerationTotalRow1.createCell(0).setCellValue("Expected is"+expCount+", Actual count is"+(actCount));
        IntegerationTotalRow = IntegerationTotalRow + 1;

        for (int j = 0; j < IntegerationColCount; j = j + 2) {
            oIntegerationSheet.addMergedRegion(new CellRangeAddress(0, 0, j, j + 1));
            oIntegerationSheet.autoSizeColumn(j);
            oIntegerationSheet.autoSizeColumn(j + 1);

        }
        oIntegerationWb.write(fos);
        fos.close();
        fis.close();
    }
}
