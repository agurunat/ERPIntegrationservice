package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class Obj_Treatments extends AbstractPage {

    public WebElement peopleProvideTreatmentTextBox() {
        return waitForUnstableElement(By.id("C5__QUE_5847B0D83AF0F962263894"));
    }

    public WebElement anyOtherTreatmentsYesNoButton(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Yes")) {
            value = "Y";
        }
        String cssSelector = "input[name='C5__DIRECTLINE[1].YOURBUSINESS[1].TREATMENTS[1].PROVIDEANYOTHERTREATMENT'][value=" + value + "]";
        return waitForUnstableElement(By.cssSelector(cssSelector));
    }


    public WebElement addTreatmentButton() {
        return waitForElementToBeClickableAndReturnElement(By.id("C5__BUT_5847B0D83AF0F962263914"));
    }

    public WebElement addAnotherTreatmentButton() {
        return waitForElementToBeClickableAndReturnElement(By.id("C5__BUT_5847B0D83AF0F962263917"));
    }

    public WebElement treatmentDropdown() {
        return waitForElementPresent(By.id("C5__QUE_C8F3E8A0E3C242A2684128"));
    }

    public WebElement peoplePerformTreatmentTextBox() {
        return waitForElementPresent(By.id("C5__QUE_C8F3E8A0E3C242A2684140"));
    }

    public WebElement addTreatmentPopUpButton() {
        return waitForElementToBeClickableAndReturnElement(By.id("C5__BUT_C8F3E8A0E3C242A2684185"));
    }

    public WebElement qualificationYesNoButton(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Yes")) {
            value = "Y";
        }
        String cssSelector = "input[name='C5__DIRECTLINE[1].YOURBUSINESS[1].TREATMENTS[1].MAKESUREALLEMPLOYEES'][value=" + value + "]";
        return waitForUnstableElement(By.cssSelector(cssSelector));
    }

    public WebElement nextButton() {
        return waitForElementToBeClickableAndReturnElement(By.id("C5__BUT_5847B0D83AF0F962263931"));
    }

    public WebElement anyOtherTreatmentYesButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C5__provideOtherTreatment']/label[1]/span"));

    }

    public WebElement anyOtherTreatmentNoButton() {
        return waitForUnstableElement(By.xpath("//*[@id='radio_C5__provideOtherTreatment']/label[2]/span"));
    }

    public WebElement qualificationYesButton() {
        return waitForElementToBeClickableAndReturnElement(By.xpath("//*[@id='radio_C5__QUE_5847B0D83AF0F962263921']/label[1]/span"));
    }

    public WebElement qualificationNoButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C5__QUE_5847B0D83AF0F962263921']/label[2]/span"));
    }

    public WebElement addATreatmentButton() {
        return waitForElementToBeClickableAndReturnElement(By.id("C5__BUT_5847B0D83AF0F962263914"));
    }

    public WebElement addATreatmentButtonInternal() {
        return waitForElementToBeClickableAndReturnElement(By.id("C5__BUT_5847B0D83AF0F962263914"));
    }


    public WebElement manicureText() {
        return waitForUnstableElement(By.xpath("//*[@id='C3__C1__QUE_647B1F94A26D5FE1997836_R1']"));
        //*[@id="C3__C1__QUE_647B1F94A26D5FE1997836_R1"]
    }

    public WebElement facialText() {
        return waitForUnstableElement(By.xpath("//*[@id='C3__C1__QUE_647B1F94A26D5FE1997836_R2']"));
        //*[@id="C3__C1__QUE_647B1F94A26D5FE1997836_R2"]
    }

    public WebElement anyTreatmentNoButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C5__provideOtherTreatmentList']/label[2]/span"));

    }

    public WebElement anyTreatmentYesButton() {
        return waitForElementPresent(By.xpath("//*[@id='radio_C5__provideOtherTreatmentList']/label[1]/span"));

    }

    public WebElement anyOtherTreatmentsNoEmpYesNoButton(String YorN) {
        String value = "N";
        if (YorN.equalsIgnoreCase("Yes")) {
            value = "Y";
        }
        String cssSelector = "input[name^='C5__DIRECTLINE[1].YOURBUSINESS[1].TREATMENTS[1].PROVIDEANYTREATMENTS'][value=" + value + "]";
        return waitForUnstableElement(By.cssSelector(cssSelector));
    }

    public WebElement saveAndExit() {
        return waitForElementPresent(By.xpath("//*[@id='C5__BUT_D3E81D5ED026892F3306326']"));
    }

    public WebElement saveAndExitPopUp() {
        return waitForElementPresent(By.xpath("//*[@id='BUT_D3E81D5ED026892F1577152']"));
    }

    public WebElement treatmentBinButton() {
        return waitForElementPresent(By.id("C5__BUT_1EED2E0882C2655C536241"));
    }
    public WebElement moreOptionTreatment() {
        return waitForElementPresent(By.xpath("//*[@id='C3__QUE_24D9276FBA6E19C58823812']/p"));
    }
    //    //*[@id="C3__QUE_24D9276FBA6E19C58823812"]/p
    public List<WebElement> eleAccordionTreatment() {
        return findElements(By.xpath("//a[@id='step-1'][contains(text(),'Treatments provided by your business')]"));
    }
    public WebElement validationPopUp(){
        return waitForElementPresent(By.xpath("//*[@id='C5__HEAD_D175D5C43A7D6F933374031' or @id='C8__HEAD_523D3ECD008FAE54670308']"));
    }
    public WebElement validationPopUpYesButton(){
        return waitForElementPresent(By.xpath("//*[@id='C5__BUT_D175D5C43A7D6F933376635' or @id='C8__BUT_523D3ECD008FAE54670615']"));
    }
    public WebElement validationPopUpNoButton(){
        return waitForElementPresent(By.xpath("//*[@id='C5__BUT_D175D5C43A7D6F933374036' or @id='C8__BUT_523D3ECD008FAE54670620']"));
    }

//    C5__HEAD_D175D5C43A7D6F933374031

}

