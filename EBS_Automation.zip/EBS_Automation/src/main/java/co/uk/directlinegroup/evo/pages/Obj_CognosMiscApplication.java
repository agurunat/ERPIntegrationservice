package co.uk.directlinegroup.evo.pages;

import com.usmanhussain.habanero.framework.AbstractPage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 * Created by 323996 on 9/11/2017.
 */
public class Obj_CognosMiscApplication extends AbstractPage {

    public WebElement ccSearchedPolicyNumber() {
        return waitForElementVisible(By.xpath("//*[@id='p4_QUE_48B4D9E9C6401711205890']/div/div"));
    }
}
