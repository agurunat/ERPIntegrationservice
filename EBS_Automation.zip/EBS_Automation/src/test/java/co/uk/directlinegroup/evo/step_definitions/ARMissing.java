package co.uk.directlinegroup.evo.step_definitions;

import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.assertj.core.api.SoftAssertions;
import org.junit.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class ARMissing {

    String xmlId = null;
    String csvSplitBy = ",";
    private File inputFile;
    private Scenario scenario;
    String Pass = "<font color =\"#0E1FED\"><B>PASS</B></font>";

    @Before()
    public void before(Scenario scenario) {
        this.scenario = scenario;
    }


    @Given("^Xml Source file with Missing tages$")
    public File XmlSourceFileWithMissingtags() throws Throwable {
        inputFile = new File("C:\\Test\\AR_Trans.xml");
        return inputFile;
    }


    @When("^Target CSV File With null Value$")
    public void targetCSVFileWithNullValue() throws Throwable {
        //Scanner out = new Scanner(new BufferedReader(new FileReader("C:\\Test\\ARMissingTaginSourceFileCompare.csv")));

    }

    @Then("^Validate missing tag values in Target Table$")
    public void validateMissingTagValuesInTargetTable() throws Throwable {
        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(inputFile);
        doc.getDocumentElement().normalize();
        System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
        NodeList nList = doc.getElementsByTagName("dlg_ar_transaction");
        scenario.write("Root element :" + doc.getDocumentElement().getNodeName());
        System.out.println("----------------------------");
        for (int j = 0; j < nList.getLength(); j++) {
            Node nNode = nList.item(j);
            System.out.println("\nCurrent Element :" + nNode.getNodeName());
            scenario.write("\nCurrent Element :" + nNode.getNodeName());
            scenario.write("----------------------------");
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                String xmlId = eElement
                        .getElementsByTagName("id")
                        .item(0)
                        .getTextContent();


                // --------- Read the csv file ------------------
                Scanner out = new Scanner(new BufferedReader(new FileReader("C:\\Test\\ARMissingTaginSourceFileCompare.csv")));
                while (out.hasNextLine()) {
                    String data = out.nextLine();
                    String[] value = data.split(csvSplitBy);
                    for (int csv = 0; csv < value.length; csv++) {
                        if (value[csv].equals(xmlId)) {
                            //------------ validate id tag ---------------
                            String xmlID = eElement
                                    .getElementsByTagName("id")
                                    .item(0)
                                    .getTextContent();
                            //scenario.write("TEst"+1 +" ");
                            //System.out.println("Field Name      Value from Source Aquarium File     Value from DB        ");
                            scenario.write("---------------------------------------------------------------------------- ");
                            scenario.write("Field Name |    Value from Source Aquarium File  |   Value from DB  |      STATUS ");
                            scenario.write("---------------------------------------------------------------------------- ");

                            Assert.assertTrue("id validation",value[csv].equals(xmlID));
                            if (value[csv].equals(xmlID)) {
                                System.out.println("XML id :-" + xmlID + " is matching with CSV File:-" + value[csv] + " ------------ > PASS");
                                //scenario.write("Source :-" + xmlID + " is matching with CSV File:-" + value[csv] + " ------------ > PASS");
                                scenario.write("Source      |   "         +     xmlID       +       "   |   "   +    value[csv]       +      "|     PASS   ");
                                csv++;
                            } else {
                                System.out.println("id is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                            }

                            //------------ validate Base Currency Amount  ---------------
                            String xmlbaseCurrencyAmount = eElement
                                    .getElementsByTagName("base_currency_amount")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("XML Base Currency Amount validation:- Source Base Currency Amount is matching with CSV value",value[csv].equals(xmlbaseCurrencyAmount));
                            if (value[csv].equals(eElement
                                    .getElementsByTagName("base_currency_amount")
                                    .item(0)
                                    .getTextContent())) {
                                System.out.println("XML Base Currency Amount :-" + xmlbaseCurrencyAmount + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                //scenario.write("XML Base Currency Amount :-" + xmlbaseCurrencyAmount + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("Base Currency Amount      |"         +     xmlbaseCurrencyAmount       +       "    |  "   +    value[csv]       +      "|     PASS   ");
                                csv++;
                            } else {
                                System.out.println("Base Currency Amount is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("XML Base Currency Amount :-" + xmlbaseCurrencyAmount + " is not matching with CSV File:-" + value[csv] + " ----- > FAIL");
                            }

                            //------------ validate Currency cd  ---------------
                            String xmlcurrencyCode = eElement
                                    .getElementsByTagName("currency_cd")
                                    .item(0)
                                    .getTextContent();

                            Assert.assertTrue("XML Currency cd validation:- Source Base Currency Amount is matching with CSV value",value[csv].equals(xmlcurrencyCode));
                            if (value[csv].equals(eElement
                                    .getElementsByTagName("currency_cd")
                                    .item(0)
                                    .getTextContent())) {
                                System.out.println("XML Currency cd :-" + xmlcurrencyCode + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("XML Currency cd :-" + xmlcurrencyCode + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                csv++;
                            } else {
                                System.out.println("Currency cd is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("XML Currency cd :-" + xmlcurrencyCode + " is not matching with CSV File:-" + value[csv] + " ----- > FAIL");
                            }

                            //------------ validate Payer Name   ---------------
                            String xmlpayerName = eElement
                                    .getElementsByTagName("payer_name")
                                    .item(0)
                                    .getTextContent();

                            if (value[csv].equals(eElement
                                    .getElementsByTagName("payer_name")
                                    .item(0)
                                    .getTextContent())) {
                                System.out.println("XML Payer Name :-" + xmlpayerName + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("XML Payer Name :-" + xmlpayerName + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                csv++;
                            } else {
                                System.out.println("Payer Name is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("XML Payer Name :-" + xmlpayerName + " is not matching with CSV File:-" + value[csv] + " ----- > FAIL");
                            }

                            //------------ validate policy_term ---------------
                            System.out.println("        Missing Field Validation        ");
                            boolean blnPolicyterm = eElement
                                    .getElementsByTagName("policy_term_months").equals(0);
                            if (!blnPolicyterm) {
                                System.out.println("Policy term month fields does not available in Source file and values from CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("Policy term month fields does not available in Source file and values from CSV File:-" + value[csv] + " ----- > PASS");
                                csv++;
                            } else {
                                System.out.println("Policy term month fields is available in Source file and values from CSV File:-" + value[csv] + " ----- > Fail");
                                scenario.write("Policy term month fields does not available in Source file and values from CSV File:-" + value[csv] + " ----- > Fail");
                            }



                        }
                    }
                }
            }
        }
    }
}