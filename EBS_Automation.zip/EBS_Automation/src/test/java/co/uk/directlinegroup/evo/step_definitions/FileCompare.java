package co.uk.directlinegroup.evo.step_definitions;

import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class FileCompare {
    String xmlId = null;
    String csvSplitBy = ",";
    public File inputFile;
    private Scenario scenario;

    int pass_count = 0;
    int fail_count = 0;
    String Pass = "<font color =\"#0E1FED\"><B>PASS</B></font>";
    String Fail = "<font color =\"#ff1a1a\"><B>FAIL</B></font>";
    String v_pass = "<font color =\"#0E1FED\"><B>Passed</B></font>";
    String v_fail = "<font color =\"#ff1a1a\"><B>Failed</B></font>";
    String Total_Pass = "<font color =\"#0E1FED\"><B>TOTAL VERIFICATION</B></font>";
    String reportHeader = "<font color =\"#0E1FED\"><B>Aquarium AR : File - DB Comparision Report</B></font>";

    String fieldname = "<font color =\"#0E1FED\"><B>Field Name</B></font>";
    String SourceValue = "<font color =\"#0E1FED\"><B>Source Value</B></font>";
    String dbvalue = "<font color =\"#0E1FED\"><B>DB value</B></font>";
    String status = "<font color =\"#0E1FED\"><B>STATUS</B></font>";
    String TAB1 = "\t";
    String TAB2 = "\t\t";
    String TAB3 = "\t\t\t";
    String TAB4 = "\t\t\t\t";
    String TAB5 = "\t\t\t\t\t";


    @Before()
    public void before(Scenario scenario) {
        this.scenario = scenario;
    }
    @Given("^Source xml file$")
    public File sourceXmlFile() throws Throwable {
        inputFile = new File("C:\\Test\\AR_Trans.xml");
        //throw new PendingException();
        return inputFile;
    }
    @When("^Target csv file$")
    public void targetCsvFile() throws Throwable {
        Scanner out = new Scanner(new BufferedReader(new FileReader("C:\\Test\\AR_CSV\\AR_Consalidate.csv")));
        //throw new PendingException();

    }

    @Then("^validate the tags$")
    public void validateTheTags() throws Throwable, IOException {

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(inputFile);
        doc.getDocumentElement().normalize();
        //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
        //scenario.write("Root element :" + doc.getDocumentElement().getNodeName());

        NodeList nList = doc.getElementsByTagName("dlg_ar_transaction");
        scenario.write(TAB5 +reportHeader+ TAB5);
        System.out.println("----------------------------");
        for (int j = 0; j < nList.getLength(); j++) {
            Node nNode = nList.item(j);
            System.out.println("\nCurrent Element :" + nNode.getNodeName());
            scenario.write("\nCurrent Element :" + nNode.getNodeName());
            scenario.write("----------------------------");
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                String xmlId = eElement
                        .getElementsByTagName("id")
                        .item(0)
                        .getTextContent();

                // --------- Read the csv file ------------------
                Scanner out = new Scanner(new BufferedReader(new FileReader("C:\\Test\\AR_CSV\\AR_Consalidate.csv")));
                while (out.hasNextLine()) {
                    String data = out.nextLine();
                    String[] value = data.split(csvSplitBy);
                    for (int csv = 0; csv < value.length; csv++) {
                        if (value[csv].equals(xmlId)) {
                            //------------ validate id tag ---------------
                            String xmlID = eElement
                                    .getElementsByTagName("id")
                                    .item(0)
                                    .getTextContent();

                            Assert.assertTrue("XML ID Validation", value[csv].equals(xmlID));
                            if (value[csv].equals(xmlID)) {
                                System.out.println("XML id :-" + xmlID + " is matching with CSV File:-" + value[csv] + " ------------ > PASS");
                                scenario.write("-------------------------------------------------------------------------------------------------------------------");
                                scenario.write(fieldname + " \t\t\t" + SourceValue + "\t\t\t\t" + dbvalue + " \t\t\t" + status + "\t\t\t");
                                scenario.write("-------------------------------------------------------------------------------------------------------------------");
                                scenario.write("id \t\t\t\t"   + xmlID + " \t\t\t\t" + value[csv] + " \t\t\t"+Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("id is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("id \t\t\t\t"   + xmlID + " \t\t\t\t" + value[csv] + " \t\t\t"+Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Base Currency Amount  ---------------
                            String xmlbaseCurrencyAmount = eElement
                                    .getElementsByTagName("base_currency_amount")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("base Currenct amount validation",value[csv].equals(xmlbaseCurrencyAmount));
                            if (value[csv].equals(eElement
                                    .getElementsByTagName("base_currency_amount")
                                    .item(0)
                                    .getTextContent())) {
                                scenario.write("Base Currency Amount" + TAB2 +  xmlbaseCurrencyAmount +  TAB5 +  value[csv]  + TAB4 +Pass);
                                System.out.println("XML Base Currency Amount :-" + xmlbaseCurrencyAmount + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("XML Base Currency Amount :-" + xmlbaseCurrencyAmount + " is not matching with CSV File:-" + value[csv] + " ----- > FAIL");
                                scenario.write("Base Currency Amount" + TAB2 +  xmlbaseCurrencyAmount +  TAB5 +  value[csv]  + TAB4 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Currency cd  ---------------
                            String xmlcurrencyCode = eElement
                                    .getElementsByTagName("currency_cd")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("Currenct Code validation",value[csv].equals(xmlcurrencyCode));
                            if (value[csv].equals(eElement
                                    .getElementsByTagName("currency_cd")
                                    .item(0)
                                    .getTextContent())) {
                                scenario.write("Currency_cd"+ TAB3  + xmlcurrencyCode  +  TAB5  + value[csv] +  TAB4 +Pass);
                                System.out.println("XML Currency cd :-" + xmlcurrencyCode + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                csv = csv+5;
                                pass_count++;
                            } else {
                                System.out.println("Currency cd is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("Currency_cd"+ TAB3  + xmlcurrencyCode  +  TAB5  + value[csv] +  TAB4 +Fail);
                                csv = csv+5;
                                fail_count++;
                            }

                            //------------ validate Transaction id ---------------
                            String xmltransactionId = eElement
                                    .getElementsByTagName("transaction_id")
                                    .item(0)
                                    .getTextContent();
                            //String xmlupdateTransID = xmlclaimNumber + xmltransactionId;

                            Assert.assertTrue("XML Transaction id Validation", value[csv].equals(xmltransactionId));
                            if (value[csv].equals(xmltransactionId)) {
                                System.out.println("XML Transaction id :-" + xmltransactionId + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                scenario.write("Document Number "+ TAB2  + xmltransactionId +  TAB4 + value[csv] + TAB3 + Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("XML Transaction id :-" + xmltransactionId + " is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("Document Number "+ TAB2  + xmltransactionId +  TAB4 + value[csv] + TAB3 + Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Payer Name   ---------------
                            String xmlpayerName = eElement
                                    .getElementsByTagName("payer_name")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("payer Name Validation", value[csv].equals(xmlpayerName));
                            if (value[csv].equals(eElement
                                    .getElementsByTagName("payer_name")
                                    .item(0)
                                    .getTextContent())) {
                                System.out.println("XML Payer Name :-" + xmlpayerName + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("interface_line_attribute1" + TAB1  + xmlpayerName +  TAB4 +  value[csv]  + TAB3 + Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("XML Payer Name :-" + xmlpayerName + " is not matching with CSV File:-" + value[csv] + " ----- > FAIL");
                                scenario.write("interface_line_attribute1"  + xmlpayerName +  TAB4 +    value[csv]  + TAB3 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Loss Date   ---------------
                            String xmllossDate = eElement
                                    .getElementsByTagName("loss_date")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("payer Name Validation", value[csv].equals(xmllossDate));
                            if (value[csv].equals(eElement
                                    .getElementsByTagName("loss_date")
                                    .item(0)
                                    .getTextContent())) {
                                System.out.println("XML Loss_Date :-" + xmllossDate + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("interface_line_attribute2" +TAB1  + xmllossDate +  TAB3 + value[csv] + TAB2 + Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("XML Loss_Date :-" + xmllossDate + " is not matching with CSV File:-" + value[csv] + " ----- > FAIL");
                                scenario.write("interface_line_attribute2" +TAB1  + xmllossDate +  TAB3 + value[csv] + TAB2 + Fail);
                                csv++;
                                fail_count++;
                            }

                            /*
                                Policy term month filed does not available in Source file. Clarification required.
                             */

                            //------------ validate exposure   ---------------
                            String xmlexposure = eElement
                                    .getElementsByTagName("exposure")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("exposure Validation", value[csv].equals(xmlexposure));
                            if (value[csv].equals(xmlexposure)) {
                                System.out.println("XML exposure :-" + xmlexposure + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("interface_line_attribute4" +TAB1  + xmlexposure +  TAB5 + value[csv]  + TAB4 + Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("XML exposure :-" + xmlexposure + " is not matching with CSV File:-" + value[csv] + " ----- > FAIL");
                                scenario.write("interface_line_attribute4" +TAB1  + xmlexposure +  TAB5 + value[csv]  + TAB4 + Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Exchange Rate   ---------------
                            String xmlexchangeRate = eElement
                                    .getElementsByTagName("exchange_rate")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("Exchange Rate Validation", value[csv].equals(xmlexchangeRate));
                            if (value[csv].equals(xmlexchangeRate)) {
                                System.out.println("XML Exchange Rate :- " + xmlexchangeRate + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("interface_line_attribute5" +TAB1  + xmlexchangeRate +  TAB5 +  value[csv]  + TAB4 +Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("Exchange Rate is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("interface_line_attribute5" +TAB1  + xmlexchangeRate +  TAB5 +  value[csv]  + TAB4 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Currency cd  interface_line_attribute6 ---------------
                            String xmlcurrencyCd_LA6 = eElement
                                    .getElementsByTagName("currency_cd")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("Currenct Code validation",value[csv].equals(xmlcurrencyCd_LA6));
                            if (value[csv].equals(xmlcurrencyCd_LA6)) {
                                scenario.write("interface_line_attribute6" +TAB1  +  xmlcurrencyCd_LA6  + TAB5 + value[csv] +  TAB4 +Pass);
                                System.out.println("XML Currency cd :-" + xmlcurrencyCd_LA6 + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("Currency cd is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("interface_line_attribute6" +TAB1  +  xmlcurrencyCd_LA6  + TAB5 + value[csv] +  TAB4 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Base Currency Amount interface_line_attribute7 ---------------
                            String xmlbaseCurrencyAmount_LA7 = eElement
                                    .getElementsByTagName("base_currency_amount")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("base Currenct amount validation",value[csv].equals(xmlbaseCurrencyAmount_LA7));
                            if (value[csv].equals(xmlbaseCurrencyAmount_LA7)) {
                                scenario.write("interface_line_attribute7" +TAB1 +  xmlbaseCurrencyAmount_LA7  +  TAB5  +  value[csv]  +  TAB4 +Pass);
                                System.out.println("XML Base Currency Amount :-" + xmlbaseCurrencyAmount_LA7 + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                csv = csv+1;
                                pass_count++;
                            } else {
                                System.out.println("XML Base Currency Amount :-" + xmlbaseCurrencyAmount_LA7 + " is not matching with CSV File:-" + value[csv] + " ----- > FAIL");
                                scenario.write("interface_line_attribute7" +TAB1 +  xmlbaseCurrencyAmount_LA7  +  TAB5  +  value[csv]  +  TAB4 +Fail);
                                csv = csv+1;
                                fail_count++;
                            }

                            //------------ validate interface_line_attribute8 Hardcoded value - 'LINE'---------------
                            boolean blnint_line_AT8 = eElement
                                    .getElementsByTagName("taxable_flag").equals(0);
                            if (!blnint_line_AT8){
                                if(value[csv].equals("'LINE'")){
                                    scenario.write("interface_line_attribute8"+ TAB1 + "Hardcoded value - 'LINE'"+ TAB2 + value[csv]+ TAB4 +Pass);
                                    csv++;
                                    pass_count++;
                                }else{
                                    scenario.write("interface_line_attribute8"+ TAB1 + "Hardcoded value - 'LINE'"+ TAB2 + value[csv]+ TAB4 +Fail);
                                    csv++;
                                    fail_count++;
                                }
                            }

                            //------------ validate claim number ---------------
                            String xmlclaimNumber = eElement
                                    .getElementsByTagName("claim_number")
                                    .item(0)
                                    .getTextContent();

                            Assert.assertTrue("XML claim number Validation", value[csv].equals(xmlclaimNumber));
                            if (value[csv].equals(eElement
                                    .getElementsByTagName("claim_number")
                                    .item(0)
                                    .getTextContent())) {
                                System.out.println("Claim number   " + xmlclaimNumber + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                scenario.write("interface_line_attribute9" +TAB1   + xmlclaimNumber +   TAB4 + value[csv] + TAB3 +Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("claim number is not matching with CSV File:-" + value[csv] + " ------ > FAIL");
                                scenario.write("interface_line_attribute9" +TAB1   + xmlclaimNumber +   TAB4 + value[csv] + TAB3 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Transaction id interface_line_attribute14---------------
                            String xmltransactionId_LA14 = eElement
                                    .getElementsByTagName("transaction_id")
                                    .item(0)
                                    .getTextContent();

                            Assert.assertTrue("XML Transaction id Validation", value[csv].equals(xmltransactionId_LA14));
                            if (value[csv].equals(xmltransactionId_LA14)) {
                                System.out.println("XML Transaction id :-" + xmltransactionId_LA14 + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                scenario.write("interface_line_attribute14" +TAB1 + xmltransactionId_LA14 +  TAB4 + value[csv] + TAB3 +Pass);
                                csv = csv+4;
                                pass_count++;
                            } else {
                                System.out.println("XML Transaction id :-" + xmltransactionId_LA14 + " is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("interface_line_attribute14" +TAB1 + xmltransactionId_LA14 +  TAB4 + value[csv] + TAB3 +Fail);
                                csv = csv+4;
                                fail_count++;
                            }

                            //------------ validate claim number header_attribute1---------------
                            String xmlclaimNumber_HA1 = eElement
                                    .getElementsByTagName("claim_number")
                                    .item(0)
                                    .getTextContent();

                            Assert.assertTrue("XML claim number Validation", value[csv].equals(xmlclaimNumber_HA1));
                            if (value[csv].equals(xmlclaimNumber_HA1)) {
                                System.out.println("Claim number   " + xmlclaimNumber_HA1 + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                scenario.write("header_attribute1"+ TAB2  + xmlclaimNumber_HA1 +  TAB4 + value[csv] + TAB3 +Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("claim number is not matching with CSV File:-" + value[csv] + " ------ > FAIL");
                                scenario.write("header_attribute1"+ TAB2  + xmlclaimNumber_HA1 +  TAB4 + value[csv] + TAB3 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Recovery ref ---------------
                            String xmlRecovery_ref = eElement
                                    .getElementsByTagName("recovery_ref")
                                    .item(0)
                                    .getTextContent();

                            Assert.assertTrue("XML Recovery ref Validation", value[csv].equals(xmlRecovery_ref));
                            if (value[csv].equals(xmlRecovery_ref)) {
                                System.out.println("XML Recovery ref :-" + xmlRecovery_ref + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("header_attribute2" + TAB2  + xmlRecovery_ref +  TAB4 + value[csv] + TAB3 +Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("Recovery ref is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("header_attribute2" + TAB2  + xmlRecovery_ref +  TAB4 + value[csv] + TAB3 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Policy Number ---------------
                            String xmlpolicyNumber = eElement
                                    .getElementsByTagName("policy_number")
                                    .item(0)
                                    .getTextContent();

                            Assert.assertTrue("XML Policy Number Validation", value[csv].equals(xmlpolicyNumber));
                            if (value[csv].equals(xmlpolicyNumber)) {
                                System.out.println("XML Policy Number:- " + xmlpolicyNumber + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                scenario.write("header_attribute3" + TAB2  + xmlpolicyNumber +  TAB4 + value[csv] + TAB3 +Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("Policy Number is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("header_attribute3" + TAB2  + xmlpolicyNumber +  TAB4 + value[csv] + TAB3 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Recovery Category ---------------
                            String xmlRecoveryCatg = eElement
                                    .getElementsByTagName("recovery_category")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("Recovery Category Validation", value[csv].equals(xmlRecoveryCatg));
                            if (value[csv].equals(xmlRecoveryCatg)) {
                                System.out.println("XML Recovery Category :-" + xmlRecoveryCatg + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                scenario.write("header_attribute4" +TAB2  + xmlRecoveryCatg +  TAB5 + value[csv] + TAB4 +Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("Recovery Category is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("header_attribute4" +TAB2  + xmlRecoveryCatg +  TAB5 + value[csv] + TAB4 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Payer Name  header_attribute5 ---------------
                            String xmlpayerName_HA5 = eElement
                                    .getElementsByTagName("payer_name")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("payer Name Validation", value[csv].equals(xmlpayerName_HA5));
                            if (value[csv].equals(xmlpayerName_HA5)) {
                                System.out.println("XML Payer Name :-" + xmlpayerName_HA5 + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("header_attribute5" +TAB2 + xmlpayerName_HA5 +  TAB4 +  value[csv]  + TAB3 +Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("XML Payer Name :-" + xmlpayerName_HA5 + " is not matching with CSV File:-" + value[csv] + " ----- > FAIL");
                                scenario.write("header_attribute5" +TAB2 + xmlpayerName_HA5 +  TAB4 +  value[csv]  + TAB3 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Underwriter ---------------
                            String xmlUnderwriter = eElement
                                    .getElementsByTagName("underwriter")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("Underwriter Validation", value[csv].equals(xmlUnderwriter));
                            if (value[csv].equals(xmlUnderwriter)) {
                                System.out.println("XML Underwriter :- " + xmlUnderwriter + "  is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("header_attribute6" +TAB2  + xmlUnderwriter +  TAB5 +   value[csv]  + TAB4 +Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("Underwriter is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("header_attribute6" +TAB2  + xmlUnderwriter +  TAB5 +   value[csv]  + TAB4 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate brand ---------------
                            String xmlbrand = eElement
                                    .getElementsByTagName("brand")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("Brand Validation", value[csv].equals(xmlbrand));
                            if (value[csv].equals(xmlbrand)) {
                                System.out.println("XML Brand :- " + xmlbrand + "  is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("header_attribute7" +TAB2  + xmlbrand + TAB4 +   value[csv]  + TAB3 +Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("Brand is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("header_attribute7" +TAB2  + xmlbrand + TAB4 +   value[csv]  + TAB3 +Fail);
                                csv++;
                                fail_count++;
                            }


                            //------------ validate Product  ---------------
                            String xmlProduct = eElement
                                    .getElementsByTagName("product")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("Product Validation", value[csv].equals(xmlProduct));
                            if (value[csv].equals(xmlProduct)) {
                                System.out.println("XML Product :- " + xmlProduct + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("header_attribute8" +TAB2  + xmlProduct +  TAB4 +  value[csv]  + TAB3 +Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("Product is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("header_attribute8" +TAB2  + xmlProduct +  TAB4 +  value[csv]  + TAB3 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Cost Type  ---------------
                            String xmlcostType = eElement
                                    .getElementsByTagName("cost_type")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("Cost Type Validation", value[csv].equals(xmlcostType));
                            if (value[csv].equals(xmlcostType)) {
                                System.out.println("XML Cost Type :- " + xmlcostType + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("header_attribute9" +TAB2  + xmlcostType + TAB4 +  value[csv]   + TAB3 +Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("Cost Type is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("header_attribute9" +TAB2  + xmlcostType + TAB4 +  value[csv]   + TAB3 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Cost category  ---------------
                            String xmlcostCategory = eElement
                                    .getElementsByTagName("cost_category")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("Cost category Validation", value[csv].equals(xmlcostCategory));
                            if (value[csv].equals(xmlcostCategory)) {
                                System.out.println("XML Cost category :- " + xmlcostCategory + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("header_attribute10" + TAB2  + xmlcostCategory +  TAB5 +   value[csv]   + TAB4 +Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("Cost category is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("header_attribute10" + TAB2  + xmlcostCategory +  TAB5 +   value[csv]   + TAB4 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Change Type ---------------
                            String xmlChangeType = eElement
                                    .getElementsByTagName("change_type")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("Change Type Validation", value[csv].equals(xmlChangeType));
                            if (value[csv].equals(xmlChangeType)) {
                                System.out.println("XML Change Type :- " + xmlChangeType + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("header_attribute11" +TAB2  + xmlChangeType +  TAB4 +  value[csv]  + TAB3 +Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("Change Type is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("header_attribute11" +TAB2  + xmlChangeType +  TAB4 +  value[csv]  + TAB3 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Currency cd  header_attribute12 ---------------
                            String xmlcurrencyCd_HA12 = eElement
                                    .getElementsByTagName("currency_cd")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("Currenct Code validation",value[csv].equals(xmlcurrencyCd_HA12));
                            if (value[csv].equals(xmlcurrencyCd_HA12)) {
                                scenario.write("header_attribute12" +TAB2  +  xmlcurrencyCd_HA12  + TAB5   +  value[csv]  + TAB4 +Pass);
                                System.out.println("XML Currency cd :-" + xmlcurrencyCd_HA12 + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("Currency cd is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("header_attribute12" +TAB2  +  xmlcurrencyCd_HA12  + TAB5   +  value[csv]  + TAB4 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Base Currency Amount header_attribute13 ---------------
                            String xmlbaseCurrencyAmount_HA13 = eElement
                                    .getElementsByTagName("base_currency_amount")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("base Currenct amount validation",value[csv].equals(xmlbaseCurrencyAmount_HA13));
                            if (value[csv].equals(xmlbaseCurrencyAmount_HA13)) {
                                scenario.write("header_attribute13" +TAB2  +  xmlbaseCurrencyAmount_HA13  +  TAB5 +  value[csv]  + TAB4 +Pass);
                                System.out.println("XML Base Currency Amount :-" + xmlbaseCurrencyAmount_HA13 + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("XML Base Currency Amount :-" + xmlbaseCurrencyAmount_HA13 + " is not matching with CSV File:-" + value[csv] + " ----- > FAIL");
                                scenario.write("header_attribute13\t\t "  +  xmlbaseCurrencyAmount_HA13  +  "\t\t\t\t\t "  +  value[csv]  +   "\t\t\t\t"+Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate Recovery ref header_attribute14---------------
                            String xmlRecovery_ref_HA14 = eElement
                                    .getElementsByTagName("recovery_ref")
                                    .item(0)
                                    .getTextContent();

                            Assert.assertTrue("XML Recovery ref Validation", value[csv].equals(xmlRecovery_ref_HA14));
                            if (value[csv].equals(xmlRecovery_ref_HA14)) {
                                System.out.println("XML Recovery ref :-" + xmlRecovery_ref_HA14 + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                scenario.write("header_attribute14" +TAB2 + xmlRecovery_ref_HA14 +  TAB4 + value[csv] + TAB3 +Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("Recovery ref is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("header_attribute14" +TAB2 + xmlRecovery_ref_HA14 +  TAB4 + value[csv] + TAB3 +Fail);
                                csv++;
                                fail_count++;
                            }

                            //------------ validate line_type Hardcoded value - 'LINE'---------------
                            boolean blnline_type = eElement
                                    .getElementsByTagName("line_type").equals(0);
                            if (!blnline_type){
                                if(value[csv].equals("'LINE'")){
                                    scenario.write("line_type" +TAB3 + "Hardcoded value - 'LINE'"+ TAB2+ value[csv]+ TAB4 +Pass);
                                    csv = csv+5;
                                    pass_count++;
                                }else{
                                    scenario.write("line_type" +TAB3 + "Hardcoded value - 'LINE'"+ TAB2+ value[csv]+ TAB4 +Fail);
                                    csv = csv+5;
                                    fail_count++;
                                }
                            }

                            //------------ validate ltaxable_flag Hardcoded value - 'N'---------------
                            boolean blntaxable_flag = eElement
                                    .getElementsByTagName("taxable_flag").equals(0);
                            if (!blntaxable_flag){
                                if(value[csv].equals("'N'")){
                                    scenario.write("taxable_flag"+TAB3 + "Hardcoded value - 'N'"+ TAB3 + value[csv]+ TAB4 +Pass);
                                    csv = csv+3;
                                    pass_count++;
                                }else{
                                    scenario.write("taxable_flag"+TAB3 + "Hardcoded value - 'N'"+ TAB3 + value[csv]+ TAB4 +Fail);
                                    csv = csv+3;
                                    fail_count++;
                                }
                            }


                            //------------ validate Transaction Date  ---------------
                            String xmltransactionDate = eElement
                                    .getElementsByTagName("transaction_date")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("Transaction Date Validation", value[csv].equals(xmltransactionDate));
                            if (value[csv].equals(xmltransactionDate)) {
                                System.out.println("XML Transaction Date :- " + xmltransactionDate + "i s matching with CSV File:-" + value[csv] + " ------ > PASS");
                                scenario.write("trx_date"+  TAB3  + xmltransactionDate + TAB3 + value[csv] + TAB2 +Pass);
                                csv = csv+2;
                                pass_count++;
                            } else {
                                System.out.println("Transaction Date is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("trx_date"+  TAB3  + xmltransactionDate + TAB3 + value[csv] + TAB2 +Fail);
                                csv = csv+2;
                                fail_count++;
                            }

                            //------------ validate Base Currency Amount unit_selling_price ---------------
                            String xmlbaseCurrencyAmount_USP = eElement
                                    .getElementsByTagName("base_currency_amount")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("base Currenct amount validation",value[csv].equals(xmlbaseCurrencyAmount_USP));
                            if (value[csv].equals(xmlbaseCurrencyAmount_USP)) {
                                scenario.write("unit_selling_price" +TAB2 +  xmlbaseCurrencyAmount_USP + TAB5    +  value[csv]  + TAB4 +Pass);
                                System.out.println("XML Base Currency Amount :-" + xmlbaseCurrencyAmount_USP + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                csv = csv+2;
                                pass_count++;
                            } else {
                                System.out.println("XML Base Currency Amount :-" + xmlbaseCurrencyAmount_USP + " is not matching with CSV File:-" + value[csv] + " ----- > FAIL");
                                scenario.write("unit_selling_price" +TAB2 +  xmlbaseCurrencyAmount_USP + TAB5    +  value[csv]  + TAB4 +Fail);
                                csv = csv+2;
                                fail_count++;
                            }

                            //------------ validate cc_public_id ---------------
                            String xmlccPublicId = eElement
                                    .getElementsByTagName("cc_public_id")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("cc_public_id validation",value[csv].equals(xmlccPublicId));
                            if (value[csv].equals(xmlccPublicId)) {
                                scenario.write("HEADER_GDF_ATTRIBUTE1" +TAB2  +  xmlccPublicId  +  TAB4 + value[csv] + TAB3 +Pass);
                                System.out.println("XML cc_public_id :-" + xmlccPublicId + " is matching with CSV File:-" + value[csv] + " ----- > PASS");
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("XML cc_public_id :-" + xmlccPublicId + " is not matching with CSV File:-" + value[csv] + " ----- > FAIL");
                                scenario.write("HEADER_GDF_ATTRIBUTE1" +TAB2  +  xmlccPublicId  +  TAB4 + value[csv] + TAB3 +Fail);
                                csv++;
                                fail_count++;
                            }


                        }
                    }
                }
            }
        }
        int tot_count =  pass_count+fail_count;
        scenario.write("---------------------------------------------------------------------------------------------------------------");
        scenario.write(Total_Pass + ":" +TAB3 + tot_count + TAB2 + v_pass+"\t:" + pass_count +TAB3 + v_fail+ TAB1+":" + fail_count);
        scenario.write("---------------------------------------------------------------------------------------------------------------");
    }

}
