package co.uk.directlinegroup.evo.step_definitions;

import co.uk.directlinegroup.evo.utils.Reader;
import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class ARLookUpValue extends Reader{

    String xmlId = null;
    String csvSplitBy = ",";
    private File inputFile;
    private Scenario scenario;
    String getCellValue = null;
    String getCellValue_Rate = null;
    public Reader rd;

    int pass_count = 0;
    int fail_count = 0;
    String Pass = "<font color =\"#0E1FED\"><B>PASS</B></font>";
    String Fail = "<font color =\"#ff1a1a\"><B>FAIL</B></font>";
    String v_pass = "<font color =\"#0E1FED\"><B>Passed</B></font>";
    String v_fail = "<font color =\"#ff1a1a\"><B>Failed</B></font>";
    String Total_Pass = "<font color =\"#0E1FED\"><B>TOTAL PASS VERIFICATION</B></font>";
    String reportHeader = "<font color =\"#0E1FED\"><B>Aquarium AR : File - DB Comparision Report</B></font>";

    String fieldname = "<font color =\"#0E1FED\"><B>System Maintainable Field Name</B></font>";
    String SourceValue = "<font color =\"#0E1FED\"><B>LookUp Value</B></font>";
    String dbvalue = "<font color =\"#0E1FED\"><B>DB value</B></font>";
    String status = "<font color =\"#0E1FED\"><B>STATUS</B></font>";
    String TAB1 = "\t";
    String TAB2 = "\t\t";
    String TAB3 = "\t\t\t";
    String TAB4 = "\t\t\t\t";
    String TAB5 = "\t\t\t\t\t";


    @Before()
    public void before(Scenario scenario) {
        this.scenario = scenario;
    }


    @Given("^Xml Source file with Missing LookUp Fields$")
    public File XmlSourceFileWithMissingLookUpFields() throws Throwable {
        inputFile = new File("C:\\Test\\AR_Trans.xml");
        return inputFile;
    }


    @When("^Target CSV File with LookUp value$")
    public void targetCSVFileWithLookUpValue() throws Throwable {
        Scanner out = new Scanner(new BufferedReader(new FileReader("C:\\Test\\AR_CSV\\AR_Consalidate.csv")));
    }

    @Then("^Read the LookUp file$")
    public void readTheLookUpFile() throws Throwable {
        rd = new Reader();
        //getCellValue = rd.lookUpreference();
    }

    @Then("^Validate the LookUp values in Target Table$")
    public void validateTheLookUpValuesInTargetTable() throws Throwable {

            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            doc.getDocumentElement().normalize();
            //System.out.println("Root element :" + doc.getDocumentElement().getNodeName());
            //scenario.write("Root element :" + doc.getDocumentElement().getNodeName());

            NodeList nList = doc.getElementsByTagName("dlg_ar_transaction");
            System.out.println("----------------------------");
            scenario.write(TAB5 +reportHeader+ TAB5);
            for (int j = 0; j < nList.getLength(); j++) {
                Node nNode = nList.item(j);
                System.out.println("\nCurrent Element :" + nNode.getNodeName());
                scenario.write("\nCurrent Element :" + nNode.getNodeName());
                scenario.write("----------------------------");
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element eElement = (Element) nNode;
                    String xmlId = eElement
                            .getElementsByTagName("id")
                            .item(0)
                            .getTextContent();

                    // --------- Read the csv file ------------------
                    Scanner out = new Scanner(new BufferedReader(new FileReader("C:\\Test\\AR_CSV\\AR_Consalidate.csv")));
                    while (out.hasNextLine()) {
                        String data = out.nextLine();
                        String[] value = data.split(csvSplitBy);
                        for (int csv = 0; csv < value.length; csv++) {
                            if (value[csv].equals(xmlId)) {
                                //------------ validate id tag ---------------
                                String xmlID = eElement
                                        .getElementsByTagName("id")
                                        .item(0)
                                        .getTextContent();
                                Assert.assertTrue("XML id validation:- Source id is matching with CSV value",value[csv].equals(xmlID));
                                if (value[csv].equals(xmlID)) {
                                    System.out.println("XML id :-" + xmlID + " is matching with CSV File:-" + value[csv] + " ------------ > PASS");
                                    scenario.write(TAB5+ " Maintainable Lookup "+ TAB5);
                                    scenario.write("-------------------------------------------------------------------------------------------------------------------");
                                    scenario.write(fieldname +TAB2 + SourceValue + TAB4  + dbvalue +TAB3 + status + TAB4);
                                    scenario.write("-------------------------------------------------------------------------------------------------------------------");
                                    scenario.write("id "+ TAB5  +  xmlID   + TAB4 + value[csv] + TAB3 + Pass );
                                    csv = csv+3;
                                    pass_count++;
                                } else {
                                    System.out.println("id is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                    scenario.write("id "+ TAB5  +  xmlID   + TAB4 + value[csv] + TAB3 + Fail );
                                    csv = csv+3;
                                    fail_count++;
                                }


                                //------------- validate DLG_PULSE_CONVERSION_TYPE lookup value ------------------
                                 getCellValue = rd.lookUpreference("DLG_PULSE_CONVERSION_TYPE","Common Lookup",0,1);
                                if(value[csv].equals(getCellValue)) {
                                    System.out.println("DLG_PULSE_CONVERSION_TYPE fields values in lookup Table value is :-" + getCellValue + " and values from CSV File:-" + value[csv] + " ----- > PASS");
                                    scenario.write("conversion_type "+TAB3 + getCellValue + TAB5 + value[csv] + TAB4 +Pass);
                                    csv++;
                                    pass_count++;
                                } else {
                                    System.out.println("Policy term month fields is available in Source file and values from CSV File:-" + value[csv] + " ----- > Fail");
                                    scenario.write("conversion_type "+TAB3 + getCellValue + TAB5 + value[csv] + TAB4 +Fail);
                                    csv++;
                                    fail_count++;
                                }

                                //------------- validate DLG_PULSE_CONVERSION_RATE lookup value ------------------
                                getCellValue = rd.lookUpreference("DLG_PULSE_CONVERSION_RATE","Common Lookup",0,1);
                                if(getCellValue.equals(value[csv])){
                                    System.out.println("DLG_PULSE_CONVERSION_TYPE fields values in lookup Table value is :-" + getCellValue + " and values from CSV File:-" + value[csv] + " ----- > PASS");
                                    scenario.write("conversion_rate" +TAB4 + getCellValue + TAB5 + value[csv] + TAB4 +Pass);
                                    csv++;
                                    pass_count++;

                                } else {
                                    System.out.println("Policy term month fields is available in Source file and values from CSV File:-" + value[csv] + " ----- > Fail");
                                    scenario.write("conversion_rate" +TAB4 + getCellValue + TAB5 + value[csv] + TAB4 +Fail);
                                    csv++;
                                    fail_count++;
                                }

                                //------------- validate DLG_CLAIMS_CHURCHILL_RECOVERIES lookup value ------------------
                                getCellValue = rd.lookUpreference("DLG_CLAIMS_CHURCHILL_RECOVERIES","Common Lookup",0,1);
                                if (value[csv].equals(getCellValue)) {
                                    System.out.println("DLG_CLAIMS_CHURCHILL_RECOVERIES fields values in lookup Table value is :-" + getCellValue + " and values from CSV File:-" + value[csv] + " ----- > PASS");
                                    scenario.write("batch_source_name "+TAB3 + getCellValue + TAB3 + value[csv] + TAB2 +Pass);
                                    csv = csv+12;
                                    pass_count++;
                                } else {
                                    System.out.println("Policy term month fields is available in Source file and values from CSV File:-" + value[csv] + " ----- > Fail");
                                    scenario.write("batch_source_name "+TAB3 + getCellValue + TAB3 + value[csv] + TAB2 +Fail);
                                    csv = csv+12;
                                    fail_count++;
                                }

                                //------------ Validate interface_line_context -------------
                                getCellValue = rd.lookUpreference("DLG_CLAIMS_INTERFACE_LINE_CONTEXT","Common Lookup",0,1);
                                if (value[csv].equals(getCellValue)) {
                                    System.out.println("DLG_CLAIMS_INTERFACE_LINE_CONTEXT fields values in lookup Table value is :-" + getCellValue + " and values from CSV File:-" + value[csv] + " ----- > PASS");
                                    scenario.write("interface_line_context"+ TAB3  + getCellValue + TAB3 + value[csv] + TAB2 +Pass);
                                    csv++;
                                    pass_count++;
                                } else {
                                    System.out.println("Policy term month fields is available in Source file and values from CSV File:-" + value[csv] + " ----- > Fail");
                                    scenario.write("interface_line_context"+ TAB3  + getCellValue + TAB3 + value[csv] + TAB2 +Fail);
                                    csv++;
                                    fail_count++;
                                }

                                //------------ Validate attribute_category -------------
                                getCellValue = rd.lookUpreference("DLG_CLAIMS_INTERFACE_LINE_CONTEXT","Common Lookup",0,1);
                                if (value[csv].equals(getCellValue)) {
                                    System.out.println("DLG_CLAIMS_INTERFACE_LINE_CONTEXT fields values in lookup Table value is :-" + getCellValue + " and values from CSV File:-" + value[csv] + " ----- > PASS");
                                    scenario.write("attribute_category"+TAB3 + getCellValue + TAB3  + value[csv] + TAB2 +Pass);
                                    csv++;
                                    pass_count++;
                                } else {
                                    System.out.println("Policy term month fields is available in Source file and values from CSV File:-" + value[csv] + " ----- > Fail");
                                    scenario.write("attribute_category"+TAB3 + getCellValue + TAB3  + value[csv] + TAB2 +Fail);
                                    csv++;
                                    fail_count++;
                                }

                                //------------ Validate header_attribute_category -------------
                                getCellValue = rd.lookUpreference("DLG_CLAIMS_INTERFACE_LINE_CONTEXT","Common Lookup",0,1);
                                if (value[csv].equals(getCellValue)) {
                                    System.out.println("DLG_CLAIMS_INTERFACE_LINE_CONTEXT fields values in lookup Table value is :-" + getCellValue + " and values from CSV File:-" + value[csv] + " ----- > PASS");
                                    scenario.write("header_attribute_category"+TAB2  + getCellValue + TAB3  + value[csv] + TAB2  +Pass);
                                    csv = csv+16;
                                    pass_count++;
                                } else {
                                    System.out.println("Policy term month fields is available in Source file and values from CSV File:-" + value[csv] + " ----- > Fail");
                                    scenario.write("header_attribute_category"+TAB2  + getCellValue + TAB3  + value[csv] + TAB2  +Fail);
                                    csv = csv+16;
                                    fail_count++;
                                }

                                //------------ Validate orig_system_bill_address_ref -------------
                                String xmlorig_system_bill_address_ref = eElement
                                        .getElementsByTagName("payer_type")
                                        .item(0)
                                        .getTextContent();

                                getCellValue = rd.lookUpreference(xmlorig_system_bill_address_ref,"Common Lookup",1,2);
                                if (value[csv].equals(getCellValue)) {
                                    System.out.println("DLG_CLAIMS_INTERFACE_LINE_CONTEXT fields values in lookup Table value is :-" + getCellValue + " and values from CSV File:-" + value[csv] + " ----- > PASS");
                                    scenario.write("orig_system_bill_address_ref "+TAB2  + getCellValue + TAB5  + value[csv] + TAB4 +Pass);
                                    csv++;
                                    pass_count++;
                                } else {
                                    System.out.println("Policy term month fields is available in Source file and values from CSV File:-" + value[csv] + " ----- > Fail");
                                    scenario.write("orig_system_bill_address_ref "+TAB2  + getCellValue + TAB5  + value[csv] + TAB4 +Fail);
                                    csv++;
                                    fail_count++;
                                }
                                //------------ Validate orig_system_bill_customer_ref -------------
                                String xmlorig_system_bill_customer_ref = eElement
                                        .getElementsByTagName("payer_type")
                                        .item(0)
                                        .getTextContent();

                                getCellValue = rd.lookUpreference(xmlorig_system_bill_customer_ref,"Common Lookup",1,3);
                                if (value[csv].equals(getCellValue)) {
                                    System.out.println("DLG_CLAIMS_INTERFACE_LINE_CONTEXT fields values in lookup Table value is :-" + getCellValue + " and values from CSV File:-" + value[csv] + " ----- > PASS");
                                    scenario.write("orig_system_bill_customer_ref "+TAB2  + getCellValue + TAB5  + value[csv] + TAB4 +Pass);
                                    csv++;
                                    pass_count++;
                                } else {
                                    System.out.println("Policy term month fields is available in Source file and values from CSV File:-" + value[csv] + " ----- > Fail");
                                    scenario.write("orig_system_bill_customer_ref "+TAB2  + getCellValue + TAB5  + value[csv] + TAB4 +Fail);
                                    csv++;
                                    fail_count++;
                                }



                                //------------ Validate quantity -------------
                                getCellValue = rd.lookUpreference("DLG_PULSE_QUANTITY","Common Lookup",0,1);
                                if (value[csv].equals(getCellValue)) {
                                    System.out.println("DLG_PULSE_QUANTITY fields values in lookup Table value is :-" + getCellValue + " and values from CSV File:-" + value[csv] + " ----- > PASS");
                                    scenario.write("quantity "+TAB4 + getCellValue + TAB5 + value[csv] + TAB4+Pass);
                                    csv++;
                                    pass_count++;
                                } else {
                                    System.out.println("Policy term month fields is available in Source file and values from CSV File:-" + value[csv] + " ----- > Fail");
                                    scenario.write("quantity "+TAB4 + getCellValue + TAB5 + value[csv] + TAB4+Fail);
                                    csv++;
                                    fail_count++;
                                }

                                //------------ Validate quantity_ordered -------------
                                getCellValue = rd.lookUpreference("DLG_PULSE_QUANTITY_ORDERED","Common Lookup",0,1);
                                if (value[csv].equals(getCellValue)) {
                                    System.out.println("DLG_PULSE_QUANTITY_ORDERED fields values in lookup Table value is :-" + getCellValue + " and values from CSV File:-" + value[csv] + " ----- > PASS");
                                    scenario.write("quantity_ordered "+TAB3  + getCellValue + TAB5 + value[csv] + TAB4 +Pass);
                                    csv = csv+2;
                                    pass_count++;
                                } else {
                                    System.out.println("Policy term month fields is available in Source file and values from CSV File:-" + value[csv] + " ----- > Fail");
                                    scenario.write("quantity_ordered "+TAB3  + getCellValue + TAB5 + value[csv] + TAB4 +Fail);
                                    csv = csv+2;
                                    fail_count++;
                                }

                                //------------ Validate set_of_books_id -------------
                                String xmlset_of_books_id = eElement
                                        .getElementsByTagName("currency_cd")
                                        .item(0)
                                        .getTextContent();

                                getCellValue = rd.lookUpreference(xmlset_of_books_id,"Common Lookup",2,0);
                                if (value[csv].equals(getCellValue)) {
                                    System.out.println("DLG_CLAIMS_INTERFACE_LINE_CONTEXT fields values in lookup Table value is :-" + getCellValue + " and values from CSV File:-" + value[csv] + " ----- > PASS");
                                    scenario.write("set_of_books_id "+ TAB3  + getCellValue + TAB5  + value[csv] + TAB4 +Pass);
                                    csv++;
                                    pass_count++;
                                } else {
                                    System.out.println("Policy term month fields is available in Source file and values from CSV File:-" + value[csv] + " ----- > Fail");
                                    scenario.write("set_of_books_id "+ TAB3  + getCellValue + TAB5  + value[csv] + TAB4 +Fail);
                                    csv++;
                                    fail_count++;
                                }


                                //------------ Validate tax_rate_code -------------
                                getCellValue = rd.lookUpreference("DLG_PULSE_BI_PURCH_STD_TAX_CODE","Common Lookup",0,1);
                                if (value[csv].equals(getCellValue)) {
                                    System.out.println("DLG_PULSE_BI_PURCH_STD_TAX_CODE fields values in lookup Table value is :-" + getCellValue + " and values from CSV File:-" + value[csv] + " ----- > PASS");
                                    scenario.write("tax_rate_code" +TAB4 + getCellValue + TAB4  + value[csv] + TAB3 +Pass);
                                    csv++;
                                    pass_count++;
                                } else {
                                    System.out.println("Policy term month fields is available in Source file and values from CSV File:-" + value[csv] + " ----- > Fail");
                                    scenario.write("tax_rate_code" +TAB4 + getCellValue + TAB4  + value[csv] + TAB3 +Fail);
                                    csv++;
                                    fail_count++;
                                }

                            }
                        }

                    }
                }

            }
        int tot_count =  pass_count+fail_count;
        scenario.write("---------------------------------------------------------------------------------------------------------------");
        scenario.write(Total_Pass + ":" +TAB3 + tot_count + TAB2 + v_pass+"\t:" + pass_count +TAB3 + v_fail+ TAB1+":" + fail_count);
        scenario.write("---------------------------------------------------------------------------------------------------------------");

    }



}




