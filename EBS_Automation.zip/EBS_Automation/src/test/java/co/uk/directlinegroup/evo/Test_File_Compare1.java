package co.uk.directlinegroup.evo;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
//package co.uk.directlinegroup.evo;

import cucumber.api.CucumberOptions;
import cucumber.api.SnippetType;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        plugin = {"pretty", "html:target/cucumber_reports/regression_results"},
        format = {"html:target/site/cucumber-pretty"},
        features = {"@target/target/cucumber_reports/regression_results/Rerun4.txt"})
        //features = {"Test"})



public class Test_File_Compare1 {
}
