package co.uk.directlinegroup.evo.step_definitions;

import cucumber.api.PendingException;
import cucumber.api.Scenario;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.junit.Assert;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;

public class ARConcatenateTags {

    String xmlId = null;
    String csvSplitBy = ",";
    private File inputFile;
    private Scenario scenario;
    String filename = "ARConcatenateTagFileCompare.csv";

    int pass_count = 0;
    int fail_count = 0;
    String Pass = "<font color =\"#0E1FED\"><B>PASS</B></font>";
    String Fail = "<font color =\"#ff1a1a\"><B>FAIL</B></font>";
    String v_pass = "<font color =\"#0E1FED\"><B>Passed</B></font>";
    String v_fail = "<font color =\"#ff1a1a\"><B>Failed</B></font>";
    String Total_Pass = "<font color =\"#0E1FED\"><B>TOTAL VERIFICATION</B></font>";
    String reportHeader = "<font color =\"#0E1FED\"><B>Aquarium AR : File - DB Comparision Report</B></font>";

    String fieldname = "<font color =\"#0E1FED\"><B>Field Name</B></font>";
    String SourceValue = "<font color =\"#0E1FED\"><B>Source Value</B></font>";
    String dbvalue = "<font color =\"#0E1FED\"><B>DB value</B></font>";
    String status = "<font color =\"#0E1FED\"><B>STATUS</B></font>";

    String TAB1 = "\t";
    String TAB2 = "\t\t";
    String TAB3 = "\t\t\t";
    String TAB4 = "\t\t\t\t";
    String TAB5 = "\t\t\t\t\t";


    @Before()
    public void before(Scenario scenario) {
        this.scenario = scenario;
    }


    @Given("^Xml Source file$")
    public File XmlSourceFile() throws Throwable {
        inputFile = new File("C:\\Test\\AR_Trans.xml");
        return inputFile;
    }


    @When("^Target CSV File with Concatenate value$")
    public void targetCSVFileWithNullValue() throws Throwable {
        Scanner out = new Scanner(new BufferedReader(new FileReader("C:\\Test\\AR_CSV\\AR_Consalidate.csv")));


    }

    @Then("^Validate the Concatenate values in Target Table$")
    public void validateMissingTagValuesInTargetTable() throws Throwable {

        DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
        Document doc = dBuilder.parse(inputFile);
        doc.getDocumentElement().normalize();

        NodeList nList = doc.getElementsByTagName("dlg_ar_transaction");
        scenario.write(TAB5 +reportHeader+ TAB5);
        scenario.write("File Name   :\t\t" + filename);

        for (int j = 0; j < nList.getLength(); j++) {
            Node nNode = nList.item(j);
            System.out.println("\nCurrent Element :" + nNode.getNodeName());
            scenario.write("\nCurrent Element :" + nNode.getNodeName());
            scenario.write("----------------------------");
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                Element eElement = (Element) nNode;
                String xmlId = eElement
                        .getElementsByTagName("id")
                        .item(0)
                        .getTextContent();

                // --------- Read the csv file ------------------
                Scanner out = new Scanner(new BufferedReader(new FileReader("C:\\Test\\AR_CSV\\AR_Consalidate.csv")));
                while (out.hasNextLine()) {
                    String data = out.nextLine();
                    String[] value = data.split(csvSplitBy);
                    for (int csv = 0; csv < value.length; csv++) {
                        if (value[csv].equals(xmlId)) {
                            //------------ validate id tag ---------------
                            String xmlID = eElement
                                    .getElementsByTagName("id")
                                    .item(0)
                                    .getTextContent();
                            Assert.assertTrue("XML id validation:- Source id is matching with CSV value", value[csv].equals(xmlID));
                            if (value[csv].equals(xmlID)) {
                                System.out.println("XML id :-" + xmlID + " is matching with CSV File:-" + value[csv] + " ------------ > PASS");
                                scenario.write("-------------------------------------------------------------------------------------------------------------------");
                                scenario.write(fieldname +TAB3 + SourceValue + TAB4  + dbvalue +TAB3 + status + TAB4);
                                scenario.write("-------------------------------------------------------------------------------------------------------------------");
                                scenario.write("id "+ TAB4  +  xmlID   + TAB4 + value[csv] + TAB3 + Pass );
                                csv = csv+6;
                                pass_count++;
                            } else {
                                System.out.println("id is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("id "+ TAB5  +  xmlID   + TAB4 + value[csv] + TAB3 + Fail );
                                csv = csv+6;
                                fail_count++;
                            }

                            //------------ validate claim number ---------------
                            String xmlclaimNumber = eElement
                                    .getElementsByTagName("claim_number")
                                    .item(0)
                                    .getTextContent();

                            //------------ validate Transaction id ---------------
                            String xmltransactionId = eElement
                                    .getElementsByTagName("transaction_id")
                                    .item(0)
                                    .getTextContent();
                            String xmlupdateTransID = xmlclaimNumber + xmltransactionId;

                            //----------- CSV transaction value concatenate claim number and transaction id in xml -------
                            if (value[csv].equals(xmlupdateTransID)) {
                                System.out.println("XML Transaction id :-" + xmltransactionId + " is matching concatenated Claim number with CSV File:-" + value[csv] + " ------ > PASS");
                                scenario.write("description" +TAB3 + xmlupdateTransID + TAB3 + value[csv] + TAB2 + Pass);
                                csv=csv+20;
                                pass_count++;
                            } else {
                                System.out.println("XML Transaction id :-" + xmltransactionId + " is not matching concatenated Claim number with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("description" +TAB3 + xmlupdateTransID + TAB3 + value[csv] + TAB2 + Fail);
                                csv = csv+20;
                                fail_count++;
                            }

                            //------------ validate Brand ---------------
                            String xmlbrand = eElement
                                    .getElementsByTagName("brand")
                                    .item(0)
                                    .getTextContent();
                            if (xmlbrand.equals("BIS_Ins")) {
                                xmlbrand = "BIS_Ins";
                                String csvbrand = value[csv];
                                if (csvbrand.equals("NIG_Ins")) {
                                    System.out.println("XML Brand :- " + xmlbrand + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                    scenario.write("Brand"+TAB5 + xmlbrand + TAB4 + value[csv] + TAB4 + Pass);
                                    csv=csv+17;
                                    pass_count++;
                                }
                            } else if (value[csv].equals(xmlbrand)) {
                                System.out.println("XML Brand :- " + xmlbrand + " is matching with CSV File:-" + value[csv] + " ------ > PASS");
                                scenario.write("Brand"+TAB4 + xmlbrand + TAB4 + value[csv] + TAB3 + Pass);
                                csv=csv+17;
                                pass_count++;
                            } else {
                                System.out.println("Brand is not matching with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("Brand"+TAB4 + xmlbrand + TAB4 + value[csv] + TAB3 + Fail);
                                csv = csv+17;
                                fail_count++;
                            }

                            /*---------- trx_number -------------
                                    claim_number || '~' || cr_dat.transaction_id
                             */

                            String trx_number = xmlclaimNumber + "~" + xmltransactionId;
                            if (value[csv].equals(trx_number)) {
                                System.out.println("XML Transaction id :-" + trx_number + " is matching concatenated Claim number with CSV File:-" + value[csv] + " ------ > PASS");
                                //scenario.write("XML Transaction id :-" + xmltransactionId + " is matching concatenated Claim number with CSV File:-" + value[csv] + " ------ > PASS");
                                scenario.write("trx_number "+ TAB3 + trx_number + TAB3+ value[csv] + TAB2 + Pass);
                                csv=csv+6;
                                pass_count++;
                            } else {
                                System.out.println("XML Transaction id :-" + trx_number + " is not matching concatenated Claim number with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("trx_number "+ TAB3 + trx_number + TAB3+ value[csv] + TAB2 + Fail);
                                csv = csv+6;
                                fail_count++;
                            }

                            /*---------- cust_trx_type_name -------------
                                    product||'~'||product_type||'~'||transaction_type'~'||0||'~'||'N'
                             */

                            String xmlproduct = eElement
                                    .getElementsByTagName("product")
                                    .item(0)
                                    .getTextContent();

                            String xmlproductType = eElement
                                    .getElementsByTagName("product_type")
                                    .item(0)
                                    .getTextContent();
                            String xmltransaction_type = eElement
                                    .getElementsByTagName("transaction_type")
                                    .item(0)
                                    .getTextContent();

                            String cust_trx_type_name = xmlproduct + "~" + xmlproductType + "~" + xmltransaction_type + "~" + 0 + "~" + 'N';
                            if (value[csv].equals(cust_trx_type_name)) {
                                System.out.println("XML Transaction id :-" + cust_trx_type_name + " is matching concatenated Claim number with CSV File:-" + value[csv] + " ------ > PASS");
                                scenario.write("cust_trx_type_name " +TAB2 + cust_trx_type_name + TAB2+ value[csv] + TAB1 + Pass);
                                csv++;
                                pass_count++;
                            } else {
                                System.out.println("XML Transaction id :-" + cust_trx_type_name + " is not matching concatenated Claim number with CSV File:-" + value[csv] + " ------------ > FAIL");
                                scenario.write("cust_trx_type_name " +TAB2 + cust_trx_type_name + TAB2+ value[csv] + TAB1 + Fail);
                                csv++;
                                fail_count++;
                            }

                        }
                    }
                }
            }
        }
        int tot_count =  pass_count+fail_count;
        scenario.write("---------------------------------------------------------------------------------------------------------------");
        scenario.write(Total_Pass + ":" +TAB3 + tot_count + TAB2 + v_pass+"\t:" + pass_count +TAB3 + v_fail+ TAB1+":" + fail_count);
        scenario.write("---------------------------------------------------------------------------------------------------------------");

    }
}






