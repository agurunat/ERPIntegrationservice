package pages;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.sql.*;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

public class TravelGLBilling {

    static Statement SQLstmt_fsh = null;
    static Statement SQLstmt_isci = null;
    static ResultSet SQLResultset_fsh = null;
    static ResultSet SQLResultset_icsi = null;
    DecimalFormat df2 = new DecimalFormat(".##");
    public static HTML_Report_Generation report_generation;

    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException, SQLException, ParseException {

        report_generation = new HTML_Report_Generation();

        //XML Fields
        String BATCH_PKEY = null;
        String FILE_NAME = null;


        // Conslidation table  initialisation
        String db_BATCH_PKEY = null;
        String db_FILE_NAME = null;
        String db_bc_header_id = "null";
        String db_source = "null";
        String db_account_number = "null";
        String db_policy_number = "null";
        String db_underwriter = "null";
    //    String db_brand = "null";
        String db_line_of_business = "null";
    //    String db_channel = "null";
        String db_product_Type = "null";
        String db_transaction_reference = "null";
        String db_transaction_date = "null";
        String db_transaction_sub_type = "null";
        String db_transaction_reason = "null";
        String db_payment_method = "null";
        String db_sun_number = "null";
        String db_mid_number = "null";
        String db_ddi_reference = "null";
     //   String db_pay_in_slip_number = "null";
     //   String db_cheque_number = "null";
        String db_card_type = "null";
        String db_bacs_narrative = "null";
    //    String db_card_narrative = "null";
	   String db_channnel = "null";
	   String db_order_number = "null";
        String db_reversal_indicator = "null";
        String db_currency_code = "null";
        String db_exchange_rate = "null";
		String db_exchange_rate_type = "null";
        String db_base_currency_amount = "null";
		String db_exchange_date = "null";
		String db_cross_reference = "null";
		String db_bc_line_id = "null";
		String db_dr_cr_flag = "null";
		String db_amount = "null";
		
    //    String db_base_interest_amount = "null";
    //    String db_tax_deductible = "null";
    //    String db_order_number = "null";
    //    String db_payment_transaction_type_id = "null";
    //    String db_currency_amount = "null";
    //    String db_credit_ind = "null";
    //    String db_exchange_rate_type = "null";
    //    String db_interest_amount = "null";
    //    String db_interest_currency_code = "null";
    //    String db_bc_line_id = "null";
    //    String db_amount = "null";
    //   String db_dr_cr_flag = "null";
    //    String db_line_bc_header_id = "null";

        //----------- Staging table variable decleration-------------
        String db_stg_reversal_indicator = "null";
        String db_stg_bc_header_id = "null";
        String db_stg_source = "null";
    //    String db_stg_brand = "null";
        String db_stg_account_number = "null";
        String db_stg_policy_number = "null";
		String db_stg_underwriter = "null";
		String db_stg_product_type = "null";
		String db_stg_line_of_business = "null";
		String db_stg_transaction_reference = "null";
        String db_stg_transaction_date = "null";
        String db_stg_transaction_sub_type = "null";
        String db_stg_transaction_reason = "null";
        String db_stg_payment_method = "null";
        String db_stg_sun_number = "null";
        String db_stg_mid_number = "null";
        String db_stg_ddi_reference = "null";
    //    String db_stg_pay_in_slip_number = "null";
    //    String db_stg_cheque_number = "null";
        String db_stg_card_type = "null";
        String db_stg_bacs_narrative = "null";
    //    String db_stg_card_narrative = "null";
        String db_stg_channel = "null";
    //    String db_stg_currency_code = "null";
	String db_stg_order_number = "null";
	String db_stg_reversal_indicator = "null";
	String db_stg_currency_code = "null";
        String db_stg_exchange_rate = "null";
		String db_stg_exchange_rate_type = "null";
        String db_stg_base_currency_amount = "null";
		String db_stg_credit_ind = "null";
		String db_stg_currency_amount = "null";
		
    //    String db_stg_base_interest_amount = "null";
    //    String db_stg_tax_deductible = "null";
    //    String db_stg_order_number = "null";
    //    String db_stg_payment_transaction_type_id = "null";
    //    String db_stg_currency_amount = "null";
    //    String db_stg_credit_ind = "null";
    //    String db_stg_underwriter = "null";
    //    String db_stg_transaction_reference = "null";
    //    String db_stg_interest_amount = "null";
    //    String db_stg_interest_currency_code = "null";
    //    String db_stg_exchange_rate_type = "null";
    //    String db_stg_event_code = "null";
    //    String db_stg_event_type_code = "null";
    //    String db_stg_line_of_business = "null";
    //    String db_stg_status = "null";
    //    String db_stg_batch_fkey = "null";
    //    String db_stg_file_name = "null";
    //    String db_stg_TOH_id = "null";
    //    String db_stg_product_type = "null";
    //    String db_aggregate_toh_id = "null";

        List<String> filename_list = new ArrayList<String>();

// --------- fetch the source files -------------
        String path = "C:\\Test\\Phase 2\\SSPXGLBILLING\\";
        File[] files = new File(path).listFiles();

        for (File file : files) {
            if (file.isFile()) {
                filename_list.add(file.getName());
                System.out.println("Total number of files" + filename_list.size());
            } else {
                System.out.println("File Not found exception");
                System.exit(1);
            }

        }
// oracle driver to connect through code - class
        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
/* Now to make a connection to DB using driverManager
 jdbc:oracle:thin:@172.30.235.67:1521/FSHDTST2 - Oracle DB Connection String */
        Connection connection = null;
        Connection connection_icsi = null;

        try {
           /* connection = DriverManager.getConnection(
                    "jdbc:oracle:thin:@dcn2ddbx007z.gwd.grpinf.net:1521/FSHTSIT1", "FSH_ORA_DATA", "FSH_SIT1_DATA");*/
            /*connection = DriverManager.getConnection(
                    "jdbc:oracle:thin:@172.30.235.67:1521/FSHDTST1", "FSH_ORA_DATA", "Development_Test1");*/
			/*connection = DriverManager.getConnection(
                    "jdbc:oracle:thin:@172.30.235.67:1521/FSHDTST3", "FSH_ORA_DATA", "Development_Test3");*/		
            connection = DriverManager.getConnection(
                    "jdbc:oracle:thin:@172.30.235.67:1521/FSHDTST2", "FSH_ORA_DATA", "Development_Test2");
            
            connection_icsi = DriverManager.getConnection(
                    "jdbc:oracle:thin:@dcn2ddbx340.gwd.grpinf.net:1618:ICSI", "apps", "apps4icsi");
//Now create a simple SQL query					
            SQLstmt_fsh = connection.createStatement();
            SQLstmt_isci = connection_icsi.createStatement();
            System.out.println("Connection established");
        } catch (SQLException e) {
            e.printStackTrace();
        }

        for (String file_list : filename_list) {

            //initialising Array

            List<String> section1_list_results = new ArrayList<String>();
            List<String> section2_list_results = new ArrayList<String>();
            List<String> section3_list_results = new ArrayList<String>();
            List<String> section4_list_results = new ArrayList<String>();
			List<String> mandatory_list_results = new ArrayList<String>();
            int direct_map_row = 1;
            int lookup_map_row = 1;
            int TO_table_map_row = 1;
			int mandatory_row = 1;
            String db_cons_status;

            String inputFile = path + file_list;
            System.out.println("Input file in processing is" + inputFile);

            //XML File reading
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(inputFile);
            Element ele = doc.getDocumentElement();
            NodeList child_node = ele.getElementsByTagName("n1:dlg_bc_header");
            System.out.println("Length of Header child node is " + child_node.getLength());
            Element ele1 = doc.getDocumentElement();
            NodeList child_node1 = ele1.getElementsByTagName("n1:dlg_bc_line");
            System.out.println("Length of Line child node is " + child_node1.getLength());

            //Reading data from Line fields
            for (int i = 0; i < child_node1.getLength(); i++) {
                Node Line_fields = child_node1.item(i);
                System.out.println("\nCurrent Element :" + Line_fields.getNodeName());
                if (Line_fields.getNodeType() == Node.ELEMENT_NODE) {
                    Element tags1 = (Element) Line_fields;
                    String xml_bc_line_id = tags1.getElementsByTagName("n1:bc_line_id").item(0).getTextContent();
                    String xml_line_bc_header_id = tags1.getElementsByTagName("n1:bc_header_id").item(0).getTextContent();
                    String xml_dr_cr_flag = tags1.getElementsByTagName("n1:dr_cr_flag").item(0).getTextContent();
                    String xml_amount = tags1.getElementsByTagName("n1:amount").item(0).getTextContent();
                    System.out.println("***********");
//Execution of SQL query begins after extracting the data from XML   
                    System.out.println("Line validation starts here");
                    SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT  * FROM DLG_FSH_CONS_AQUA_BC_HDR  WHERE FILE_NAME = '" + file_list + "' and HEADER_ID = '" + xml_line_bc_header_id + "'");
                    Boolean data_in_DB = true;
                    if (!SQLResultset_fsh.next()) {
                        data_in_DB = false;
                        String header_id = direct_map_row + ",HEADER_ID," + "CONS Table does not have records. please verify Batch Control table" + "," + xml_line_bc_header_id + ",Fail";
                        section1_list_results.add(header_id);
                        direct_map_row++;
                    }
                    if (data_in_DB) {
                        SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT  * FROM DLG_FSH_CONS_AQUA_BC_HDR  WHERE FILE_NAME = '" + file_list + "' and HEADER_ID = '" + xml_line_bc_header_id + "'");
                        while (SQLResultset_fsh.next()) {
                            db_bc_line_id = SQLResultset_fsh.getString("BC_LINE_ID");
                            db_line_bc_header_id = SQLResultset_fsh.getString("BC_HEADER_ID");
                            db_dr_cr_flag = SQLResultset_fsh.getString("DR_CR_FLAG");
                            db_amount = SQLResultset_fsh.getString("AMOUNT");

                            //Comparing xml line fields and Consolidation fields
                            if (xml_bc_line_id.equals(db_bc_line_id)) {
                                String STR_LINE_ID = direct_map_row + ",LINE_ID," + db_bc_line_id + "," + xml_bc_line_id + ",Pass";
                                section1_list_results.add(STR_LINE_ID);
                                direct_map_row++;
                            } else {
                                String STR_LINE_ID = ",LINE_ID," + db_bc_line_id + "," + xml_bc_line_id + ",Fail";
                                section1_list_results.add(STR_LINE_ID);
                            }
                            if (xml_line_bc_header_id.equals(db_line_bc_header_id)) {
                                String LINE_BC_HEADER_ID = direct_map_row + ",BC_HEADER_ID," + db_line_bc_header_id + "," + xml_line_bc_header_id + ",Pass";
                                section1_list_results.add(LINE_BC_HEADER_ID);
                                direct_map_row++;
                            } else {
                                String LINE_BC_HEADER_ID = ",BC_HEADER_ID," + db_line_bc_header_id + "," + xml_line_bc_header_id + ",Fail";
                                section1_list_results.add(LINE_BC_HEADER_ID);
                            }
                            if (xml_dr_cr_flag.equals(db_dr_cr_flag)) {
                                String STR_DR_CR_FLAG = direct_map_row + ",DR_CR_FLAG," + db_dr_cr_flag + "," + xml_dr_cr_flag + ",Pass";
                                section1_list_results.add(STR_DR_CR_FLAG);
                                direct_map_row++;
                            } else {
                                String STR_DR_CR_FLAG = ",DR_CR_FLAG," + db_dr_cr_flag + "," + xml_dr_cr_flag + ",Fail";
                                section1_list_results.add(STR_DR_CR_FLAG);
                            }
                            if (xml_amount.equals(db_amount)) {
                                String STR_LINE_ID = direct_map_row + ",LINE_AMOUNT," + db_amount + "," + xml_amount + ",Pass";
                                section1_list_results.add(STR_LINE_ID);
                                direct_map_row++;
                            } else {
                                String STR_LINE_ID = ",LINE_AMOUNT," + db_amount + "," + xml_amount + ",Fail";
                                section1_list_results.add(STR_LINE_ID);
                            }

//Reading data from Header fields
                            // Validating data  in CONS table
                            for (int j = 0; j < child_node.getLength(); j++) {
                                Node Header_fields = child_node.item(j);
                                System.out.println("\nCurrent Element :" + Header_fields.getNodeName());
                                if (Header_fields.getNodeType() == Node.ELEMENT_NODE) {
                                    Element tags = (Element) Header_fields;
                                    String xml_sun_number = null;
                                    String xml_mid_number = null;
                                    String xml_pay_in_slip_number = null;
                                    String xml_cheque_number = null;
                                    String xml_card_type = null;
                                    String xml_card_narrative = null;
                                    String xml_order_number = null;
                                    String xml_ddi_reference = null;
                                    String xml_bacs_narrative = null;
                                    String xml_tax_deductible = null;
                                    String xml_bc_header_id = tags.getElementsByTagName("n1:header_id").item(0).getTextContent();
                                    String xml_source = tags.getElementsByTagName("n1:source").item(0).getTextContent();
                                    String xml_account_number = tags.getElementsByTagName("n1:account_number").item(0).getTextContent();
                                    String xml_policy_number = tags.getElementsByTagName("n1:policy_number").item(0).getTextContent();
                                    String xml_underwriter = tags.getElementsByTagName("n1:underwriter").item(0).getTextContent();
                                    String xml_brand = tags.getElementsByTagName("n1:brand").item(0).getTextContent();
                                    String xml_line_of_business = tags.getElementsByTagName("n1:line_of_business").item(0).getTextContent();
                                    String xml_product_type = tags.getElementsByTagName("n1:product_type").item(0).getTextContent();
                                    String xml_channel = tags.getElementsByTagName("n1:channel").item(0).getTextContent();
                                    String xml_transaction_reference = tags.getElementsByTagName("n1:transaction_reference").item(0).getTextContent();
                                    String xml_transaction_date = tags.getElementsByTagName("n1:transaction_date").item(0).getTextContent();
                                    String xml_transaction_subtype = tags.getElementsByTagName("n1:transaction_subtype").item(0).getTextContent();
                                    String xml_transaction_reason = tags.getElementsByTagName("n1:transaction_reason").item(0).getTextContent();
                                    String xml_payment_method = tags.getElementsByTagName("n1:payment_method").item(0).getTextContent();
                                    if ((tags.getElementsByTagName("n1:sun_number").getLength()) > 0)
                                        xml_sun_number = tags.getElementsByTagName("n1:sun_number").item(0).getTextContent();
                                    if ((tags.getElementsByTagName("n1:ddi_reference").getLength()) > 0)
                                        xml_ddi_reference = tags.getElementsByTagName("n1:ddi_reference").item(0).getTextContent();
                                    if ((tags.getElementsByTagName("n1:bacs_narrative").getLength()) > 0)
                                        xml_bacs_narrative = tags.getElementsByTagName("n1:bacs_narrative").item(0).getTextContent();
                                    String xml_interest_amount = tags.getElementsByTagName("n1:interest_amount").item(0).getTextContent();
                                    xml_interest_amount = xml_interest_amount.indexOf(".") < 0 ? xml_interest_amount : xml_interest_amount.replaceAll("0*$", "").replaceAll("\\.$", "");
                                    String xml_interest_currency_code = tags.getElementsByTagName("n1:interest_amount").item(0).getAttributes().item(0).getTextContent();
                                    String xml_base_interest_amount = tags.getElementsByTagName("n1:base_interest_amount").item(0).getTextContent();
                                    xml_base_interest_amount = xml_base_interest_amount.indexOf(".") < 0 ? xml_base_interest_amount : xml_base_interest_amount.replaceAll("0*$", "").replaceAll("\\.$", "");
                                    if ((tags.getElementsByTagName("n1:tax_deductible").getLength()) > 0)
                                        xml_tax_deductible = tags.getElementsByTagName("n1:tax_deductible").item(0).getTextContent();
                                    String xml_reversal_indicator = tags.getElementsByTagName("n1:reversal_indicator").item(0).getTextContent();
                                    String xml_payment_transaction_type_id = tags.getElementsByTagName("n1:payment_transaction_type_id").item(0).getTextContent();
                                    String xml_exchange_rate = tags.getElementsByTagName("n1:exchange_rate").item(0).getTextContent();
                                    xml_exchange_rate = xml_exchange_rate.indexOf(".") < 0 ? xml_exchange_rate : xml_exchange_rate.replaceAll("0*$", "").replaceAll("\\.$", "");
                                    String xml_exchange_rate_type = tags.getElementsByTagName("n1:exchange_rate_type").item(0).getTextContent();
                                    String xml_base_currency_amount = tags.getElementsByTagName("n1:base_currency_amount").item(0).getTextContent();
                                    xml_base_currency_amount = xml_base_currency_amount.indexOf(".") < 0 ? xml_base_currency_amount : xml_base_currency_amount.replaceAll("0*$", "").replaceAll("\\.$", "");
                                    String xml_credit_ind = tags.getElementsByTagName("n1:credit_ind").item(0).getTextContent();
                                    if ((tags.getElementsByTagName("n1:mid_number").getLength()) > 0)
                                        xml_mid_number = tags.getElementsByTagName("n1:mid_number").item(0).getTextContent();
                                    if ((tags.getElementsByTagName("n1:pay_in_slip_number").getLength()) > 0)
                                        xml_pay_in_slip_number = tags.getElementsByTagName("n1:pay_in_slip_number").item(0).getTextContent();
                                    if ((tags.getElementsByTagName("n1:cheque_number").getLength()) > 0)
                                        xml_cheque_number = tags.getElementsByTagName("n1:cheque_number").item(0).getTextContent();
                                    if ((tags.getElementsByTagName("n1:card_type").getLength()) > 0)
                                        xml_card_type = tags.getElementsByTagName("n1:card_type").item(0).getTextContent();
                                    if ((tags.getElementsByTagName("n1:card_narrative").getLength()) > 0)
                                        xml_card_narrative = tags.getElementsByTagName("n1:card_narrative").item(0).getTextContent();
                                    String xml_currency_amount = tags.getElementsByTagName("n1:currency_amount").item(0).getTextContent();
                                    String xml_currency_code = tags.getElementsByTagName("n1:currency_amount").item(0).getAttributes().item(0).getTextContent();
                                    if ((tags.getElementsByTagName("n1:order_number").getLength()) > 0)
                                        xml_order_number = tags.getElementsByTagName("n1:order_number").item(0).getTextContent();
                                    System.out.println("***********");

                                    System.out.println("Header validation starts here");
                                    SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT  * FROM DLG_FSH_CONS_AQUA_BC_HDR  WHERE FILE_NAME = '" + file_list + "' and HEADER_ID = '" + xml_bc_header_id + "'");
                                    Boolean data_in_Line_DB = true;
                                    if (!SQLResultset_fsh.next()) {
                                        data_in_DB = false;
                                        String header_id = direct_map_row + ",HEADER_ID," + "CONS Table does not have records. please verify Batch Control table" + "," + xml_bc_header_id + ",Fail";
                                        section1_list_results.add(header_id);
                                        direct_map_row++;
                                    }
                                    if (data_in_DB) {
                                        SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT  * FROM DLG_FSH_CONS_AQUA_BC_HDR  WHERE FILE_NAME = '" + file_list + "' and HEADER_ID = '" + xml_bc_header_id + "'");
                                        while (SQLResultset_fsh.next()) {
                                            db_bc_header_id = SQLResultset_fsh.getString("HEADER_ID");
                                            db_source = SQLResultset_fsh.getString("SOURCE");
                                            db_account_number = SQLResultset_fsh.getString("ACCOUNT_NUMBER");
                                            db_policy_number = SQLResultset_fsh.getString("POLICY_NUMBER");
                                            db_underwriter = SQLResultset_fsh.getString("UNDERWRITER");
                                         //   db_brand = SQLResultset_fsh.getString("BRAND");
                                            db_product_Type = SQLResultset_fsh.getString("PRODUCT_TYPE");
                                            db_line_of_business = SQLResultset_fsh.getString("LINE_OF_BUSINESS");
                                            db_transaction_reference = SQLResultset_fsh.getString("TRANSACTION_REFERENCE");
                                            db_transaction_date = SQLResultset_fsh.getString("TRANSACTION_DATE");
                                            db_transaction_sub_type = SQLResultset_fsh.getString("TRANSACTION_SUBTYPE");
                                            db_transaction_reason = SQLResultset_fsh.getString("TRANSACTION_REASON");
                                            db_payment_method = SQLResultset_fsh.getString("PAYMENT_METHOD");
                                            db_sun_number = SQLResultset_fsh.getString("SUN_NUMBER");
                                            db_mid_number = SQLResultset_fsh.getString("MID_NUMBER");
                                            db_ddi_reference = SQLResultset_fsh.getString("DDI_REFERENCE");
											
											
                                        //    db_pay_in_slip_number = SQLResultset_fsh.getString("PAY_IN_SLIP_NUMBER");
                                        //    db_cheque_number = SQLResultset_fsh.getString("CHEQUE_NUMBER");
                                            db_card_type = SQLResultset_fsh.getString("CARD_TYPE");
                                            db_bacs_narrative = SQLResultset_fsh.getString("BACS_NARRATIVE");
                                        //    db_card_narrative = SQLResultset_fsh.getString("CARD_NARRATIVE");
                                            db_channel = SQLResultset_fsh.getString("CHANNEL");
                                            db_reversal_indicator = SQLResultset_fsh.getString("REVERSAL_INDICATOR");
										    db_order_number = SQLResultset_fsh.getString("ORDER_NUMBER");
                                            db_currency_code = SQLResultset_fsh.getString("CURRENCY_CODE");
                                            db_exchange_rate = SQLResultset_fsh.getString("EXCHANGE_RATE");
                                            db_exchange_rate_type = SQLResultset_fsh.getString("EXCHANGE_RATE_TYPE");
                                            db_base_currency_amount = SQLResultset_fsh.getString("BASE_CURRENCY_AMOUNT");
											db_exchange_date = SQLResultset_fsh.getString("EXCHANGE_DATE");
											db_cross_reference = SQLResultset_fsh.getString("CROSS_REFERENCE");
											db_bc_line_id = SQLResultset_fsh.getString("BC_LINE_ID");
											db_dr_cr_flag = SQLResultset_fsh.getString("DR_CR_FLAG");
											db_amount = SQLResultset_fsh.getString("AMOUNT");
											
                                        //    db_base_interest_amount = SQLResultset_fsh.getString("BASE_INTEREST_AMOUNT");
                                        //    db_tax_deductible = SQLResultset_fsh.getString("TAX_DEDUCTIBLE");
											
                                            
                                        //    db_payment_transaction_type_id = SQLResultset_fsh.getString("PAYMENT_TRANSACTION_TYPE_ID");
                                        //    db_currency_amount = SQLResultset_fsh.getString("CURRENCY_AMOUNT");
                                        //    db_credit_ind = SQLResultset_fsh.getString("CREDIT_IND");
                                        //    db_interest_amount = SQLResultset_fsh.getString("INTEREST_AMOUNT");
                                        //    db_interest_currency_code = SQLResultset_fsh.getString("INTEREST_CURRENCY_CODE");
                                        //    db_BATCH_PKEY = SQLResultset_fsh.getString("BATCH_FKEY");
                                        //    db_FILE_NAME = SQLResultset_fsh.getString("FILE_NAME");
                                        //    db_cons_status = SQLResultset_fsh.getString("STATUS");


  //Validating mandatory fields in consolidation table
                                            if (db_payment_method.equals("BACS_Ins")) {
                                                if ((db_sun_number == null) && (db_cons_status != "REVIEW")) {
                                                    String sun_number = mandatory_row + "," + db_bc_header_id + ",SUN NUMBER," + "DB_PAYMENT_METHOD : " + db_payment_method + "," + "SUN NUMBER was not found," + db_cons_status + "," + "Fail";
                                                    mandatory_list_results.add(sun_number);
                                                    mandatory_row++;
                                                } else {
                                                    String sun_number = mandatory_row + "," + db_bc_header_id + ",SUN NUMBER," + "DB_PAYMENT_METHOD : " + db_payment_method + "," + "SUN NUMBER is found," + db_cons_status + "," + "Pass";
                                                    mandatory_list_results.add(sun_number);
                                                    mandatory_row++;
                                                }
                                                if ((db_ddi_reference == null) && (db_cons_status != "REVIEW")) {
                                                    String ddi_reference = "," + db_bc_header_id + ",DDI REFERENCE," + "DB_DDI REFERENCE : " + db_ddi_reference + "," + "DDI REFERENCE was not found," + db_cons_status + "," + "Fail";
                                                    mandatory_list_results.add(ddi_reference);
                                                } else {
                                                    String ddi_reference = "," + db_bc_header_id + ",DDI REFERENCE," + "DB_DDI REFERENCE : " + db_ddi_reference + "," + "DDI REFERENCE is found," + db_cons_status + "," + "Pass";
                                                    mandatory_list_results.add(ddi_reference);
                                                }
                                                if ((db_bacs_narrative == null) && (db_cons_status != "REVIEW")) {
                                                    String bacs_narrative = "," + db_bc_header_id + ",BACS NARRATIVE," + "DB_BACS NARRATIVE : " + db_bacs_narrative + "," + "BACS NARRATIVE was not found," + db_cons_status + "," + "Fail";
                                                    mandatory_list_results.add(bacs_narrative);
                                                } else {
                                                    String bacs_narrative = "," + db_bc_header_id + ",BACS NARRATIVE," + "DB_BACS NARRATIVE : " + db_bacs_narrative + "," + "BACS NARRATIVE is found," + db_cons_status + "," + "Pass";
                                                    mandatory_list_results.add(bacs_narrative);
                                                }

                                            } else if (db_payment_method.equals("Card")) {
                                                if ((db_mid_number == null) && (db_cons_status != "REVIEW")) {
                                                    String mid_number = mandatory_row + "," + db_bc_header_id + ",MID NUMBER," + "DB_MID NUMBER : " + db_mid_number + "," + "MID NUMBER was not found," + db_cons_status + "," + "Fail";
                                                    mandatory_list_results.add(mid_number);
                                                    mandatory_row++;
                                                } else {
                                                    String mid_number = mandatory_row + "," + db_bc_header_id + ",MID NUMBER," + "DB_MID NUMBER : " + db_mid_number + "," + "MID NUMBER is found," + db_cons_status + "," + "Pass";
                                                    mandatory_list_results.add(mid_number);
                                                    mandatory_row++;
                                                }
                                                if ((db_card_type == null) && (db_cons_status != "REVIEW")) {
                                                    String card_type = "," + db_bc_header_id + ",CARD TYPE," + "DB_CARD TYPE : " + db_card_type + "," + "CARD TYPE was not found," + db_cons_status + "," + "Fail";
                                                    mandatory_list_results.add(card_type);
                                                } else {
                                                    String card_type = "," + db_bc_header_id + ",CARD TYPE," + "DB_CARD TYPE : " + db_card_type + "," + "CARD TYPE is found," + db_cons_status + "," + "Pass";
                                                    mandatory_list_results.add(card_type);
                                                }
                                                if ((db_order_number == null) && (db_cons_status != "REVIEW")) {
                                                    String order_number = "," + db_bc_header_id + ",ORDER NUMBER," + "DB_ORDER NUMBER : " + db_order_number + "," + "ORDER NUMBER was not found," + db_cons_status + "," + "Fail";
                                                    mandatory_list_results.add(order_number);
                                                } else {
                                                    String order_number = "," + db_bc_header_id + ",ORDER NUMBER," + "DB_ORDER NUMBER : " + db_order_number + "," + "ORDER NUMBER is found," + db_cons_status + "," + "Pass";
                                                    mandatory_list_results.add(order_number);
                                                }
                                                
								//TO BE REVIEWED				
												if ((db_card_narrative == null) && (db_cons_status != "REVIEW")) {
                                                    String card_narrative = "," + db_bc_header_id + ",CARD NARRATIVE," + "DB_CARD NARRATIVE : " + db_card_narrative + "," + "CARD NARRATIVE was not found," + db_cons_status + "," + "Fail";
                                                    mandatory_list_results.add(card_narrative);
                                                } else {
                                                    String card_narrative = "," + db_bc_header_id + ",CARD NARRATIVE," + "DB_CARD NARRATIVE : " + db_card_narrative + "," + "CARD NARRATIVE is found," + db_cons_status + "," + "Pass";
                                                    mandatory_list_results.add(card_narrative);
                                                }
                                            }

                                    //Comparing xml and Consolidation fields
                                            if (xml_bc_header_id.equals(db_bc_header_id)) {
                                                String STR_HEADER_ID = direct_map_row + ",HEADER_ID," + db_bc_header_id + "," + xml_bc_header_id + ",Pass";
                                                section1_list_results.add(STR_HEADER_ID);
                                                direct_map_row++;
                                            } else {
                                                String STR_HEADER_ID = ",HEADER_ID," + db_bc_header_id + "," + xml_bc_header_id + ",Fail";
                                                section1_list_results.add(STR_HEADER_ID);
                                            }
                                            if (db_source.equals("SSPXGLBilling")) {
                                                String str_original_source = ",ORIGINAL_SOURCE," + db_source + "," + "SSPXGLBilling" + ",Pass";
                                                section1_list_results.add(str_original_source);

                                            } else {
                                                String str_original_source = ",ORIGINAL_SOURCE," + db_source + "," + "SSPXGLBilling" + ",Fail";
                                                section1_list_results.add(str_original_source);

                                            }
                                            if (xml_policy_number.equals(db_policy_number)) {
                                                String str_policy_number = ",POLICY_NUMBER," + db_policy_number + "," + xml_policy_number + ",Pass";
                                                section1_list_results.add(str_policy_number);

                                            } else {
                                                String str_policy_number = ",POLICY_NUMBER," + db_policy_number + "," + xml_policy_number + ",Fail";
                                                section1_list_results.add(str_policy_number);

                                            }
                                            if (xml_account_number.equals(db_account_number)) {
                                                String str_account_number = ",ACCOUNT_NUMBER," + db_account_number + "," + xml_account_number + ",Pass";
                                                section1_list_results.add(str_account_number);

                                            } else {
                                                String str_account_number = ",ACCOUNT_NUMBER," + db_account_number + "," + xml_account_number + ",Fail";
                                                section1_list_results.add(str_account_number);

                                            }
                                            if (xml_underwriter.equals(db_underwriter)) {
                                                String str_underwiter = ",UNDERWRITER," + db_underwriter + "," + xml_underwriter + ",Pass";
                                                section1_list_results.add(str_underwiter);

                                            } else {
                                                String str_underwiter = ",UNDERWRITER," + db_underwriter + "," + xml_underwriter + ",Fail";
                                                section1_list_results.add(str_underwiter);

                                            }
                            /*if (xml_brand.equals(db_brand)) {
                                String str_brand = ",BRAND," + db_brand + "," + xml_brand + ",Pass";
                                section1_list_results.add(str_brand);

                            } else {
                                String str_brand = ",BRAND," + db_brand + "," + xml_brand + ",Fail";
                                section1_list_results.add(str_brand);

                            }*/
                                            if (xml_line_of_business.equals(db_line_of_business)) {
                                                String str_line_of_business = ",LINE OF BUSINESS," + db_line_of_business + "," + xml_line_of_business + ",Pass";
                                                section1_list_results.add(str_line_of_business);

                                            } else {
                                                String str_line_of_business = ",LINE OF BUSINESS," + db_line_of_business + "," + xml_line_of_business + ",Fail";
                                                section1_list_results.add(str_line_of_business);

                                            }
                                            if (xml_channel.equals(db_channel)) {
                                                String str_channel = ",CHANNEL," + db_channel + "," + xml_channel + ",Pass";
                                                section1_list_results.add(str_channel);

                                            } else {
                                                String str_channel = ",CHANNEL," + db_channel + "," + xml_channel + ",Fail";
                                                section1_list_results.add(str_channel);

                                            }
                                            if (xml_product_type.equals(db_product_Type)) {
                                                String str_product_type = ",PRODUCT TYPE," + db_product_Type + "," + xml_product_type + ",Pass";
                                                section1_list_results.add(str_product_type);

                                            } else {
                                                String str_product_type = ",PRODUCT TYPE," + db_product_Type + "," + xml_product_type + ",Fail";
                                                section1_list_results.add(str_product_type);

                                            }
                                            if (xml_transaction_reference.equals(db_transaction_reference)) {
                                                String str_transaction_reference = ",TRANSACTION REFERENCE," + db_transaction_reference + "," + xml_transaction_reference + ",Pass";
                                                section1_list_results.add(str_transaction_reference);

                                            } else {
                                                String str_transaction_reference = ",TRANSACTION REFERENCE," + db_transaction_reference + "," + xml_transaction_reference + ",Fail";
                                                section1_list_results.add(str_transaction_reference);

                                            }
                                            if (xml_transaction_date.equals(db_transaction_date)) {
                                                String str_transaction_date = ",TRANSACTION DATE," + db_transaction_date + "," + xml_transaction_date + ",Pass";
                                                section1_list_results.add(str_transaction_date);

                                            } else {
                                                String str_transaction_date = ",TRANSACTION DATE," + db_transaction_date + "," + xml_transaction_date + ",Fail";
                                                section1_list_results.add(str_transaction_date);

                                            }
                                            if (xml_transaction_subtype.equals(db_transaction_sub_type)) {
                                                String str_transaction_subtype = ",TRANSACTION SUBTYPE," + db_transaction_sub_type + "," + xml_transaction_subtype + ",Pass";
                                                section1_list_results.add(str_transaction_subtype);

                                            } else {
                                                String str_transaction_subtype = ",TRANSACTION SUBTYPE," + db_transaction_sub_type + "," + xml_transaction_subtype + ",Fail";
                                                section1_list_results.add(str_transaction_subtype);

                                            }
                                            if (xml_transaction_reason.equals(db_transaction_reason)) {
                                                String str_transaction_reason = ",TRANSACTION REASON," + db_transaction_reason + "," + xml_transaction_reason + ",Pass";
                                                section1_list_results.add(str_transaction_reason);

                                            } else {
                                                String str_transaction_reason = ",TRANSACTION REASON," + db_transaction_reason + "," + xml_transaction_reason + ",Fail";
                                                section1_list_results.add(str_transaction_reason);

                                            }
                                            if (xml_payment_method.equals(db_payment_method)) {
                                                String str_payment_method = ",PAYMENT METHOD," + db_payment_method + "," + xml_payment_method + ",Pass";
                                                section1_list_results.add(str_payment_method);

                                            } else {
                                                String str_payment_method = ",PAYMENT METHOD," + db_payment_method + "," + xml_payment_method + ",Fail";
                                                section1_list_results.add(str_payment_method);

                                            }
                                            if (xml_sun_number == null || db_sun_number == null) {
                                                if (xml_sun_number == db_sun_number) {
                                                    String str_sun_number = ",SUN NUMBER," + db_sun_number + "," + xml_sun_number + ",Pass";
                                                    section1_list_results.add(str_sun_number);

                                                } else {
                                                    String str_sun_number = ",SUN NUMBER," + db_sun_number + "," + xml_sun_number + ",Fail";
                                                    section1_list_results.add(str_sun_number);

                                                }
                                            } else {
                                                if (xml_sun_number.equals(db_sun_number)) {
                                                    String str_sun_number = ",SUN NUMBER," + db_sun_number + "," + xml_sun_number + ",Pass";
                                                    section1_list_results.add(str_sun_number);

                                                } else {
                                                    String str_sun_number = ",SUN NUMBER," + db_sun_number + "," + xml_sun_number + ",Fail";
                                                    section1_list_results.add(str_sun_number);

                                                }
                                            }
                                            if (xml_mid_number == null || db_mid_number == null) {
                                                if (xml_mid_number == db_mid_number) {
                                                    String str_mid_number = ",MID NUMBER," + db_mid_number + "," + xml_mid_number + ",Pass";
                                                    section1_list_results.add(str_mid_number);

                                                } else {
                                                    String str_mid_number = ",MID NUMBER," + db_mid_number + "," + xml_mid_number + ",Fail";
                                                    section1_list_results.add(str_mid_number);

                                                }

                                            } else {
                                                if (xml_mid_number.equals(db_mid_number)) {
                                                    String str_mid_number = ",MID NUMBER," + db_mid_number + "," + xml_mid_number + ",Pass";
                                                    section1_list_results.add(str_mid_number);

                                                } else {
                                                    String str_mid_number = ",MID NUMBER," + db_mid_number + "," + xml_mid_number + ",Fail";
                                                    section1_list_results.add(str_mid_number);

                                                }
                                            }
                                            if (xml_ddi_reference == null || db_ddi_reference == null) {
                                                if (xml_ddi_reference == db_ddi_reference) {
                                                    String str_ddi_reference = ",DDI REFERENCE," + db_ddi_reference + "," + xml_ddi_reference + ",Pass";
                                                    section1_list_results.add(str_ddi_reference);

                                                } else {
                                                    String str_ddi_reference = ",DDI REFERENCE," + db_ddi_reference + "," + xml_ddi_reference + ",Fail";
                                                    section1_list_results.add(str_ddi_reference);

                                                }

                                            } else {
                                                if (xml_ddi_reference.equals(db_ddi_reference)) {
                                                    String str_ddi_reference = ",DDI REFERENCE," + db_ddi_reference + "," + xml_ddi_reference + ",Pass";
                                                    section1_list_results.add(str_ddi_reference);

                                                } else {
                                                    String str_ddi_reference = ",DDI REFERENCE," + db_ddi_reference + "," + xml_ddi_reference + ",Fail";
                                                    section1_list_results.add(str_ddi_reference);

                                                }
                                            }
                            /*if (xml_pay_in_slip_number == null || db_pay_in_slip_number == null) {
                                if (xml_pay_in_slip_number == db_pay_in_slip_number) {
                                    String str_pay_in_slip_number = ",PAY IN SLIP NUMBER," + db_pay_in_slip_number + "," + xml_pay_in_slip_number + ",Pass";
                                    section1_list_results.add(str_pay_in_slip_number);

                                } else {
                                    String str_pay_in_slip_number = ",PAY IN SLIP NUMBER," + db_pay_in_slip_number + "," + xml_pay_in_slip_number + ",Fail";
                                    section1_list_results.add(str_pay_in_slip_number);

                                }
                            } else {
                                if (xml_pay_in_slip_number.equals(db_pay_in_slip_number)) {
                                    String str_pay_in_slip_number = ",PAY IN SLIP NUMBER," + db_pay_in_slip_number + "," + xml_pay_in_slip_number + ",Pass";
                                    section1_list_results.add(str_pay_in_slip_number);

                                } else {
                                    String str_pay_in_slip_number = ",PAY IN SLIP NUMBER," + db_pay_in_slip_number + "," + xml_pay_in_slip_number + ",Fail";
                                    section1_list_results.add(str_pay_in_slip_number);

                                }
                            }
                            if (xml_cheque_number == null || db_cheque_number == null) {
                                if (xml_cheque_number == db_cheque_number) {
                                    String str_cheque_number = ",CHEQUE NUMBER," + db_cheque_number + "," + xml_cheque_number + ",Pass";
                                    section1_list_results.add(str_cheque_number);

                                } else {
                                    String str_cheque_number = ",CHEQUE NUMBER," + db_cheque_number + "," + xml_cheque_number + ",Fail";
                                    section1_list_results.add(str_cheque_number);

                                }
                            } else {
                                if (xml_cheque_number.equals(db_cheque_number)) {
                                    String str_cheque_number = ",CHEQUE NUMBER," + db_cheque_number + "," + xml_cheque_number + ",Pass";
                                    section1_list_results.add(str_cheque_number);

                                } else {
                                    String str_cheque_number = ",CHEQUE NUMBER," + db_cheque_number + "," + xml_cheque_number + ",Fail";
                                    section1_list_results.add(str_cheque_number);

                                }
                            }*/
                                            if (xml_card_type == null || db_card_type == null) {
                                                if (xml_card_type == db_card_type) {
                                                    String str_card_type = ",CARD TYPE," + db_card_type + "," + xml_card_type + ",Pass";
                                                    section1_list_results.add(str_card_type);

                                                } else {
                                                    String str_card_type = ",CARD TYPE," + db_card_type + "," + xml_card_type + ",Fail";
                                                    section1_list_results.add(str_card_type);

                                                }
                                            } else {
                                                if (xml_card_type.equals(db_card_type)) {
                                                    String str_card_type = ",CARD TYPE," + db_card_type + "," + xml_card_type + ",Pass";
                                                    section1_list_results.add(str_card_type);

                                                } else {
                                                    String str_card_type = ",CARD TYPE," + db_card_type + "," + xml_card_type + ",Fail";
                                                    section1_list_results.add(str_card_type);

                                                }
                                            }
                                            if (xml_bacs_narrative == null || db_bacs_narrative == null) {
                                                if (xml_bacs_narrative == db_bacs_narrative) {
                                                    String str_bacs_narrative = ",BACS NARRATIVE," + db_bacs_narrative + "," + xml_bacs_narrative + ",Pass";
                                                    section1_list_results.add(str_bacs_narrative);

                                                } else {
                                                    String str_bacs_narrative = ",BACS NARRATIVE," + db_bacs_narrative + "," + xml_bacs_narrative + ",Fail";
                                                    section1_list_results.add(str_bacs_narrative);

                                                }
                                            } else {

                                                if (xml_bacs_narrative.equals(db_bacs_narrative)) {
                                                    String str_bacs_narrative = ",BACS NARRATIVE," + db_bacs_narrative + "," + xml_bacs_narrative + ",Pass";
                                                    section1_list_results.add(str_bacs_narrative);

                                                } else {
                                                    String str_bacs_narrative = ",BACS NARRATIVE," + db_bacs_narrative + "," + xml_bacs_narrative + ",Fail";
                                                    section1_list_results.add(str_bacs_narrative);

                                                }
                                            }
                                            if (xml_card_narrative == null || db_card_narrative == null) {
                                                if (xml_card_narrative == db_card_narrative) {
                                                    String str_card_narrative = ",CARD NARRATIVE," + db_card_narrative + "," + xml_card_narrative + ",Pass";
                                                    section1_list_results.add(str_card_narrative);

                                                } else {
                                                    String str_card_narrative = ",CARD NARRATIVE," + db_card_narrative + "," + xml_card_narrative + ",Fail";
                                                    section1_list_results.add(str_card_narrative);

                                                }
                                            } else {
                                                if (xml_card_narrative.equals(db_card_narrative)) {
                                                    String str_card_narrative = ",CARD NARRATIVE," + db_card_narrative + "," + xml_card_narrative + ",Pass";
                                                    section1_list_results.add(str_card_narrative);

                                                } else {
                                                    String str_card_narrative = ",CARD NARRATIVE," + db_card_narrative + "," + xml_card_narrative + ",Fail";
                                                    section1_list_results.add(str_card_narrative);

                                                }
                                            }
                                            if (xml_reversal_indicator.equals(db_reversal_indicator)) {
                                                String str_reversal_indicator = ",REVERSAL INDICATOR," + db_reversal_indicator + "," + db_reversal_indicator + ",Pass";
                                                section1_list_results.add(str_reversal_indicator);

                                            } else {
                                                String str_reversal_indicator = ",REVERSAL INDICATOR," + db_reversal_indicator + "," + db_reversal_indicator + ",Fail";
                                                section1_list_results.add(str_reversal_indicator);

                                            }
                            /*if (xml_interest_amount.equals(db_interest_amount)) {
                                String str_interest_amount = ",INTEREST AMOUNT," + db_interest_amount + "," + xml_interest_amount + ",Pass";
                                section1_list_results.add(str_interest_amount);

                            } else {
                                String str_interest_amount = ",INTEREST AMOUNT," + db_interest_amount + "," + xml_interest_amount + ",Fail";
                                section1_list_results.add(str_interest_amount);

                            }
                            if (xml_interest_currency_code.equals(db_interest_currency_code)) {
                                String str_interest_currency_code = ",INTEREST CURRENCY CODE," + db_interest_currency_code + "," + xml_interest_currency_code + ",Pass";
                                section1_list_results.add(str_interest_currency_code);

                            } else {
                                String str_interest_currency_code = ",INTEREST CURRENCY CODE," + db_interest_currency_code + "," + xml_interest_currency_code + ",Fail";
                                section1_list_results.add(str_interest_currency_code);

                            }*/
                                            if (xml_currency_code.equals(db_currency_code)) {
                                                String str_currency_code = ",CURRENCY CODE," + db_currency_code + "," + xml_currency_code + ",Pass";
                                                section1_list_results.add(str_currency_code);

                                            } else {
                                                String str_currency_code = ",CURRENCY CODE," + db_currency_code + "," + xml_currency_code + ",Fail";
                                                section1_list_results.add(str_currency_code);

                                            }
                                            if (xml_exchange_rate.equals(db_exchange_rate)) {
                                                String str_exchange_rate = ",EXCHANGE RATE," + db_exchange_rate + "," + xml_exchange_rate + ",Pass";
                                                section1_list_results.add(str_exchange_rate);

                                            } else {
                                                String str_exchange_rate = ",EXCHANGE RATE," + db_exchange_rate + "," + xml_exchange_rate + ",Fail";
                                                section1_list_results.add(str_exchange_rate);

                                            }
                                            if (xml_exchange_rate_type.equals(db_exchange_rate_type)) {
                                                String str_exchange_rate_type = ",EXCHANGE RATE TYPE," + db_exchange_rate_type + "," + xml_exchange_rate_type + ",Pass";
                                                section1_list_results.add(str_exchange_rate_type);

                                            } else {
                                                String str_exchange_rate_type = ",EXCHANGE RATE TYPE," + db_exchange_rate_type + "," + xml_exchange_rate_type + ",Fail";
                                                section1_list_results.add(str_exchange_rate_type);

                                            }
                                            if (xml_base_currency_amount.equals(db_base_currency_amount)) {
                                                String str_base_currency_amount = ",BASE_CURRENCY_AMOUNT," + db_base_currency_amount + "," + xml_base_currency_amount + ",Pass";
                                                section1_list_results.add(str_base_currency_amount);

                                            } else {
                                                String str_base_currency_amount = ",BASE_CURRENCY_AMOUNT," + db_base_currency_amount + "," + xml_base_currency_amount + ",Fail";
                                                section1_list_results.add(str_base_currency_amount);

                                            }
                            /*if (xml_base_interest_amount.equals(db_base_interest_amount)) {
                                String str_base_interest_amount = ",BASE_INTEREST_AMOUNT," + db_base_interest_amount + "," + xml_base_interest_amount + ",Pass";
                                section1_list_results.add(str_base_interest_amount);

                            } else {
                                String str_base_interest_amount = ",BASE_INTEREST_AMOUNT," + db_base_interest_amount + "," + xml_base_interest_amount + ",Fail";
                                section1_list_results.add(str_base_interest_amount);

                            }
                            if (xml_tax_deductible != null) {
                                if (xml_tax_deductible.equals(db_tax_deductible)) {
                                    String str_tax_deductible = ",TAX DEDUCTIBLE," + db_tax_deductible + "," + xml_tax_deductible + ",Pass";
                                    section1_list_results.add(str_tax_deductible);

                                } else {
                                    String str_tax_deductible = ",TAX DEDUCTIBLE," + db_tax_deductible + "," + xml_tax_deductible + ",Fail";
                                    section1_list_results.add(str_tax_deductible);

                                }
                            }
                            if (xml_order_number == null || db_order_number == null) {
                                if (xml_order_number == db_order_number) {
                                    String str_order_number = ",ORDER NUMBER," + db_order_number + "," + xml_order_number + ",Pass";
                                    section1_list_results.add(str_order_number);

                                } else {
                                    String str_order_number = ",ORDER NUMBER," + db_order_number + "," + xml_order_number + ",Fail";
                                    section1_list_results.add(str_order_number);

                                }
                            } else {
                                if (xml_order_number.equals(db_order_number)) {
                                    String str_order_number = ",ORDER NUMBER," + db_order_number + "," + xml_order_number + ",Pass";
                                    section1_list_results.add(str_order_number);

                                } else {
                                    String str_order_number = ",ORDER NUMBER," + db_order_number + "," + xml_order_number + ",Fail";
                                    section1_list_results.add(str_order_number);

                                }
                            }
                            if (xml_payment_transaction_type_id.equals(db_payment_transaction_type_id)) {
                                String str_payment_transaction_type_id = ",PAYMENT TRANSACTION TYPE ID," + db_payment_transaction_type_id + "," + xml_payment_transaction_type_id + ",Pass";
                                section1_list_results.add(str_payment_transaction_type_id);

                            } else {
                                String str_payment_transaction_type_id = ",PAYMENT TRANSACTION TYPE ID," + db_payment_transaction_type_id + "," + xml_payment_transaction_type_id + ",Fail";
                                section1_list_results.add(str_payment_transaction_type_id);

                            }
                            if (xml_currency_amount.equals(db_currency_amount)) {
                                String str_currency_amount = ",CURRENCY AMOUNT," + db_currency_amount + "," + xml_currency_amount + ",Pass";
                                section1_list_results.add(str_currency_amount);

                            } else {
                                String str_currency_amount = ",CURRENCY AMOUNT," + db_currency_amount + "," + xml_currency_amount + ",Fail";
                                section1_list_results.add(str_currency_amount);

                            }
                            if (xml_credit_ind.equals(db_credit_ind)) {
                                String str_credit_ind = ",CREDIT INDICATOR," + db_credit_ind + "," + xml_credit_ind + ",Pass";
                                section1_list_results.add(str_credit_ind);

                            } else {
                                String str_credit_ind = ",CREDIT INDICATOR," + db_credit_ind + "," + xml_credit_ind + ",Fail";
                                section1_list_results.add(str_credit_ind);

                            }*/

                                            //Validating Batch_PKey and File name
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT BATCH_PKEY,FILE_NAME FROM DLG_FSH_CTL_BATCH WHERE FILE_NAME = '" + file_list + "'");
                                            while (SQLResultset_fsh.next()) {
                                                BATCH_PKEY = SQLResultset_fsh.getString("BATCH_PKEY");
                                                FILE_NAME = SQLResultset_fsh.getString("FILE_NAME");
                                                //break;
                                            }
                                            if (BATCH_PKEY.equals(db_BATCH_PKEY)) {
                                                String str_batch_pkey = ",BATCH_PKEY," + db_BATCH_PKEY + "," + BATCH_PKEY + ",Pass";
                                                section1_list_results.add(str_batch_pkey);

                                            } else {
                                                String str_batch_pkey = ",BATCH_PKEY," + db_BATCH_PKEY + "," + BATCH_PKEY + ",Fail";
                                                section1_list_results.add(str_batch_pkey);

                                            }
                                            if (FILE_NAME.equals(db_FILE_NAME)) {
                                                String str_file_name = ",FILE_NAME," + db_FILE_NAME + "," + FILE_NAME + ",Pass";
                                                section1_list_results.add(str_file_name);

                                            } else {
                                                String str_file_name = ",FILE_NAME," + db_FILE_NAME + "," + FILE_NAME + ",Fail";
                                                section1_list_results.add(str_file_name);

                                            }
                                            String Record_status = "Actual Record Status in FSH : " + db_cons_status;
                                            section1_list_results.add(Record_status);
                                        }
                                    }

                                    //Cons to stage validation
                                    SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT *  from DLG_FSH_STG_COMM_BCCC_HDR WHERE FILE_NAME = '" + file_list + "' and HEADER_ID = '" + xml_bc_header_id + "'");
                                    boolean stg_flag = true;
                                    if (!SQLResultset_fsh.next()) {
                                        stg_flag = false;
                                        if (xml_bc_header_id != null) {
                                            String stg_header_id = lookup_map_row + ",HEADER_ID," + "Staging DB Does not have any records. please verify in the Batch Control table" + "," + xml_bc_header_id + ",Fail";
                                            section2_list_results.add(stg_header_id);
                                            lookup_map_row++;
                                        } else {
                                            String stg_header_id = lookup_map_row + ",HEADER_ID," + "Staging Table Does not have any records. please verify in the Batch Control table" + "," + "Cons table Does not have any records. please verify in the Batch Control table" + ",Fail";
                                            section2_list_results.add(stg_header_id);
                                            lookup_map_row++;
                                        }
                                    }

                                    if (stg_flag) {
                                        SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT *  from DLG_FSH_STG_COMM_BCCC_HDR WHERE FILE_NAME = '" + file_list + "' and HEADER_ID = '" + xml_bc_header_id + "'");
                                        while (SQLResultset_fsh.next()) {
                                            db_stg_bc_header_id = SQLResultset_fsh.getString("HEADER_ID");
                                            db_stg_source = SQLResultset_fsh.getString("SOURCE");
                                            db_stg_account_number = SQLResultset_fsh.getString("ACCOUNT_NUMBER");
                                        //    db_stg_brand = SQLResultset_fsh.getString("BRAND");
                                        //    db_stg_account_number = SQLResultset_fsh.getString("ACCOUNT_NUMBER");
                                            db_stg_policy_number = SQLResultset_fsh.getString("POLICY_NUMBER");
											db_stg_underwriter = SQLResultset_fsh.getString("UNDERWRITER");
											db_stg_product_type = SQLResultset_fsh.getString("PRODUCT_TYPE");
											db_stg_line_of_business = SQLResultset_fsh.getString("LINE_OF_BUSINESS");
											db_stg_transaction_reference = SQLResultset_fsh.getString("TRANSACTION_REFERENCE");							
                                            db_stg_transaction_date = SQLResultset_fsh.getString("TRANSACTION_DATE");                                           
                                            db_stg_transaction_sub_type = SQLResultset_fsh.getString("TRANSACTION_SUB_TYPE");
                                            db_stg_transaction_reason = SQLResultset_fsh.getString("TRANSACTION_REASON");
                                            db_stg_payment_method = SQLResultset_fsh.getString("PAYMENT_METHOD");                                           
                                            db_stg_sun_number = SQLResultset_fsh.getString("SUN_NUMBER");
                                            db_stg_mid_number = SQLResultset_fsh.getString("MID_NUMBER");
                                            db_stg_ddi_reference = SQLResultset_fsh.getString("DDI_REFERENCE");
											db_stg_card_type = SQLResultset_fsh.getString("CARD_TYPE");
											db_stg_bacs_narrative = SQLResultset_fsh.getString("BACS_NARRATIVE");
											db_stg_channel = SQLResultset_fsh.getString("CHANNEL");
											db_stg_order_number = SQLResultset_fsh.getString("ORDER_NUMBER");
											db_stg_reversal_indicator = SQLResultset_fsh.getString("REVERSAL_INDICATOR");
											db_stg_currency_code = SQLResultset_fsh.getString("CURRENCY_CODE");
											db_stg_exchange_rate = SQLResultset_fsh.getString("EXCHANGE_RATE");
											db_stg_exchange_rate_type = SQLResultset_fsh.getString("EXCHANGE_RATE_TYPE");
											db_stg_base_currency_amount = SQLResultset_fsh.getString("BASE_CURRENCY_AMOUNT");
											db_stg_credit_ind = SQLResultset_fsh.getString("CREDIT_IND");
											db_stg_currency_amount = SQLResultset_fsh.getString("CURRENCY_AMOUNT");
											
											
                   /* To be reviewed        db_stg_pay_in_slip_number = SQLResultset_fsh.getString("PAY_IN_SLIP_NUMBER");
                                            db_stg_cheque_number = SQLResultset_fsh.getString("CHEQUE_NUMBER");  
                                            db_stg_card_narrative = SQLResultset_fsh.getString("CARD_NARRATIVE");                 
                                            db_stg_base_interest_amount = SQLResultset_fsh.getString("BASE_INTEREST_AMOUNT");
                                            db_stg_tax_deductible = SQLResultset_fsh.getString("TAX_DEDUCTIBLE");
                                            db_stg_payment_transaction_type_id = SQLResultset_fsh.getString("PAYMENT_TRANSACTION_TYPE_ID");
                                            db_stg_underwriter = SQLResultset_fsh.getString("UNDERWRITER");   
                                            db_stg_event_code = SQLResultset_fsh.getString("EVENT_CODE");
                                            db_stg_event_type_code = SQLResultset_fsh.getString("ENTITY_TYPE_CODE");
                                            db_stg_status = SQLResultset_fsh.getString("STATUS");
                                            db_stg_interest_amount = SQLResultset_fsh.getString("INTEREST_AMOUNT");
                                            db_stg_interest_currency_code = SQLResultset_fsh.getString("INTEREST_CURRENCY_CODE");
                                            db_stg_batch_fkey = SQLResultset_fsh.getString("BATCH_FKEY");
                                            db_stg_file_name = SQLResultset_fsh.getString("FILE_NAME");      */

                                            if (db_bc_header_id.equals(db_stg_bc_header_id)) {
                                                String stg_header_id = lookup_map_row + ",HEADER_ID," + db_stg_bc_header_id + "," + db_bc_header_id + ",Pass";
                                                section2_list_results.add(stg_header_id);
                                                lookup_map_row++;
                                            } else {
                                                String stg_header_id = ",HEADER_ID," + db_stg_bc_header_id + "," + db_bc_header_id + ",Fail";
                                                section2_list_results.add(stg_header_id);
                                            }
                                            if (db_BATCH_PKEY.equals(db_stg_batch_fkey)) {
                                                String stg_batch_pkey = ",BATCH_PKEY," + db_stg_batch_fkey + "," + db_BATCH_PKEY + ",Pass";
                                                section2_list_results.add(stg_batch_pkey);

                                            } else {
                                                String stg_batch_pkey = ",BATCH_PKEY," + db_stg_batch_fkey + "," + db_BATCH_PKEY + ",Fail";
                                                section2_list_results.add(stg_batch_pkey);
                                            }
                                            if (db_FILE_NAME.equals(db_stg_file_name)) {
                                                String stg_file_name = ",FILE_NAME," + db_stg_file_name + "," + db_FILE_NAME + ",Pass";
                                                section2_list_results.add(stg_file_name);

                                            } else {
                                                String stg_file_name = ",FILE_NAME," + db_stg_file_name + "," + db_FILE_NAME + ",Fail";
                                                section2_list_results.add(stg_file_name);
                                            }
                                            if (db_source.equals(db_stg_source)) {
                                                String stg_original_source = ",ORIGINAL_SOURCE," + db_stg_source + "," + db_source + ",Pass";
                                                section2_list_results.add(stg_original_source);

                                            } else {
                                                String stg_original_source = ",ORIGINAL_SOURCE," + db_stg_source + "," + db_source + ",Fail";
                                                section2_list_results.add(stg_original_source);
                                            }
                                            if (db_policy_number.equals(db_stg_policy_number)) {
                                                String stg_policy_number = ",POLICY_NUMBER," + db_stg_policy_number + "," + db_policy_number + ",Pass";
                                                section2_list_results.add(stg_policy_number);

                                            } else {
                                                String stg_policy_number = ",POLICY_NUMBER," + db_stg_policy_number + "," + db_policy_number + ",Fail";
                                                section2_list_results.add(stg_policy_number);

                                            }
                                            if (db_account_number.equals(db_stg_account_number)) {
                                                String stg_account_number = ",ACCOUNT_NUMBER," + db_stg_account_number + "," + db_account_number + ",Pass";
                                                section2_list_results.add(stg_account_number);

                                            } else {
                                                String stg_account_number = ",ACCOUNT_NUMBER," + db_stg_account_number + "," + db_account_number + ",Fail";
                                                section2_list_results.add(stg_account_number);

                                            }

                                            if (db_stg_transaction_date.equals(db_transaction_date)) {
                                                String stg_transaction_date = ",TRANSACTION_DATE," + db_stg_transaction_date + "," + db_transaction_date + ",Pass";
                                                section2_list_results.add(stg_transaction_date);
                                            } else {
                                                String stg_transaction_date = ",TRANSACTION_DATE," + db_stg_transaction_date + "," + db_transaction_date + ",Fail";
                                                section2_list_results.add(stg_transaction_date);
                                            }


                                            if (db_stg_transaction_reference.equals(db_transaction_reference)) {
                                                String stg_transaction_reference = ",TRANSACTION_REFERENCE," + db_stg_transaction_reference + "," + db_transaction_reference + ",Pass";
                                                section2_list_results.add(stg_transaction_reference);
                                            } else {
                                                String stg_transaction_reference = ",TRANSACTION_REFERENCE," + db_stg_transaction_reference + "," + db_transaction_reference + ",Fail";
                                                section2_list_results.add(stg_transaction_reference);
                                            }

                                            if (db_stg_exchange_rate.equals(db_exchange_rate)) {
                                                String stg_exchange_rate = ",EXCHANGE_RATE," + db_stg_exchange_rate + "," + db_exchange_rate + ",Pass";
                                                section2_list_results.add(stg_exchange_rate);
                                            } else {
                                                String stg_exchange_rate = ",EXCHANGE_RATE," + db_stg_exchange_rate + "," + db_exchange_rate + ",Fail";
                                                section2_list_results.add(stg_exchange_rate);
                                            }

                                            if (db_stg_exchange_rate_type.equals(db_exchange_rate_type)) {
                                                String stg_exchange_rate_type = ",EXCHANGE_RATE_TYPE," + db_stg_exchange_rate_type + "," + db_exchange_rate_type + ",Pass";
                                                section2_list_results.add(stg_exchange_rate_type);
                                            } else {
                                                String stg_exchange_rate_type = ",EXCHANGE_RATE_TYPE," + db_stg_exchange_rate_type + "," + db_exchange_rate_type + ",Fail";
                                                section2_list_results.add(stg_exchange_rate_type);
                                            }

                                            if (xml_payment_method.equals("5")) {
                                                if (db_stg_sun_number.equals(db_sun_number)) {
                                                    String stg_sun_number = ",SUN_NUMBER," + db_stg_sun_number + "," + db_sun_number + ",Pass";
                                                    section2_list_results.add(stg_sun_number);
                                                } else {
                                                    String stg_sun_number = ",SUN_NUMBER," + db_stg_sun_number + "," + db_sun_number + ",Fail";
                                                    section2_list_results.add(stg_sun_number);
                                                }
                                            }

                                            if (xml_payment_method.equals("6")) {
                                                if (db_stg_mid_number.equals(db_mid_number)) {
                                                    String stg_mid_number = ",MID_NUMBER," + db_stg_mid_number + "," + db_mid_number + ",Pass";
                                                    section2_list_results.add(stg_mid_number);
                                                } else {
                                                    String stg_mid_number = ",MID_NUMBER," + db_stg_mid_number + "," + db_mid_number + ",Fail";
                                                    section2_list_results.add(stg_mid_number);
                                                }
                                            }

                                            if (xml_payment_method.equals("5")) {
                                                if (db_stg_ddi_reference == db_ddi_reference || db_stg_ddi_reference.equals(db_ddi_reference)) {
                                                    String stg_ddi_reference = ",DDI_REFERENCE," + db_stg_ddi_reference + "," + db_ddi_reference + ",Pass";
                                                    section2_list_results.add(stg_ddi_reference);
                                                } else {
                                                    String stg_ddi_reference = ",DDI_REFERENCE," + db_stg_ddi_reference + "," + db_ddi_reference + ",Fail";
                                                    section2_list_results.add(stg_ddi_reference);
                                                }
                                            }

                                            /*if (xml_payment_method.equals("2")) {
                                                if ((db_stg_pay_in_slip_number == db_pay_in_slip_number) || db_stg_pay_in_slip_number.equals(db_pay_in_slip_number)) {
                                                    String stg_pay_in_slip_number = ",PAY_IN_SLIP_NUMBER," + db_stg_pay_in_slip_number + "," + db_pay_in_slip_number + ",Pass";
                                                    section2_list_results.add(stg_pay_in_slip_number);
                                                } else {
                                                    String stg_pay_in_slip_number = ",PAY_IN_SLIP_NUMBER," + db_stg_pay_in_slip_number + "," + db_pay_in_slip_number + ",Fail";
                                                    section2_list_results.add(stg_pay_in_slip_number);
                                                }
                                            }

                                            if (xml_payment_method.equals("2")) {
                                                if (db_stg_cheque_number.equals(db_cheque_number)) {
                                                    String stg_cheque_number = ",CHEQUE_NUMBER," + db_stg_cheque_number + "," + db_cheque_number + ",Pass";
                                                    section2_list_results.add(stg_cheque_number);
                                                } else {
                                                    String stg_cheque_number = ",CHEQUE_NUMBER," + db_stg_cheque_number + "," + db_cheque_number + ",Fail";
                                                    section2_list_results.add(stg_cheque_number);
                                                }
                                            }

                                            if (xml_payment_method.equals("5")) {
                                                if (db_stg_bacs_narrative == db_bacs_narrative || db_stg_bacs_narrative.equals(db_bacs_narrative)) {
                                                    String stg_bacs_narrative = ",BACS_NARRATIVE," + db_stg_bacs_narrative + "," + db_bacs_narrative + ",Pass";
                                                    section2_list_results.add(stg_bacs_narrative);
                                                } else {
                                                    String stg_bacs_narrative = ",BACS_NARRATIVE," + db_stg_bacs_narrative + "," + db_bacs_narrative + ",Fail";
                                                    section2_list_results.add(stg_bacs_narrative);
                                                }
                                            }

                                            if (xml_payment_method.equals("6")) {
                                                if (db_stg_card_narrative.equals(db_card_narrative)) {
                                                    String stg_card_narrative = ",CARD_NARRATIVE," + db_stg_card_narrative + "," + db_card_narrative + ",Pass";
                                                    section2_list_results.add(stg_card_narrative);
                                                } else {
                                                    String stg_card_narrative = ",CARD_NARRATIVE," + db_stg_card_narrative + "," + db_card_narrative + ",Fail";
                                                    section2_list_results.add(stg_card_narrative);
                                                }
                                            }*/
                                            if (xml_payment_method.equals("Card")) {
                                                if (db_stg_order_number.equals(db_order_number)) {
                                                    String stg_order_number = ",ORDER_NUMBER," + db_stg_order_number + "," + db_order_number + ",Pass";
                                                    section2_list_results.add(stg_order_number);
                                                } else {
                                                    String stg_order_number = ",ORDER_NUMBER," + db_stg_order_number + "," + db_order_number + ",Fail";
                                                    section2_list_results.add(stg_order_number);
                                                }
                                            }
                                            if (xml_payment_method.equals("Card")) {
                                                if (db_stg_card_type.equals(db_card_type)) {
                                                    String stg_card_type = ",CARD_TYPE," + db_stg_card_type + "," + db_card_type + ",Pass";
                                                    section2_list_results.add(stg_card_type);
                                                } else {
                                                    String stg_card_type = ",CARD_TYPE," + db_stg_card_type + "," + db_card_type + ",Fail";
                                                    section2_list_results.add(stg_card_type);
                                                }
                                            }

                                            if (db_stg_reversal_indicator.equals(db_reversal_indicator)) {
                                                String stg_reversal_indicator = ",REVERSAL_INDICATOR," + db_stg_reversal_indicator + "," + db_reversal_indicator + ",Pass";
                                                section2_list_results.add(stg_reversal_indicator);
                                            } else {
                                                String stg_reversal_indicator = ",REVERSAL_INDICATOR," + db_stg_reversal_indicator + "," + db_reversal_indicator + ",Fail";
                                                section2_list_results.add(stg_reversal_indicator);
                                            }


                                            if (db_stg_base_currency_amount.equals(db_base_currency_amount)) {
                                                String stg_base_currency_amount = ",BASE_CURRENCY_AMOUNT," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Pass";
                                                section2_list_results.add(stg_base_currency_amount);
                                            } else {
                                                String stg_base_currency_amount = ",BASE_CURRENCY_AMOUNT," + db_stg_base_currency_amount + "," + db_base_currency_amount + ",Fail";
                                                section2_list_results.add(stg_base_currency_amount);
                                            }


                                            /*if (db_stg_base_interest_amount.equals(db_base_interest_amount)) {
                                                String stg_base_interest_amount = ",BASE_INTEREST_AMOUNT," + db_stg_base_interest_amount + "," + db_base_interest_amount + ",Pass";
                                                section2_list_results.add(stg_base_interest_amount);
                                            } else {
                                                String stg_base_interest_amount = ",BASE_INTEREST_AMOUNT," + db_stg_base_interest_amount + "," + db_base_interest_amount + ",Fail";
                                                section2_list_results.add(stg_base_interest_amount);
                                            }

                                            if (db_stg_interest_amount.equals(db_interest_amount)) {
                                                String stg_interest_amount = ",INTEREST_AMOUNT," + db_stg_interest_amount + "," + db_interest_amount + ",Pass";
                                                section2_list_results.add(stg_interest_amount);
                                            } else {
                                                String stg_interest_amount = ",INTEREST_AMOUNT," + db_stg_interest_amount + "," + db_interest_amount + ",Fail";
                                                section2_list_results.add(stg_interest_amount);
                                            }*/
              /* To Be reviewed            if (db_stg_interest_currency_code.equals(db_interest_currency_code)) {
                                                String stg_interest_currency_code = ",INTEREST_CURRENCY_CODE," + db_stg_interest_currency_code + "," + db_interest_currency_code + ",Pass";
                                                section2_list_results.add(stg_interest_currency_code);
                                            } else {
                                                String stg_interest_currency_code = ",INTEREST_CURRENCY_CODE," + db_stg_interest_currency_code + "," + db_interest_currency_code + ",Fail";
                                                section2_list_results.add(stg_interest_currency_code);
                                            }   To Be reviewed */

                                            /*if (db_tax_deductible != null) {
                                                if (db_stg_tax_deductible.equals(db_tax_deductible)) {
                                                    String stg_tax_deductible = ",TAX_DEDUCTIBLE," + db_stg_tax_deductible + "," + db_tax_deductible + ",Pass";
                                                    section2_list_results.add(stg_tax_deductible);
                                                } else {
                                                    String stg_tax_deductible = ",TAX_DEDUCTIBLE," + db_stg_tax_deductible + "," + db_tax_deductible + ",Fail";
                                                    section2_list_results.add(stg_tax_deductible);
                                                }
                                            }*/
                                            if (db_stg_currency_amount.equals(db_currency_amount)) {
                                                String stg_currency_amount = ",CURRENCY_AMOUNT," + db_stg_currency_amount + "," + db_currency_amount + ",Pass";
                                                section2_list_results.add(stg_currency_amount);
                                            } else {
                                                String stg_currency_amount = ",CURRENCY_AMOUNT," + db_stg_currency_amount + "," + db_currency_amount + ",Fail";
                                                section2_list_results.add(stg_currency_amount);
                                            }


                                            if (db_stg_credit_ind.equals(db_credit_ind)) {
                                                String stg_credit_ind = ",CREDIT_IND," + db_stg_credit_ind + "," + db_credit_ind + ",Pass";
                                                section2_list_results.add(stg_credit_ind);
                                            } else {
                                                String stg_credit_ind = ",CREDIT_IND," + db_stg_credit_ind + "," + db_credit_ind + ",Fail";
                                                section2_list_results.add(stg_credit_ind);
                                            }

              /* To be reviewed             if (db_stg_event_code.equals("EVO_BC_EVENT_CODE")) {
                                                String stg_event_code = ",EVENT_CODE," + db_stg_event_code + "," + "EVO_BC_EVENT_CODE" + ",Pass";
                                                section2_list_results.add(stg_event_code);
                                            } else {
                                                String stg_event_code = ",EVENT_CODE," + db_stg_event_code + "," + "EVO_BC_EVENT_CODE" + ",Fail";
                                                section2_list_results.add(stg_event_code);
                                            }    To be reviewed */

             /* To be reviewed                               if (db_stg_event_type_code.equals("B4C ENTITY")) {
                                                String stg_event_type_code = ",EVENT_TYPE_CODE," + db_stg_event_type_code + "," + "B4C ENTITY" + ",Pass";
                                                section2_list_results.add(stg_event_type_code);
                                            } else {
                                                String stg_event_type_code = ",EVENT_TYPE_CODE," + db_stg_event_type_code + "," + "B4C ENTITY" + ",Fail";
                                                section2_list_results.add(stg_event_type_code);
                                            }   To be reviewed */

                                            //========================== LookUp Validation ==========================
                                            //------------------------ UnderWriter Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_underwriter + "' and LOOKUP_TYPE = 'UNDERWRITER' and System = 'AQUA'  and PATTERN = 'GLBilling'");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_underWriter_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_underWriter_meaning.equals("null")) {
                                                String lookup_underWriter_meaning = ",UNDERWRITER LOOKUP," + "LookUp value not found" + "," + db_stg_underwriter + ",Fail";
                                                section2_list_results.add(lookup_underWriter_meaning);
                                            } else if (db_lookup_underWriter_meaning != null) {
                                                if (db_lookup_underWriter_meaning.equals(db_stg_underwriter)) {
                                                    String lookup_underWriter_meaning = ",UNDERWRITER LOOKUP," + db_lookup_underWriter_meaning + "," + db_stg_underwriter + ",Pass";
                                                    section2_list_results.add(lookup_underWriter_meaning);
                                                } else {
                                                    String lookup_underWriter_meaning = ",UNDERWRITER LOOKUP," + db_lookup_underWriter_meaning + "," + db_stg_underwriter + ",Fail";
                                                    section2_list_results.add(lookup_underWriter_meaning);
                                                }
                                            }

                                            //------------------------ PRODUCT_TYPE Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_product_Type + "' and LOOKUP_TYPE = 'PRODUCT_TYPE' and System = 'AQUA'  and PATTERN = 'GLBilling'");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_product_type_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_product_type_meaning.equals("null")) {
                                                String lookup_product_type_meaning = ",PRODUCT_TYPE LOOKUP," + "LookUp value not found" + "," + db_stg_product_type + ",Fail";
                                                section2_list_results.add(lookup_product_type_meaning);
                                            } else if (db_lookup_product_type_meaning != null) {
                                                if (db_lookup_product_type_meaning.equals(db_stg_product_type)) {
                                                    String lookup_product_type_meaning = ",PRODUCT_TYPE LOOKUP," + db_lookup_product_type_meaning + "," + db_stg_product_type + ",Pass";
                                                    section2_list_results.add(lookup_product_type_meaning);
                                                } else {
                                                    String lookup_product_type_meaning = ",PRODUCT_TYPE LOOKUP," + db_lookup_product_type_meaning + "," + db_stg_product_type + ",Fail";
                                                    section2_list_results.add(lookup_product_type_meaning);
                                                }
                                            }

                                            //------------------------ LINE_OF_BUSINESS Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_line_of_business + "' and LOOKUP_TYPE = 'LINE_OF_BUSINESS' and System = 'AQUA' and pattern = 'GLBilling'");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_line_of_business_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_line_of_business_meaning.equals("null")) {
                                                String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS LOOKUP," + "LookUp value not found" + "," + db_stg_line_of_business + ",Fail";
                                                section2_list_results.add(lookup_line_of_business_meaning);
                                            } else if (db_lookup_line_of_business_meaning != null) {
                                                if (db_lookup_line_of_business_meaning.equals(db_stg_line_of_business)) {
                                                    String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS LOOKUP," + db_lookup_line_of_business_meaning + "," + db_stg_line_of_business + ",Pass";
                                                    section2_list_results.add(lookup_line_of_business_meaning);
                                                } else {
                                                    String lookup_line_of_business_meaning = ",LINE_OF_BUSINESS LOOKUP," + db_lookup_line_of_business_meaning + "," + db_stg_line_of_business + ",Fail";
                                                    section2_list_results.add(lookup_line_of_business_meaning);
                                                }
                                            }
											
											//------------------------ CREDIT_IND Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_credit_ind + "' and LOOKUP_TYPE = 'CREDIT_INDICATOR' and System = 'AQUA' and pattern = 'GLBilling'");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_credit_ind_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_credit_ind_meaning.equals("null")) {
                                                String lookup_credit_ind_meaning = ",CREDIT_INDICATOR LOOKUP," + "LookUp value not found" + "," + db_stg_credit_ind + ",Fail";
                                                section2_list_results.add(lookup_credit_ind_meaning);
                                            } else if (db_lookup_credit_ind_meaning != null) {
                                                if (db_lookup_credit_ind_meaning.equals(db_stg_credit_ind)) {
                                                    String lookup_credit_ind_meaning = ",CREDIT_INDICATOR LOOKUP," + db_lookup_credit_ind_meaning + "," + db_stg_credit_ind + ",Pass";
                                                    section2_list_results.add(lookup_credit_ind_meaning);
                                                } else {
                                                    String lookup_credit_ind_meaning = ",CREDIT_INDICATOR LOOKUP," + db_lookup_credit_ind_meaning + "," + db_stg_credit_ind + ",Fail";
                                                    section2_list_results.add(lookup_credit_ind_meaning);
                                                }
                                            }
											
									/*		//------------------------ InitialChargeTxn_TrxSubtype Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_initialchargetxn_trxsubtype + "' and LOOKUP_TYPE = 'InitialChargeTxn_TrxSubtype' and System = 'AQUA' and pattern = 'GLBilling' ");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_initialchargetxn_trxsubtype_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_initialchargetxn_trxsubtype_meaning.equals("null")) {
                                                String lookup_initialchargetxn_trxsubtype_meaning = ",InitialChargeTxn_TrxSubtype LOOKUP," + "LookUp value not found" + "," + db_stg_initialchargetxn_trxsubtype + ",Fail";
                                                section2_list_results.add(lookup_initialchargetxn_trxsubtype_meaning);
                                            } else if (db_lookup_initialchargetxn_trxsubtype_meaning != null) {
                                                if (db_lookup_initialchargetxn_trxsubtype_meaning.equals(db_stg_initialchargetxn_trxsubtype)) {
                                                    String lookup_initialchargetxn_trxsubtype_meaning = ",InitialChargeTxn_TrxSubtype LOOKUP," + db_lookup_initialchargetxn_trxsubtype_meaning + "," + db_stg_initialchargetxn_trxsubtype + ",Pass";
                                                    section2_list_results.add(lookup_initialchargetxn_trxsubtype_meaning);
                                                } else {
                                                    String lookup_initialchargetxn_trxsubtype_meaning = ",InitialChargeTxn_TrxSubtype LOOKUP," + db_lookup_initialchargetxn_trxsubtype_meaning + "," + db_stg_initialchargetxn_trxsubtype + ",Fail";
                                                    section2_list_results.add(lookup_initialchargetxn_trxsubtype_meaning);
                                                }
                                            }
											
											//------------------------ InitialChargeTxn_Cross_Ref_RC Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_initialchargetxn_cross_ref_rc + "' and LOOKUP_TYPE = 'InitialChargeTxn_Cross_Ref_RC' and System = 'AQUA' and pattern = 'GLBilling' ");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_initialchargetxn_cross_ref_rc_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_initialchargetxn_cross_ref_rc_meaning.equals("null")) {
                                                String lookup_initialchargetxn_cross_ref_rc_meaning = ",InitialChargeTxn_Cross_Ref_RC LOOKUP," + "LookUp value not found" + "," + db_stg_initialchargetxn_cross_ref_rc + ",Fail";
                                                section2_list_results.add(lookup_initialchargetxn_cross_ref_rc_meaning);
                                            } else if (db_lookup_initialchargetxn_cross_ref_rc_meaning != null) {
                                                if (db_lookup_initialchargetxn_cross_ref_rc_meaning.equals(db_stg_initialchargetxn_cross_ref_rc)) {
                                                    String lookup_initialchargetxn_cross_ref_rc_meaning = ",InitialChargeTxn_Cross_Ref_RC LOOKUP," + db_lookup_initialchargetxn_cross_ref_rc_meaning + "," + db_stg_initialchargetxn_cross_ref_rc + ",Pass";
                                                    section2_list_results.add(lookup_initialchargetxn_cross_ref_rc_meaning);
                                                } else {
                                                    String lookup_initialchargetxn_cross_ref_rc_meaning = ",InitialChargeTxn_Cross_Ref_RC LOOKUP," + db_lookup_initialchargetxn_cross_ref_rc_meaning + "," + db_stg_initialchargetxn_cross_ref_rc + ",Fail";
                                                    section2_list_results.add(lookup_initialchargetxn_cross_ref_rc_meaning);
                                                }
                                            }   */
											
											//------------------------ TRANSACTION_DATE Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE TRUNC(TRANSACTION_DATE) = TRUNC('" + db_transaction_date + "') and LOOKUP_TYPE = 'TRANSACTION_DATE' and System = 'AQUA' and pattern = 'GLBilling'");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_transaction_date_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_transaction_date_meaning.equals("null")) {
                                                String lookup_transaction_date_meaning = ",TRANSACTION_DATE LOOKUP," + "LookUp value not found" + "," + db_stg_transaction_date + ",Fail";
                                                section2_list_results.add(lookup_transaction_date_meaning);
                                            } else if (db_lookup_transaction_date_meaning != null) {
                                                if (db_lookup_transaction_date_meaning.equals(db_stg_transaction_date)) {
                                                    String lookup_transaction_date_meaning = ",TRANSACTION_DATE LOOKUP," + db_lookup_transaction_date_meaning + "," + db_stg_transaction_date + ",Pass";
                                                    section2_list_results.add(lookup_transaction_date_meaning);
                                                } else {
                                                    String lookup_transaction_date_meaning = ",TRANSACTION_DATE LOOKUP," + db_lookup_transaction_date_meaning + "," + db_stg_transaction_date + ",Fail";
                                                    section2_list_results.add(lookup_transaction_date_meaning);
                                                }
                                            }
											
											//------------------------ REVERSAL_INDICATOR Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE NVL(REVERSAL_INDICATOR) = NVL('" + db_reversal_indicator + "') and LOOKUP_TYPE = 'REVERSAL_INDICATOR' and System = 'AQUA' and pattern = 'GLBilling'");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_reversal_indicator_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_reversal_indicator_meaning.equals("null")) {
                                                String lookup_reversal_indicator_meaning = ",REVERSAL_INDICATOR LOOKUP," + "LookUp value not found" + "," + db_stg_reversal_indicator + ",Fail";
                                                section2_list_results.add(lookup_reversal_indicator_meaning);
                                            } else if (db_lookup_reversal_indicator_meaning != null) {
                                                if (db_lookup_reversal_indicator_meaning.equals(db_stg_reversal_indicator)) {
                                                    String lookup_reversal_indicator_meaning = ",REVERSAL_INDICATOR LOOKUP," + db_lookup_reversal_indicator_meaning + "," + db_stg_reversal_indicator + ",Pass";
                                                    section2_list_results.add(lookup_reversal_indicator_meaning);
                                                } else {
                                                    String lookup_reversal_indicator_meaning = ",REVERSAL_INDICATOR LOOKUP," + db_lookup_reversal_indicator_meaning + "," + db_stg_reversal_indicator + ",Fail";
                                                    section2_list_results.add(lookup_reversal_indicator_meaning);
                                                }
                                            }

                                            //------------------------ TRANSACTION_SUBTYPE Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_transaction_sub_type + "' and LOOKUP_TYPE = 'TRANSACTION_SUBTYPE' and System = 'AQUA' and pattern = 'GLBilling' ");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_transaction_sub_type_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_transaction_sub_type_meaning.equals("null")) {
                                                String lookup_transaction_sub_type_meaning = ",TRANSACTION_SUBTYPE LOOKUP," + "LookUp value not found" + "," + db_stg_transaction_sub_type + ",Fail";
                                                section2_list_results.add(lookup_transaction_sub_type_meaning);
                                            } else if (db_lookup_transaction_sub_type_meaning != null) {
                                                if (db_lookup_transaction_sub_type_meaning.equals(db_stg_transaction_sub_type)) {
                                                    String lookup_transaction_sub_type_meaning = ",TRANSACTION_SUBTYPE LOOKUP," + db_lookup_transaction_sub_type_meaning + "," + db_stg_transaction_sub_type + ",Pass";
                                                    section2_list_results.add(lookup_transaction_sub_type_meaning);
                                                } else {
                                                    String lookup_transaction_sub_type_meaning = ",TRANSACTION_SUBTYPE LOOKUP," + db_lookup_transaction_sub_type_meaning + "," + db_stg_transaction_sub_type + ",Fail";
                                                    section2_list_results.add(lookup_transaction_sub_type_meaning);
                                                }
                                            }

                                            //------------------------ TRANSACTION_REASON Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_transaction_reason + "' and LOOKUP_TYPE = 'TRANSACTION_REASON' and System = 'AQUA' and pattern = 'GLBilling'");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_transaction_reason_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_transaction_reason_meaning.equals("null")) {
                                                String lookup_transaction_reason_meaning = ",TRANSACTION_REASON LOOKUP," + "LookUp value not found" + "," + db_stg_transaction_reason + ",Fail";
                                                section2_list_results.add(lookup_transaction_reason_meaning);
                                            } else if (db_lookup_transaction_reason_meaning != null) {
                                                if (db_lookup_transaction_reason_meaning.equals(db_stg_transaction_reason)) {
                                                    String lookup_transaction_reason_meaning = ",TRANSACTION_REASON LOOKUP," + db_lookup_transaction_reason_meaning + "," + db_stg_transaction_reason + ",Pass";
                                                    section2_list_results.add(lookup_transaction_reason_meaning);
                                                } else {
                                                    String lookup_transaction_reason_meaning = ",TRANSACTION_REASON LOOKUP," + db_lookup_transaction_reason_meaning + "," + db_stg_transaction_reason + ",Fail";
                                                    section2_list_results.add(lookup_transaction_reason_meaning);
                                                }
                                            }

                                            //------------------------ PAYMENT_METHOD Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE UPPER(LOOKUP_CODE) = UPPER('" + db_payment_method + "') and LOOKUP_TYPE = 'PAYMENT_METHOD' and System = 'AQUA' and pattern = 'GLBilling'");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_payment_method_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_payment_method_meaning.equals("null")) {
                                                String lookup_payment_method_meaning = ",PAYMENT_METHOD LOOKUP," + "LookUp value not found" + "," + db_stg_payment_method + ",Fail";
                                                section2_list_results.add(lookup_payment_method_meaning);
                                            } else if (db_lookup_payment_method_meaning != null) {
                                                if (db_lookup_payment_method_meaning.equals(db_stg_payment_method)) {
                                                    String lookup_payment_method_meaning = ",PAYMENT_METHOD LOOKUP," + db_lookup_payment_method_meaning + "," + db_stg_payment_method + ",Pass";
                                                    section2_list_results.add(lookup_payment_method_meaning);
                                                } else {
                                                    String lookup_payment_method_meaning = ",PAYMENT_METHOD LOOKUP," + db_lookup_payment_method_meaning + "," + db_stg_payment_method + ",Fail";
                                                    section2_list_results.add(lookup_payment_method_meaning);
                                                }
                                            }

                                       /*     //------------------------ CARD_TYPE Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_card_type + "' and LOOKUP_TYPE = 'CARD_TYPE' and System = 'AQUA' and pattern = 'GLBilling'");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_card_type_meaning = SQLResultset_fsh.getString("MEANING");
                                            }
                                            if (xml_payment_method.equalsIgnoreCase("6")) {
                                                if (db_lookup_card_type_meaning.equals("null")) {
                                                    String lookup_card_type_meaning = ",CARD_TYPE LOOKUP," + "LookUp value not found" + "," + db_stg_card_type + ",Fail";
                                                    section2_list_results.add(lookup_card_type_meaning);
                                                } else if (db_lookup_card_type_meaning != null) {
                                                    if (db_lookup_card_type_meaning.equals(db_stg_card_type)) {
                                                        String lookup_card_type_meaning = ",CARD_TYPE LOOKUP," + db_lookup_card_type_meaning + "," + db_stg_card_type + ",Pass";
                                                        section2_list_results.add(lookup_card_type_meaning);
                                                    } else {
                                                        String lookup_card_type_meaning = ",CARD_TYPE LOOKUP," + db_lookup_card_type_meaning + "," + db_stg_card_type + ",Fail";
                                                        section2_list_results.add(lookup_card_type_meaning);
                                                    }
                                                }
                                            }  */

                                            //------------------------ CHANNEL Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_channel + "' and LOOKUP_TYPE = 'CHANNEL' and System = 'AQUA' and pattern = 'GLBilling'");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_channel_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_channel_meaning.equals("null")) {
                                                String lookup_channel_meaning = ",CHANNEL LOOKUP," + "LookUp value not found" + "," + db_stg_channel + ",Fail";
                                                section2_list_results.add(lookup_channel_meaning);
                                            } else if (db_lookup_channel_meaning != null) {
                                                if (db_lookup_channel_meaning.equals(db_stg_channel)) {
                                                    String lookup_channel_meaning = ",CHANNEL LOOKUP," + db_lookup_channel_meaning + "," + db_stg_channel + ",Pass";
                                                    section2_list_results.add(lookup_channel_meaning);
                                                } else {
                                                    String lookup_channel_meaning = ",CHANNEL LOOKUP," + db_lookup_channel_meaning + "," + db_stg_channel + ",Fail";
                                                    section2_list_results.add(lookup_channel_meaning);
                                                }
                                            }

                                            //------------------------ CURRENCY_CODE Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE UPPER(LOOKUP_CODE) = UPPER('" + db_currency_code + "') and LOOKUP_TYPE = 'CURRENCY_CODE' and System = 'AQUA' and pattern = 'GLBilling'");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_currency_code_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_currency_code_meaning.equals("null")) {
                                                String lookup_currency_code_meaning = ",CURRENCY_CODE LOOKUP," + "LookUp value not found" + "," + db_stg_currency_code + ",Fail";
                                                section2_list_results.add(lookup_currency_code_meaning);
                                            } else if (db_lookup_currency_code_meaning != null) {
                                                if (db_lookup_currency_code_meaning.equals(db_stg_currency_code)) {
                                                    String lookup_currency_code_meaning = ",CURRENCY_CODE LOOKUP," + db_lookup_currency_code_meaning + "," + db_stg_currency_code + ",Pass";
                                                    section2_list_results.add(lookup_currency_code_meaning);
                                                } else {
                                                    String lookup_currency_code_meaning = ",CURRENCY_CODE LOOKUP," + db_lookup_currency_code_meaning + "," + db_stg_currency_code + ",Fail";
                                                    section2_list_results.add(lookup_currency_code_meaning);
                                                }
                                            }
											
											//------------------------ BRAND Validation -----------------
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE RIGHT(LOOKUP_CODE) = RIGHT('" + db_brand + "') and LOOKUP_TYPE = 'BRAND' and System = 'AQUA' and pattern = 'GLBilling'");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_brand_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_brand_meaning.equals("null")) {
                                                String lookup_brand_meaning = ",BRAND LOOKUP," + "LookUp value not found" + "," + db_stg_brand + ",Fail";
                                                section2_list_results.add(lookup_brand_meaning);
                                            } else if (db_lookup_brand_meaning != null) {
                                                if (db_lookup_brand_meaning.equals(db_stg_brand)) {
                                                    String lookup_brand_meaning = ",BRAND LOOKUP," + db_lookup_brand_meaning + "," + db_stg_brand + ",Pass";
                                                    section2_list_results.add(lookup_brand_meaning);
                                                } else {
                                                    String lookup_brand_meaning = ",BRAND LOOKUP," + db_lookup_brand_meaning + "," + db_stg_brand + ",Fail";
                                                    section2_list_results.add(lookup_brand_meaning);
                                                }
                                            }

                                            //------------------------ PAYMENT_TRANSACTION_TYPE_ID Validation -----------------
                                            /*SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT Meaning FROM DLG_FSH_LOOKUP_VALUES WHERE LOOKUP_CODE = '" + db_payment_transaction_type_id + "' and LOOKUP_TYPE = 'PAYMENT_TRANSACTION_TYPE_ID' and System = 'SSPX' and pattern = 'GLBilling'");
                                            while (SQLResultset_fsh.next()) {
                                                db_lookup_payment_transaction_type_id_meaning = SQLResultset_fsh.getString("MEANING");
                                            }

                                            if (db_lookup_payment_transaction_type_id_meaning.equals("null")) {
                                                String lookup_payment_transaction_type_id_meaning = ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP," + "LookUp value not found" + "," + db_stg_payment_transaction_type_id + ",Fail";
                                                section2_list_results.add(lookup_payment_transaction_type_id_meaning);
                                            } else if (db_lookup_payment_transaction_type_id_meaning != null) {
                                                if (db_lookup_payment_transaction_type_id_meaning.equals(db_stg_payment_transaction_type_id)) {
                                                    String lookup_payment_transaction_type_id_meaning = ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP," + db_lookup_payment_transaction_type_id_meaning + "," + db_stg_payment_transaction_type_id + ",Pass";
                                                    section2_list_results.add(lookup_payment_transaction_type_id_meaning);
                                                } else {
                                                    String lookup_payment_transaction_type_id_meaning = ",PAYMENT_TRANSACTION_TYPE_ID LOOKUP," + db_lookup_payment_transaction_type_id_meaning + "," + db_stg_payment_transaction_type_id + ",Fail";
                                                    section2_list_results.add(lookup_payment_transaction_type_id_meaning);
                                                }
                                            }
                                            String Record_status = "Actual Record Status in FSH : " + db_stg_status;
                                            section2_list_results.add(Record_status);
                                        }
                                    }
                                }
                            }*/

                                            //--------------------------------- Staging to Staging Aggregate Validations ---------------------------------//
                                            //----------------------------------Count Validations---------------------------------------------------------//
                                            boolean sec3flag = true;
                                            String db_STG_ACTL_RCDS = null;
                                            Integer db_STG_ACTL_RCDS1 = 0;
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT COUNT(HEADER_ID) as STG_ACTL_RCDS FROM DLG_FSH_STG_COMM_BCCC_HDR WHERE FILE_NAME = '" + file_list + "'");
                                            while (SQLResultset_fsh.next()) {
                                                db_STG_ACTL_RCDS = SQLResultset_fsh.getString("STG_ACTL_RCDS");
                                                db_STG_ACTL_RCDS1 = SQLResultset_fsh.getInt("STG_ACTL_RCDS");
                                                System.out.println("Staging count ----" + db_STG_ACTL_RCDS);
                                            }

                                            if (db_STG_ACTL_RCDS1 == 0) {  //--- Zero record validation
                                                sec3flag = false;
                                                String pc_stg_header_line = 1 + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_ACTL_RCDS DB Does not have any records" + "," + "STG_AGG_ACTUAL_HEADER DB Does not have any records" + ",Fail";
                                                section3_list_results.add(pc_stg_header_line);
                                            }
                                            if (sec3flag) {
                                                do {
                                                    SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT COUNT(a.HEADER_ID) as STG_EXP_SUM_HDRS FROM(SELECT HEADER_ID\n" +
                                                            ",row_number() over(partition by SOURCE,UNDERWRITER,BRAND,LINE_OF_BUSINESS,PRODUCT_TYPE,CHANNEL,TRANSACTION_DATE,TRANSACTION_SUB_TYPE,TRANSACTION_REASON\n" +
                                                            ",PAYMENT_METHOD,SUN_NUMBER,BACS_NARRATIVE,MID_NUMBER,CARD_TYPE,CARD_NARRATIVE,REVERSAL_INDICATOR,PAYMENT_TRANSACTION_TYPE_ID,CURRENCY_CODE,EXCHANGE_RATE,EXCHANGE_RATE_TYPE,CREDIT_IND,EVENT_CODE,ENTITY_TYPE_CODE ORDER BY UNDERWRITER\n" +
                                                            ",BRAND,LINE_OF_BUSINESS,PRODUCT_TYPE,CHANNEL,TRANSACTION_DATE,TRANSACTION_SUB_TYPE,TRANSACTION_REASON,PAYMENT_METHOD,SUN_NUMBER,BACS_NARRATIVE,MID_NUMBER,CARD_TYPE\n" +
                                                            ",CARD_NARRATIVE,REVERSAL_INDICATOR,PAYMENT_TRANSACTION_TYPE_ID,CURRENCY_CODE,EXCHANGE_RATE,EXCHANGE_RATE_TYPE,CREDIT_IND,EVENT_CODE,ENTITY_TYPE_CODE) row_1\n" +
                                                            "FROM DLG_FSH_STG_COMM_BCCC_HDR WHERE FILE_NAME = '" + file_list + "')a where a.row_1 = 1");

                                                    while (SQLResultset_fsh.next()) {
                                                        String STG_EXP_SUM_HDRS = SQLResultset_fsh.getString("STG_EXP_SUM_HDRS");
                                                        SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT count(TOH_ID)as STG_AGG_ACTUAL_HEADER FROM DLG_FSH_STG_COMM_BCCC_AGG_HDR WHERE FILE_NAME = '" + file_list + "'");
                                                        while (SQLResultset_fsh.next()) {
                                                            String STG_AGG_ACTUAL_HEADER = SQLResultset_fsh.getString("STG_AGG_ACTUAL_HEADER");
                                                            System.out.println("Staging Aggregate header count ----" + STG_AGG_ACTUAL_HEADER);
                                                            if (db_stg_reversal_indicator.equals("Y")) {
                                                                if (db_STG_ACTL_RCDS.equals(STG_AGG_ACTUAL_HEADER)) {
                                                                    String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + db_STG_ACTL_RCDS + "," + STG_AGG_ACTUAL_HEADER + ",Pass";
                                                                    section3_list_results.add(pc_stg_header_line);
                                                                } else {
                                                                    String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + db_STG_ACTL_RCDS + "," + STG_AGG_ACTUAL_HEADER + ",Fail";
                                                                    section3_list_results.add(pc_stg_header_line);
                                                                }
                                                            } else {
                                                                if (STG_EXP_SUM_HDRS.equals(STG_AGG_ACTUAL_HEADER)) {
                                                                    String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Pass";
                                                                    section3_list_results.add(pc_stg_header_line);
                                                                } else {
                                                                    String pc_stg_header_line = 1 + "," + db_STG_ACTL_RCDS + "," + STG_EXP_SUM_HDRS + "," + STG_AGG_ACTUAL_HEADER + ",Fail";
                                                                    section3_list_results.add(pc_stg_header_line);
                                                                }

                                                            }
                                                        }
                                                    }

                                                } while (SQLResultset_fsh.next());
                                            }

                                            //-------------------------------------------Staging Aggregate and TO Table Validations---------------------------------//
                                            boolean stg_agg_flag = true;
                                            SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT *  from DLG_FSH_STG_COMM_BCC_AGG_HDR  WHERE FILE_NAME = '" + file_list + "'");
                                            if (!SQLResultset_fsh.next()) {
                                                stg_agg_flag = false;
                                                if (db_stg_TOH_id != "null") {
                                                    String stg_agg_toh_id = lookup_map_row + ",TOH_ID," + "STG Table does not have any records. please verify in the Batch Control table" + "," + db_stg_TOH_id + ",Fail";
                                                    section2_list_results.add(stg_agg_toh_id);
                                                    lookup_map_row++;
                                                } else {
                                                    String stg_agg_toh_id = lookup_map_row + ",TOH_ID," + "Staging Table Does not have any records. please verify in the Batch Control table" + "," + "Staging Aggregate table Does not have any records. please verify in the Batch Control table" + ",Fail";
                                                    section2_list_results.add(stg_agg_toh_id);
                                                    lookup_map_row++;
                                                }
                                            }
                                            if (stg_agg_flag) {
                                                Integer to_count = 0;
                                                SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT COUNT(TOH_ID) as COUNT_TOH_ID FROM DLG_FSH_STG_COMM_CC_AGG_HDR WHERE FILE_NAME = '" + file_list + "' ");
                                                while (SQLResultset_fsh.next()) {
                                                    to_count = SQLResultset_fsh.getInt("COUNT_TOH_ID");
                                                }
                                                System.out.println("Count of the record is " + to_count);
                                                ArrayList<String> list_toh = new ArrayList<String>();
                                                SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT TOH_ID FROM DLG_FSH_STG_COMM_CC_AGG_HDR WHERE FILE_NAME = '" + file_list + "' ");
                                                for (int k = 0; k < to_count; k++) {
                                                    while (SQLResultset_fsh.next()) {
                                                        list_toh.add(SQLResultset_fsh.getString("TOH_ID"));
                                                    }
                                                }
                                                for (int k = 0; k < list_toh.size(); k++) {
                                                    SQLResultset_fsh = SQLstmt_fsh.executeQuery("SELECT * FROM DLG_FSH_STG_COMM_BCC_AGG_HDR WHERE TOH_ID = '" + list_toh.get(k) + "' ");
                                                    while (SQLResultset_fsh.next()) {
                                                        String agg_toh_id = SQLResultset_fsh.getString("TOH_ID");
                                                        String agg_source = SQLResultset_fsh.getString("SOURCE");
                                                        String agg_account_number = SQLResultset_fsh.getString("ACCOUNT_NUMBER");
                                                        String agg_policy_number = SQLResultset_fsh.getString("POLICY_NUMBER");
                                                        String agg_underwriter = SQLResultset_fsh.getString("UNDERWRITER");
                                                        String agg_brand = SQLResultset_fsh.getString("BRAND");
                                                        String agg_line_of_business = SQLResultset_fsh.getString("LINE_OF_BUSINESS");
                                                        String agg_product_type = SQLResultset_fsh.getString("PRODUCT_TYPE");
                                                        String agg_channel = SQLResultset_fsh.getString("CHANNEL");
                                                        String agg_transaction_reference = SQLResultset_fsh.getString("TRANSACTION_REFERENCE");
                                                        String agg_transaction_date = SQLResultset_fsh.getString("TRANSACTION_DATE");
                                                        String agg_transaction_subtype = SQLResultset_fsh.getString("TRANSACTION_SUB_TYPE");
                                                        String agg_transaction_reason = SQLResultset_fsh.getString("TRANSACTION_REASON");
                                                        String agg_payment_method = SQLResultset_fsh.getString("PAYMENT_METHOD");
                                                        String agg_sun_number = SQLResultset_fsh.getString("SUN_NUMBER");
                                                        String agg_ddi_reference = SQLResultset_fsh.getString("DDI_REFERENCE");
                                                        String agg_bacs_narrative = SQLResultset_fsh.getString("BACS_NARRATIVE");	
                                                        String agg_mid_number = SQLResultset_fsh.getString("MID_NUMBER");
                                                        String agg_card_type = SQLResultset_fsh.getString("CARD_TYPE");
                                                        String agg_order_number = SQLResultset_fsh.getString("ORDER_NUMBER");
														String agg_reversal_indicator = SQLResultset_fsh.getString("REVERSAL_INDICATOR");
														String agg_currency_code = SQLResultset_fsh.getString("CURRENCY_CODE");
														String agg_exchange_rate = SQLResultset_fsh.getString("EXCHANGE_RATE");
														String agg_exchange_rate_type = SQLResultset_fsh.getString("EXCHANGE_RATE_TYPE");
                                                        String agg_base_currency_amount = SQLResultset_fsh.getString("BASE_CURRENCY_AMOUNT");
														String agg_credit_ind = SQLResultset_fsh.getString("CREDIT_IND");
														String agg_currency_amount = SQLResultset_fsh.getString("CURRENCY_AMOUNT");
														String agg_batch_fkey = SQLResultset_fsh.getString("BATCH_FKEY");
														String agg_base_interest_amount = SQLResultset_fsh.getString("BASE_INTEREST_AMOUNT");
														String agg_cheque_number = SQLResultset_fsh.getString("CHEQUE_NUMBER");
														String agg_claim_number = SQLResultset_fsh.getString("CLAIM_NUMBER");
														String agg_interest_amount = SQLResultset_fsh.getString("INTEREST_AMOUNT");
														String agg_interest_currency_code = SQLResultset_fsh.getString("INTEREST_CURRENCY_CODE");
														String agg_pay_in_slip_number = SQLResultset_fsh.getString("PAY_IN_SLIP_NUMBER");
														String agg_payment_transaction_type_id = SQLResultset_fsh.getString("PAYMENT_TRANSACTION_TYPE_ID");
														String agg_file_name = SQLResultset_fsh.getString("FILE_NAME");
														String agg_tax_deductible = SQLResultset_fsh.getString("TAX_DEDUCTIBLE");
                                                        String agg_card_narrative = SQLResultset_fsh.getString("CARD_NARRATIVE");
                                                        String agg_event_code = SQLResultset_fsh.getString("EVENT_CODE");
                                                        String agg_entity_type_code = SQLResultset_fsh.getString("ENTITY_TYPE_CODE");

                                                        boolean TO_table_flag = true;
                                                        SQLResultset_icsi = SQLstmt_isci.executeQuery("SELECT *  from apps.DLG_FSH_TO_CC WHERE TOH_ID = '" + agg_toh_id + "'");

                                                        if (!SQLResultset_icsi.next()) {
                                                            TO_table_flag = false;
                                                            String pc_TO_header_line = TO_table_map_row + ",pc_header_id" + "," + agg_toh_id + "," + "TO table does not have records. please verify Batch control table" + ",Fail";
                                                            section4_list_results.add(pc_TO_header_line);
                                                            TO_table_map_row++;
                                                        }
                                                        if (TO_table_flag) {
                                                            SQLResultset_icsi = SQLstmt_isci.executeQuery("SELECT *  from apps.DLG_FSH_TO_CC WHERE TOH_ID = '" + agg_toh_id + "' and SOURCE='SSPXGLBilling'");
                                                            while (SQLResultset_icsi.next()) {
                                                                String TO_toh_id = SQLResultset_icsi.getString("TOH_ID");
                                                                String TO_source = SQLResultset_icsi.getString("SOURCE");
                                                                String TO_account_number = SQLResultset_icsi.getString("ACCOUNT_NUMBER");
                                                                String TO_policy_number = SQLResultset_icsi.getString("POLICY_NUMBER");
                                                                String TO_underwriter = SQLResultset_icsi.getString("UNDERWRITER");
                                                                String TO_brand = SQLResultset_icsi.getString("BRAND");
                                                                String TO_line_of_business = SQLResultset_icsi.getString("LINE_OF_BUSINESS");
                                                                String TO_product_type = SQLResultset_icsi.getString("PRODUCT_TYPE");
                                                                String TO_channel = SQLResultset_icsi.getString("CHANNEL");
                                                                String TO_transaction_reference = SQLResultset_icsi.getString("TRANSACTION_REFERENCE");
                                                                String TO_transaction_date = SQLResultset_icsi.getString("TRANSACTION_DATE");
                                                                String TO_transaction_subtype = SQLResultset_icsi.getString("TRANSACTION_SUBTYPE");
                                                                String TO_transaction_reason = SQLResultset_icsi.getString("TRANSACTION_REASON");
                                                                String TO_payment_method = SQLResultset_icsi.getString("PAYMENT_METHOD");
                                                                String TO_sun_number = SQLResultset_icsi.getString("SUN_NUMBER");
                                                                String TO_ddi_reference = SQLResultset_icsi.getString("DDI_REFERENCE");
                                                                String TO_bacs_narrative = SQLResultset_icsi.getString("BACS_NARRATIVE");
                                                                String TO_mid_number = SQLResultset_icsi.getString("MID_NUMBER");
                                                                String TO_card_type = SQLResultset_icsi.getString("CARD_TYPE");
                                                                String TO_order_number = SQLResultset_icsi.getString("ORDER_NUMBER");
                                                                String TO_card_narrative = SQLResultset_icsi.getString("CARD_NARRATIVE");
                                                                String TO_pay_in_slip_number = SQLResultset_icsi.getString("PAY_IN_SLIP_NUMBER");
                                                                String TO_cheque_number = SQLResultset_icsi.getString("CHEQUE_NUMBER");
                                                                String TO_interest_amount = SQLResultset_icsi.getString("INTEREST_AMOUNT");
                                                                String TO_interest_currency_code = SQLResultset_icsi.getString("INTEREST_CURRENCY_CODE");
                                                                String TO_base_interest_amount = SQLResultset_icsi.getString("BASE_INTEREST_AMOUNT");
                                                                String TO_tax_deductible = SQLResultset_icsi.getString("TAX_DEDUCTIBLE");
                                                                String TO_reversal_indicator = SQLResultset_icsi.getString("REVERSAL_INDICATOR");
                                                                String TO_payment_transaction_type_id = SQLResultset_icsi.getString("PAYMENT_TRANSACTION_TYPE_ID");
                                                                String TO_currency_amount = SQLResultset_icsi.getString("CURRENCY_AMOUNT");
                                                                String TO_currency_code = SQLResultset_icsi.getString("CURRENCY_CODE");
                                                                String TO_exchange_rate = SQLResultset_icsi.getString("EXCHANGE_RATE");
                                                                String TO_exchange_rate_type = SQLResultset_icsi.getString("EXCHANGE_RATE_TYPE");
                                                                String TO_base_currency_amount = SQLResultset_icsi.getString("BASE_CURRENCY_AMOUNT");
                                                                String TO_credit_ind = SQLResultset_icsi.getString("CREDIT_IND");
                                                                String TO_event_code = SQLResultset_icsi.getString("EVENT_CODE");
                                                                String TO_entity_type_code = SQLResultset_icsi.getString("ENTITY_TYPE_CODE");
                                                                String TO_batch_fkey = SQLResultset_icsi.getString("SOURCE_FILE_HEADER_ID");
                                                                String TO_file_name = SQLResultset_icsi.getString("SOURCE_FILE_NAME");
                                                                String TO_event_id = SQLResultset_icsi.getString("EVENT_ID");
                                                                String TO_event_date = SQLResultset_icsi.getString("EVENT_DATE");
                                                                String TO_bcp_req_id = SQLResultset_icsi.getString("BCP_REQ_ID");

                                                                //------------ TOH_ID validation ----------------------
                                                                if (agg_toh_id.equals(TO_toh_id)) {
                                                                    String bc_TO_toh_id = TO_table_map_row + ",TOH_ID" + "," + TO_toh_id + "," + agg_toh_id + ",Pass";
                                                                    section4_list_results.add(bc_TO_toh_id);
                                                                    TO_table_map_row++;
                                                                } else {
                                                                    String bc_TO_toh_id = TO_table_map_row + ",TOH_ID" + "," + TO_toh_id + "," + agg_toh_id + ",Fail";
                                                                    section4_list_results.add(bc_TO_toh_id);
                                                                    TO_table_map_row++;
                                                                }
                                                                //------------ SOURCE validation ----------------------
                                                                if (agg_source.equals(TO_source)) {
                                                                    String bc_to_source = ",SOURCE" + "," + TO_source + "," + agg_source + ",Pass";
                                                                    section4_list_results.add(bc_to_source);
                                                                } else {
                                                                    String bc_to_source = ",SOURCE" + "," + TO_source + "," + agg_source + ",Fail";
                                                                    section4_list_results.add(bc_to_source);
                                                                }

                                                                //-------------- Validate ACCOUNT_NUMBER ---------------------------
                                                                if (agg_account_number.equals(TO_account_number)) {
                                                                    String bc_account_number = ",ACCOUNT_NUMBER," + TO_account_number + "," + agg_account_number + ",Pass";
                                                                    section4_list_results.add(bc_account_number);
                                                                } else {
                                                                    String bc_account_number = ",ACCOUNT_NUMBER," + TO_account_number + "," + agg_account_number + ",Fail";
                                                                    section4_list_results.add(bc_account_number);
                                                                }

                                                                //-------------- Validate POLICY_NUMBER ---------------------------
                                                                if (agg_policy_number.equals(TO_policy_number)) {
                                                                    String bc_policy_number = ",POLICY_NUMBER," + TO_policy_number + "," + agg_policy_number + ",Pass";
                                                                    section4_list_results.add(bc_policy_number);
                                                                } else {
                                                                    String bc_policy_number = ",POLICY_NUMBER," + TO_policy_number + "," + agg_policy_number + ",Fail";
                                                                    section4_list_results.add(bc_policy_number);
                                                                }


                                                                //------------ UNDERWRITER validation ----------------------
                                                                if (agg_underwriter.equals(TO_underwriter)) {
                                                                    String bc_to_underwriter = ",UNDERWRITER" + "," + TO_underwriter + "," + agg_underwriter + ",Pass";
                                                                    section4_list_results.add(bc_to_underwriter);
                                                                } else {
                                                                    String bc_to_underwriter = ",UNDERWRITER" + "," + TO_underwriter + "," + agg_underwriter + ",Fail";
                                                                    section4_list_results.add(bc_to_underwriter);
                                                                }

                                                                //------------ BRAND validation ----------------------
                                                                if (agg_brand.equals(TO_brand)) {
                                                                    String bc_to_brand = ",BRAND" + "," + TO_brand + "," + agg_brand + ",Pass";
                                                                    section4_list_results.add(bc_to_brand);
                                                                } else {
                                                                    String bc_to_brand = ",BRAND" + "," + TO_brand + "," + agg_brand + ",Fail";
                                                                    section4_list_results.add(bc_to_brand);
                                                                }

                                                                //------------ LINE_OF_BUSINESS validation ----------------------
                                                                if (agg_line_of_business.equals(TO_line_of_business)) {
                                                                    String bc_to_line_of_business = ",LINE_OF_BUSINESS" + "," + TO_line_of_business + "," + agg_line_of_business + ",Pass";
                                                                    section4_list_results.add(bc_to_line_of_business);
                                                                } else {
                                                                    String bc_to_line_of_business = ",LINE_OF_BUSINESS" + "," + TO_line_of_business + "," + agg_line_of_business + ",Fail";
                                                                    section4_list_results.add(bc_to_line_of_business);
                                                                }

                                                                //------------ PRODUCT_TYPE validation ----------------------
                                                                if (agg_product_type.equals(TO_product_type)) {
                                                                    String bc_to_product_type = ",PRODUCT_TYPE" + "," + TO_product_type + "," + agg_product_type + ",Pass";
                                                                    section4_list_results.add(bc_to_product_type);
                                                                } else {
                                                                    String bc_to_product_type = ",PRODUCT_TYPE" + "," + TO_product_type + "," + agg_product_type + ",Fail";
                                                                    section4_list_results.add(bc_to_product_type);
                                                                }

                                                                //------------ CHANNEL validation ----------------------
                                                                if (agg_channel.equals(TO_channel)) {
                                                                    String pc_to_channel = ",CHANNEL" + "," + TO_channel + "," + agg_channel + ",Pass";
                                                                    section4_list_results.add(pc_to_channel);
                                                                } else {
                                                                    String pc_to_channel = ",CHANNEL" + "," + TO_channel + "," + agg_channel + ",Fail";
                                                                    section4_list_results.add(pc_to_channel);
                                                                }

                                                                //------------ Transaction_reference validation ----------------------
                                                                if (agg_transaction_reference.equals(TO_transaction_reference)) {
                                                                    String bc_transaction_reference = ",TRANSACTION REFERENCE" + "," + TO_transaction_reference + "," + agg_transaction_reference + ",Pass";
                                                                    section4_list_results.add(bc_transaction_reference);
                                                                } else {
                                                                    String bc_transaction_reference = ",TRANSACTION REFERENCE" + "," + TO_transaction_reference + "," + agg_transaction_reference + ",Fail";
                                                                    section4_list_results.add(bc_transaction_reference);
                                                                }

                                                                //------------ Transaction_date validation ----------------------
                                                                if (agg_transaction_date.equals(TO_transaction_date)) {
                                                                    String bc_transaction_date = ",TRANSACTION_DATE" + "," + TO_transaction_date + "," + agg_transaction_date + ",Pass";
                                                                    section4_list_results.add(bc_transaction_date);
                                                                } else {
                                                                    String bc_transaction_date = ",TRANSACTION_DATE" + "," + TO_transaction_date + "," + agg_transaction_date + ",Fail";
                                                                    section4_list_results.add(bc_transaction_date);
                                                                }

                                                                //------------ TRANSACTION_SUBTYPE validation ----------------------
                                                                if (agg_transaction_subtype.equals(TO_transaction_subtype)) {
                                                                    String bc_transaction_subtype = ",TRANSACTION_SUBTYPE" + "," + TO_transaction_subtype + "," + agg_transaction_subtype + ",Pass";
                                                                    section4_list_results.add(bc_transaction_subtype);
                                                                } else {
                                                                    String bc_transaction_subtype = ",TRANSACTION_SUBTYPE" + "," + TO_transaction_subtype + "," + agg_transaction_subtype + ",Fail";
                                                                    section4_list_results.add(bc_transaction_subtype);
                                                                }

                                                                //------------ Transaction_reason validation ----------------------
                                                                if (agg_transaction_reason.equals(TO_transaction_reason)) {
                                                                    String bc_transaction_reason = ",TRANSACTION_REASON" + "," + TO_transaction_reason + "," + agg_transaction_reason + ",Pass";
                                                                    section4_list_results.add(bc_transaction_reason);
                                                                } else {
                                                                    String bc_transaction_reason = ",TRANSACTION_REASON" + "," + TO_transaction_reason + "," + agg_transaction_reason + ",Fail";
                                                                    section4_list_results.add(bc_transaction_reason);
                                                                }

                                                                //------------ payment_method validation ----------------------
                                                                if (agg_payment_method.equals(TO_payment_method)) {
                                                                    String bc_payment_method = ",PAYMENT_METHOD" + "," + TO_payment_method + "," + agg_payment_method + ",Pass";
                                                                    section4_list_results.add(bc_payment_method);
                                                                } else {
                                                                    String bc_payment_method = ",PAYMENT_METHOD" + "," + TO_payment_method + "," + agg_payment_method + ",Fail";
                                                                    section4_list_results.add(bc_payment_method);
                                                                }

                                                                //------------ sun_number validation ----------------------
                                                                if (agg_sun_number == null || TO_sun_number == null) {
                                                                    if (agg_sun_number == TO_sun_number) {
                                                                        String bc_sun_number = ",SUN_NUMBER" + "," + TO_sun_number + "," + agg_sun_number + ",Pass";
                                                                        section4_list_results.add(bc_sun_number);
                                                                    } else {
                                                                        String bc_sun_number = ",SUN_NUMBER" + "," + TO_sun_number + "," + agg_sun_number + ",Fail";
                                                                        section4_list_results.add(bc_sun_number);
                                                                    }
                                                                } else {
                                                                    if (agg_sun_number.equals(TO_sun_number)) {
                                                                        String bc_sun_number = ",SUN_NUMBER" + "," + TO_sun_number + "," + agg_sun_number + ",Pass";
                                                                        section4_list_results.add(bc_sun_number);
                                                                    } else {
                                                                        String bc_sun_number = ",SUN_NUMBER" + "," + TO_sun_number + "," + agg_sun_number + ",Fail";
                                                                        section4_list_results.add(bc_sun_number);
                                                                    }
                                                                }

                                                                //------------ ddi_reference validation ----------------------
                                                                if (agg_ddi_reference == null || TO_ddi_reference == null) {
                                                                    if (agg_ddi_reference == TO_ddi_reference) {
                                                                        String bc_ddi_reference = ",DDI_REFERENCE" + "," + TO_ddi_reference + "," + agg_ddi_reference + ",Pass";
                                                                        section4_list_results.add(bc_ddi_reference);
                                                                    } else {
                                                                        String bc_ddi_reference = ",DDI_REFERENCE" + "," + TO_ddi_reference + "," + agg_ddi_reference + ",Fail";
                                                                        section4_list_results.add(bc_ddi_reference);
                                                                    }
                                                                } else {
                                                                    if (agg_ddi_reference.equals(TO_ddi_reference)) {
                                                                        String bc_ddi_reference = ",DDI_REFERENCE" + "," + TO_ddi_reference + "," + agg_ddi_reference + ",Pass";
                                                                        section4_list_results.add(bc_ddi_reference);
                                                                    } else {
                                                                        String bc_ddi_reference = ",DDI_REFERENCE" + "," + TO_ddi_reference + "," + agg_ddi_reference + ",Fail";
                                                                        section4_list_results.add(bc_ddi_reference);
                                                                    }
                                                                }

                                                                //------------ bacs_narrative validation ----------------------
                                                                if (agg_bacs_narrative == null || TO_bacs_narrative == null) {
                                                                    if (agg_bacs_narrative == TO_bacs_narrative) {
                                                                        String bc_bacs_narrative = ",BACS_NARRATIVE" + "," + TO_bacs_narrative + "," + agg_bacs_narrative + ",Pass";
                                                                        section4_list_results.add(bc_bacs_narrative);
                                                                    } else {
                                                                        String bc_bacs_narrative = ",BACS_NARRATIVE" + "," + TO_bacs_narrative + "," + agg_bacs_narrative + ",Fail";
                                                                        section4_list_results.add(bc_bacs_narrative);
                                                                    }
                                                                } else {
                                                                    if (agg_bacs_narrative.equals(TO_bacs_narrative)) {
                                                                        String bc_bacs_narrative = ",BACS_NARRATIVE" + "," + TO_bacs_narrative + "," + agg_bacs_narrative + ",Pass";
                                                                        section4_list_results.add(bc_bacs_narrative);
                                                                    } else {
                                                                        String bc_bacs_narrative = ",BACS_NARRATIVE" + "," + TO_bacs_narrative + "," + agg_bacs_narrative + ",Fail";
                                                                        section4_list_results.add(bc_bacs_narrative);
                                                                    }
                                                                }

                                                                //------------mid_number validation ----------------------
                                                                if (agg_mid_number == null || TO_mid_number == null) {
                                                                    if (agg_mid_number == TO_mid_number) {
                                                                        String bc_mid_number = ",MID_NUMBER" + "," + TO_mid_number + "," + agg_mid_number + ",Pass";
                                                                        section4_list_results.add(bc_mid_number);
                                                                    } else {
                                                                        String bc_mid_number = ",MID_NUMBER" + "," + TO_mid_number + "," + agg_mid_number + ",Fail";
                                                                        section4_list_results.add(bc_mid_number);
                                                                    }
                                                                } else {
                                                                    if (agg_mid_number.equals(TO_mid_number)) {
                                                                        String bc_mid_number = ",MID_NUMBER" + "," + TO_mid_number + "," + agg_mid_number + ",Pass";
                                                                        section4_list_results.add(bc_mid_number);
                                                                    } else {
                                                                        String bc_mid_number = ",MID_NUMBER" + "," + TO_mid_number + "," + agg_mid_number + ",Fail";
                                                                        section4_list_results.add(bc_mid_number);
                                                                    }
                                                                }

                                                                //------------ card_type validation ----------------------
                                                                if (agg_card_type == null || TO_card_type == null) {
                                                                    if (agg_card_type == TO_card_type) {
                                                                        String bc_card_type = ",CARD_TYPE" + "," + TO_card_type + "," + agg_card_type + ",Pass";
                                                                        section4_list_results.add(bc_card_type);
                                                                    } else {
                                                                        String bc_card_type = ",CARD_TYPE" + "," + TO_card_type + "," + agg_card_type + ",Fail";
                                                                        section4_list_results.add(bc_card_type);
                                                                    }
                                                                } else {
                                                                    if (agg_card_type.equals(TO_card_type)) {
                                                                        String bc_card_type = ",CARD_TYPE" + "," + TO_card_type + "," + agg_card_type + ",Pass";
                                                                        section4_list_results.add(bc_card_type);
                                                                    } else {
                                                                        String bc_card_type = ",CARD_TYPE" + "," + TO_card_type + "," + agg_card_type + ",Fail";
                                                                        section4_list_results.add(bc_card_type);
                                                                    }
                                                                }

                                                                //------------ order_number validation ----------------------
                                                                if (agg_order_number == null || TO_order_number == null) {
                                                                    if (agg_order_number == TO_order_number) {
                                                                        String bc_order_number = ",ORDER_NUMBER" + "," + TO_order_number + "," + agg_order_number + ",Pass";
                                                                        section4_list_results.add(bc_order_number);
                                                                    } else {
                                                                        String bc_order_number = ",ORDER_NUMBER" + "," + TO_order_number + "," + agg_order_number + ",Fail";
                                                                        section4_list_results.add(bc_order_number);
                                                                    }
                                                                } else {
                                                                    if (agg_order_number.equals(TO_order_number)) {
                                                                        String bc_order_number = ",ORDER_NUMBER" + "," + TO_order_number + "," + agg_order_number + ",Pass";
                                                                        section4_list_results.add(bc_order_number);
                                                                    } else {
                                                                        String bc_order_number = ",ORDER_NUMBER" + "," + TO_order_number + "," + agg_order_number + ",Fail";
                                                                        section4_list_results.add(bc_order_number);
                                                                    }
                                                                }

                                                                //------------ card_narrative validation ----------------------
                                                                if (agg_card_narrative == null || TO_card_narrative == null) {
                                                                    if (agg_card_narrative == TO_card_narrative) {
                                                                        String bc_card_narrative = ",CARD_NARRATIVE" + "," + TO_card_narrative + "," + agg_card_narrative + ",Pass";
                                                                        section4_list_results.add(bc_card_narrative);
                                                                    } else {
                                                                        String bc_card_narrative = ",CARD_NARRATIVE" + "," + TO_card_narrative + "," + agg_card_narrative + ",Fail";
                                                                        section4_list_results.add(bc_card_narrative);
                                                                    }
                                                                } else {
                                                                    if (agg_card_narrative.equals(TO_card_narrative)) {
                                                                        String bc_card_narrative = ",CARD_NARRATIVE" + "," + TO_card_narrative + "," + agg_card_narrative + ",Pass";
                                                                        section4_list_results.add(bc_card_narrative);
                                                                    } else {
                                                                        String bc_card_narrative = ",CARD_NARRATIVE" + "," + TO_card_narrative + "," + agg_card_narrative + ",Fail";
                                                                        section4_list_results.add(bc_card_narrative);
                                                                    }
                                                                }

                                                                //------------ pay_in_slip_number validation ----------------------
                                                /*if (agg_pay_in_slip_number == null || TO_pay_in_slip_number == null) {
                                                    if (agg_pay_in_slip_number == TO_pay_in_slip_number) {
                                                        String bc_pay_in_slip_number = ",PAY_IN_SLIP_NUMBER" + "," + TO_pay_in_slip_number + "," + agg_pay_in_slip_number + ",Pass";
                                                        section4_list_results.add(bc_pay_in_slip_number);
                                                    } else {
                                                        String bc_pay_in_slip_number = ",PAY_IN_SLIP_NUMBER" + "," + TO_pay_in_slip_number + "," + agg_pay_in_slip_number + ",Fail";
                                                        section4_list_results.add(bc_pay_in_slip_number);
                                                    }
                                                } else {
                                                    if (agg_pay_in_slip_number.equals(TO_pay_in_slip_number)) {
                                                        String bc_pay_in_slip_number = ",PAY_IN_SLIP_NUMBER" + "," + TO_pay_in_slip_number + "," + agg_pay_in_slip_number + ",Pass";
                                                        section4_list_results.add(bc_pay_in_slip_number);
                                                    } else {
                                                        String bc_pay_in_slip_number = ",PAY_IN_SLIP_NUMBER" + "," + TO_pay_in_slip_number + "," + agg_pay_in_slip_number + ",Fail";
                                                        section4_list_results.add(bc_pay_in_slip_number);
                                                    }
                                                }

                                                //------------ cheque_number validation ----------------------
                                                if (agg_cheque_number == null || TO_cheque_number == null) {
                                                    if (agg_cheque_number == TO_cheque_number) {
                                                        String bc_cheque_number = ",CHEQUE_NUMBER" + "," + TO_cheque_number + "," + agg_cheque_number + ",Pass";
                                                        section4_list_results.add(bc_cheque_number);
                                                    } else {
                                                        String bc_cheque_number = ",CHEQUE_NUMBER" + "," + TO_cheque_number + "," + agg_cheque_number + ",Fail";
                                                        section4_list_results.add(bc_cheque_number);
                                                    }
                                                } else {
                                                    if (agg_cheque_number.equals(TO_cheque_number)) {
                                                        String bc_cheque_number = ",CHEQUE_NUMBER" + "," + TO_cheque_number + "," + agg_cheque_number + ",Pass";
                                                        section4_list_results.add(bc_cheque_number);
                                                    } else {
                                                        String bc_cheque_number = ",CHEQUE_NUMBER" + "," + TO_cheque_number + "," + agg_cheque_number + ",Fail";
                                                        section4_list_results.add(bc_cheque_number);
                                                    }
                                                }

                                                //------------ interest_amount validation ----------------------
                                                if (agg_interest_amount.equals(TO_interest_amount)) {
                                                    String bc_interest_amount = ",INTEREST_AMOUNT" + "," + TO_interest_amount + "," + agg_interest_amount + ",Pass";
                                                    section4_list_results.add(bc_interest_amount);
                                                } else {
                                                    String bc_interest_amount = ",INTEREST_AMOUNT" + "," + TO_interest_amount + "," + agg_interest_amount + ",Fail";
                                                    section4_list_results.add(bc_interest_amount);
                                                }

                                                //------------ interest_currency_code validation ----------------------
                                                if (agg_interest_currency_code.equals(TO_interest_currency_code)) {
                                                    String bc_interest_currency_code = ",INTEREST_CURRENCY_CODE" + "," + TO_interest_currency_code + "," + agg_interest_currency_code + ",Pass";
                                                    section4_list_results.add(bc_interest_currency_code);
                                                } else {
                                                    String bc_interest_currency_code = ",INTEREST_CURRENCY_CODE" + "," + TO_interest_currency_code + "," + agg_interest_currency_code + ",Fail";
                                                    section4_list_results.add(bc_interest_currency_code);
                                                }

                                                //------------ base_interest_amount validation ----------------------
                                                if (agg_base_interest_amount.equals(TO_base_interest_amount)) {
                                                    String bc_base_interest_amount = ",BASE_INTEREST_AMOUNT" + "," + TO_base_interest_amount + "," + agg_base_interest_amount + ",Pass";
                                                    section4_list_results.add(bc_base_interest_amount);
                                                } else {
                                                    String bc_base_interest_amount = ",BASE_INTEREST_AMOUNT" + "," + TO_base_interest_amount + "," + agg_base_interest_amount + ",Fail";
                                                    section4_list_results.add(bc_base_interest_amount);
                                                }

                                                //------------ tax_deductible validation ----------------------
                                                if (agg_tax_deductible == null || TO_tax_deductible == null) {
                                                    if (agg_tax_deductible == TO_tax_deductible) {
                                                        String bc_tax_deductible = ",TAX_DEDUCTIBLE" + "," + TO_tax_deductible + "," + agg_tax_deductible + ",Pass";
                                                        section4_list_results.add(bc_tax_deductible);
                                                    } else {
                                                        String bc_tax_deductible = ",TAX_DEDUCTIBLE" + "," + TO_tax_deductible + "," + agg_tax_deductible + ",Fail";
                                                        section4_list_results.add(bc_tax_deductible);
                                                    }
                                                } else {
                                                    if (agg_tax_deductible.equals(TO_tax_deductible)) {
                                                        String bc_tax_deductible = ",TAX_DEDUCTIBLE" + "," + TO_tax_deductible + "," + agg_tax_deductible + ",Pass";
                                                        section4_list_results.add(bc_tax_deductible);
                                                    } else {
                                                        String bc_tax_deductible = ",TAX_DEDUCTIBLE" + "," + TO_tax_deductible + "," + agg_tax_deductible + ",Fail";
                                                        section4_list_results.add(bc_tax_deductible);
                                                    }
                                                }*/
                                                                //------------ reversal_indicator validation ----------------------
                                                                if (agg_reversal_indicator.equals(TO_reversal_indicator)) {
                                                                    String bc_reversal_indicator = ",REVERSAL_INDICATOR" + "," + TO_reversal_indicator + "," + agg_reversal_indicator + ",Pass";
                                                                    section4_list_results.add(bc_reversal_indicator);
                                                                } else {
                                                                    String bc_reversal_indicator = ",REVERSAL_INDICATOR" + "," + TO_reversal_indicator + "," + agg_reversal_indicator + ",Fail";
                                                                    section4_list_results.add(bc_reversal_indicator);
                                                                }

                                                                //------------payment_transaction_type_id validation ----------------------
                                                /*if (agg_payment_transaction_type_id.equals(TO_payment_transaction_type_id)) {
                                                    String bc_payment_transaction_type_id = ",PAYMENT_TRANSACTION_TYPE_ID" + "," + TO_payment_transaction_type_id + "," + agg_payment_transaction_type_id + ",Pass";
                                                    section4_list_results.add(bc_payment_transaction_type_id);
                                                } else {
                                                    String bc_payment_transaction_type_id = ",PAYMENT_TRANSACTION_TYPE_ID" + "," + TO_payment_transaction_type_id + "," + agg_payment_transaction_type_id + ",Fail";
                                                    section4_list_results.add(bc_payment_transaction_type_id);
                                                }*/

                                                                //------------currency_amount validation ----------------------
                                                                if (agg_currency_amount.equals(TO_currency_amount)) {
                                                                    String bc_currency_amount = ",CURRENCY_AMOUNT" + "," + TO_currency_amount + "," + agg_currency_amount + ",Pass";
                                                                    section4_list_results.add(bc_currency_amount);
                                                                } else {
                                                                    String bc_currency_amount = ",CURRENCY_AMOUNT" + "," + TO_currency_amount + "," + agg_currency_amount + ",Fail";
                                                                    section4_list_results.add(bc_currency_amount);
                                                                }

                                                                //------------currency_code validation ----------------------
                                                                if (agg_currency_code.equals(TO_currency_code)) {
                                                                    String bc_currency_code = ",CURRENCY_CODE" + "," + TO_currency_code + "," + agg_currency_code + ",Pass";
                                                                    section4_list_results.add(bc_currency_code);
                                                                } else {
                                                                    String bc_currency_code = ",CURRENCY_CODE" + "," + TO_currency_code + "," + agg_currency_code + ",Fail";
                                                                    section4_list_results.add(bc_currency_code);
                                                                }

                                                                //------------exchange_rate validation ----------------------
                                                                if (agg_exchange_rate.equals(TO_exchange_rate)) {
                                                                    String bc_exchange_rate = ",EXCHANGE_RATE" + "," + TO_exchange_rate + "," + agg_exchange_rate + ",Pass";
                                                                    section4_list_results.add(bc_exchange_rate);
                                                                } else {
                                                                    String bc_exchange_rate = ",EXCHANGE_RATE" + "," + TO_exchange_rate + "," + agg_exchange_rate + ",Fail";
                                                                    section4_list_results.add(bc_exchange_rate);
                                                                }

                                                                //------------exchange_rate_type validation ----------------------
                                                                if (agg_exchange_rate_type.equals(TO_exchange_rate_type)) {
                                                                    String bc_exchange_rate_type = ",EXCHANGE_RATE_TYPE" + "," + TO_exchange_rate_type + "," + agg_exchange_rate_type + ",Pass";
                                                                    section4_list_results.add(bc_exchange_rate_type);
                                                                } else {
                                                                    String bc_exchange_rate_type = ",EXCHANGE_RATE_TYPE" + "," + TO_exchange_rate_type + "," + agg_exchange_rate_type + ",Fail";
                                                                    section4_list_results.add(bc_exchange_rate_type);
                                                                }

                                                                //------------base_currency_amount validation ----------------------
                                                                if (agg_base_currency_amount.equals(TO_base_currency_amount)) {
                                                                    String bc_base_currency_amount = ",BASE_CURRENCY_AMOUNT" + "," + TO_base_currency_amount + "," + agg_base_currency_amount + ",Pass";
                                                                    section4_list_results.add(bc_base_currency_amount);
                                                                } else {
                                                                    String bc_base_currency_amount = ",BASE_CURRENCY_AMOUNT" + "," + TO_base_currency_amount + "," + agg_base_currency_amount + ",Fail";
                                                                    section4_list_results.add(bc_base_currency_amount);
                                                                }

                                                                //------------credit_ind validation ----------------------
                                                                if (agg_credit_ind.equals(TO_credit_ind)) {
                                                                    String bc_credit_ind = ",CREDIT_IND" + "," + TO_credit_ind + "," + agg_credit_ind + ",Pass";
                                                                    section4_list_results.add(bc_credit_ind);
                                                                } else {
                                                                    String bc_credit_ind = ",CREDIT_IND" + "," + TO_credit_ind + "," + agg_credit_ind + ",Fail";
                                                                    section4_list_results.add(bc_credit_ind);
                                                                }
                                                                //------------event_code validation ----------------------
                                                                if (agg_event_code.equals(TO_event_code)) {
                                                                    String bc_event_code = ",EVENT_CODE" + "," + TO_event_code + "," + agg_event_code + ",Pass";
                                                                    section4_list_results.add(bc_event_code);
                                                                } else {
                                                                    String bc_event_code = ",EVENT_CODE" + "," + TO_event_code + "," + agg_event_code + ",Fail";
                                                                    section4_list_results.add(bc_event_code);
                                                                }
                                                                //------------entity_type_code validation ----------------------
                                                                if (agg_entity_type_code.equals(TO_entity_type_code)) {
                                                                    String bc_entity_type_code = ",ENTITY_TYPE_CODE" + "," + TO_entity_type_code + "," + agg_entity_type_code + ",Pass";
                                                                    section4_list_results.add(bc_entity_type_code);
                                                                } else {
                                                                    String bc_entity_type_code = ",ENTITY_TYPE_CODE" + "," + TO_entity_type_code + "," + agg_entity_type_code + ",Fail";
                                                                    section4_list_results.add(bc_entity_type_code);
                                                                }
                                                                //------------batch_fkey validation ----------------------
                                                                if (agg_batch_fkey.equals(TO_batch_fkey)) {
                                                                    String bc_batch_fkey = ",BATCH_FKEY" + "," + TO_batch_fkey + "," + agg_batch_fkey + ",Pass";
                                                                    section4_list_results.add(bc_batch_fkey);
                                                                } else {
                                                                    String bc_batch_fkey = ",BATCH_FKEY" + "," + TO_batch_fkey + "," + agg_batch_fkey + ",Fail";
                                                                    section4_list_results.add(bc_batch_fkey);
                                                                }
                                                                //------------file_name validation ----------------------
                                                                if (agg_file_name.equals(TO_file_name)) {
                                                                    String bc_file_name = ",FILE_NAME" + "," + TO_file_name + "," + agg_file_name + ",Pass";
                                                                    section4_list_results.add(bc_file_name);
                                                                } else {
                                                                    String bc_file_name = ",FILE_NAME" + "," + TO_file_name + "," + agg_file_name + ",Fail";
                                                                    section4_list_results.add(bc_file_name);
                                                                }
                                                                //------------event_id validation ----------------------
                                                                if (TO_event_id == null) {
                                                                    String bc_event_id = ",EVENT_ID" + "," + TO_event_id + "," + "null" + ",Pass";
                                                                    section4_list_results.add(bc_event_id);
                                                                } else {
                                                                    String bc_event_id = ",EVENT_ID" + "," + TO_event_id + "," + "null" + ",Fail";
                                                                    section4_list_results.add(bc_event_id);
                                                                }

                                                                //------------event_date validation ----------------------
                                                                if (TO_event_date == null) {
                                                                    String bc_event_date = ",EVENT_DATE" + "," + TO_event_date + "," + "null" + ",Pass";
                                                                    section4_list_results.add(bc_event_date);
                                                                } else {
                                                                    String bc_event_date = ",EVENT_DATE" + "," + TO_event_date + "," + "null" + ",Fail";
                                                                    section4_list_results.add(bc_event_date);
                                                                }

                                                                //------------bcp_req_id validation ----------------------
                                                                if (TO_bcp_req_id == null) {
                                                                    String bc_bcp_req_id = ",BCP_REQ_ID" + "," + TO_bcp_req_id + "," + "null" + ",Pass";
                                                                    section4_list_results.add(bc_bcp_req_id);
                                                                } else {
                                                                    String bc_bcp_req_id = ",BCP_REQ_ID" + "," + TO_bcp_req_id + "," + "null" + ",Fail";
                                                                    section4_list_results.add(bc_bcp_req_id);
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }

                                            List<String> list = new ArrayList<String>();
                                            list.addAll(section1_list_results);
                                            list.addAll(section2_list_results);
                                            list.addAll(mandatory_list_results);
                                            list.addAll(section3_list_results);
                                            list.addAll(section4_list_results);

                                            //-------------- Report generation -------------
                                            report_generation.report_Test1(section1_list_results, "Section1", file_list, "TravelGLBilling SOURCE TO CONS VALIDATION", "TravelGLBilling", "TravelGLBilling VALIDATION");
                                            report_generation.report_Test1(section2_list_results, "Section2", file_list, "TravelGLBilling CONS TO STAGING VALIDATION", "TravelGLBilling", "TravelGLBilling VALIDATION");
                                            report_generation.report_Test1(section3_list_results, "Section3", file_list, "TravelGLBilling Staging to Staging Aggregate Validation", "TravelGLBilling", "SSPXGLBilling VALIDATION");
                                            report_generation.report_Test1(section4_list_results, "Section4", file_list, "TravelGLBilling Staging to TO Validation", "TravelGLBilling", "TravelGLBilling VALIDATION");
                                            report_generation.report_Test1(mandatory_list_results, "Mandatory", file_list, "TravelGLBilling Mandatory Field Check", "TravelGLBilling", "TravelGLBilling Mandatory Field VALIDATION");
                                        }
                                    }
                                }


                            }
                        }
                    }
                }
            }
        }
    }

}
